package com.nordbuds.studio

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Global feedback switches, set from Settings. Taps in the UI call [tick]; Settings > Test vibration calls [test]. */
object Fx {
    @Volatile var sound = true
    @Volatile var haptics = true
    @Volatile private var vib: Vibrator? = null
    @Volatile private var lastBuzz = 0L

    private fun vibrator(ctx: Context): Vibrator? {
        vib?.let { return it }
        val app = ctx.applicationContext
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31)
            (app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") (app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
        vib = v
        return v
    }

    /**
     * Picks the strongest effect the motor really supports. The old code fell back to a 16 ms pulse whenever the
     * phone did not report the predefined TICK/CLICK effect as supported (common on OnePlus / OPPO builds that answer
     * "unknown"), and a pulse that short is below what most motors can spin up for, so nothing was felt.
     */
    private fun effectFor(v: Vibrator, strong: Boolean): Pair<VibrationEffect, String> {
        if (Build.VERSION.SDK_INT >= 30) {
            val prim = if (strong) VibrationEffect.Composition.PRIMITIVE_CLICK else VibrationEffect.Composition.PRIMITIVE_TICK
            if (v.areAllPrimitivesSupported(prim))
                return VibrationEffect.startComposition().addPrimitive(prim, if (strong) 1f else 0.85f).compose() to "haptic primitive"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val id = if (strong) VibrationEffect.EFFECT_CLICK else VibrationEffect.EFFECT_TICK
            val ok = Build.VERSION.SDK_INT < 30 || v.areAllEffectsSupported(id) == Vibrator.VIBRATION_EFFECT_SUPPORT_YES
            if (ok) return VibrationEffect.createPredefined(id) to "system effect"
        }
        val ms = if (strong) 40L else 28L
        val amp = if (v.hasAmplitudeControl()) (if (strong) 255 else 210) else VibrationEffect.DEFAULT_AMPLITUDE
        return VibrationEffect.createOneShot(ms, amp) to "timed pulse"
    }

    /** Returns how the buzz was produced, or null when this phone cannot vibrate. */
    private fun buzz(ctx: Context, strong: Boolean, throttle: Boolean): String? {
        val now = System.currentTimeMillis()
        if (throttle && now - lastBuzz < 30) return "throttled"
        lastBuzz = now
        return try {
            val v = vibrator(ctx) ?: return null
            if (!v.hasVibrator()) return null
            val (effect, how) = effectFor(v, strong)
            v.vibrate(effect)
            how
        } catch (_: Exception) { null }
    }

    fun tick(ctx: Context, strong: Boolean = false) { if (haptics) buzz(ctx, strong, throttle = true) }

    /** Plays one buzz whatever the switch says and describes the result (shown by Settings > Test vibration). */
    fun test(ctx: Context): String {
        val how = buzz(ctx, strong = true, throttle = false) ?: return "This phone did not vibrate. Check Android's Sound & vibration settings (touch feedback / vibration intensity)."
        return "Vibrated using a $how." + if (haptics) "" else " Haptics is switched off in Budsy."
    }
}
