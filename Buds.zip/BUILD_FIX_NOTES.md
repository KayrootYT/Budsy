# Build log fixes

The supplied GitHub Actions log failed during `:app:compileDebugKotlin`, not during Android SDK setup.

Fixes applied:
- Added the missing `kotlinx.coroutines.launch` import used by the directional drag-return animation.
- Added missing Compose animation-core imports used by the animated pinned header.
- Replaced invalid four-argument `Triple(...)` theme entries with a typed `ThemeChoiceItem` model.
- Added missing Compose `background` and `RoundedCornerShape` imports in the theme settings UI.
- Marked the diagnostics UI function `@Composable`.

Validation:
- ZIP structure/integrity checked after packaging.
- This container does not have Gradle or an Android SDK configured, so a new Android build has not been run here. Run the GitHub Actions build to confirm there are no further compiler errors.

## Hero + connection update
- Hero: case is larger (330dp stage). Open state uses the original open-case art (both buds inside); when a bud is removed it switches to empty case + per-cradle bud sprites and the bud lifts out and floats above the case, the other stays. Both out: case fades away, buds settle in the centre. Reverse when put back.
- Connection: the app is only "Connected" after the earbuds answer a protocol frame (no more fake connections). Battery is re-polled until all slots are filled, wear state is polled every 2s, a 30s watchdog drops dead links so auto-connect can retry.
- Auto-connect: new `BtConnectReceiver` connects as soon as the earbuds connect to the phone, even if the app is closed. The in-app retry loop is faster while the earbuds are connected as audio.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build to confirm.

## Hero: cradle blur fix + realistic bud animation
- `hero_case_empty_{black,white}.png`: smudged (blurred) area where the buds used to sit was repainted with clean, crisp cradle wells.
- `HeroArt.kt`: spring-based lift (soft settle), bud rises straight up then drifts in an arc, cradle sprite and real bud swap at the same instant (no ghosting), soft contact shadow under the lifted bud.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build to confirm.
- hero_case_empty_*: replaced with real empty-case photos (no painted/fake cradles). Closed/open-with-buds/sprites still belong to the old case model.

## Hero / UI overhaul
- Case: new real empty-case photos (white 58422 / black 58421); buds: new real bud photos (4). Hero now draws the buds standing in the cradles, clipped at the case lip; no sprite crops from the old case. Old open-case/sprite/pair PNGs removed. Closed-case PNGs are still the old model (need a closed photo of the new case).
- Lag: palette/typography/colour scheme cached (they were rebuilt on every recomposition, invalidating the whole UI); glow border caches its brush; only the selected theme card animates.
- Tiles/rows: one size system (TILE_H=96dp, ROW_H=64dp).
- Light/Dark: onAccent (dark text on the lime accent), deeper accents in Light, Material onPrimary/inverseSurface set.
- Launcher icon: new Nord-Buds style adaptive icon (+ monochrome for themed icons).
- Earbud controls: real bud photo (white on dark, black on light) with a pulsing touch-pad marker.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build.

## Theme-switch lag, Nothing font, both-in case art, controls bud size
- Lag: tap tones no longer build a `ToneGenerator` on the UI thread per tap (one reusable generator on a background thread); `enableEdgeToEdge` runs only when light/dark flips (was a `SideEffect` on every Root recomposition); idle `PulseDot`s no longer run an infinite animation; `AuroraBackground` caches its gradient brushes; removed unused infinite transitions in Overview.
- Nothing Dot Matrix: `Txt` now applies the theme font family and a size scale (`TypeSpec` in Theme.kt: mono 0.86x, floor 10sp, tighter tracking) so labels no longer overflow/ellipsise.
- Hero: "both buds inside" uses the supplied PNGs again (`hero_case_both_{black,white}.png`), fading in after a returning bud has dropped in; one-bud-out keeps the floating-bud animation.
- Controls: earbud picture reduced 190dp -> 124dp with a soft halo and L/R crossfade.
- Not compiled here (no Android SDK): run the GitHub Actions build.

## Hero v3: real lid flip + one-photo-per-state
- Assets regenerated from the supplied photos (960x960): closed / empty / both-in for black; white colourway built by LUT-matching black -> white; new `hero_case_lout_*` and `hero_case_rout_*` (real photo with one bud removed, feathered patch from the empty case).
- `HeroArt.kt` rewritten: Animatable-driven lid flip (dome pivots on back hinge, spring overshoot), bud pop-out on a spring with velocity-based tilt and hover sway, case sinks to make room, contact shadows, both-out fades the case and shows a OnePlus wordmark. Bud returns first, photo swaps after landing, lid closes last.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build.

## Hero v4: 3D cutout-to-sprite morph + tilt parallax
- New `hero_cut_{l,r}_{black,white}.png`: the real bud pixels cut out of the case photo (hand-fit outline), so lift-off starts pixel-identical (no pop). `hero_case_lout/rout_*` regenerated with the same outline so the cradle is clean.
- `FlyingBud`: cutout turns in perspective (rotationX/Y, cameraDistance) and cross-fades into the standing studio sprite, which arrives turning from the opposite side; floating bud keeps a slow 3D wobble.
- `rememberTilt()`: accelerometer parallax (case + buds at different depths). Uses TYPE_ACCELEROMETER only, no permission needed.
- Not compiled here: run the GitHub Actions build.

## Gesture bud + haptics fix
- Earbud Controls picker now uses the 4 supplied front-view PNGs (`gesture_bud_{l,r}_{white,black}.png`, cropped); red touch-pad overlay re-aligned to the pill. Hero/other screens keep the old bud art.
- Haptics: replaced Compose `performHapticFeedback(TextHandleMove)` (silent on many OEM builds / when system touch feedback is off) with `Fx.tick()` calling the Vibrator service directly (predefined TICK/CLICK when supported, else a short one-shot). Added `VIBRATE` permission. Still respects Settings -> Haptics.
- Not compiled here: run the GitHub Actions build.

## Gesture protocol audit
- Fixed: gesture set to None was reported "not confirmed" because disabled entries are absent from the table; a missing entry now counts as None.
- Fixed: verifying one gesture cleared newer pending writes (fast consecutive changes lost their pending state); only verified keys are dropped now.
- Fixed: no reply to a gesture write left the optimistic value on screen forever; 5 s timeout re-reads the earbud's real table.
- Fixed: a rejected Hold write (0x0404) was shown as a Noise Control failure; failures are now attributed to the pending setting.
- Added: save/confirm/fail line under the gesture tiles, `Protocol.buildGestureSet()` + unit test for the write payload.
- Still unverified without a device capture: Hold payload [2,1,mask], find-device stop, and whether the 0x0108 query [2,3,1] returns every gesture id.

## Protocol / gesture / haptics audit (2026-10-28)
Checked against published OPOv1 captures; compiled and unit-tested the protocol layer here (kotlinc, 32 tests), type-checked Buds/Link/Fx against stubs. Full Gradle/Android build and real-earbud behaviour are NOT verified here.
- Gesture table: on-call (button 6) entries overwrote the main tap / long-hold mapping, so gestures showed as None and failed verification. Only button 1 counts now; writes mirror every main slot the table lists.
- Buds' `0x0500` time request was never answered (they stop replying and reset the link). Now answered, plus the other buds requests; informational pushes are not answered.
- Push `03` sub-types: hold-cycle / Smart-level pushes were read as Noise Control modes. Fixed; removed the ANC code-swap hack.
- Handshake `0x0100`, product `0x0103`, event list `0x0200` and `0x0205` subscribe added (only offered events); game-mode, peers and EQ-changed pushes are applied.
- Frame length is LEB128 (frames of 128+ bytes, e.g. custom EQ lists, were mis-parsed); our seq stays 01..FE (FF is the push marker).
- Wear detection wrote feature 0x0B (Golden Sound). Now feature 0x04.
- Custom EQ wrote 0x0422 (Spatial type). Now 0x0418 with create / save+select, id taken from the 0x0122 list.
- Find my earbuds: payload per capture (`01` / `01 side` / `00`), ack shown, one retry with the old list format.
- RFCOMM: the OPO service UUID 0000079A-... is tried first; vendor UUIDs starting 0000110x-D102-... are no longer filtered out as "audio".
- Battery: case level 0 is unknown, not 0 %.
- Haptics: when the phone did not report TICK/CLICK as supported, a 16 ms pulse was used (not felt). Now haptic primitive -> system effect -> 28/40 ms pulse; bass slider ticks; new Settings > Test vibration row reports what was used. (`Fx` moved to Fx.kt.)
