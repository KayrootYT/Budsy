# Budsy delivery status

This ZIP contains the native Android Budsy project and current source-level Bluetooth/protocol work.

Implemented:
- BLE and Classic Bluetooth discovery as separate flows.
- Android pairing request/wait before RFCOMM connection.
- HeyMelody vendor RFCOMM UUID and SPP fallback policy.
- GATT diagnostic service/characteristic discovery and notification subscription; no speculative GATT command writes.
- Read-only multi-device peer state (`0x0112/0x8112`).
- Removed arbitrary unknown feature-flag selection as a Dual Connection toggle.

Verified in this environment:
- Platform-independent protocol Kotlin compile.
- Protocol and peer parser smoke tests.
- ZIP integrity.

Not verified:
- Full Android Gradle build/JUnit; Android SDK and Gradle are absent.
- Real GATT/RFCOMM pairing on hardware.
- Nord Buds 3 and Nord Buds 3 Pro model compatibility.
- Dual-device enable/disable/audio-switch command.

Use `.github/workflows/build-apk.yml` in GitHub Actions to run `clean testDebugUnitTest assembleDebug` with Android SDK and Gradle 8.9. Hardware validation steps are in `BLUETOOTH_RELEASE_VALIDATION.md`.
