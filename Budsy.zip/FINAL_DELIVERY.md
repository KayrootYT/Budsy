# Budsy Protocol Laboratory — Final Combined Delivery (Phases 1–12)

## What is included

This archive consolidates the existing native Android Kotlin/Jetpack Compose Budsy project and Protocol Laboratory work through Phase 12.

| Phase | Capability |
|---|---|
| 1 | Opt-in capture of Budsy's own RFCOMM framed traffic |
| 2 | Conservative payload decoding, request/reply correlation, local history and exports |
| 3 | Read-only Android HCI btsnoop import and baseline comparison |
| 4 | HCI ACL, L2CAP and Classic RFCOMM stream reassembly |
| 5 | BLE ATT/GATT discovery and event inspection from imported HCI captures |
| 6 | Differential command/feature candidate analysis |
| 7 | Persistent command database with Unassigned / Nord Buds 3 / Nord Buds 3 Pro profiles |
| 8 | In-app live monitor for Budsy's own control connection |
| 9 | Differential candidate import with raw evidence samples |
| 10 | Model-specific evidence workflow and OBSERVED/VERIFIED state |
| 11 | Conservative command safety gate; manual review only |
| 12 | Consolidated release-readiness report, export and device-capture checklist |

## Important hardware/evidence boundary

No real Nord Buds 3 or Nord Buds 3 Pro capture was supplied with this final packaging step. Existing known observations remain in `Unassigned` and `OBSERVED`; they are not promoted or assigned to either model. User-entered positive-capture references and negative-control status are evidence notes, not automatic proof that the original captures were independently validated.

The live monitor observes Budsy's own RFCOMM/control traffic while capture is enabled. It is not a system-wide Bluetooth sniffer and cannot directly intercept HeyMelody's private connection. HCI/btsnoop imports are offline, read-only analysis. BLE link encryption and Android protected logging remain platform limitations.

No arbitrary command replay or guessed GATT writes are enabled. The evidence gate can only allow manual engineering review; it never transmits a packet. HeyMelody custom EQ `0x0418` remains a source-level payload-layout candidate; service UUID, write characteristic, wrapper/checksum, security requirements and response behavior remain unconfirmed.

## Validation performed for this archive

- Input Phase 8 archive extracted and its ZIP CRC integrity check passed.
- Source files and phase integration points reviewed.
- Final archive CRC integrity checked after packaging.
- Targeted source checks confirm model profiles, OBSERVED/VERIFIED workflow, differential candidate import, release gate and report export are present.

## Not verified

- Android Gradle compilation, `testDebugUnitTest` or `assembleDebug`: this execution environment does not have a Gradle wrapper, Gradle executable, Android SDK or Kotlin compiler.
- UI rendering on an emulator or physical phone.
- Actual behavior on Nord Buds 3 / Nord Buds 3 Pro hardware.
- ANC, Transparency, Game Mode, Find My Buds, case battery, touch gestures, firmware and custom EQ compatibility.
- Upgrade installation over an existing signed release.

## Build on GitHub Actions

The repository includes `.github/workflows/build-apk.yml`. Push the extracted project files to the repository's `main` branch, or run the workflow manually from GitHub Actions. The workflow sets up Java 17, Android SDK and Gradle 8.9, then runs:

```bash
gradle --no-daemon --stacktrace clean testDebugUnitTest assembleDebug
```

It uploads the debug APK as the `Budsy-apk` artifact. A successful workflow is still not proof of physical earbud feature support.

## Final status

**All 12 planned software phases are consolidated in this source package. Release status: engineering preview, not hardware-certified.** Real target-device captures and a successful Android build/test/device-upgrade cycle remain required before calling this a production-ready APK.
