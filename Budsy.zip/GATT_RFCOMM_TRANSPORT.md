# Budsy transport priority

## Priority
1. BLE GATT (HeyMelody proprietary 0x079A service) is attempted first.
2. RFCOMM is attempted if GATT setup fails, no protocol frame is received during the initial read window, or GATT fails after a connection is established.

## GATT UUIDs extracted from the supplied HeyMelody decompile
- Service: `0000079A-D102-11E1-9B23-00025B00A5A5`
- Write: `0100079A-D102-11E1-9B23-00025B00A5A5`
- Notify: `0200079A-D102-11E1-9B23-00025B00A5A5`
- CCCD: `00002902-0000-1000-8000-00805F9B34FB`

The supplied HeyMelody GATT write class sets `WRITE_TYPE_NO_RESPONSE`; its connection class serializes GATT commands and receives notification frames. Budsy sends the same `Protocol.buildFrame(...)` packets over either transport.

## Safety limits
The decompiled code does not establish a custom ATT fragmentation scheme for this target. Budsy therefore sends complete frames only when they fit the negotiated ATT payload (`MTU - 3`). Oversized frames fail the GATT path and trigger RFCOMM fallback rather than being split using an invented format.

## Verification status
- Source integration: implemented.
- Android Gradle build: not run in this environment (Gradle executable/wrapper unavailable).
- Nord Buds 3 hardware GATT command test: pending.
- RFCOMM fallback: integrated in connection setup and runtime GATT loss path; hardware test pending.
