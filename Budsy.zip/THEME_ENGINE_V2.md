# Budsy Theme Engine V2

This source update adds a schema-2 declarative UI contract for imported themes.

## Included
- Per-theme page spacing, section rhythm, panel/tile/row geometry and button/dialog styling.
- Theme-selected header and bottom-navigation variants.
- Per-screen layout profiles for Overview, Sound, Controls and Settings.
- Theme-selected interaction style, motion timing and background effects.
- Custom tab, battery and header icons plus custom hero artwork.
- Strict schema-2 import checks; schema-1 packages remain backward-compatible.

## Included theme packages
`theme_packs/` contains six schema-2 `.budsytheme` files: Nothing Matrix, OnePlus Aurora, Crystal Light, Titanium Luxury, Sony Studio and Spatial 3D.

## Safety and compatibility
Theme packages are data-only. No code, scripts, binaries or protocol implementation is executed from imported packages. Existing Bluetooth, BLE/GATT, RFCOMM, ANC, EQ and earbuds protocol sources were not changed.

## Build status
This archive was source-edited and ZIP-validated. It has not been Android-built in this environment because the source archive has no Gradle wrapper and the environment has no Android SDK/Gradle installation. Run a GitHub Actions Android build before installing the APK.


# V3 visual redesign layer

V3 moves beyond palette tokens. It replaces the Compose visual primitives used throughout the app with profile-specific tile composition, icon containers, active/press motion, card surfaces, switch geometry, button geometry, battery presentation, screen intro compositions, audio spectrum animation, and theme-selected Controls list/grid layouts. The Overview hero uses five per-theme device/case state illustrations.

The six packages in `theme_packs/` are version 3.0 schema-2 packages. They include complete Light/Dark/AMOLED palettes, custom typeface, wallpaper, six navigation/system icons, and five hero state illustrations.
