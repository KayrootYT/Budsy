# Budsy mobile redesign — Lovable design translation

The Lovable project is a web-only interaction prototype. This Android project remains the source of truth for device connectivity and protocol behavior. The redesign is translated into native Jetpack Compose components; no web runtime or browser screen is embedded.

## Design tokens translated
- Screen gutters: 20dp; content top/bottom breathing room: 8dp / 36dp.
- Section spacing: 14dp; section heading top rhythm: 18dp.
- Surfaces: 24–26dp rounded cards with 20dp internal padding.
- Feature tiles: minimum 112dp height, 38dp icon wells, 13sp title and 11sp supporting label.
- Navigation: floating 68dp capsule, 16dp side inset, rounded active indicator and spring transition.
- Existing theme palette continues to drive Light, Dark and AMOLED appearance.

## Screen mapping
- Overview: native live device hero and status, real connection actions, battery data, ANC controls, Find Buds and device details.
- Sound Studio: existing protocol-backed presets, custom EQ, BassWave and supported enhancements.
- Controls: existing earbud gesture assignments and call / wear controls.
- Settings: existing device, firmware, permissions, appearance, theme manager and diagnostics.

## Invariants
- Bluetooth discovery, GATT, RFCOMM, ANC, EQ, battery, gesture and protocol handlers are not replaced by prototype/demo state.
- Prototype-only sample values and demo controls are not copied into the native app.
- Stock Budsy theme and Light/Dark/AMOLED modes remain available.
