package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/** One permanent Stock Budsy identity; appearance switches Light, Dark and AMOLED. */
object ThemeMode {
    /** The only built-in theme. Imported themes will be managed separately. */
    const val AURORA = 0 // legacy IDs retained only for source compatibility
    const val CRYSTAL = 1
    const val NOTHING = 2
    const val TITANIUM = 3
    const val STOCK = 4
    const val ONEPLUS = 5
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

private fun stockPal(appearance: Int): Pal = when (appearance) {
    AppearanceMode.LIGHT, AppearanceMode.SYSTEM -> Pal(false, false,
        Color(0xFFF4F7FB), Color(0xFFFFFFFF), Color(0xFFE8EEF5), Color(0xFF111827),
        Color(0xFF667085), Color(0xFFDCE4EE), Color(0xFFCAD5E2), Color(0xFF087FB8),
        Color(0xFF20B879), Color(0xFFE5A23B), Color(0xFFE05252), Color(0xF9FFFFFF), Color(0xFF8055C8))
    AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF090D16), Color(0xFF151B28),
        Color(0xFFF2F7FC), Color(0xFF9BAFC2), Color(0xFF202B3A), Color(0xFF344457), Color(0xFF00DCC0),
        Color(0xFF2ED573), Color(0xFFFFB84D), Color(0xFFFF647C), Color(0xFF05080E), Color(0xFF9D4EDD))
    else -> Pal(true, false, Color(0xFF04050D), Color(0xFF0B0E1C), Color(0xFF151B2D),
        Color(0xFFEAF8FF), Color(0xFFB2C5D6), Color(0xFF243248), Color(0xFF34445C), Color(0xFF00F5D4),
        Color(0xFF2ED573), Color(0xFFFFA502), Color(0xFFFF4D6D), Color(0xF90B0E1C), Color(0xFF9D4EDD))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null): Pal {
    // Budsy now has one consistent Kayroot-inspired visual identity. Appearance only
    // changes the luminance profile; no alternate theme packs or imported palettes apply.
    return stockPal(appearance)
}

@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) = TypeSpec(FontFamily.SansSerif, 1f, 0f)

/** Theme-owned presentation tokens for the five built-in identities. */
private fun builtInThemeSpec(mode: Int): ThemeSpec = when (mode) {
    ThemeMode.AURORA -> ThemeSpec(name = "Aurora Glass", source = "builtin-aurora",
        shapes = ShapeSpec(panel = 28f, card = 24f, tile = 22f, button = 18f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1.1f, borderAlpha = 0.72f, fillAlpha = 0.92f, glow = true),
        motion = MotionSpec(speed = 1.08f, enter = true, bounce = true, glowPulse = true, tabTransition = "slide"),
        background = BackgroundSpec(blobs = true, imageAlpha = 0.88f))
    ThemeMode.CRYSTAL -> ThemeSpec(name = "Crystal Light", source = "builtin-crystal",
        shapes = ShapeSpec(panel = 30f, card = 26f, tile = 24f, button = 20f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1.2f, borderAlpha = 0.86f, fillAlpha = 0.96f, glow = false),
        motion = MotionSpec(speed = 0.92f, enter = true, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, imageAlpha = 0.94f))
    ThemeMode.NOTHING -> ThemeSpec(name = "Nothing Matrix", source = "builtin-nothing",
        shapes = ShapeSpec(panel = 14f, card = 12f, tile = 10f, button = 10f, pill = 8f),
        card = CardSpec(style = CardStyle.OUTLINE, borderWidth = 1f, borderAlpha = 0.62f, fillAlpha = 1f, glow = false),
        font = FontSpec(family = "mono", scale = 0.90f, tracking = -0.12f),
        motion = MotionSpec(speed = 0.82f, enter = false, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, dotMatrix = true, imageAlpha = 0.9f))
    ThemeMode.TITANIUM -> ThemeSpec(name = "Titanium Luxury", source = "builtin-titanium",
        shapes = ShapeSpec(panel = 24f, card = 20f, tile = 18f, button = 15f, pill = 50f),
        card = CardSpec(style = CardStyle.GRADIENT, borderWidth = 1f, borderAlpha = 0.68f, fillAlpha = 0.96f, glow = false,
            gradientFrom = 0xFF3A3B3F, gradientTo = 0xFF202226),
        motion = MotionSpec(speed = 0.88f, enter = true, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, imageAlpha = 0.9f))
    ThemeMode.ONEPLUS -> ThemeSpec(name = "OnePlus Aurora", source = "builtin-oneplus",
        shapes = ShapeSpec(panel = 22f, card = 18f, tile = 18f, button = 14f, pill = 50f),
        card = CardSpec(style = CardStyle.GRADIENT, borderWidth = 0.8f, borderAlpha = 0.48f, fillAlpha = 0.98f, glow = true,
            gradientFrom = 0xFF14283D, gradientTo = 0xFF0D1724),
        motion = MotionSpec(speed = 1.16f, enter = true, bounce = true, glowPulse = true, tabTransition = "slide"),
        background = BackgroundSpec(blobs = true, imageAlpha = 0.9f))
    else -> ThemeSpec.STOCK.copy(name = "Stock Budsy", source = "builtin-stock",
        shapes = ShapeSpec(panel = 22f, card = 18f, tile = 18f, button = 16f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1f, borderAlpha = 0.68f, fillAlpha = 0.96f, glow = true),
        motion = MotionSpec(speed = 1f, enter = true, bounce = true, glowPulse = true, tabTransition = "slide"))
}

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.STOCK) }
val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.STOCK, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

/** The active theme spec (Stock when nothing imported is applied) and the id/folder it was loaded from. */
val LocalThemeSpec = staticCompositionLocalOf { ThemeSpec.STOCK }
val LocalThemeId = staticCompositionLocalOf<String?> { null }
/** True when an imported theme is applied (lets Components pick themed or stock chrome). */
val LocalThemed = staticCompositionLocalOf { false }

/** Loads the theme font, falling back to the generic family if the file is missing or not a valid font. */
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun loadFamily(ctx: android.content.Context, themeId: String?, spec: ThemeSpec?): FontFamily {
    val generic = when (spec?.font?.family) { "serif" -> FontFamily.Serif; "mono" -> FontFamily.Monospace; "cursive" -> FontFamily.Cursive; else -> FontFamily.SansSerif }
    if (spec == null || themeId == null) return generic
    val dir = ThemeStore.themeDir(ctx, themeId) ?: return generic
    val regular = spec.font.file?.let { ThemeStore.resolve(dir, it) } ?: return generic
    return try {
        android.graphics.Typeface.createFromFile(regular)        // throws on corrupt font files
        val bold = spec.font.boldFile?.let { ThemeStore.resolve(dir, it) }?.takeIf { f -> runCatching { android.graphics.Typeface.createFromFile(f) }.isSuccess }
        FontFamily(
            androidx.compose.ui.text.font.Font(regular, FontWeight.Normal),
            androidx.compose.ui.text.font.Font(regular, FontWeight.Medium),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.SemiBold),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.Bold)
        )
    } catch (_: Throwable) { generic }
}

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null, themeId: String? = null, content: @Composable () -> Unit) {
    // Keep the selected built-in identity flowing through composition; imported packages
    // still supply their own ThemeSpec and override the built-in palette where defined.
    val safeMode = ThemeMode.STOCK
    val spec = imported ?: builtInThemeSpec(safeMode)
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = remember(safeMode, appearance, imported) { makePal(safeMode, appearance, imported) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val family = remember(themeId, imported) { loadFamily(ctx, themeId, imported) }
    val themedTypography = remember(family) {
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = family), displayMedium = t.displayMedium.copy(fontFamily = family),
            displaySmall = t.displaySmall.copy(fontFamily = family), headlineLarge = t.headlineLarge.copy(fontFamily = family),
            headlineMedium = t.headlineMedium.copy(fontFamily = family), headlineSmall = t.headlineSmall.copy(fontFamily = family),
            titleLarge = t.titleLarge.copy(fontFamily = family), titleMedium = t.titleMedium.copy(fontFamily = family),
            titleSmall = t.titleSmall.copy(fontFamily = family), bodyLarge = t.bodyLarge.copy(fontFamily = family),
            bodyMedium = t.bodyMedium.copy(fontFamily = family), bodySmall = t.bodySmall.copy(fontFamily = family),
            labelLarge = t.labelLarge.copy(fontFamily = family), labelMedium = t.labelMedium.copy(fontFamily = family),
            labelSmall = t.labelSmall.copy(fontFamily = family)
        )
    }
    val typeSpec = remember(family, imported, safeMode) {
        val base = typeSpecFor(safeMode)
        if (imported != null) TypeSpec(family, spec.font.scale, spec.font.tracking) else base
    }
    val systemReduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(
        LocalPal provides p,
        LocalTypeSpec provides typeSpec,
        LocalReduceMotion provides (systemReduce || !spec.motion.enabled),
        LocalThemeMode provides safeMode,
        LocalThemeSpec provides spec,
        LocalThemeId provides themeId,
        LocalThemed provides (imported != null || safeMode != ThemeMode.STOCK)
    ) {
        MaterialTheme(colorScheme = cs, typography = themedTypography, content = content)
    }
}
