# Budsy Theme Package Format — Theme Engine v2

A theme is a ZIP archive named `.budsytheme` (or a compatible `.mtz`). Theme packages are declarative data only. No scripts, bytecode, plugins, or executable code are loaded. Existing v1 packages remain supported.

## Package structure

```text
MyTheme.budsytheme
├── budsy/theme.json
├── wallpaper/background.webp
├── fonts/Regular.ttf
├── fonts/Bold.ttf
├── icons/                 # PNG/WebP/JPG glyphs
└── assets/                # optional artwork slots
```

`theme.json` may be at the archive root or at `budsy/theme.json`. Asset paths are relative to the package root (or the folder containing the JSON). Supported assets: PNG, WebP, JPG/JPEG, TTF, OTF, JSON, properties, XML and TXT. Import rejects unsafe paths, duplicate entries, more than 400 entries, a file over 16 MB, or a package over 48 MB.

## Full v2 example

```json
{
  "schema": 2, "name": "Example Studio", "author": "You", "version": "2.0",
  "colors": {
    "light": {"bg":"#F5F6FA","card":"#FFFFFF","thumb":"#E9EBF2","text":"#171923","sub":"#777D8D","line":"#E3E6EE","track":"#D5D9E4","accent":"#536DFF","accent2":"#8A6DFF","sheet":"#FAFFFFFF"},
    "dark": {"bg":"#11131A","card":"#1C202B","thumb":"#292E3A","text":"#F7F8FC","sub":"#9BA3B5","line":"#303746","track":"#3B4354","accent":"#7D96FF","accent2":"#B08AFF","sheet":"#F91C202B"},
    "amoled": {"bg":"#000000","card":"#090B10","text":"#FFFFFF","sub":"#9BA3B5","line":"#242A35","accent":"#83A0FF","accent2":"#C08BFF"}
  },
  "shapes": {"panel":26,"card":22,"tile":20,"button":16,"pill":50},
  "card": {"style":"glass","borderWidth":1,"borderAlpha":0.6,"fillAlpha":1,"glow":true,"gradientFrom":"#202A45","gradientTo":"#141A2C"},
  "font": {"file":"fonts/Regular.ttf","boldFile":"fonts/Bold.ttf","family":"sans","scale":1,"tracking":0},
  "motion": {"enabled":true,"speed":1.2,"enter":true,"bounce":true,"glowPulse":true,"tabTransition":"fade"},
  "background": {"image":"wallpaper/background.webp","imageAlpha":0.9,"overlayAlpha":0.12,"blobs":false,"dotMatrix":false},
  "icons": {"tintAccent":false,"tab_device":"icons/device.png","tab_sound":"icons/sound.png","tab_controls":"icons/controls.png","tab_settings":"icons/settings.png","battery":"icons/battery.png","app_header":"icons/app.png","connect":"icons/connect.png","disconnect":"icons/disconnect.png","anc":"icons/anc.png","transparency":"icons/transparency.png","game_mode":"icons/game.png","find_buds":"icons/find.png","equalizer":"icons/eq.png","firmware":"icons/firmware.png","bluetooth":"icons/bluetooth.png","call":"icons/call.png","noise_control":"icons/noise.png","battery_case":"icons/case.png","battery_left":"icons/left.png","battery_right":"icons/right.png","preset":"icons/preset.png","custom_eq":"icons/custom_eq.png","touch_controls":"icons/touch.png","settings_general":"icons/general.png","settings_about":"icons/about.png"},
  "layout": {"pageHorizontal":16,"pageTop":4,"pageBottom":28,"sectionGap":10,"panelPadding":14,"sectionInset":4,"rowHeight":64,"tileHeight":72,"navHeight":64,"contentMaxWidth":0,"gridColumns":2},
  "components": {"panel":"glass","tile":"glass","button":"rounded","switch":"ios","dialog":"glass","navigation":"floating","iconShape":"squircle","iconScale":1,"elevation":3,"dividerStyle":"hairline"},
  "effects": {"glass":0.6,"blur":12,"shadow":0.35,"glow":1,"grain":0,"scanlines":false,"animatedGradient":false,"parallax":false},
  "screens": {"overview":"dashboard","sound":"editorial","controls":"compact","settings":"minimal"}
}
```

## v2 controls

| Group | Controls | What it governs |
|---|---|---|
| `colors.light/dark/amoled` | palette tokens | Each appearance mode independently |
| `shapes.*`, `card.*` | corner radii, card fill, border, gradient, glow | Shared card and tile chrome |
| `font.*` | TTF/OTF, family, scale, tracking | App typography |
| `motion.*` | speed, entrance, bounce, pulse, tab transition | Motion timing and interaction feel |
| `background.*` | artwork, alpha, overlay, blobs, dot matrix | App backdrop |
| `icons.*` | logical icon slots | Tabs, header, battery and feature icon assets |
| `layout.*` | page insets, vertical rhythm, panel padding, tile/row/nav sizes, max width, grid column preference | Shared page and component geometry; grid-column preference is available to a future adaptive grid renderer |
| `components.*` | panel/tile/button/switch/dialog/navigation/icon/divider presets | Reusable component visual language |
| `effects.*` | glass, blur, shadow, glow, grain, scanlines, gradient and parallax flags | Effect profile for supported renderers |
| `screens.*` | overview/sound/controls/settings profile names | Per-screen design profiles |

Named component presets are validated against allow-lists. Numeric values are clamped to safe ranges. Unknown keys are ignored. The shared page, panel, tile, switch, button, dialog and navigation primitives consume the applicable v2 tokens. Screen profile names and advanced effects (real-time blur, grain, scanlines, parallax, adaptive grids and custom screen composition) are safely parsed and retained as renderer configuration; they require dedicated renderers before they can change screen structure or draw those effects. No theme file can change Bluetooth, ANC, EQ, device, or protocol behaviour.

## Compatibility

Theme Engine v2 reads v1 `.budsytheme` files and standard MIUI/HyperOS MTZ metadata, fonts and wallpaper. Stock Budsy remains the permanent built-in theme and continues to support Light, Dark, AMOLED and System appearance.
