# Budsy theme package format (Theme Engine v1)

A theme is a ZIP file named `.budsytheme` or `.mtz`. Nothing in it is ever executed.

## Where the engine reads from (later layers win)
1. `description.xml` (MIUI / HyperOS MTZ): name, author, version.
2. MTZ standard resources: first `fonts/*.ttf|otf` becomes the font, `wallpaper/default_wallpaper.*` becomes the wallpaper.
3. `theme.properties`: legacy flat palette (`lightBg`, `lightCard`, `darkBg`, `darkCard`, `accent`, `text`, `sub`) or the dotted keys below.
4. `budsy/theme.json` or `theme.json`: full spec (recommended). Paths inside it are relative to the package root or to the folder holding theme.json.

Files with extensions other than png, webp, jpg, jpeg, ttf, otf, json, properties, xml, txt are skipped, never written to disk (MTZ native modules, binaries, scripts). Path traversal, duplicate paths, more than 400 entries, a single file above 16 MB or a total above 48 MB reject the package.

## theme.json
```json
{
  "schema": 1, "name": "Violet Dusk", "author": "You", "version": "1.0", "description": "...",
  "colors": {
    "light":  { "bg":"#F6F3FF","card":"#FFFFFF","thumb":"#ECE6FB","text":"#1D1535","sub":"#7A7396","line":"#E4DDF7","track":"#D6CCF0","accent":"#6B4EFF","accent2":"#A07CFF","sheet":"#F9FFFFFF" },
    "dark":   { "...": "same keys" },
    "amoled": { "...": "same keys; falls back to dark when omitted" }
  },
  "shapes":  { "panel": 30, "card": 24, "tile": 26, "button": 18, "pill": 50 },
  "card":    { "style": "glass", "borderWidth": 1, "borderAlpha": 0.55, "fillAlpha": 1, "glow": true, "gradientFrom": "#...", "gradientTo": "#..." },
  "font":    { "file": "fonts/My.ttf", "boldFile": "fonts/My-Bold.ttf", "family": "sans", "scale": 0.96, "tracking": 0.1 },
  "motion":  { "enabled": true, "speed": 1.3, "enter": true, "bounce": true, "glowPulse": true, "tabTransition": "slide" },
  "background": { "image": "wallpaper/bg.png", "imageAlpha": 0.9, "overlayAlpha": 0, "blobs": true, "dotMatrix": false },
  "icons":   { "tintAccent": true, "tab_device": "icons/tab_device.png", "tab_sound": "...", "tab_controls": "...", "tab_settings": "...", "battery": "...", "app_header": "..." }
}
```
Every key is optional. Colours are `#RRGGBB` or `#AARRGGBB`. Numbers are clamped (shapes 0 to 48 dp, speed 0.25 to 3, font scale 0.8 to 1.3).

| Area | Keys | Where it shows |
|---|---|---|
| Colours | `colors.light/dark/amoled.*` | Every screen, dialogs, switches, navigation |
| Shapes | `shapes.*` | Panels, cards, tiles, buttons, pills |
| Cards | `card.style` = solid, glass, gradient, outline, flat | All cards, tiles, panels |
| Font | `font.*` | All text (custom TTF/OTF, scale, tracking) |
| Animation | `motion.*` | Entrance, tap bounce, glow pulse, tab transition, theme fade, speed |
| Wallpaper | `background.*` | App background, blobs, dot-matrix, overlay |
| Icons | `icons.*` (PNG/WebP up to 2048 px, white glyphs recommended) | Bottom tabs, header, battery label |
| Artwork | `assets/hero_case_closed`, `hero_case_open`, `hero_both_out`, `hero_left_out`, `hero_right_out` (png/webp/jpg) | Device hero image |

## MTZ limits
Budsy reads the title, author, font and wallpaper of a normal HyperOS/MIUI MTZ. Lock screen, launcher, status bar and system icon packs inside an MTZ are system-level and cannot be applied to one app. To skin Budsy fully from an MTZ, add `budsy/theme.json` (see `Violet_Dusk.mtz`).

## Theme library
Apply, Preview (live mini-UI using the theme), Duplicate, Save/Export (`.budsytheme`), Delete. Stock Budsy (Light, Dark, AMOLED, System) is built in and cannot be deleted.


## Theme Engine V2 — complete Budsy UI packages

V2 packages use `"schema": 2` and must set `"ui": {"complete": true}`. A V2 import is rejected unless it supplies all six logical app icons, complete light/dark/AMOLED palettes, and all four screen-layout selections. The package remains data-only; it cannot run scripts or replace Bluetooth/protocol code.

The `ui` block controls the visual composition tokens used across the app:

```json
{
  "ui": {
    "complete": true,
    "profile": "nothing",
    "pageHorizontal": 14,
    "pageTop": 2,
    "pageBottom": 24,
    "sectionGap": 8,
    "panelPadding": 12,
    "rowHeight": 60,
    "tileHeight": 68,
    "navHeight": 66,
    "navStyle": "underline",
    "headerStyle": "console",
    "panelStyle": "console",
    "tileStyle": "outlined",
    "iconStyle": "pixel",
    "interactionStyle": "mechanical",
    "backgroundEffect": "scanlines",
    "overviewLayout": "console",
    "soundLayout": "mixer",
    "controlsLayout": "console",
    "settingsLayout": "console"
  }
}
```

Supported values:
- `profile`: `classic`, `nothing`, `aurora`, `crystal`, `titanium`, `sony`, `spatial`
- `navStyle`: `pill`, `dock`, `underline`, `rail`
- `headerStyle`: `compact`, `editorial`, `console`, `minimal`
- `panelStyle`: `standard`, `outlined`, `glass`, `flat`, `console`
- `tileStyle`: `standard`, `compact`, `poster`, `outlined`, `console`
- `iconStyle`: `glyph`, `monochrome`, `duotone`, `outlined`, `pixel`
- `interactionStyle`: `spring`, `snap`, `ripple`, `mechanical`, `soft`
- `backgroundEffect`: `none`, `dots`, `scanlines`, `aurora`, `grain`, `orbit`
- `overviewLayout`: `device`, `dashboard`, `console`, `editorial`
- `soundLayout`: `studio`, `mixer`, `console`, `minimal`
- `controlsLayout`: `grid`, `list`, `console`, `radial`
- `settingsLayout`: `grouped`, `list`, `dashboard`, `console`

V2 also applies theme tokens to page spacing, section rhythm, panel/tile geometry, buttons, rows, sheets, dialogs, tab navigation, header composition, typography, imported artwork, and motion timing. The screen layout names select supported Budsy screen renderers; they do not execute theme code. The original device commands and Bluetooth transport remain part of Budsy and are not supplied by theme packages.

### Required assets for schema 2

- `wallpaper/<theme wallpaper>.png`
- `icons/tab_device.png`
- `icons/tab_sound.png`
- `icons/tab_controls.png`
- `icons/tab_settings.png`
- `icons/battery.png`
- `icons/app_header.png`
- `assets/hero_case_closed.png`, `assets/hero_case_open.png`, `assets/hero_both_out.png`, `assets/hero_left_out.png`, `assets/hero_right_out.png`

For schema 2, all six icon paths must be valid. Hero artwork is recommended and takes precedence over the built-in hero illustration when the matching device state is displayed.
