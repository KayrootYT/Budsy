# Budsy theme package format

A `.budsytheme` file is a ZIP archive. It may contain `theme.properties` at the archive root and optional images under `assets/`.

Example `theme.properties`:

```properties
name=Ocean Calm
author=Theme creator
description=Soft blue earbuds companion theme
source=budsytheme
lightBg=#F4F7FC
lightCard=#FFFFFF
darkBg=#171B24
darkCard=#242B38
accent=#397BEA
text=#18202D
sub=#778397
```

Supported palette keys are optional. Colors accept `#RRGGBB` or `#AARRGGBB`.

## Optional artwork slots

Place PNG, WebP, JPG, or JPEG files in `assets/`. Budsy recognizes these names (case-insensitive):

| Slot | Preferred file names |
|---|---|
| App background | `background.png`, `wallpaper.png`, `bg.png` |
| Closed charging case | `hero_case_closed.png`, `case_closed.png`, `case.png` |
| Open case / buds inside | `hero_case_open.png`, `case_open.png`, `open_case.png`, `hero_both_in.png` |
| Both earbuds outside | `hero_both_out.png`, `buds.png`, `earbuds.png`, `hero.png` |
| Left earbud outside | `hero_left_out.png`, `left_bud.png` |
| Right earbud outside | `hero_right_out.png`, `right_bud.png` |

The same base names with `.webp`, `.jpg`, or `.jpeg` extensions are also supported. Images are decoded with dimension and file-size limits. When an asset is absent, Budsy falls back to its built-in artwork.

Imported packages are stored in Budsy private app storage. Scripts, APKs, DEX, shared libraries, JAR and HTML files are rejected. Package size and entry count are limited. Arbitrary code is never executed. MTZ archives are accepted as ZIP containers; only recognized image and palette resources are currently mapped.


## Theme library actions

Imported themes can be duplicated inside Budsy. A duplicate receives a separate local folder and metadata name ending in “Copy”; its artwork and palette are copied, so editing or deleting the duplicate does not change the original. The built-in Stock Budsy theme is not part of the imported-theme library and cannot be duplicated or deleted.


## Import/export safety and compatibility

Budsy rejects absolute paths, parent-directory traversal, duplicate archive paths, executable payloads, and packages exceeding the entry or expanded-size limits. Export preserves the `assets/` directory structure without nesting it twice. MTZ support remains limited to ZIP-compatible packages and recognized image/palette resources; it is not a full HyperOS theme engine.
