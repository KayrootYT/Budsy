# Budsy Theme Engine v2 upgrade

## Scope kept intentionally narrow

This upgrade changes only the theme engine, shared theme-aware Compose primitives, parser tests, and theme package documentation. It does not change screen feature logic, Bluetooth/GATT/RFCOMM, ANC, EQ commands, device discovery, connection state, or protocol handlers.

## What v2 adds

- Theme schema v2 with backward compatibility for v1 `.budsytheme` and `.mtz` packages.
- Global layout tokens: page insets, vertical rhythm, panel padding, row/tile/navigation heights, max content width and adaptive grid preference.
- Component presets for panels, tiles, buttons, switches, dialogs, navigation, icon pod shape/scale and dividers.
- Effect profile tokens for glass amount, blur, shadow, glow, grain, scanlines, animated gradients and parallax.
- Per-screen design profiles for Overview, Sound Studio, Controls and Settings.
- Expanded logical icon slots for connection, ANC, transparency, game mode, Find Buds, EQ, firmware, call/noise controls, individual battery components and settings groups.
- Shared Page, GlassPanel, FeatureTile, BounceIcon, IosSwitch, WideButton, dialog and navigation components now consume the applicable layout/component tokens.
- Glow intensity now follows the theme effect profile; panel elevation and glass fill are theme controlled.
- Parser tests cover v2 layout/component/effect values, numeric clamping and rejection of unknown presets.

## Explicit limits

This is a theme-engine foundation, not a new screen editor. Screen profile names, adaptive grid preference and some advanced effect values (real-time blur, grain, scanlines, parallax and arbitrary screen composition) are parsed and retained, but still need dedicated renderers before they can visibly rearrange screens or draw those effects. The current shared UI consumes the supported common tokens; it does not execute code supplied by theme packages.

## Verification

- Original project extracted from the supplied `Budsy.zip`.
- Compared source trees: five existing files changed — `ThemeEngine.kt`, `ThemeAssets.kt`, `Components.kt`, `ThemeParserTest.kt`, and `THEME_PACKAGE_FORMAT.md`. `THEME_ENGINE_V2_UPGRADE.md` is a new change report.
- `ThemeEngine.kt` passed standalone Kotlin syntax compilation with Android-specific `AppearanceMode` and `org.json` stubs.
- Full Android Gradle build and instrumented/runtime theme application were not run: this project archive has no Gradle wrapper and this environment has no installed Gradle/Android SDK build setup.
