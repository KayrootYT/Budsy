package com.nordbuds.studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Optional foreground service (Settings > Stay connected in background). It only exists so Android does not kill the
 * process (and with it the control link, notification and widget updates) while the earbuds are connected.
 */
class KeepAliveService : Service() {
    private val listener: () -> Unit = { refreshNotification() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Buds.attach(applicationContext)
        Buds.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val n = build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(NOTIF_ID, n)
        } catch (_: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Buds.removeListener(listener)
        super.onDestroy()
    }

    private fun refreshNotification() {
        if (!Buds.connected || !Buds.keepAlive) { stopSelf(); return }
        try { getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, build()) } catch (_: Exception) { }
    }

    private fun build(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm?.getNotificationChannel(CHANNEL) == null)
            nm?.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.ka_channel), NotificationManager.IMPORTANCE_MIN))
        val l = Buds.battery[0]; val r = Buds.battery[1]; val c = Buds.battery[2]
        val text = if (l < 0 || r < 0) getString(R.string.connected)
            else if (c >= 0) getString(R.string.notif_connected, l, r, c) else getString(R.string.notif_connected_no_case, l, r)
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat_buds)
            .setContentTitle(Buds.displayName.ifEmpty { getString(R.string.app_name) }).setContentText(text)
            .setOngoing(true).setSilent(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_MIN).build()
    }

    companion object {
        private const val NOTIF_ID = 2
        private const val CHANNEL = "keepalive"

        /** Starts the service while connected and enabled, stops it otherwise. Never throws. */
        fun sync(ctx: Context) {
            val i = Intent(ctx, KeepAliveService::class.java)
            try { if (Buds.connected && Buds.keepAlive) ContextCompat.startForegroundService(ctx, i) else ctx.stopService(i) } catch (_: Exception) { }
        }
    }
}
