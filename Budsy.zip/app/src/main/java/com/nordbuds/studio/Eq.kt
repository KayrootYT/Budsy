package com.nordbuds.studio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import com.nordbuds.studio.buds.Prefs
import org.json.JSONArray
import org.json.JSONObject

/** One saved custom EQ profile: a name and one gain (dB) per band. */
class EqSlot(val name: String, val gains: List<Int>)

/** Three custom profiles, kept on the phone as JSON. A null slot is empty. */
object EqSlots {
    const val COUNT = 3
    /** The editor shows -RANGE..+RANGE dB. */
    const val RANGE = 6
    const val NAME_MAX = 16
    /** Band layout used when the buds have not reported their own. */
    val DEFAULT_HZ = listOf(62, 250, 1000, 4000, 8000, 16000)

    fun defaultName(i: Int) = "Custom ${i + 1}"

    fun parse(raw: String?): List<EqSlot?> {
        val out = MutableList<EqSlot?>(COUNT) { null }
        if (raw.isNullOrBlank()) return out
        try {
            val arr = JSONArray(raw)
            for (i in 0 until minOf(COUNT, arr.length())) {
                val o = arr.optJSONObject(i) ?: continue
                val g = o.optJSONArray("g") ?: continue
                out[i] = EqSlot(o.optString("n", defaultName(i)), List(g.length()) { g.optInt(it, 0).coerceIn(-RANGE, RANGE) })
            }
        } catch (_: Exception) { }
        return out
    }

    fun encode(slots: List<EqSlot?>): String {
        val arr = JSONArray()
        for (i in 0 until COUNT) {
            val s = slots.getOrNull(i)
            if (s == null) arr.put(JSONObject.NULL)
            else arr.put(JSONObject().put("n", s.name).put("g", JSONArray(s.gains)))
        }
        return arr.toString()
    }

    fun label(hz: Int) = if (hz >= 1000) "${hz / 1000}k" else "$hz"
}

/** Observable copy of the three slots, backed by [Prefs]. */
object EqStore {
    val slots = mutableStateListOf<EqSlot?>(null, null, null)
    /** Slot currently applied to the buds, -1 for none (a preset is in use). */
    var active by mutableIntStateOf(-1)
        private set
    private var loaded = false

    fun load(p: Prefs) {
        if (loaded) return
        loaded = true
        EqSlots.parse(p.eqSlots).forEachIndexed { i, s -> slots[i] = s }
        active = p.eqActive.takeIf { it in 0 until EqSlots.COUNT && slots[it] != null } ?: -1
    }

    fun put(p: Prefs, i: Int, s: EqSlot?) {
        slots[i] = s
        p.eqSlots = EqSlots.encode(slots)
        if (s == null && active == i) setActive(p, -1)
    }

    fun setActive(p: Prefs, i: Int) { active = i; p.eqActive = i }
}
