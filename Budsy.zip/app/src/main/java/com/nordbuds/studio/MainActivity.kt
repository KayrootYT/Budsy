package com.nordbuds.studio

import androidx.compose.animation.core.animateFloat
import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothDisabled
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Circle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        val tag = newBase.getSharedPreferences("budsy", android.content.Context.MODE_PRIVATE).getString("app_lang", "") ?: ""
        if (tag.isEmpty()) { super.attachBaseContext(newBase); return }
        val loc = java.util.Locale.forLanguageTag(tag)
        java.util.Locale.setDefault(loc)
        val cfg = android.content.res.Configuration(newBase.resources.configuration)
        cfg.setLocale(loc)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }
    override fun onStart() { super.onStart(); Buds.foreground = true }
    override fun onStop() { Buds.foreground = false; super.onStop() }
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen(); super.onCreate(savedInstanceState); Buds.attach(this); enableEdgeToEdge()
        setContent { Root() }
    }
}

@Composable
fun Root() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = Buds.prefs
    remember { Fx.sound = prefs.tapSound; Fx.haptics = prefs.haptics; true }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var chosenTheme by rememberSaveable { mutableIntStateOf(ThemeMode.STOCK) }
    var chosenAppearance by rememberSaveable { mutableIntStateOf(prefs.appearanceMode) }
    val systemDark = isSystemInDarkTheme()
    val appearance = when (chosenAppearance) {
        AppearanceMode.LIGHT, AppearanceMode.DARK, AppearanceMode.AMOLED -> chosenAppearance
        else -> if (systemDark) AppearanceMode.DARK else AppearanceMode.LIGHT
    }
    val theme = ThemeMode.STOCK
    var activeImportedTheme by remember { mutableStateOf(prefs.activeImportedTheme) }
    // One reload counter: bumps when the Theme Manager imports / edits / deletes so the active spec is re-read from disk.
    var themeRev by remember { mutableIntStateOf(0) }
    var showThemeManager by rememberSaveable { mutableStateOf(false) }
    val activeSpec = remember(activeImportedTheme, themeRev) { ThemeStore.spec(ctx, activeImportedTheme) }
    // If the applied theme was deleted outside the app, silently fall back to Stock.
    LaunchedEffect(activeImportedTheme, activeSpec) { if (activeImportedTheme != null && activeSpec == null) { activeImportedTheme = null; prefs.activeImportedTheme = null } }
    val dark = makePal(theme, appearance, activeSpec).dark
    val activity = ctx as? ComponentActivity
    // Only when light/dark actually flips: SideEffect ran enableEdgeToEdge (window-flag + insets work) on every
    // recomposition of Root, which is what made switching theme stutter.
    LaunchedEffect(dark) {
        activity?.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark },
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
        )
    }
    BackHandler(enabled = showThemeManager) { showThemeManager = false }
    BackHandler(enabled = tab != 0 && !showThemeManager) { tab = 0 }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var perm by remember { mutableStateOf(Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) }
    var scanPerm by remember { mutableStateOf(if (Build.VERSION.SDK_INT >= 31) ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED else ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) }
    var notifPerm by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val askBt = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val askScan = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { scanPerm = it }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifPerm = it }
    var showPermRationale by remember { mutableStateOf(false) }
    var showWelcome by remember { mutableStateOf(!prefs.welcomed) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Buds.msg) { val m = Buds.msg ?: return@LaunchedEffect; snack.currentSnackbarData?.dismiss(); snack.showSnackbar(Buds.str(m.res, *m.args.toTypedArray()), duration = SnackbarDuration.Short) }
    val toast: (String) -> Unit = { m -> scope.launch { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(m) } }
    val link = remember { AudioLink(ctx.applicationContext) }
    LaunchedEffect(Buds.connected, Buds.keepAlive) { KeepAliveService.sync(ctx.applicationContext) }
    DisposableEffect(Unit) { onDispose { link.stop() } }
    LaunchedEffect(perm) { if (perm) { link.start(); lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) { while (isActive) { link.refresh(); delay(3000) } } } }
    LaunchedEffect(perm) { if (!perm) showPermRationale = true }
    LaunchedEffect(perm, Buds.autoPaused) {
        if (!perm || Buds.autoPaused) { Buds.searching = false; return@LaunchedEffect }
        var fails = 0
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
        while (isActive) {
            val btEnabled = try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true } catch (_: Exception) { false }
            Buds.btEnabled = btEnabled
            if (!btEnabled) { Buds.searching = false; fails = 0; delay(2000); continue }
            if (Buds.connected) { Buds.searching = false; fails = 0; delay(2000); continue }
            Buds.searching = true
            if (!Buds.connecting) {
                val audio = link.audioAddrs; val last = prefs.lastAddr; val list = bondedDevices(ctx)
                val d = list.firstOrNull { it.address == last }
                    ?: list.firstOrNull { it.address in audio && (it.name ?: "").contains("buds", true) }
                    ?: list.firstOrNull { (it.name ?: "").contains("nord buds", true) }
                if (d != null) { Buds.connect(d, auto = true); fails++ } else fails = 0
            }
            val earbudsOnPhone = prefs.lastAddr?.uppercase()?.let { it in link.audioAddrs } == true
            delay(if (earbudsOnPhone) 2500 else if (fails > 2) 10000 else 4000)
        }
        }
    }
    BudsyTheme(theme, appearance, activeSpec, activeImportedTheme) {
        val titles = listOf(
            Buds.displayName.ifEmpty { stringResource(R.string.app_name) }.removePrefix("OnePlus ").trim(),
            stringResource(R.string.sound_lab), stringResource(R.string.control_center), stringResource(R.string.personalize_budsy)
        )
        val items = listOf(
            Triple(0, Icons.Rounded.Headphones, stringResource(R.string.tab_device)),
            Triple(1, Icons.Rounded.GraphicEq, stringResource(R.string.tab_sound)),
            Triple(2, Icons.Rounded.Tune, stringResource(R.string.tab_controls)),
            Triple(3, Icons.Rounded.Settings, stringResource(R.string.tab_settings))
        )
        val tabAnim = LocalThemeSpec.current.motion.let { if (it.enabled) it.tabTransition else "none" }
        val tabSpeed = LocalThemeSpec.current.motion.speed
        val tabMs: (Int) -> Int = { (it / tabSpeed).toInt().coerceAtLeast(1) }
        Box(Modifier.fillMaxSize().background(P.bg)) {
        val bgSpec = LocalThemeSpec.current.background
        ImportedThemeImage(activeImportedTheme, "background", Modifier.fillMaxSize(), alpha = bgSpec.imageAlpha)
        if (bgSpec.overlayAlpha > 0f) Box(Modifier.fillMaxSize().background(P.bg.copy(alpha = bgSpec.overlayAlpha)))
        AuroraBackground()
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack) { d -> GlassSnack(d.visuals.message) } },
            topBar = { TopBar(titles[tab.coerceIn(0, 3)], theme) },
            bottomBar = { BottomNav(items, tab) { tab = it } }
        ) { pad ->
            val c = Ctx(
                b = Buds, prefs = prefs, perm = perm, askPerm = { showPermRationale = true }, toast = toast, go = { tab = it },
                theme = theme, setTheme = { chosenTheme = ThemeMode.STOCK; prefs.theme = ThemeMode.STOCK },
                appearance = chosenAppearance, setAppearance = { chosenAppearance = it; prefs.appearanceMode = it },
                activeImportedTheme = activeImportedTheme,
                setActiveImportedTheme = { id -> activeImportedTheme = id; prefs.activeImportedTheme = id },
                openThemeManager = { showThemeManager = true }, themeChanged = { themeRev++ },
                audio = link.audioAddrs, audioKnown = link.ready, askScanPerm = { askScan.launch(if (Build.VERSION.SDK_INT >= 31) Manifest.permission.BLUETOOTH_SCAN else Manifest.permission.ACCESS_FINE_LOCATION) }, scanPerm = scanPerm,
                askNotifPerm = { if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }, notifGranted = notifPerm
            )
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.TopCenter) {
              Box(Modifier.widthIn(max = 640.dp).fillMaxSize()) {
                CompositionLocalProvider(LocalScreenKey provides when (tab) {
                    0 -> "overview"; 1 -> "sound"; 2 -> "controls"; else -> "settings"
                }) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        when (tabAnim) {
                            "none" -> fadeIn(tween(1)) togetherWith fadeOut(tween(1))
                            "fade" -> fadeIn(tween(tabMs(260))) togetherWith fadeOut(tween(tabMs(160)))
                            else -> (fadeIn(tween(tabMs(260))) + slideInHorizontally(tween(tabMs(320))) { (it / 8) * dir }) togetherWith
                                (fadeOut(tween(tabMs(160))) + slideOutHorizontally(tween(tabMs(260))) { -(it / 8) * dir })
                        }
                    },
                    label = "tabs"
                ) { t ->
                    when (t) {
                        0 -> OverviewScreen(c)
                        1 -> SoundScreen(c)
                        2 -> ControlsScreen(c)
                        else -> SettingsScreen(c)
                    }
                }
                }
              }
            }
        }
        ThemeFadeOverlay(theme * 10 + appearance + (activeImportedTheme?.hashCode() ?: 0) * 100, P.bg)
        androidx.compose.animation.AnimatedVisibility(
            visible = showThemeManager,
            enter = fadeIn(tween(220)) + slideInHorizontally(tween(300)) { it / 6 },
            exit = fadeOut(tween(180)) + slideOutHorizontally(tween(240)) { it / 6 }
        ) {
            ThemeManagerScreen(
                activeId = activeImportedTheme, appearance = chosenAppearance,
                onApply = { id -> activeImportedTheme = id; prefs.activeImportedTheme = id },
                onAppearance = { chosenAppearance = it; prefs.appearanceMode = it },
                onChanged = { themeRev++ }, toast = toast, onBack = { showThemeManager = false }
            )
        }
        }
    }
    if (showWelcome) BudsyTheme(theme, appearance) {
        val closeWelcome = { showWelcome = false; prefs.welcomed = true }
        GlassDialog(stringResource(R.string.welcome_title), closeWelcome, stringResource(R.string.got_it), closeWelcome) {
            Txt(stringResource(R.string.welcome_body), 15, color = P.text, lineHeight = 21)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.welcome_b1), 14, lineHeight = 20)
            Txt(stringResource(R.string.welcome_b2), 14, lineHeight = 20)
            Txt(stringResource(R.string.welcome_b3), 14, lineHeight = 20)
        }
    }
    if (showPermRationale && !perm) BudsyTheme(theme, appearance) {
        GlassDialog(
            stringResource(R.string.perm_title), { showPermRationale = false }, stringResource(R.string.perm_grant),
            { showPermRationale = false; if (Build.VERSION.SDK_INT >= 31) askBt.launch(Manifest.permission.BLUETOOTH_CONNECT) },
            stringResource(R.string.not_now)
        ) { Txt(stringResource(R.string.perm_body), 15, color = P.text, lineHeight = 21) }
    }
}

/** Compact, pinned app header: theme identity + page title + live connection state. */
@Composable
private fun TopBar(title: String, theme: Int) {
    val ok = Buds.connected
    val ui = LocalUiSpec.current
    val themedHeader = LocalThemed.current
    val chip = RoundedCornerShape(50)
    val themeIcon = when (theme) {
        ThemeMode.NOTHING -> Icons.Rounded.Circle
        ThemeMode.AURORA -> Icons.Rounded.Bolt
        ThemeMode.CRYSTAL -> Icons.Rounded.GraphicEq
        ThemeMode.TITANIUM -> Icons.Rounded.AutoAwesome
        else -> Icons.Rounded.Headphones
    }
    val reduce = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "pinnedHeaderMotion")
    val pulse by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.045f,
        animationSpec = infiniteRepeatable(
            tween(when (theme) { ThemeMode.NOTHING -> 760; ThemeMode.CRYSTAL -> 1450; ThemeMode.TITANIUM -> 1050; else -> 1200 }, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "pinnedHeaderPulse"
    )
    Row(
        Modifier.fillMaxWidth()
            .background(P.bg.copy(alpha = 0.96f))
            .statusBarsPadding()
            .padding(
                start = if (themedHeader) ui.pageHorizontal.dp else 16.dp,
                end = if (themedHeader) ui.pageHorizontal.dp else 14.dp,
                top = if (ui.headerStyle == "editorial") 15.dp else 7.dp,
                bottom = if (ui.headerStyle == "minimal") 4.dp else 9.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(if (ui.headerStyle == "console") 44.dp else 38.dp)
                .clip(RoundedCornerShape(when (ui.headerStyle) { "console" -> 5.dp; "editorial" -> 18.dp; "minimal" -> 8.dp; else -> 13.dp }))
                .background(Brush.linearGradient(listOf(P.accent.copy(alpha = 0.20f), P.tile)))
                .border(1.dp, P.accent.copy(alpha = 0.26f), RoundedCornerShape(when (ui.headerStyle) { "console" -> 5.dp; "editorial" -> 18.dp; "minimal" -> 8.dp; else -> 13.dp })),
            contentAlignment = Alignment.Center
        ) {
            ThemedIcon(IconKeys.APP, themeIcon, P.accent,
                modifier = Modifier.size(21.dp).graphicsLayer {
                    val pz = if (reduce) 1f else pulse
                    scaleX = pz; scaleY = pz
                    translationY = if (theme == ThemeMode.CRYSTAL) (pz - 1f) * 18f else 0f
                    rotationZ = if (theme == ThemeMode.TITANIUM) (pz - 1f) * 180f else 0f
                })
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Txt(
                if (ui.headerStyle == "console") title.uppercase() else title,
                if (ui.headerStyle == "editorial") 22 else 19,
                FontWeight.Bold, P.text, maxLines = 1,
                spacing = if (ui.profile == "nothing" || ui.headerStyle == "console") 0.8f else 0f
            )
            if (ui.headerStyle != "minimal") Txt(
                when (ui.profile) {
                    "nothing" -> "BUDSY  /  DEVICE MATRIX"
                    "sony" -> "BUDSY  /  SOUND ENGINE"
                    "spatial" -> "BUDSY  /  SPATIAL AUDIO"
                    else -> "BUDSY  /  PERSONAL AUDIO"
                }, 9, FontWeight.SemiBold, P.sub, spacing = 1.15f, maxLines = 1
            )
        }
        Spacer(Modifier.width(8.dp))
        Row(
            Modifier.glowBorder(50.dp, if (ok) P.green else P.line, P.accent, rememberGlow(ok))
                .clip(chip)
                .background(if (ok) P.green.copy(alpha = 0.10f) else P.tile)
                .border(1.dp, if (ok) P.green.copy(alpha = 0.45f) else P.line, chip)
                .padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(if (ok) Icons.Rounded.Bluetooth else Icons.Rounded.BluetoothDisabled, null,
                tint = if (ok) P.green else P.sub, modifier = Modifier.size(14.dp))
            PulseDot(if (ok) P.green else P.sub, ok, 5.dp)
            Txt(if (ok) stringResource(R.string.connected) else stringResource(R.string.offline), 11, FontWeight.SemiBold,
                if (ok) P.green else P.sub, maxLines = 1)
        }
    }
    HorizontalDivider(color = P.line.copy(alpha = 0.72f), thickness = 0.6.dp)
}
