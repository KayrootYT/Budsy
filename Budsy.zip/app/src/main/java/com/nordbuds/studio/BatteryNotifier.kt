package com.nordbuds.studio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat

object BatteryNotifier {
    private var channelDone = false
    fun ensureChannel(ctx: Context) {
        if (channelDone) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("battery", ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        channelDone = true
    }
    fun update(ctx: Context) {
        if (!Buds.isAttached()) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (!Buds.prefs.batteryNotif || !Buds.connected) { nm.cancel(1); return }
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val l = Buds.battery[0]; val r = Buds.battery[1]; val c = Buds.battery[2]
        val text = if (l < 0 || r < 0) ctx.getString(R.string.connected) else if (c >= 0) ctx.getString(R.string.notif_connected, l, r, c) else ctx.getString(R.string.notif_connected_no_case, l, r)
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, "battery").setSmallIcon(R.drawable.ic_stat_buds).setContentTitle(Buds.displayName.ifEmpty { ctx.getString(R.string.app_name) }).setContentText(text).setContentIntent(pi).setOngoing(true).build()
        nm.notify(1, n)
    }
    fun cancel(ctx: Context) { ctx.getSystemService(NotificationManager::class.java)?.cancel(1) }
}
