package com.nordbuds.studio.security

import android.content.Context
import android.util.Base64
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import com.nordbuds.studio.BuildConfig
import java.security.SecureRandom

/**
 * Client-side Play Integrity token acquisition.
 *
 * IMPORTANT: a token is not a verdict. Send it to your trusted backend for Google Play
 * decoding and policy evaluation. Never accept client-side checks as a licensing/security gate.
 */
object PlayIntegrityClient {
    private val random = SecureRandom()

    /** Returns a fresh URL-safe nonce suitable for binding a request to a server challenge. */
    fun newNonce(): String {
        val bytes = ByteArray(24)
        random.nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    fun isConfigured(): Boolean = BuildConfig.PLAY_CLOUD_PROJECT_NUMBER > 0L

    fun requestToken(
        context: Context,
        nonce: String,
        onResult: (Result<String>) -> Unit
    ) {
        if (!isConfigured()) {
            onResult(Result.failure(IllegalStateException(
                "Play Integrity is not configured. Set PLAY_CLOUD_PROJECT_NUMBER in gradle.properties."
            )))
            return
        }
        if (nonce.length < 16) {
            onResult(Result.failure(IllegalArgumentException("Nonce must be at least 16 characters.")))
            return
        }

        try {
            val manager = IntegrityManagerFactory.create(context.applicationContext)
            val request = IntegrityTokenRequest.builder()
                .setCloudProjectNumber(BuildConfig.PLAY_CLOUD_PROJECT_NUMBER)
                .setNonce(nonce)
                .build()
            manager.requestIntegrityToken(request)
                .addOnSuccessListener { response -> onResult(Result.success(response.token())) }
                .addOnFailureListener { error -> onResult(Result.failure(error)) }
        } catch (error: Exception) {
            onResult(Result.failure(error))
        }
    }
}
