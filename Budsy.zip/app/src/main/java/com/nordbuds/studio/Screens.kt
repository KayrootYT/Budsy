package com.nordbuds.studio

import androidx.compose.foundation.border
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nordbuds.studio.protocol.Protocol
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

fun openBluetooth(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { }
}

/** Card notice: glowing icon, two lines of text and a button. */
@Composable
private fun NoticeRow(icon: ImageVector, tint: Color, title: String, detail: String, action: String, onAction: () -> Unit) {
    GlassPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BounceIcon(icon, true, 44.dp, false, rememberGlow(true))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(title, 16, FontWeight.SemiBold, P.text)
                Txt(detail, 13, lineHeight = 18)
            }
            Spacer(Modifier.width(10.dp))
            SmallButton(action, false) { onAction() }
        }
    }
}

@Composable
fun NeedConnect(x: Ctx) {
    NoticeRow(
        Icons.Rounded.Bluetooth, P.accent,
        stringResource(R.string.earbuds_not_connected), stringResource(R.string.connect_on_the_overview_tab_first),
        stringResource(R.string.overview)
    ) { x.go(0) }
}

/** Audio counts as connected if the phone lists this address OR a device with the same name (BT identity addresses can differ). */
private fun audioUp(addr: String, name: String?, audio: Set<String>): Boolean =
    addr.uppercase() in audio || (!name.isNullOrEmpty() && ("name:" + name) in audio)

@Composable
private fun AudioWarning(name: String) {
    val ctx = LocalContext.current
    NoticeRow(
        Icons.Rounded.Warning, P.amber,
        stringResource(R.string.audio_is_not_connected), stringResource(R.string.audio_warning_detail, name),
        stringResource(R.string.open_2)
    ) { openBluetooth(ctx) }
}

/** Little "saved / saving / failed" line under a setting. */
@Composable
private fun SaveLine(state: Buds.SaveState, message: String) {
    if (state == Buds.SaveState.IDLE || message.isBlank()) return
    val c = when (state) { Buds.SaveState.SAVED -> P.green; Buds.SaveState.FAILED -> P.amber; Buds.SaveState.SAVING -> P.accent; else -> P.sub }
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (state == Buds.SaveState.SAVING) CircularProgressIndicator(Modifier.size(15.dp), color = c, strokeWidth = 2.dp)
        else Icon(if (state == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = c, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Txt(message, 13, color = c, lineHeight = 17)
    }
}

/** Expanding rings behind the hero image. */
@Composable
private fun PulseRings(active: Boolean, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "heroRings")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "heroRingPhase"
    )
    val accent = P.accent; val accent2 = P.accent2
    Canvas(modifier) {
        val maxR = size.minDimension * 0.62f
        val k = if (active) 1f else 0.45f
        drawCircle(Brush.radialGradient(colors = listOf(accent.copy(alpha = 0.22f * k), Color.Transparent), center = center, radius = maxR), maxR, center)
        for (i in 0..2) {
            val q = (phase + i / 3f) % 1f
            drawCircle(accent2.copy(alpha = (1f - q) * 0.30f * k), maxR * (0.34f + 0.66f * q), center, style = Stroke(1.4.dp.toPx()))
        }
    }
}

private val NoiseIds = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)

// ================================================================= OVERVIEW

@Composable
fun OverviewScreen(x: Ctx) {
    val b = x.b
    val ctx = LocalContext.current
    var showList by rememberSaveable { mutableStateOf(false) }
    val connectFirstText = stringResource(R.string.err_connect_first)
    val floatTransition = rememberInfiniteTransition(label = "floatingProduct")
    val float by floatTransition.animateFloat(
        initialValue = -4f, targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(2100, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "floatingProductOffset"
    )
    val tilt by floatTransition.animateFloat(
        initialValue = -1.2f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "floatingProductTilt"
    )
    Page {
        if (b.connected && x.audioKnown && !audioUp(b.deviceAddr, b.deviceName, x.audio)) {
            AudioWarning(if (b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.your_earbuds))
        }

        // Hero: floating buds over pulsing rings, status and primary action grouped together.
        GlassPanel(index = 0) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("YOUR DEVICE", 11, FontWeight.Bold, P.sub, spacing = 1.5f)
                    Spacer(Modifier.height(5.dp))
                    Txt(Buds.displayName.ifEmpty { "Nord Buds 3" }.removePrefix("OnePlus "), 22, FontWeight.Bold, P.text, maxLines = 1)
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulseDot(if (b.connected) P.green else P.sub, b.connected)
                        Spacer(Modifier.width(4.dp))
                        Txt(if (b.connected) stringResource(R.string.connected) else b.status, 13, color = if (b.connected) P.green else P.sub, maxLines = 1)
                    }
                }
                BounceIcon(Icons.Rounded.Bluetooth, b.connected, 48.dp, false, rememberGlow(b.connected), P.accent)
            }
            val liveHero = rememberSettledHero(HeroResolver.resolve(HeroInput(b.connected, b.lidState, b.leftPos, b.rightPos)))
            val previewSel = HeroPreview.selected
            val shown = if (previewSel != null) HeroResolver.preview(previewSel) else liveHero
            Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                PulseRings(b.connected, Modifier.fillMaxSize())
                DeviceHeroArt(x.theme, shown.state, Modifier.fillMaxWidth().height(236.dp), dashed = shown.source == HeroSource.ESTIMATED, appearance = x.appearance)
            }
            HeroCaption(shown)
            if (!b.connected) {
                if (b.autoPaused) {
                    Txt(stringResource(R.string.auto_connect_is_off_because_you_disconnected), 13, color = P.sub,
                        align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AccentPill(if (b.autoPaused) stringResource(R.string.connect_auto_on) else stringResource(R.string.connect_earbuds), Icons.Rounded.Bluetooth) {
                        if (!x.perm) {
                            x.askPerm()
                        } else {
                            b.resumeAutoConnect()
                            val remembered = bondedDevices(ctx).firstOrNull { it.address == b.prefs.lastAddr }
                            if (remembered != null) b.connect(remembered) else showList = true
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.refresh_2), false, icon = Icons.Rounded.Refresh) { b.refreshAll() } }
                    Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.disconnect_2), true, icon = Icons.Rounded.LinkOff) { b.disconnect() } }
                }
            }
        }

        if (!b.connected && showList) GlassPanel { ConnectBlock(x) }

        SectionLabel("Battery", Icons.Rounded.BatteryChargingFull, "Live charge levels for each earbud and the case")
        GlassPanel(index = 1) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BatteryStat(b.battery[0], b.charging[0], stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc))
                BatteryStat(b.battery[1], b.charging[1], stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc))
                BatteryStat(
                    if (b.connected) b.battery[2] else -1,
                    b.connected && b.charging[2],
                    stringResource(R.string.widget_case_label), Modifier.weight(1f),
                    desc = stringResource(R.string.battery_case_desc), icon = Icons.Rounded.BatteryFull
                )
            }
        }

        if (b.connected) {
            SectionLabel(stringResource(R.string.noise_control), Icons.Rounded.Waves, "Choose the sound around you")
            GlassPanel(index = 2) {
                Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.noise_cancel), "ANC", Icons.Rounded.Waves, b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { b.setAnc(Buds.ANC_ON) }
                    FeatureTile(stringResource(R.string.hold_off), "Off", Icons.Rounded.Block, b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { b.setAnc(Buds.ANC_OFF) }
                    FeatureTile(stringResource(R.string.hold_transparency), "Aware", Icons.Rounded.Hearing, b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { b.setAnc(Buds.ANC_TRANSP) }
                }
                SaveLine(b.ancSaveState, b.ancSaveMessage)
            }
        }

        SectionLabel("Make it yours", Icons.Rounded.AutoAwesome, "Fine-tune your listening experience")
        GlassPanel(index = 3) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.game_mode), if (b.gameMode == true) "On" else stringResource(R.string.lower_audio_latency), Icons.Rounded.SportsEsports,
                    b.connected && b.gameMode == true, Modifier.weight(1f), 61, 112.dp) {
                    if (b.connected) b.setGame(b.gameMode != true) else x.toast(connectFirstText)
                }
                FeatureTile(stringResource(R.string.sound_lab), stringResource(R.string.eq_bass_audio), Icons.Rounded.GraphicEq, false, Modifier.weight(1f), 62, 112.dp) { x.go(1) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.smart_controls), stringResource(R.string.anc_gestures), Icons.Rounded.Tune, false, Modifier.weight(1f), 63, 112.dp) { x.go(2) }
                FeatureTile(stringResource(R.string.tab_settings), "Theme · Alerts", Icons.Rounded.Settings, false, Modifier.weight(1f), 64, 112.dp) { x.go(3) }
            }
        }

        if (b.connected) {
            SectionLabel(stringResource(R.string.find_my_earbuds), Icons.Rounded.LocationSearching, "Play a tone to locate your earbuds")
            GlassPanel(index = 4) {
                Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.left_2), "Left bud", Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, Modifier.weight(1f), 21) { b.findEarbuds(1) }
                    FeatureTile(stringResource(R.string.right_2), "Right bud", Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, Modifier.weight(1f), 22) { b.findEarbuds(2) }
                    FeatureTile(stringResource(R.string.both_2), "Both", Icons.Rounded.NotificationsActive, b.findAlertRequested && b.findAlertSide == 3, Modifier.weight(1f), 23) { b.findEarbuds(3) }
                }
                if (b.findAlertRequested || b.findAlertMessage.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Txt("${if (b.findAlertRequested) "Alert requested" else "Stop requested"} · ${when (b.findAlertSide) { 1 -> "Left"; 2 -> "Right"; else -> "Both" }}", 13, color = P.sub)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { WideButton("Play again", false, icon = Icons.Rounded.Replay) { b.findEarbuds(b.findAlertSide) } }
                        Box(Modifier.weight(1f)) { WideButton("Pause / Stop", true, icon = Icons.Rounded.Stop) { b.stopFindEarbuds() } }
                    }
                    if (b.findAlertMessage.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Txt(b.findAlertMessage, 12, color = P.sub, lineHeight = 16)
                    }
                }
                if (b.wear.any { it >= 0 }) {
                    Spacer(Modifier.height(12.dp))
                    Txt(stringResource(R.string.wear_sides, wearText(b.wear[0]), wearText(b.wear[1])), 13)
                }
            }
        }
    }
}

// ================================================================= SOUND

private fun presetIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Rounded.Equalizer
    1 -> Icons.Rounded.RecordVoiceOver
    else -> Icons.Rounded.Speaker
}

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    Page {
        if (!b.connected) NeedConnect(x)

        SectionLabel(stringResource(R.string.eq_presets), Icons.Rounded.Equalizer)
        GlassPanel(index = 0) {
            val labels = Buds.PRESETS.mapIndexed { i, p -> presetIcon(i) to stringResource(p.second) }
            val idx = if (b.connected) Buds.PRESETS.indexOfFirst { it.first == b.eqPreset } else -1
            Segmented(labels, idx) { i ->
                if (b.connected) { b.setEq(Buds.PRESETS[i].first); EqStore.setActive(x.prefs, -1) } else x.toast(connectFirstText)
            }
            val cur = Buds.PRESETS.firstOrNull { it.first == b.eqPreset }
            if (b.connected && cur != null) { Spacer(Modifier.height(10.dp)); Txt(stringResource(cur.third), 14) }
        }

        SectionLabel(stringResource(R.string.basswave), Icons.Rounded.Speaker)
        if (!b.connected) {
            Txt(stringResource(R.string.connect_your_earbuds_to_adjust_the_bass), 14, modifier = Modifier.padding(horizontal = 6.dp))
        } else {
            SwitchRow(stringResource(R.string.basswave), stringResource(R.string.adjust_the_low_end), b.bassOn == true, icon = Icons.Rounded.Speaker) { b.setBassOn(it) }
            val lv = b.bassLevel
            if (lv != null) {
                var drag by remember { mutableStateOf<Float?>(null) }
                GlassPanel(index = 1) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.VolumeUp, null, tint = P.accent, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Txt(stringResource(R.string.level), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                        val shown = (drag ?: lv.toFloat()).roundToInt()
                        Txt(if (shown > 0) "+$shown" else "$shown", 17, FontWeight.Bold, P.accent)
                    }
                    Slider(
                        value = drag ?: lv.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null },
                        valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(),
                        steps = (b.bassMax - b.bassMin - 1).coerceAtLeast(0),
                        enabled = b.bassOn == true,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = P.accent, inactiveTrackColor = P.track,
                            activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                        )
                    )
                }
            }
        }

        CustomEqSection(x)
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt(stringResource(R.string.bluetooth_permission_is_needed_to_find_your_pair), 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton(stringResource(R.string.allow_bluetooth), icon = Icons.Rounded.Bluetooth) { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting) { bondedDevices(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (b.searching || b.connecting) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), color = P.accent, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Txt(if (b.connecting) "Connecting…" else "Scanning for your earbuds…", 16, FontWeight.Medium, P.text)
            }
        }
        Txt(stringResource(R.string.select_a_device_to_connect), 17, FontWeight.SemiBold, P.text)
        Txt(stringResource(R.string.connect_the_earbuds_for_audio_in_bluetooth_setti), 14, lineHeight = 20)
        if (list.isEmpty()) Txt(stringResource(R.string.no_paired_devices_found), 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if ((d.name ?: "").contains("buds", ignoreCase = true))
                    Image(painterResource(R.drawable.hero_buds), null, Modifier.width(54.dp), contentScale = ContentScale.Fit)
                else BounceIcon(Icons.Rounded.Headphones, false, 40.dp, false, { 0f }, P.accent)
                Spacer(Modifier.width(12.dp))
                val up = audioUp(d.address, d.name, x.audio)
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(if (up) stringResource(R.string.connected_for_audio) else if (x.audioKnown) stringResource(R.string.not_connected_for_audio) else stringResource(R.string.paired), 13, color = if (up) P.green else P.sub)
                }
                if (x.audioKnown && !up) {
                    SmallButton(stringResource(R.string.bluetooth), icon = Icons.Rounded.Bluetooth) { openBluetooth(ctx) }
                    Spacer(Modifier.width(6.dp))
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.control), false) { if (!b.connecting) b.connect(d) }
                } else {
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.connect), icon = Icons.Rounded.Link) { if (!b.connecting) b.connect(d) }
                }
            }
            Divider()
        }
        Row(
            Modifier.clip(CircleShape).clickable { openBluetooth(ctx) }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt(stringResource(R.string.open_bluetooth_settings), 15, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val labelRes: Int)
private val NONE = Opt(Buds.F_NONE, R.string.fn_none)
private val PLAY = Opt(Buds.F_PLAY, R.string.fn_play)
private val PREV = Opt(Buds.F_PREV, R.string.fn_prev)
private val NEXT = Opt(Buds.F_NEXT, R.string.fn_next)
private val VOICE = Opt(Buds.F_VOICE, R.string.fn_voice)
private val GAME = Opt(Buds.F_GAME, R.string.fn_game)
private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, R.string.fn_vol_up), Opt(Buds.F_VOL_DN, R.string.fn_vol_down))
private fun optsFor(gid: Int) = when (gid) { Buds.G_SINGLE -> SINGLE_OPTS; Buds.G_DOUBLE -> DOUBLE_OPTS; Buds.G_TRIPLE -> TRIPLE_OPTS; else -> LONG_OPTS }

private fun fnIcon(fn: Int): ImageVector = when (fn) {
    Buds.F_NONE -> Icons.Rounded.Block
    Buds.F_PLAY -> Icons.Rounded.PlayArrow
    Buds.F_PREV -> Icons.Rounded.SkipPrevious
    Buds.F_NEXT -> Icons.Rounded.SkipNext
    Buds.F_VOICE -> Icons.Rounded.Mic
    Buds.F_GAME -> Icons.Rounded.SportsEsports
    Buds.F_VOL_UP -> Icons.Rounded.VolumeUp
    Buds.F_VOL_DN -> Icons.Rounded.VolumeDown
    Buds.F_ANC -> Icons.Rounded.Waves
    else -> Icons.Rounded.Tune
}

@Composable
private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return stringResource(it.labelRes) }
    return when (fn) {
        0x07 -> stringResource(R.string.fn_volume)
        0x0A -> stringResource(R.string.fn_switch_track)
        Buds.F_ANC -> stringResource(R.string.fn_anc)
        else -> stringResource(R.string.unknown_action, Protocol.hex(fn).uppercase())
    }
}

@Composable
private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add(stringResource(R.string.hold_anc))
        if ((mask and Buds.M_OFF) != 0) add(stringResource(R.string.hold_off))
        if ((mask and Buds.M_TRANSP) != 0) add(stringResource(R.string.hold_transparency))
    }
    return n.joinToString(", ")
}

@Composable
private fun wearText(f: Int): String = when {
    f < 0 -> "—"
    (f and 2) != 0 -> stringResource(R.string.wear_in_ear)
    (f and 1) == 0 -> stringResource(R.string.wear_in_case)
    else -> stringResource(R.string.wear_out_case)
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) stringResource(R.string.left) else stringResource(R.string.right)
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast(connectFirstText) }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null
    fun isSet(g: Int): Boolean = live && (cur(g) ?: Buds.F_NONE) != Buds.F_NONE

    Page {
        if (!live) NeedConnect(x)

        SectionLabel(stringResource(R.string.noise_control), Icons.Rounded.Waves)
        GlassPanel(index = 0) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.noise_cancel), "Reduce outside noise", Icons.Rounded.Waves, live && b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { if (live) b.setAnc(Buds.ANC_ON) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.hold_off), "Natural listening", Icons.Rounded.Block, live && b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { if (live) b.setAnc(Buds.ANC_OFF) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.hold_transparency), "Hear surroundings", Icons.Rounded.Hearing, live && b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { if (live) b.setAnc(Buds.ANC_TRANSP) else x.toast(connectFirstText) }
            }
            if (live) SaveLine(b.ancSaveState, b.ancSaveMessage)
        }

        SwitchRow(stringResource(R.string.game_mode), stringResource(R.string.lower_audio_latency), b.gameMode == true, live, Icons.Rounded.SportsEsports) { b.setGame(it) }

        SectionLabel(stringResource(R.string.find_my_earbuds), Icons.Rounded.LocationSearching)
        GlassPanel(index = 1) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.left_2), "Play left bud tone", Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, Modifier.weight(1f), 21) { if (live) b.findEarbuds(1) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.right_2), "Play right bud tone", Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, Modifier.weight(1f), 22) { if (live) b.findEarbuds(2) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.both_2), "Play both tones", Icons.Rounded.NotificationsActive, b.findAlertRequested && b.findAlertSide == 3, Modifier.weight(1f), 23) { if (live) b.findEarbuds(3) else x.toast(connectFirstText) }
            }
            if (live && b.findAlertRequested) { Spacer(Modifier.height(10.dp)); WideButton("Stop alert", false, icon = Icons.Rounded.Stop) { b.stopFindEarbuds() } }
        }

        SectionLabel(stringResource(R.string.earbud_controls), Icons.Rounded.TouchApp, "Pick an earbud, then tap a gesture")
        GlassPanel(index = 2) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { BudArt(side == 2, 140.dp, touchSpot = true) }
            Spacer(Modifier.height(12.dp))
            Segmented(listOf(Icons.Rounded.ChevronLeft to stringResource(R.string.left_2), Icons.Rounded.ChevronRight to stringResource(R.string.right_2)), side - 1) { side = it + 1 }
        }

        SectionLabel(stringResource(R.string.when_not_on_a_call), Icons.Rounded.MusicNote)
        GlassPanel(index = 3) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Single tap", fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE)), Icons.Rounded.TouchApp, isSet(Buds.G_SINGLE), Modifier.weight(1f), 41) { open(Buds.G_SINGLE) }
                FeatureTile("Double tap", fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE)), Icons.Rounded.Fingerprint, isSet(Buds.G_DOUBLE), Modifier.weight(1f), 42) { open(Buds.G_DOUBLE) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Triple tap", fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE)), Icons.Rounded.MoreHoriz, isSet(Buds.G_TRIPLE), Modifier.weight(1f), 43) { open(Buds.G_TRIPLE) }
                FeatureTile("Touch & hold", if (live) holdLabel(b.holdMask) else "—", Icons.Rounded.PanTool, live && b.holdMask > 0, Modifier.weight(1f), 44) { open(Buds.G_HOLD) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Long hold", fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), Icons.Rounded.Timer, isSet(Buds.G_LONG), Modifier.weight(1f), 45) { open(Buds.G_LONG) }
                FeatureTile(stringResource(R.string.view_tutorial), "How gestures work", Icons.Rounded.School, false, Modifier.weight(1f), 46) { tutorial = true }
            }
        }

        SectionLabel(stringResource(R.string.when_on_a_call), Icons.Rounded.Call)
        ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), stringResource(R.string.answer_end_call), chevron = false, icon = Icons.Rounded.Call)
        ValueRow(stringResource(R.string.long_touch_and_hold), stringResource(R.string.decline_call), chevron = false, icon = Icons.Rounded.CallEnd)
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> stringResource(R.string.g_single); Buds.G_DOUBLE -> stringResource(R.string.g_double); else -> stringResource(R.string.g_triple) }) + " $sideName " + stringResource(R.string.earbud)
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(stringResource(o.labelRes), fnIcon(o.fn), now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }) {
            SheetTitle(stringResource(R.string.g_long))
            Txt(stringResource(R.string.long_touch_volume_help), 15, lineHeight = 22)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.long_touch_anc_help), 15, lineHeight = 22)
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEach { o ->
                RadioRow(stringResource(o.labelRes), fnIcon(o.fn), now == o.fn) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_HOLD) {
        LaunchedEffect(Unit) { b.queryHold() }
        var sel by rememberSaveable { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        var holdTouched by remember { mutableStateOf(false) }
        LaunchedEffect(b.holdMask) { if (!holdTouched && b.holdMask > 0) sel = b.holdMask and 7 }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) { sel = v; holdTouched = true } }
        SheetDialog({ dlg = 0 }, footer = {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton(if (b.holdSaveState == Buds.SaveState.SAVING) "Saving…" else stringResource(R.string.confirm), true, icon = Icons.Rounded.Check) { if (b.holdSaveState != Buds.SaveState.SAVING) b.updateHoldMask(sel) } }
            }
        }) {
            SheetTitle(stringResource(R.string.g_hold))
            Txt(if (n == 1) stringResource(R.string.hold_one_option) else stringResource(R.string.hold_many_options, n), 15, lineHeight = 21)
            Spacer(Modifier.height(6.dp))
            CheckRow(stringResource(R.string.hold_anc), stringResource(R.string.hold_anc_sub), Icons.Rounded.Waves, (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow(stringResource(R.string.hold_off), stringResource(R.string.hold_off_sub), Icons.Rounded.Block, (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow(stringResource(R.string.hold_transparency), stringResource(R.string.hold_transparency_sub), Icons.Rounded.Hearing, (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            if (b.holdSaveState != Buds.SaveState.IDLE || b.holdSaveMessage.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                val saveColor = when (b.holdSaveState) {
                    Buds.SaveState.SAVED -> P.green
                    Buds.SaveState.FAILED -> P.amber
                    Buds.SaveState.SAVING -> P.accent
                    else -> P.sub
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (b.holdSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = saveColor)
                    else Icon(if (b.holdSaveState == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = saveColor, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Txt(b.holdSaveMessage, 12, color = saveColor, lineHeight = 17)
                }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle(stringResource(R.string.earbud_controls))
            TutorialLine(Icons.Rounded.TouchApp, stringResource(R.string.single_double_and_triple_tap_tap_the_touch_area_))
            TutorialLine(Icons.Rounded.PanTool, stringResource(R.string.touch_and_hold_hold_until_you_hear_a_beep_then_l))
            TutorialLine(Icons.Rounded.Timer, stringResource(R.string.long_touch_and_hold_keep_holding_until_you_hear_))
            TutorialLine(Icons.Rounded.Call, stringResource(R.string.during_a_call_double_tap_to_answer_or_end_it_lon))
            Spacer(Modifier.height(14.dp))
            WideButton(stringResource(R.string.got_it), true, icon = Icons.Rounded.Check) { tutorial = false }
        }
    }
}

@Composable
private fun TutorialLine(icon: ImageVector, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        BounceIcon(icon, false, 40.dp, false, { 0f }, P.accent)
        Spacer(Modifier.width(12.dp))
        Txt(text, 15, color = P.text, lineHeight = 21, modifier = Modifier.weight(1f))
    }
}

// ================================================================= SETTINGS

@Composable
fun SettingsScreen(x: Ctx) {
    var diag by remember { mutableStateOf(x.prefs.diag) }
    var batteryNotif by remember { mutableStateOf(Buds.prefs.batteryNotif) }
    var tapSound by remember { mutableStateOf(x.prefs.tapSound) }
    var haptics by remember { mutableStateOf(x.prefs.haptics) }
    var rename by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf(Buds.customName ?: Buds.deviceName) }
    val ctx = LocalContext.current
    Page {
        SectionLabel("Device", Icons.Rounded.Headphones)
        ValueRow(stringResource(R.string.rename_device), Buds.displayName.ifEmpty { stringResource(R.string.app_name) }, icon = Icons.Rounded.Edit) { nameDraft = Buds.customName ?: Buds.deviceName; rename = true }
        SwitchRow(stringResource(R.string.battery_notification), stringResource(R.string.battery_notification_sub), batteryNotif, icon = Icons.Rounded.Notifications) { enabled ->
            batteryNotif = enabled
            Buds.prefs.batteryNotif = enabled
            if (!enabled) BatteryNotifier.cancel(ctx) else if (!x.notifGranted) x.askNotifPerm() else BatteryNotifier.update(ctx)
        }
        SwitchRow(stringResource(R.string.wear_detection), stringResource(R.string.wear_detection_sub), Buds.wearDetect == true, icon = Icons.Rounded.Hearing, badge = stringResource(R.string.experimental)) { Buds.setWearDetect(it) }

        SectionLabel("Appearance", Icons.Rounded.Contrast, "Light, Dark and AMOLED work with every Budsy visual theme")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.LIGHT, title = "Light",
                subtitle = "Bright surfaces · dark readable text", icon = Icons.Rounded.WbSunny,
                mode = ThemeMode.SONY, onClick = { x.setAppearance(AppearanceMode.LIGHT) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.DARK, title = "Dark",
                subtitle = "Dark surfaces · selected theme accent", icon = Icons.Rounded.NightsStay,
                mode = ThemeMode.AURORA, onClick = { x.setAppearance(AppearanceMode.DARK) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.AMOLED, title = "AMOLED Black",
                subtitle = "Pure black background for OLED displays", icon = Icons.Rounded.Brightness4,
                mode = ThemeMode.NOTHING, onClick = { x.setAppearance(AppearanceMode.AMOLED) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.SYSTEM, title = "Follow system",
                subtitle = "Automatically follow Android Light / Dark setting", icon = Icons.Rounded.Settings,
                mode = ThemeMode.LIQUID, onClick = { x.setAppearance(AppearanceMode.SYSTEM) })
        }

        SectionLabel("Budsy themes", Icons.Rounded.Palette, "Choose a visual identity. Appearance is applied independently.")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val themeChoices = listOf(
                ThemeChoiceItem(ThemeMode.LIQUID, "iOS Liquid Glass", "Frosted glass · fluid blue-violet glow · clean SF-like typography", Icons.Rounded.WaterDrop),
                ThemeChoiceItem(ThemeMode.NOTHING, "Nothing Dot Matrix", "Monospace typography · dotted identity · black and lime", Icons.Rounded.Circle),
                ThemeChoiceItem(ThemeMode.AURORA, "OnePlus Aurora", "Graphite surfaces · confident red accents", Icons.Rounded.Bolt),
                ThemeChoiceItem(ThemeMode.SONY, "Sony Studio", "Precision audio · cool blue details", Icons.Rounded.GraphicEq),
                ThemeChoiceItem(ThemeMode.SPATIAL, "Spatial 3D", "Deep-space violet · luminous orbit", Icons.Rounded.Air)
            )
            themeChoices.forEach { choice ->
                ThemeChoiceCard(selected = x.theme == choice.mode, title = choice.title,
                    subtitle = choice.subtitle, icon = choice.icon, mode = choice.mode,
                    onClick = { x.setTheme(choice.mode) })
            }
        }

        SectionLabel("Touch feedback", Icons.Rounded.Vibration)
        SwitchRow("Tap sounds", "Play a short tone when you tap tiles and buttons", tapSound, icon = Icons.Rounded.VolumeUp) { tapSound = it; x.prefs.tapSound = it; Fx.sound = it }
        SwitchRow("Haptics", "Vibrate lightly on touch", haptics, icon = Icons.Rounded.Vibration) { haptics = it; x.prefs.haptics = it; Fx.haptics = it }

        SectionLabel(stringResource(R.string.diagnostics), Icons.Rounded.BugReport)
        SwitchRow(stringResource(R.string.diagnostics), stringResource(R.string.show_gesture_table_and_protocol_log), diag, icon = Icons.Rounded.BugReport) { diag = it; x.prefs.diag = it }
        if (diag) { HeroPreviewPicker(); Diagnostics(x) }
    }
    if (rename) AlertDialog(onDismissRequest = { rename = false }, title = { Text(stringResource(R.string.rename_device)) }, text = { TextField(value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true, label = { Text(stringResource(R.string.rename_hint)) }) }, confirmButton = { TextButton(onClick = { Buds.renameDevice(nameDraft); rename = false }) { Text(stringResource(R.string.save)) } }, dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.cancel)) } })
}

private data class ThemeChoiceItem(
    val mode: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector
)

@Composable
private fun ThemeChoiceCard(
    selected: Boolean, title: String, subtitle: String,
    icon: ImageVector, mode: Int, onClick: () -> Unit
) {
    val accent = when (mode) {
        ThemeMode.NOTHING -> Color(0xFFD8FF54)
        ThemeMode.AURORA -> Color(0xFFE84135)
        ThemeMode.SONY -> Color(0xFF84B8FF)
        ThemeMode.SPATIAL -> Color(0xFFB5A1FF)
        else -> Color(0xFF7DE3FF)
    }
    val transition = rememberInfiniteTransition(label = "themeIconMotion$mode")
    val pulse by transition.animateFloat(
        initialValue = 0.94f, targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            tween(if (mode == ThemeMode.NOTHING) 680 else if (mode == ThemeMode.SONY) 1500 else 1150, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "themeIconPulse$mode"
    )
    val drift by transition.animateFloat(
        initialValue = -2.5f, targetValue = 2.5f,
        animationSpec = infiniteRepeatable(tween(if (mode == ThemeMode.SPATIAL) 1900 else 1350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "themeIconDrift$mode"
    )
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) accent.copy(alpha = 0.09f) else P.sheet.copy(alpha = 0.72f))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) accent.copy(alpha = 0.8f) else P.line, shape)
            .tapFade { onClick() }.padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), P.tile))),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = title, tint = accent,
                modifier = Modifier.size(24.dp).graphicsLayer {
                    scaleX = if (selected) pulse else 1f
                    scaleY = if (selected) pulse else 1f
                    translationY = if (selected && (mode == ThemeMode.LIQUID || mode == ThemeMode.SONY)) drift else 0f
                    rotationZ = when {
                        !selected -> 0f
                        mode == ThemeMode.SPATIAL -> drift * 2.8f
                        mode == ThemeMode.NOTHING -> 0f
                        mode == ThemeMode.AURORA -> drift * 0.35f
                        else -> 0f
                    }
                })
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt(title, 15, FontWeight.SemiBold, P.text, maxLines = 1)
            Txt(subtitle, 12, color = P.sub, lineHeight = 16, maxLines = 2)
        }
        Spacer(Modifier.width(8.dp))
        if (selected) Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = accent, modifier = Modifier.size(22.dp))
        else Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = P.sub, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun Diagnostics(x: Ctx) {
    val b = x.b
    val logCopiedText = stringResource(R.string.log_copied)
    val clip = LocalClipboardManager.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ValueRow(stringResource(R.string.name_2), if (b.connected) b.deviceName else "\u2014", chevron = false, icon = Icons.Rounded.Badge)
        ValueRow(stringResource(R.string.bluetooth_address_2), if (b.connected) b.deviceAddr else "\u2014", chevron = false, icon = Icons.Rounded.Bluetooth)
        ValueRow(stringResource(R.string.status_2), if (b.connected) stringResource(R.string.connected) else b.status, chevron = false, icon = Icons.Rounded.Info)
        ValueRow(stringResource(R.string.firmware_2), if (b.connected) (b.firmware ?: "\u2014") else "\u2014", chevron = false, icon = Icons.Rounded.SystemUpdate)
        ValueRow(stringResource(R.string.connected_to_buds_2), if (b.connected && b.peers.isNotEmpty()) b.peers.joinToString(", ") else "\u2014", chevron = false, icon = Icons.Rounded.Devices)

        if (b.connected) WideButton(stringResource(R.string.disconnect_2), false, icon = Icons.Rounded.LinkOff) { b.disconnect() } else GlassPanel { ConnectBlock(x) }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Equalizer, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.custom_eq_saved_on_the_buds_read_only), 15, FontWeight.Medium, P.text)
            }
            Spacer(Modifier.height(6.dp))
            Txt(b.customEq ?: stringResource(R.string.nothing_read_yet), 13, FontWeight.Normal, P.sub, lineHeight = 18)
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Flag, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.feature_flags), 15, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.scan_2), false, icon = Icons.Rounded.Search) { b.scanFlags() }
            }
            Spacer(Modifier.height(6.dp))
            Txt(stringResource(R.string.to_find_a_switch_such_as_ear_detection_or_dual_c), 12, lineHeight = 17)
            Spacer(Modifier.height(6.dp))
            if (b.flags.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 13)
        }
        b.flags.toSortedMap().forEach { (id, v) ->
            SwitchRow(title = stringResource(R.string.flag_name_unknown, Protocol.hex(id).uppercase()), sub = "ID 0x${Protocol.hex(id).uppercase()}", on = v == 1, icon = Icons.Rounded.Flag) { Buds.setFlag(id, it) }
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.TouchApp, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.gesture_table_reported_by_the_buds), 15, FontWeight.Medium, P.text)
            }
            Spacer(Modifier.height(6.dp))
            val keys = b.gest.keys.sorted()
            if (keys.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 14)
            keys.forEach { k ->
                Txt(stringResource(R.string.gesture_table_entry, if (k / 16 == 1) stringResource(R.string.left) else if (k / 16 == 2) stringResource(R.string.right) else stringResource(R.string.gesture_side, k / 16), k % 16, Protocol.hex(b.gest[k] ?: 0).uppercase()), 13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp))
            }
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.BugReport, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.protocol_log), 15, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.copy), false, icon = Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(b.logText())); x.toast(logCopiedText) }
            }
            Spacer(Modifier.height(6.dp))
            val ver = b.logVersion
            val lines = remember(ver) { b.logText().lines().takeLast(14) }
            Txt(if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) stringResource(R.string.empty) else lines.joinToString("\n"), 11, FontWeight.Normal, P.sub, lineHeight = 15)
        }
        Txt(stringResource(R.string.unofficial_disclaimer), 12, lineHeight = 18, modifier = Modifier.padding(horizontal = 6.dp))
    }
}
