package com.nordbuds.studio.protocol

import java.io.ByteArrayOutputStream

/**
 * Reverse-engineered OPPO/OnePlus earbud control protocol.
 *
 * Frame: AA | length (LEB128, = 7 + payload length) | 00 00 | command-low |
 * command-group | sequence | payload-length16 LE | payload bytes.
 * The length is a LEB128 varint: identical to one plain byte below 128, two bytes
 * (e.g. 131 -> 83 01) from 128 up. Sequence numbers are 01..FE; FF marks a push
 * from the earbuds. Group 0x01 is query, 0x02 is unsolicited push/subscribe, 0x04 is
 * set and 0x05 are requests that the earbuds send to the phone. Replies set bit 7 of
 * the group byte (for example 0x0106 -> group 0x81).
 *
 * Commands observed in this implementation: 0x0105 firmware, 0x0106 battery,
 * 0x0108 gesture table, 0x0109 wear state, 0x010C noise/hold modes,
 * 0x010D feature flags, 0x010F EQ preset, 0x0112 peers, 0x0122 custom EQ,
 * 0x0124 BassWave, 0x0100 handshake, 0x0200/0x0205 event list/subscribe;
 * writes 0x0400 find earbuds, 0x0401 gesture, 0x0403 flag, 0x0404 ANC/hold,
 * 0x0406 preset, 0x0418 custom EQ, 0x041B BassWave. (0x0422 is the Spatial type, NOT custom EQ.)
 *
 * Gesture entry: [side, button, gestureId, functionId], side 1=left, 2=right,
 * button 1=main touch pad, 6=on-call group (never a main gesture).
 * This protocol is reverse engineered and has not been verified on every firmware.
 */
object Protocol {
    const val GRP_QUERY = 0x01
    const val GRP_PUSH = 0x02
    const val GRP_SET = 0x04
    const val ANC_OFF = 0
    const val ANC_ON = 1
    const val ANC_TRANSP = 2
    /** Feature switch ids (0x010D read / 0x0403 write). */
    const val FLAG_WEAR_DETECT = 0x04   // auto play/pause when a bud is taken out
    const val FLAG_GAME_MODE = 0x06
    const val FLAG_BASSWAVE = 0x1d
    /** Count first, then ids. Only ids the firmware has are returned, so extra ids are harmless. */
    val FEATURE_REQUEST = intArrayOf(7, 0x04, 0x05, 0x06, 0x0b, 0x11, 0x1b, 0x1d)
    /** Gesture button numbers. */
    const val BTN_MAIN = 1
    const val BTN_CALL = 6
    /** Push (0x0204) event codes. */
    const val EV_BATTERY = 1; const val EV_WEAR = 2; const val EV_ANC = 3; const val EV_GAME = 5; const val EV_PEERS = 6
    const val EV_CONNECTED_INFO = 0xF2
    /** Sequence numbers used for our own requests stay in 0x01..0xFE (0xFF = push from the buds). */
    fun nextSeq(seq: Int): Int = if (seq >= 0xFE || seq < 1) 1 else seq + 1

    data class Frame(val lo: Int, val hi: Int, val seq: Int, val payload: IntArray) {
        val cmd: Int get() = ((hi and 0x7f) shl 8) or lo
        val status: Int get() = payload.firstOrNull() ?: -1
        val isPush: Boolean get() = hi == GRP_PUSH && lo == 0x04
        /** True for an answer to something the phone sent (bit 7 of the group byte is set). */
        val isReply: Boolean get() = (hi and 0x80) != 0
        /** A request the earbuds send to the phone; it must be answered with the same sequence number. */
        val isRequestFromBuds: Boolean get() = !isReply && !isPush && hi >= 0x05
    }
    data class GestureEntry(val side: Int, val button: Int, val gesture: Int, val fn: Int)
    data class Battery(val slot: Int, val percent: Int, val charging: Boolean)
    data class Wear(val slot: Int, val flags: Int)
    data class Peer(val mac: String, val name: String)
    data class CustomEqProfile(val name: String, val active: Boolean, val bands: List<Pair<Int, Int>>, val id: Int = 0, val min: Int = -6, val max: Int = 6)


    fun commandName(command: Int): String = when (command) {
        0x0100 -> "Handshake"; 0x0105 -> "Firmware query"; 0x0106 -> "Battery query"
        0x0108 -> "Gesture table"; 0x0109 -> "Wear state"; 0x010C -> "ANC / hold query"
        0x010D -> "Feature discovery"; 0x010F -> "EQ preset query"; 0x0112 -> "Peer devices"
        0x0122 -> "Custom EQ query"; 0x0124 -> "BassWave query"; 0x0200 -> "Event list"
        0x0204 -> "Device event push"; 0x0205 -> "Event subscription"; 0x0400 -> "Find earbuds"
        0x0401 -> "Gesture write"; 0x0403 -> "Feature flag write"; 0x0404 -> "ANC / hold write"
        0x0406 -> "EQ preset write"; 0x0418 -> "Custom EQ write"; 0x041B -> "BassWave write"
        else -> "Unknown command"
    }

    fun hex(v: Int) = (v and 0xff).toString(16).padStart(2, '0')

    fun encodeLeb128(v: Int): ByteArray {
        var x = v; val out = ArrayList<Byte>()
        do { var b = x and 0x7f; x = x ushr 7; if (x != 0) b = b or 0x80; out += b.toByte() } while (x != 0)
        return out.toByteArray()
    }

    fun buildFrame(cmd: Int, group: Int, seq: Int, payload: IntArray): ByteArray {
        val len = encodeLeb128(7 + payload.size)
        val b = ByteArray(8 + len.size + payload.size)
        b[0] = 0xAA.toByte(); len.copyInto(b, 1)
        var o = 1 + len.size
        b[o++] = 0; b[o++] = 0
        b[o++] = (cmd and 0xff).toByte(); b[o++] = (group and 0xff).toByte(); b[o++] = (seq and 0xff).toByte()
        b[o++] = payload.size.toByte(); b[o++] = (payload.size ushr 8).toByte()
        payload.forEachIndexed { i, v -> b[o + i] = v.toByte() }
        return b
    }

    class Parser {
        private var buffer = ByteArray(0)
        fun feed(bytes: ByteArray): List<Frame> {
            if (bytes.isNotEmpty()) buffer += bytes
            val out = ArrayList<Frame>()
            while (true) {
                val start = buffer.indexOf(0xAA.toByte())
                if (start < 0) { buffer = ByteArray(0); break }
                if (start > 0) buffer = buffer.copyOfRange(start, buffer.size)
                if (buffer.size < 2) break
                // Length is a LEB128 varint (1 byte below 128, 2 bytes up to 16383).
                var len = 0; var shift = 0; var lenBytes = 0; var complete = false
                while (lenBytes < 3 && 1 + lenBytes < buffer.size) {
                    val b = buffer[1 + lenBytes].toInt() and 0xff
                    len = len or ((b and 0x7f) shl shift); shift += 7; lenBytes++
                    if (b and 0x80 == 0) { complete = true; break }
                }
                if (!complete) { if (lenBytes >= 3) { buffer = buffer.copyOfRange(1, buffer.size); continue } else break }
                if (len < 7 || len > 4096) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val total = 1 + lenBytes + len
                if (buffer.size < total) break
                val h = 1 + lenBytes + 2            // index of command-low (after the two pad bytes)
                val frame = buffer.copyOfRange(0, total)
                val payloadLen = (frame[h + 3].toInt() and 0xff) or ((frame[h + 4].toInt() and 0xff) shl 8)
                if (payloadLen != total - (h + 5)) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val payload = IntArray(payloadLen) { frame[h + 5 + it].toInt() and 0xff }
                out += Frame(frame[h].toInt() and 0xff, frame[h + 1].toInt() and 0xff, frame[h + 2].toInt() and 0xff, payload)
                buffer = buffer.copyOfRange(total, buffer.size)
            }
            return out
        }
    }

    fun parseBattery(p: IntArray): List<Battery> {
        if (p.size < 2) return emptyList()
        val count = p[1].coerceAtMost(20); val out = ArrayList<Battery>()
        repeat(count) { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size && p[j] in 1..3) {
                val raw = p[j + 1]; val pct = raw and 0x7f
                // The case only reports while its lid is open; 0 there means "not known", not an empty case.
                val unknown = pct > 100 || (p[j] == 3 && pct == 0)
                out += Battery(p[j] - 1, if (unknown) -1 else pct, raw and 0x80 != 0)
            }
        }
        return out
    }
    fun parseWear(p: IntArray): List<Wear> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(20)).mapNotNull { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size && p[j] in 1..3) Wear(p[j] - 1, p[j + 1]) else null
        }
    }
    fun parseFirmware(p: IntArray): String? = p.drop(2).mapNotNull { it.takeIf { c -> c in 32..126 }?.toChar() }.joinToString("").trim().ifEmpty { null }
    /** Every 4-byte [side, button, gesture, function] entry in a 0x0108 reply (status, count, entries...). */
    fun parseGestureEntries(p: IntArray): List<GestureEntry> {
        if (p.size < 2) return emptyList()
        val count = p[1].coerceAtMost(64); val out = ArrayList<GestureEntry>()
        repeat(count) { i ->
            val j = 2 + i * 4
            if (j + 3 < p.size) out += GestureEntry(p[j], p[j + 1], p[j + 2], p[j + 3])
        }
        return out
    }
    /**
     * Main-touch-pad gestures keyed by side * 16 + gesture. Only button 1 entries count: the on-call group
     * (button 6) repeats the same gesture numbers and used to overwrite the real mapping.
     */
    fun parseGestureTable(p: IntArray): Map<Int, Int> {
        val out = linkedMapOf<Int, Int>()
        for (e in parseGestureEntries(p)) if (e.button == BTN_MAIN && e.side in 1..2) out[e.side * 16 + e.gesture] = e.fn
        return out
    }
    /** Payload for SET 0x0401: [entry count, (side, button, gestureId, functionId)...]. side 1=left, 2=right. */
    fun buildGestureSet(side: Int, gid: Int, fn: Int): IntArray = intArrayOf(1, side, BTN_MAIN, gid, fn)
    /**
     * Write a gesture for every main-pad slot the earbuds list for (side, gesture); the table shape differs between
     * firmware revisions and writes. Falls back to a single button-1 entry when the table has none yet.
     */
    fun buildGestureWrite(table: List<GestureEntry>, side: Int, gid: Int, fn: Int): IntArray {
        val slots = table.filter { it.side == side && it.gesture == gid && it.button != BTN_CALL }.map { it.button }.distinct().ifEmpty { listOf(BTN_MAIN) }
        val out = ArrayList<Int>(); out += slots.size
        slots.forEach { b -> out += side; out += b; out += gid; out += fn }
        return out.toIntArray()
    }
    fun parseFlags(p: IntArray): List<Pair<Int, Int>> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(128)).mapNotNull { i ->
            val j = 2 + i * 2
            // Feature ID 0 is never requested; firmware may zero-pad the declared pair count.
            if (j + 1 < p.size && p[j] != 0) p[j] to p[j + 1] else null
        }
    }
    fun parsePeers(p: IntArray): List<Peer> {
        if (p.size < 2) return emptyList()
        val out = ArrayList<Peer>(); var i = 2
        repeat(p[1].coerceAtMost(8)) {
            if (i + 9 > p.size) return@repeat
            val mac = (0..5).joinToString(":") { hex(p[i + it]).uppercase() }
            val nameLen = p[i + 9]; if (i + 10 + nameLen > p.size) return@repeat
            val name = String(ByteArray(nameLen) { p[i + 10 + it].toByte() }, Charsets.UTF_8)
            out += Peer(mac, name); i += 10 + nameLen
        }
        return out
    }
    fun decodeAnc(mask: Int): Int = when {
        (mask and 0x0300) != 0 -> ANC_TRANSP
        (mask and 0x08F2) != 0 -> ANC_ON
        (mask and 0x0008) != 0 -> ANC_OFF
        // Plain codes used by the write path (1 = off, 2 = noise cancel, 4 = transparency).
        mask == 0x01 -> ANC_OFF
        mask == 0x04 -> ANC_TRANSP
        else -> -1
    }
    /** 0x0122 reply: [status, count, (selected, min, max, id, nameLen, name, bandCount, (freqLE16, gain)...)...]. */
    fun parseCustomEq(p: IntArray): List<CustomEqProfile> {
        if (p.size < 2) return emptyList()
        val out = ArrayList<CustomEqProfile>(); var i = 2
        repeat(p[1].coerceAtMost(16)) {
            try {
                if (i + 5 > p.size) return@repeat
                val base = i
                val active = p[base] == 1; val nameLen = p[base + 4]
                if (base + 5 + nameLen >= p.size) return@repeat
                val name = String(ByteArray(nameLen) { p[base + 5 + it].toByte() }, Charsets.UTF_8)
                i = base + 5 + nameLen; val bandsCount = p[i++]; val bands = ArrayList<Pair<Int, Int>>()
                repeat(bandsCount.coerceAtMost(32)) {
                    if (i + 2 < p.size) { bands += ((p[i] or (p[i + 1] shl 8)) to p[i + 2].toByte().toInt()); i += 3 }
                }
                out += CustomEqProfile(name, active, bands, id = p[base + 3], min = p[base + 1].toByte().toInt(), max = p[base + 2].toByte().toInt())
            } catch (_: Exception) { return out }
        }
        return out
    }
    const val EQ_CREATE = 1; const val EQ_SAVE_SELECT = 2; const val EQ_DELETE = 3
    /**
     * Exact payload used by HeyMelody's SetCommandManager command 1048 (0x0418).
     * Transport is the app's SPP/RFCOMM command channel; the outer vendor frame is
     * added by Link. Layout: action, min, max, id, UTF-8 name length/name, band count,
     * then repeated frequency-LE16 + signed gain-byte records.
     */
    fun buildCustomEqPayload(action: Int, profile: CustomEqProfile): IntArray =
        buildCustomEqSetPayload(action, profile.min, profile.max, profile.id, profile.name, profile.bands)

    /** Wanted events (offered by the earbuds in 0x8200) as a 0x0205 subscribe payload: [count, ids...]. */
    fun buildSubscribe(offered: Collection<Int>, wanted: List<Int> = listOf(EV_BATTERY, EV_WEAR, EV_ANC, EV_GAME, EV_PEERS)): IntArray {
        val ids = wanted.filter { it in offered }
        return intArrayOf(ids.size) + ids.toIntArray()
    }
    /** Event ids from a 0x8200 reply: [status, count, ids...]. */
    fun parseOfferedEvents(p: IntArray): List<Int> =
        if (p.size < 2) emptyList() else (0 until p[1].coerceAtMost(32)).mapNotNull { p.getOrNull(2 + it) }

    /** Answers the earbuds expect to the requests they send. Returns the reply payload, or null for push-only frames. */
    fun replyToRequest(f: Frame, unixSeconds: Long): IntArray? = when (f.cmd) {
        0x0500 -> intArrayOf(0, (unixSeconds and 0xff).toInt(), ((unixSeconds shr 8) and 0xff).toInt(), ((unixSeconds shr 16) and 0xff).toInt(), ((unixSeconds shr 24) and 0xff).toInt())
        0x050C -> intArrayOf(0, 1, 0)
        0x051C -> intArrayOf(0, 0, 0)
        0x051D -> intArrayOf(1)
        // Informational pushes (camera state/shutter, EQ changed, spatial type changed): the earbuds expect no answer.
        0x0501, 0x0502, 0x0504, 0x0510 -> null
        else -> intArrayOf(1)   // unknown request
    }
    /** The push events (0x0204) the earbuds expect an acknowledgement for, as the reply payload. */
    fun ackForPush(f: Frame): IntArray? = if (f.isPush && f.payload.firstOrNull() == EV_CONNECTED_INFO) intArrayOf(0, EV_CONNECTED_INFO) else null

    /**
     * Byte layout recovered from HeyMelody HeadsetCoreService.M0 / EqInfo.
     * The APK passes command 1048 (0x0418) to its SetCommandManager; 0x0422 is a
     * different command and must never be substituted for custom EQ.
     */
    fun buildCustomEqSetPayload(
        p3: Int,
        min: Int,
        max: Int,
        eqId: Int,
        name: String,
        bands: List<Pair<Int, Int>>
    ): IntArray {
        require(min in -128..255 && max in -128..255) { "EQ limits must fit one byte" }
        require(eqId in 0..255 && p3 in -128..255) { "EQ command fields must fit one byte" }
        require(bands.size <= 255) { "Too many EQ bands" }
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        require(nameBytes.size <= 255) { "EQ profile name is too long" }
        val out = ArrayList<Int>(5 + nameBytes.size + bands.size * 3)
        out += p3 and 0xff
        out += min and 0xff
        out += max and 0xff
        out += eqId and 0xff
        out += nameBytes.size
        nameBytes.forEach { out += it.toInt() and 0xff }
        out += bands.size
        bands.forEach { (hz, gain) ->
            require(hz in 0..65535) { "Band frequency must fit unsigned 16-bit" }
            require(gain in -128..127) { "Band gain must fit signed 8-bit" }
            out += hz and 0xff
            out += (hz ushr 8) and 0xff
            out += gain and 0xff
        }
        return out.toIntArray()
    }

    /** Compatibility alias retained for older callers; this is not a GATT encoder. */
    @Deprecated("Use buildCustomEqSetPayload; 0x0418 is the SetCommandManager custom-EQ payload")
    fun buildGattCustomEqPayload(
        p3: Int, min: Int, max: Int, eqId: Int, name: String, bands: List<Pair<Int, Int>>
    ): IntArray = buildCustomEqSetPayload(p3, min, max, eqId, name, bands)
}
