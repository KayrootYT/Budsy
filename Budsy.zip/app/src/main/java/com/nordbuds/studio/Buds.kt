package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nordbuds.studio.buds.Link
import com.nordbuds.studio.buds.Prefs
import com.nordbuds.studio.protocol.Protocol
import com.nordbuds.studio.widget.BudsWidgetProvider
import java.util.ArrayDeque
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** App-wide observable earbud state and protocol API. */
@SuppressLint("MissingPermission")
object Buds {
    const val ANC_OFF = Protocol.ANC_OFF
    const val ANC_ON = Protocol.ANC_ON
    const val ANC_TRANSP = Protocol.ANC_TRANSP
    const val G_SINGLE = 1; const val G_DOUBLE = 2; const val G_TRIPLE = 3; const val G_HOLD = 4; const val G_LONG = 6
    const val F_NONE = 0x00; const val F_PLAY = 0x01; const val F_VOICE = 0x03; const val F_PREV = 0x05; const val F_NEXT = 0x06; const val F_ANC = 0x08; const val F_VOL_UP = 0x0B; const val F_VOL_DN = 0x0C; const val F_GAME = 0x11
    const val M_OFF = 1; const val M_ANC = 2; const val M_TRANSP = 4
    val PRESETS = listOf(Triple(3, R.string.preset_balanced, R.string.preset_balanced_sub), Triple(4, R.string.preset_vocals, R.string.preset_vocals_sub), Triple(5, R.string.preset_bass, R.string.preset_bass_sub))
    data class Msg(val id: Int, val res: Int, val args: List<Any> = emptyList())
    enum class SaveState { IDLE, SAVING, SAVED, FAILED }

    private lateinit var appCtx: Context
    lateinit var prefs: Prefs; private set
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var link: Link
    var status by mutableStateOf(""); private set
    var connected by mutableStateOf(false); private set
    var connecting by mutableStateOf(false); private set
    /** True while the RFCOMM socket is open, before the earbuds have answered (not yet shown as connected). */
    @Volatile private var linkUp = false
    @Volatile private var gotFrames = 0
    @Volatile private var lastRx = 0L
    var searching by mutableStateOf(false)
    var autoPaused by mutableStateOf(false); private set
    var btEnabled by mutableStateOf(true)
    var deviceName by mutableStateOf(""); private set
    var deviceAddr by mutableStateOf(""); private set
    var customName by mutableStateOf<String?>(null); private set
    val displayName: String get() = customName ?: deviceName
    val battery = mutableStateListOf(-1, -1, -1)
    val charging = mutableStateListOf(false, false, false)
    var ancMode by mutableIntStateOf(-1); private set
    var ancSaveState by mutableStateOf(SaveState.IDLE); private set
    var ancSaveMessage by mutableStateOf(""); private set
    private var ancVerifyJob: Job? = null
    var holdMask by mutableIntStateOf(-1); private set
    var holdSaveState by mutableStateOf(SaveState.IDLE); private set
    var holdSaveMessage by mutableStateOf(""); private set
    var findAlertRequested by mutableStateOf(false); private set
    var findAlertSide by mutableIntStateOf(3); private set
    var findAlertMessage by mutableStateOf(""); private set
    var gestSaveState by mutableStateOf(SaveState.IDLE); private set
    var gestSaveMessage by mutableStateOf(""); private set
    private var gestJob: Job? = null
    private var pendingHoldMask: Int? = null
    private var holdVerifyTries = 0
    private var holdVerifyJob: Job? = null
    var eqPreset by mutableIntStateOf(-1); private set
    var gameMode by mutableStateOf<Boolean?>(null); private set
    var bassOn by mutableStateOf<Boolean?>(null); private set
    var bassLevel by mutableStateOf<Int?>(null); private set
    var bassMin by mutableIntStateOf(-10); private set
    var bassMax by mutableIntStateOf(10); private set
    var wearDetect by mutableStateOf<Boolean?>(null); private set
    val gest = mutableStateMapOf<Int, Int>()
    var msg by mutableStateOf<Msg?>(null); private set
    var logVersion by mutableIntStateOf(0); private set
    var firmware by mutableStateOf<String?>(null); private set
    val wear = mutableStateListOf(-1, -1, -1)
    /** The protocol exposes no case-lid message, so the lid is never inferred. */
    val lidState: LidState get() = LidState.UNKNOWN
    val leftPos: BudPos get() = budPosFromWear(wear[0])
    val rightPos: BudPos get() = budPosFromWear(wear[1])
    val flags = mutableStateMapOf<Int, Int>()
    var customEq by mutableStateOf<String?>(null); private set
    val customEqProfiles = mutableStateListOf<Protocol.CustomEqProfile>()
    val peers = mutableStateListOf<String>()
    var keepAlive by mutableStateOf(false); private set
    var dualFlagId by mutableIntStateOf(-1); private set
    fun updateKeepAlive(on: Boolean) { keepAlive = on; prefs.keepAlive = on }
    fun setDualFlag(id: Int) { dualFlagId = id; prefs.dualFlagId = id }
    private var heartbeatJob: Job? = null
    private var msgSeq = 0
    private var pendingAnc = -1
    private var ancAcked = false
    private var holdAcked = false
    /** Raw 4-byte gesture entries from the last 0x0108 reply; writes mirror every main-pad slot the table lists. */
    @Volatile private var gestEntries: List<Protocol.GestureEntry> = emptyList()
    @Volatile private var gestTableSeen = false
    @Volatile private var subscribed = false
    private var findLegacyTried = false
    private val ancCode = intArrayOf(1, 2, 4)
    private val pendingGest = HashMap<Int, Int>()
    private var verifyGest = false
    private var verifyTries = 0
    private var bassRawMin = 0xF6
    private var bassRawMax = 0x0A
    private val logBuf = ArrayDeque<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun attach(ctx: Context) {
        if (::appCtx.isInitialized) return
        appCtx = ctx.applicationContext; prefs = Prefs(appCtx); ProtocolLab.attach(appCtx)
        status = str(R.string.status_not_connected)
        autoPaused = prefs.autoPaused; customName = prefs.customName; keepAlive = prefs.keepAlive; dualFlagId = prefs.dualFlagId
        link = Link(scope, ::onFrame, ::onDropped) { direction, frame ->
            ProtocolLab.record(direction, frame.lo, frame.hi, frame.payload, frame.seq)
        }
        BatteryNotifier.ensureChannel(appCtx)
    }
    fun isAttached(): Boolean = ::appCtx.isInitialized
    fun str(res: Int, vararg args: Any): String = appCtx.getString(res, *args)
    fun say(res: Int, vararg args: Any) { msg = Msg(++msgSeq, res, args.toList()) }
    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun logText(): String = synchronized(logBuf) { logBuf.joinToString("\n") }
    private fun note(dir: String, lo: Int, hi: Int, p: IntArray) {
        synchronized(logBuf) { logBuf.addLast("$dir ${Protocol.hex(hi)}${Protocol.hex(lo)} " + p.joinToString(" ") { Protocol.hex(it) }); while (logBuf.size > 150) logBuf.removeFirst() }
        logVersion++
    }
    private fun notifyChanged() { listeners.forEach { it() }; if (::appCtx.isInitialized) { BudsWidgetProvider.notifyUpdate(appCtx); BatteryNotifier.update(appCtx) } }
    private fun send(cmd: Int, grp: Int, vararg pl: Int) { note("TX", cmd, grp, pl); link.write(cmd, grp, pl) }
    private fun query(ms: Int, cmd: Int, vararg pl: Int) { scope.launch { delay(ms.toLong()); if (connected || linkUp) send(cmd, Protocol.GRP_QUERY, *pl) } }

    private fun beginConnect(auto: Boolean): Boolean {
        if (auto && autoPaused) return false
        if (!auto && autoPaused) { autoPaused = false; prefs.autoPaused = false }
        if (connecting || connected) return false
        connecting = true; status = str(R.string.status_connecting); ancSaveState = SaveState.IDLE; ancSaveMessage = ""; findAlertMessage = ""
        return true
    }
    fun connect(d: BluetoothDevice, auto: Boolean = false) {
        if (!beginConnect(auto)) return
        scope.launch { runConnect(d, 0) }
    }
    /** Same as [connect] but suspends until the attempt is finished (used by the background receiver). */
    suspend fun connectAwait(d: BluetoothDevice, retries: Int = 2) {
        if (!beginConnect(true)) return
        runConnect(d, retries)
    }
    private suspend fun runConnect(d: BluetoothDevice, retries: Int) {
        try {
            var dev: BluetoothDevice? = null
            var attempt = 0
            while (dev == null && attempt <= retries) {
                dev = try { link.connect(d) } catch (_: Exception) { null }
                if (dev == null && attempt < retries) delay(1500)
                attempt++
            }
            if (dev == null) { if (!connected) status = str(R.string.status_no_channel); return }
            // An open socket is NOT a connection: wait until the earbuds really answer.
            gotFrames = 0; linkUp = true
            initialRead()
            var waited = 0; var answered = false
            while (waited < 6000 && linkUp) {
                delay(300); waited += 300
                if (gotFrames > 0) { answered = true; break }
                if (waited % 1500 == 0) send(6, Protocol.GRP_QUERY)
            }
            if (!answered) {
                linkUp = false; link.close(true)
                status = str(R.string.status_no_response)
                return
            }
            deviceName = dev.name ?: dev.address; deviceAddr = dev.address; prefs.lastAddr = deviceAddr
            lastRx = SystemClock.elapsedRealtime()
            connected = true; status = str(R.string.status_connected_to, displayName)
            // Do not change ANC automatically on connect. Read the reported mode first and
            // preserve the user's existing listening preference unless they explicitly change it.
            heartbeatJob?.cancel()
            heartbeatJob = scope.launch {
                var tick = 0
                while (isActive && connected) {
                    delay(2000); tick++
                    if (!connected) break
                    // Wear/case position is polled often so the hero animation follows the buds quickly.
                    send(9, Protocol.GRP_QUERY)
                    // Keep asking until every battery slot has a value, then every 10 s.
                    if (tick % 5 == 0 || (tick < 20 && battery.any { it < 0 })) send(6, Protocol.GRP_QUERY)
                    if (tick % 5 == 0) { send(0x0c, Protocol.GRP_QUERY, 1, 1); send(0x0c, Protocol.GRP_QUERY, 2, 1); send(0x0d, Protocol.GRP_QUERY, *Protocol.FEATURE_REQUEST) }
                    // Watchdog: a link that stopped answering is a fake connection, drop it so auto-connect can retry.
                    if (SystemClock.elapsedRealtime() - lastRx > 30000) {
                        link.close(true); cleanup("Earbuds stopped responding"); break
                    }
                }
            }
        } finally {
            connecting = false
            notifyChanged()
        }
    }
    fun resumeAutoConnect() { autoPaused = false; prefs.autoPaused = false }
    fun disconnect() { autoPaused = true; prefs.autoPaused = true; link.close(true); cleanup(str(R.string.status_auto_off)) }
    private fun onDropped(reason: String) { linkUp = false; if (connected) cleanup(reason) }
    private fun cleanup(statusMsg: String) {
        linkUp = false; connected = false; subscribed = false; gestTableSeen = false; gestEntries = emptyList(); heartbeatJob?.cancel(); heartbeatJob = null; verifyGest = false; pendingGest.clear(); gestJob?.cancel(); gestSaveState = SaveState.IDLE; gestSaveMessage = ""; pendingAnc = -1; pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.IDLE; ancVerifyJob?.cancel(); ancSaveState = SaveState.IDLE; findAlertRequested = false; findAlertMessage = ""
        for (i in 0..2) { battery[i] = -1; charging[i] = false; wear[i] = -1 }
        peers.clear(); status = statusMsg; notifyChanged()
    }
    /**
     * Same order as the OPOv1 captures: handshake, product, event list (subscribe happens when it is answered),
     * feature switches, noise control, battery, wear, gestures, hold cycle, then the extras this app shows.
     */
    private fun initialRead(full: Boolean = true) {
        scope.launch {
            val g = Protocol.GRP_QUERY
            val q = ArrayList<Triple<Int, Int, IntArray>>()
            if (full) { subscribed = false; delay(300); q += Triple(0x00, g, intArrayOf()); q += Triple(0x03, g, intArrayOf()); q += Triple(0x00, Protocol.GRP_PUSH, intArrayOf()) }
            q += Triple(0x0d, g, Protocol.FEATURE_REQUEST); q += Triple(0x0c, g, intArrayOf(1, 1)); q += Triple(0x06, g, intArrayOf())
            q += Triple(0x09, g, intArrayOf()); q += Triple(0x08, g, intArrayOf()); q += Triple(0x0c, g, intArrayOf(2, 1))
            q += Triple(0x0f, g, intArrayOf()); q += Triple(0x24, g, intArrayOf()); q += Triple(0x05, g, intArrayOf())
            q += Triple(0x22, g, intArrayOf()); q += Triple(0x12, g, intArrayOf())
            gestTableSeen = false
            for ((c, grp, pl) in q) { if (!connected && !linkUp) break; send(c, grp, *pl); delay(120) }
            // Some firmwares only answer the filtered gesture query used by older builds of this app.
            delay(2500)
            if (!gestTableSeen && (connected || linkUp)) send(8, g, 2, 3, 1)
            if (full && (connected || linkUp)) { delay(300); scanFlags(true) }
        }
    }
    fun refreshAll() { if (connected) initialRead(full = false) }
    fun scanFlags(silent: Boolean = false) {
        if (silent) { if (!connected && !linkUp) return } else if (!need()) return
        scope.launch { var id = 1; while (id <= 0x20 && (connected || linkUp)) { val n = minOf(15, 0x20 - id + 1); send(0x0d, Protocol.GRP_QUERY, *IntArray(n + 1) { if (it == 0) n else id + it - 1 }); id += n; delay(150) } }
    }
    /**
     * 0x0400 01 starts the tone, 0x0400 00 stops it (OPOv1 captures). A single side adds the side id, which both
     * the "start + side" and the older "count + side list" encodings read as left/right. If the earbuds refuse the
     * plain "both" start, the older [2, 1, 2] list is tried once.
     */
    fun findEarbuds(side: Int) {
        if (!need()) return
        findAlertSide = side.coerceIn(1, 3)
        findLegacyTried = false
        findAlertRequested = true
        findAlertMessage = "Alert command sent · waiting for the earbuds…"
        send(0, Protocol.GRP_SET, *(if (findAlertSide == 3) intArrayOf(1) else intArrayOf(1, findAlertSide)))
        notifyChanged()
    }

    fun stopFindEarbuds() {
        if (!need()) return
        send(0, Protocol.GRP_SET, 0)
        findAlertRequested = false
        findAlertMessage = "Stop sent · waiting for the earbuds…"
        notifyChanged()
    }

    private fun answerRequest(f: Protocol.Frame) {
        val reply = Protocol.replyToRequest(f, System.currentTimeMillis() / 1000) ?: return
        note("TX", f.lo, f.hi or 0x80, reply)
        link.reply(f, reply)
    }

    private fun onOfferedEvents(p: IntArray) {
        if (subscribed) return
        subscribed = true
        val payload = Protocol.buildSubscribe(Protocol.parseOfferedEvents(p))
        if (payload[0] > 0) send(0x05, Protocol.GRP_PUSH, *payload)
    }

    /** Hold-cycle mask from a 0x010C 02 01 reply or a 03 02 01 push; confirms a pending Hold write. */
    private fun onHoldValue(mask: Int) {
        val actual = mask and 7
        val expected = pendingHoldMask
        if (expected == null) { holdMask = actual; return }
        when {
            actual == expected -> {
                holdMask = actual; pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.SAVED
                holdSaveMessage = "Earbud confirmed the Hold setting"
            }
            holdVerifyTries < 2 -> { holdVerifyTries++; query(500, 0x0c, 2, 1) }
            holdAcked -> {
                // Accepted by the earbuds (status 0) but reported back differently: keep what the user chose.
                holdMask = expected; pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.SAVED
                holdSaveMessage = "Earbud accepted the Hold setting"
            }
            else -> {
                holdMask = actual; pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.FAILED
                holdSaveMessage = "Earbud value did not match the selected setting"
            }
        }
    }

    private fun onFrame(f: Protocol.Frame) {
        gotFrames++; lastRx = SystemClock.elapsedRealtime()
        note("RX", f.lo, f.hi, f.payload); val p = f.payload
        // The earbuds ask the phone things too (time, capabilities). Unanswered, they stop replying and reset the link.
        if (f.isRequestFromBuds) {
            if (f.cmd == 0x0504 && p.isNotEmpty()) eqPreset = p[0]   // "EQ changed <id>" push, e.g. from the earbuds' own controls
            answerRequest(f); notifyChanged(); return
        }
        if (f.isPush) {
            Protocol.ackForPush(f)?.let { note("TX", f.lo, f.hi or 0x80, it); link.reply(f, it) }
            if (p.isNotEmpty()) when (p[0]) {
                Protocol.EV_BATTERY -> onBattery(p)
                Protocol.EV_WEAR -> onWear(p)
                // 03 01 01 <mask> is the Noise Control mode; 03 02 01 <mask> is the Hold cycle and 03 04 01 the Smart level - not modes.
                Protocol.EV_ANC -> if (p.size >= 4 && p[2] == 1) {
                    val mask = p[3] or (if (p.size > 4) p[4] shl 8 else 0)
                    if (p[1] == 1) onAncValue(mask) else if (p[1] == 2) onHoldValue(mask)
                }
                Protocol.EV_GAME -> if (p.size >= 2) gameMode = p[p.size - 1] == 1
                Protocol.EV_PEERS -> { peers.clear(); peers.addAll(Protocol.parsePeers(p).map { it.name.ifEmpty { it.mac } }) }
            }
            notifyChanged(); return
        }
        if (p.isEmpty()) return
        val st = p[0]
        when (f.cmd) {
            0x0200 -> if (st == 0) onOfferedEvents(p)
            0x0106 -> if (st == 0) onBattery(p)
            0x0105 -> if (st == 0) Protocol.parseFirmware(p)?.let { firmware = it }
            0x0109 -> if (st == 0) onWear(p)
            0x0122 -> if (st == 0) { val profs = Protocol.parseCustomEq(p); customEqProfiles.clear(); customEqProfiles.addAll(profs); customEq = formatCustomEq(profs) }
            0x0112 -> if (st == 0) { peers.clear(); peers.addAll(Protocol.parsePeers(p).map { it.name.ifEmpty { it.mac } }) }
            0x0108 -> if (st == 0 && p.size >= 2) onGestureTable(p)
            0x010C -> if (st == 0 && p.size >= 4 && p[2] == 1) {
                val mask = p[3] or (if (p.size > 4) p[4] shl 8 else 0)
                if (p[1] == 1) onAncValue(mask) else if (p[1] == 2) onHoldValue(mask)
            }
            0x010D -> if (st == 0) for ((id, v) in Protocol.parseFlags(p)) { flags[id] = v; when (id) { Protocol.FLAG_GAME_MODE -> gameMode = v == 1; Protocol.FLAG_BASSWAVE -> bassOn = v == 1; Protocol.FLAG_WEAR_DETECT -> wearDetect = v == 1 } }
            0x010F -> if (st == 0 && p.size >= 2) eqPreset = p[1]
            0x0124 -> if (st == 0 && p.size >= 4) { bassRawMin = p[1]; bassRawMax = p[2]; val mn = p[1].toByte().toInt(); val mx = p[2].toByte().toInt(); if (mn < mx) { bassMin = mn; bassMax = mx }; bassLevel = p[3].toByte().toInt().coerceIn(bassMin, bassMax) }
            0x0401 -> {
                if (st != 0) {
                    say(R.string.err_refused_gesture, Protocol.hex(st)); pendingGest.clear(); verifyGest = false; gestJob?.cancel()
                    gestSaveState = SaveState.FAILED; gestSaveMessage = "Earbud refused the gesture (${Protocol.hex(st)}). Showing its current setting."
                    query(200, 8)
                } else { verifyGest = true; verifyTries = 0; query(500, 8) }
            }
            0x0403 -> { if (st != 0) say(R.string.err_refused_setting, Protocol.hex(st)); query(200, 0x0d, *Protocol.FEATURE_REQUEST) }
            0x0404 -> {
                if (st != 0) {
                    // 0x0404 carries both Noise Control and Hold writes; blame only the one that is actually pending.
                    val holdWas = pendingHoldMask != null
                    if (holdWas) {
                        pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.FAILED
                        holdSaveMessage = "Earbud rejected the Hold setting (${Protocol.hex(st)})"
                    }
                    if (pendingAnc >= 0 || !holdWas) {
                        pendingAnc = -1
                        ancVerifyJob?.cancel()
                        ancSaveState = SaveState.FAILED
                        ancSaveMessage = "Earbuds rejected Noise Control (${Protocol.hex(st)})"
                    }
                    say(if (st == 0x0e) R.string.err_anc_ears else R.string.err_anc_failed, Protocol.hex(st))
                }
                else {
                    // The earbuds accepted the write. Show the new value at once; the read-back below confirms it.
                    if (pendingAnc >= 0) { ancAcked = true; ancMode = pendingAnc }
                    if (pendingHoldMask != null) { holdAcked = true; holdMask = pendingHoldMask!! }
                }
                query(200, 0x0c, 1, 1); query(350, 0x0c, 2, 1)
            }
            0x0406 -> { if (st != 0) say(R.string.err_refused_preset, Protocol.hex(st)); query(200, 0x0f) }
            0x041B -> { if (st != 0) say(R.string.err_refused_bass, Protocol.hex(st)); query(200, 0x24) }
            0x0418 -> { if (st != 0) say(R.string.err_refused_setting, Protocol.hex(st)); query(300, 0x22) }
            0x0400 -> {
                if (st == 0) findAlertMessage = if (findAlertRequested) "Earbuds confirmed the alert" else "Earbuds confirmed the alert stopped"
                else if (findAlertRequested && findAlertSide == 3 && !findLegacyTried) {
                    findLegacyTried = true; findAlertMessage = "Retrying with the older alert format…"; send(0, Protocol.GRP_SET, 2, 1, 2)
                } else { findAlertRequested = false; findAlertMessage = "Earbuds refused the alert (${Protocol.hex(st)})" }
            }
        }
        notifyChanged()
    }
    private fun formatCustomEq(profs: List<Protocol.CustomEqProfile>): String? = if (profs.isEmpty()) str(R.string.custom_eq_none) else profs.joinToString("\n") { pr -> pr.name + (if (pr.active) " (active)" else "") + ": " + pr.bands.mapIndexed { i, (hz, g) -> (if (hz >= 1000) "${hz / 1000}k" else "$hz") + " " + (if (g > 0) "+$g" else "$g") + if (i < pr.bands.size - 1) " · " else "" }.joinToString("") }
    private fun onBattery(p: IntArray) { Protocol.parseBattery(p).forEach { b -> if (b.slot in 0..2) { battery[b.slot] = b.percent; charging[b.slot] = b.charging } }; notifyChanged() }
    private fun onWear(p: IntArray) { Protocol.parseWear(p).forEach { if (it.slot in 0..2) wear[it.slot] = it.flags } }
    private fun onAncValue(mask: Int) {
        val m = Protocol.decodeAnc(mask); if (m < 0) return
        val want = pendingAnc
        if (want >= 0) {
            if (m == want) { pendingAnc = -1; ancVerifyJob?.cancel(); ancSaveState = SaveState.SAVED; ancSaveMessage = "Earbuds confirmed Noise Control" }
            else { ancSaveState = SaveState.SAVING; ancSaveMessage = "Waiting for Noise Control confirmation…" }
        }
        ancMode = m
    }
    private fun onGestureTable(p: IntArray) {
        gestTableSeen = true; gestEntries = Protocol.parseGestureEntries(p)
        val pend = HashMap(pendingGest); val table = Protocol.parseGestureTable(p)
        table.forEach { (k, v) -> if (!pend.containsKey(k)) gest[k] = v }
        if (!verifyGest) return
        // A gesture set to None may be reported as disabled/missing, so a missing entry counts as F_NONE.
        val bad = pend.filter { (k, v) -> (table[k] ?: F_NONE) != v }
        if (bad.isNotEmpty() && verifyTries < 2) { verifyTries++; query(700, 8); return }
        verifyGest = false
        // Only drop the writes that were verified here; a newer write made meanwhile stays pending.
        pend.forEach { (k, v) -> if (pendingGest[k] == v) pendingGest.remove(k) }
        table.forEach { (k, v) -> if (!pendingGest.containsKey(k)) gest[k] = v }
        bad.keys.forEach { k -> if (!pendingGest.containsKey(k)) gest[k] = table[k] ?: F_NONE }
        if (pendingGest.isEmpty()) {
            gestJob?.cancel()
            if (bad.isEmpty()) { gestSaveState = SaveState.SAVED; gestSaveMessage = "Earbud confirmed the gesture" }
            else { gestSaveState = SaveState.FAILED; gestSaveMessage = "Earbud kept its previous gesture"; say(R.string.err_gesture_kept) }
        }
    }
    private fun need(): Boolean { if (!connected) { say(R.string.err_connect_first); return false }; return true }
    fun setAnc(mode: Int) {
        if (!need() || mode !in 0..2) return
        pendingAnc = mode; ancAcked = false
        ancSaveState = SaveState.SAVING
        ancSaveMessage = "Sending Noise Control setting…"
        ancVerifyJob?.cancel()
        send(4, Protocol.GRP_SET, 1, 1, ancCode[mode])
        ancVerifyJob = scope.launch {
            delay(450)
            if (connected && pendingAnc == mode) send(0x0c, Protocol.GRP_QUERY, 1, 1)
            delay(1800)
            if (connected && pendingAnc == mode) {
                pendingAnc = -1
                if (ancAcked) { ancMode = mode; ancSaveState = SaveState.SAVED; ancSaveMessage = "Earbuds accepted Noise Control" }
                else {
                    ancSaveState = SaveState.FAILED
                    ancSaveMessage = "No reply from the earbuds. Showing the last reported state"
                    query(100, 0x0c, 1, 1)
                }
                notifyChanged()
            }
        }
        notifyChanged()
    }
    fun updateHoldMask(mask: Int) {
        if (!need()) return
        val m = mask and 7
        if (m == 0) { holdSaveState = SaveState.FAILED; holdSaveMessage = "Select at least one Hold mode"; return }
        pendingHoldMask = m; holdAcked = false; holdVerifyTries = 0; holdSaveState = SaveState.SAVING
        holdSaveMessage = "Sending setting to earbuds…"
        holdVerifyJob?.cancel()
        send(4, Protocol.GRP_SET, 2, 1, m)
        holdVerifyJob = scope.launch {
            delay(500)
            if (connected && pendingHoldMask != null) send(0x0c, Protocol.GRP_QUERY, 2, 1)
            delay(1600)
            if (connected && pendingHoldMask != null) {
                val want = pendingHoldMask!!
                pendingHoldMask = null
                if (holdAcked) { holdMask = want; holdSaveState = SaveState.SAVED; holdSaveMessage = "Earbud accepted the Hold setting" }
                else { holdSaveState = SaveState.FAILED; holdSaveMessage = "No reply from the earbuds. Current value is shown."; query(100, 0x0c, 2, 1) }
                notifyChanged()
            }
        }
        notifyChanged()
    }
    fun queryHold() {
        if (connected) {
            if (pendingHoldMask == null) { holdSaveState = SaveState.IDLE; holdSaveMessage = "" }
            send(0x0c, Protocol.GRP_QUERY, 2, 1)
        }
    }
    fun setGesture(side: Int, gid: Int, fn: Int) {
        if (!need()) return
        val k = side * 16 + gid; gest[k] = fn; pendingGest[k] = fn
        gestSaveState = SaveState.SAVING; gestSaveMessage = "Sending gesture to earbud…"
        send(1, Protocol.GRP_SET, *Protocol.buildGestureWrite(gestEntries, side, gid, fn))
        gestJob?.cancel()
        gestJob = scope.launch {
            delay(5000)
            if (connected && pendingGest.isNotEmpty()) {
                pendingGest.clear(); verifyGest = false
                gestSaveState = SaveState.FAILED; gestSaveMessage = "No reply from the earbud. Showing its current setting."
                send(8, Protocol.GRP_QUERY); notifyChanged()
            }
        }
        notifyChanged()
    }
    fun setEq(id: Int) { if (!need()) return; eqPreset = id; send(6, Protocol.GRP_SET, id) }
    fun setGame(on: Boolean) { setFlag(Protocol.FLAG_GAME_MODE, on) }
    fun setBassOn(on: Boolean) { setFlag(Protocol.FLAG_BASSWAVE, on) }
    fun setBassLevel(level: Int) { if (!need()) return; val l = level.coerceIn(bassMin, bassMax); bassLevel = l; send(0x1b, Protocol.GRP_SET, bassRawMin, bassRawMax, l and 255) }
    fun setFlag(id: Int, on: Boolean) {
        if (!need()) return
        flags[id] = if (on) 1 else 0
        when (id) { Protocol.FLAG_GAME_MODE -> gameMode = on; Protocol.FLAG_BASSWAVE -> bassOn = on; Protocol.FLAG_WEAR_DETECT -> wearDetect = on }
        send(3, Protocol.GRP_SET, id, if (on) 1 else 0)
    }
    /** Auto play/pause when a bud is taken out (feature 0x04). 0x0B is Golden Sound, not ear detection. */
    fun setWearDetect(on: Boolean) { setFlag(Protocol.FLAG_WEAR_DETECT, on) }
    /**
     * Saves the band gains as the earbuds' custom EQ with command 0x0418 (not 0x0422, which is the Spatial type):
     * updates and selects the existing profile, or creates one when the earbuds have none. The list is re-read after.
     */
    fun writeCustomEq(bands: List<Pair<Int, Int>>, name: String? = null) {
        if (!need() || bands.isEmpty()) return
        val existing = customEqProfiles.firstOrNull { it.active } ?: customEqProfiles.firstOrNull()
        val profile = Protocol.CustomEqProfile(name ?: existing?.name ?: "Custom", true, bands.map { it.first to it.second.coerceIn(-6, 6) }, id = existing?.id ?: 0)
        val action = if (existing == null) Protocol.EQ_CREATE else Protocol.EQ_SAVE_SELECT
        send(0x18, Protocol.GRP_SET, *Protocol.buildCustomEqPayload(action, profile))
    }
    fun renameDevice(name: String?) { customName = name?.trim()?.takeIf { it.isNotEmpty() }; prefs.customName = customName; if (connected) status = str(R.string.status_connected_to, displayName); notifyChanged() }
}
