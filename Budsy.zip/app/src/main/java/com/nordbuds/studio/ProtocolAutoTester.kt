package com.nordbuds.studio

import com.nordbuds.studio.protocol.Protocol

/** Conservative, read-only verification based on Budsy's own request/response captures. */
object ProtocolAutoTester {
    enum class Status { PASS, PARTIAL, FAIL, UNVERIFIED }
    data class Result(
        val feature: String,
        val status: Status,
        val evidence: String,
        val nextStep: String = ""
    )

    fun evaluate(
        events: List<ProtocolLab.Event>,
        since: Long,
        connected: Boolean,
        deviceName: String,
        deviceAddress: String,
        ancMode: Int,
        eqPreset: Int,
        gameMode: Boolean?,
        bassLevel: Int?,
        firmware: String?,
        peerCount: Int,
        gattState: String
    ): List<Result> {
        val recent = events.filter { it.time >= since }
        fun reply(command: Int): ProtocolLab.Event? = recent.lastOrNull {
            it.direction.equals("RX", true) && it.command == command && it.matched
        }
        fun statusResult(command: Int, feature: String, detail: String): Result {
            val r = reply(command) ?: return Result(feature, if (recent.any { it.direction == "TX" && it.command == command }) Status.FAIL else Status.UNVERIFIED,
                if (recent.any { it.direction == "TX" && it.command == command }) "Query sent, but no matching response received" else "No query/response captured",
                "Repeat the read-only test while connected and capture is active")
            if (r.payload.firstOrNull() != 0) return Result(feature, Status.FAIL,
                "Device returned status ${r.payload.firstOrNull() ?: "missing"}", "Check model/firmware compatibility")
            return Result(feature, Status.PARTIAL, "$detail; response acknowledged, but decoded state was incomplete")
        }

        val out = mutableListOf<Result>()
        out += if (connected && deviceAddress.isNotBlank()) Result("Earbud control connection", Status.PASS,
            "$deviceName · $deviceAddress · Budsy received a live device response")
        else Result("Earbud control connection", Status.FAIL, "No authenticated Budsy control session", "Connect the earbuds first")

        val matched = recent.count { it.direction.equals("RX", true) && it.matched }
        out += if (matched > 0) Result("Request / response transport", Status.PASS,
            "$matched request(s) received a sequence-matched response during this run")
        else Result("Request / response transport", if (recent.any { it.direction == "TX" }) Status.FAIL else Status.UNVERIFIED,
            "No sequence-matched response was captured", "Keep Protocol capture enabled and retry")

        val batteryReply = reply(0x0106)
        val parsedBattery = batteryReply?.payload?.let { Protocol.parseBattery(it.toIntArray()) }.orEmpty()
        out += if (batteryReply != null && batteryReply.payload.firstOrNull() == 0 && parsedBattery.any { it.percent in 0..100 })
            Result("Battery read-back", Status.PASS, parsedBattery.joinToString { "${listOf("Left", "Right", "Case").getOrElse(it.slot) { "Slot" }} ${it.percent}%${if (it.charging) " charging" else ""}" })
        else statusResult(0x0106, "Battery read-back", "Battery response received")

        val ancReply = recent.lastOrNull { it.direction.equals("RX", true) && it.command == 0x010C && it.matched && it.payload.getOrNull(1) == 1 }
        out += if (ancReply != null && ancReply.payload.firstOrNull() == 0 && ancReply.payload.size >= 4 && ancReply.payload[1] == 1 && ancReply.payload[2] == 1 && ancMode in 0..2)
            Result("ANC state read-back", Status.PASS, "Device returned a valid ANC state (mode=$ancMode). Acoustic noise cancellation still needs a listening test.", "Switch ANC/Off/Transparency and confirm the audible effect")
        else statusResult(0x010C, "ANC state read-back", "ANC query accepted; state payload present")

        val wearReply = reply(0x0109)
        val wearEntries = wearReply?.payload?.let { Protocol.parseWear(it.toIntArray()) }.orEmpty()
        out += if (wearReply != null && wearReply.payload.firstOrNull() == 0 && wearEntries.isNotEmpty())
            Result("In-ear / wear state", Status.PASS, "${wearEntries.size} wear-state slot(s) reported. Sensor accuracy still needs physical removal/insertion test.", "Remove and reinsert each earbud and confirm the state changes")
        else statusResult(0x0109, "In-ear / wear state", "Wear-state response received")

        val eqReply = reply(0x010F)
        out += if (eqReply != null && eqReply.payload.firstOrNull() == 0 && eqReply.payload.size >= 2 && eqPreset >= 0)
            Result("EQ preset read-back", Status.PASS, "Device reported preset id $eqPreset. Sound profile effect is not measured by this protocol test.", "Change preset and listen to a known audio sample")
        else statusResult(0x010F, "EQ preset read-back", "EQ preset response received")

        val customEqReply = reply(0x0122)
        val parsedCustomProfiles = customEqReply?.payload?.takeIf { it.firstOrNull() == 0 }?.let { Protocol.parseCustomEq(it.toIntArray()) }.orEmpty()
        val validCustomProfiles = parsedCustomProfiles.filter { it.name.isNotBlank() && it.bands.isNotEmpty() && it.bands.all { band -> band.first > 0 && band.second in -24..24 } }
        out += if (customEqReply != null && customEqReply.payload.firstOrNull() == 0 && validCustomProfiles.isNotEmpty())
            Result("Custom EQ profile read-back", Status.PARTIAL,
                "${validCustomProfiles.size} profile(s) and ${validCustomProfiles.sumOf { it.bands.size }} band value(s) parsed from the device. Exact write/read-back equality is required for PASS.", "Save a profile, then compare the exact returned name, frequencies and gains")
        else if (customEqReply != null && customEqReply.payload.firstOrNull() == 0)
            Result("Custom EQ profile read-back", Status.FAIL, "Device replied, but no valid profile/band records could be decoded", "Check the model-specific 0x0122 payload layout")
        else statusResult(0x0122, "Custom EQ profile read-back", "Custom EQ profile response received")

        val flagsReply = reply(0x010D)
        out += if (flagsReply != null && flagsReply.payload.firstOrNull() == 0 && flagsReply.payload.size >= 3)
            Result("Feature flags read-back", Status.PASS, "Feature flag response received${gameMode?.let { " · Game mode=${if (it) "On" else "Off"}" } ?: ""}", "Check actual game latency separately")
        else statusResult(0x010D, "Feature flags read-back", "Feature flag response received")

        val gestureReply = reply(0x0108)
        val gestureCount = gestureReply?.payload?.getOrNull(1) ?: 0
        out += if (gestureReply != null && gestureReply.payload.firstOrNull() == 0 && gestureCount > 0)
            Result("Touch mapping read-back", Status.PARTIAL, "$gestureCount gesture table entries reported by earbuds; physical touch actions were not triggered", "Tap each configured gesture on the earbuds")
        else statusResult(0x0108, "Touch mapping read-back", "Gesture table response received")

        val bassReply = reply(0x0124)
        out += if (bassReply != null && bassReply.payload.firstOrNull() == 0 && bassReply.payload.size >= 4 && bassLevel != null)
            Result("BassWave read-back", Status.PASS, "Device returned BassWave level $bassLevel", "Listen at low/high levels to verify audible effect")
        else statusResult(0x0124, "BassWave read-back", "BassWave response received")

        val fwReply = reply(0x0105)
        out += if (fwReply != null && fwReply.payload.firstOrNull() == 0 && !firmware.isNullOrBlank())
            Result("Firmware information", Status.PASS, "Device-reported firmware: $firmware")
        else statusResult(0x0105, "Firmware information", "Firmware response received")

        val peerReply = reply(0x0112)
        out += if (peerReply != null && peerReply.payload.firstOrNull() == 0)
            Result("Dual-device peer discovery", Status.PARTIAL, if (peerCount > 0) "$peerCount peer record(s) reported. Switching/second-host audio was not tested." else "Peer query answered but no peer records were reported.", "Connect a second host and verify switching/audio on both hosts")
        else statusResult(0x0112, "Dual-device peer discovery", "Peer-list response received")

        out += when {
            gattState.contains("READY", true) -> Result("BLE GATT diagnostic", Status.PARTIAL, "GATT service/characteristic discovery and notification subscription succeeded; control writes are not verified")
            gattState.contains("failed", true) -> Result("BLE GATT diagnostic", Status.FAIL, gattState)
            else -> Result("BLE GATT diagnostic", Status.UNVERIFIED, gattState.ifBlank { "No GATT probe performed" }, "Run Probe GATT for a discovered BLE device")
        }
        out += Result("Find My Buds sound", Status.UNVERIFIED, "Not triggered automatically to avoid unexpected sound", "Start Find My Buds manually and confirm sound from each side")
        out += Result("Voice assistant behavior", Status.UNVERIFIED, "Protocol behavior is not confirmed by this safe read-only run", "Trigger the mapped earbud gesture and confirm the phone assistant opens")
        out += Result("Hearing feature behavior", Status.UNVERIFIED, "No device-specific hearing behavior is certified", "Only test after model-specific command mapping is confirmed")
        out += Result("Game Mode latency", if (gameMode != null) Status.PARTIAL else Status.UNVERIFIED,
            gameMode?.let { "Device-reported flag=${if (it) "On" else "Off"}; actual latency not measured" } ?: "No verified Game Mode state received",
            "Compare game audio/video sync with Game Mode on and off")
        return out
    }

    fun report(deviceName: String, address: String, results: List<Result>): String = buildString {
        appendLine("BUDSY AUTOMATIC PROTOCOL TEST")
        appendLine("Device: $deviceName")
        appendLine("Address: $address")
        appendLine("Generated: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
        appendLine()
        results.forEach { r ->
            appendLine("[${r.status}] ${r.feature}")
            appendLine("  ${r.evidence}")
            if (r.nextStep.isNotBlank()) appendLine("  Next: ${r.nextStep}")
        }
        appendLine()
        appendLine("PASS means protocol/read-back evidence passed; it does not certify acoustic behavior or hardware compatibility beyond this connected unit. PARTIAL and UNVERIFIED are not working confirmations.")
    }
}
