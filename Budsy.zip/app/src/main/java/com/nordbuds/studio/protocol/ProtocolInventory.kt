package com.nordbuds.studio.protocol

/** Evidence-aware protocol map. IDs are not automatically treated as safe-to-send commands. */
object ProtocolInventory {
    enum class Layer { CORE, FEATURE, ADVANCED }
    enum class Evidence { APK_SOURCE, EXISTING_CAPTURE, IMPLEMENTED_IN_BUDSY, INVENTORY_ONLY, HARDWARE_UNVERIFIED }
    data class Entry(
        val id: String,
        val label: String,
        val layer: Layer,
        val evidence: Set<Evidence>,
        val requestCommand: Int? = null,
        val responseCommand: Int? = null,
        val writable: Boolean = false,
        val note: String = ""
    )

    val entries = listOf(
        Entry("BLE/GATT", "GATT service discovery, write and notify", Layer.CORE,
            setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED),
            note = "GattLink is implemented separately from RFCOMM; primary transport selection and ATT fragmentation remain unverified."),
        Entry("BLE SCAN", "Nearby BLE discovery and result deduplication", Layer.CORE,
            setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED),
            note = "Unfiltered low-latency scan with runtime permissions; target advertisement identity still needs device testing."),
        Entry("OPOv1", "Frame encoder/stream decoder", Layer.CORE,
            setOf(Evidence.APK_SOURCE, Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY)),
        Entry("0100", "Handshake", Layer.CORE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x0100),
        Entry("0200/0205", "Event discovery/subscription", Layer.CORE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x0200, 0x0205, true),
        Entry("0106", "Battery query", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x0106),
        Entry("0108/0401", "Touch gesture query/write", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x0108, 0x0401, true),
        Entry("010C/0404", "ANC and hold-control query/write", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x010C, 0x0404, true),
        Entry("010D/0403", "Feature flags (wear/game/BassWave) query/write", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x010D, 0x0403, true),
        Entry("010F/0406", "EQ preset query/write", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY), 0x010F, 0x0406, true),
        Entry("0122/0418", "Custom EQ list/write", Layer.FEATURE, setOf(Evidence.APK_SOURCE, Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x0122, 0x0418, true,
            "0x0418 payload layout is source-confirmed; target model/firmware acceptance remains unverified."),
        Entry("0124/041B", "BassWave query/write", Layer.FEATURE, setOf(Evidence.EXISTING_CAPTURE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x0124, 0x041B, true),
        Entry("0112/8112", "Multi-device peer-state query/response", Layer.ADVANCED,
            setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x0112, 0x8112,
            note = "Peer address, state, current/main-audio/audio-active flags, device type and UTF-8 name are decoded. A dual-connect enable/disable write is not source-confirmed."),
        Entry("OTA 0300-030A", "Firmware upgrade sync/start/data/verify/commit/abort/switch", Layer.ADVANCED, setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED),
            note = "Command IDs, sync/start/data/block-verify metadata codecs recovered. Transfer is inspection-only: no OTA sender, no package acceptance, and no firmware writes enabled."),
        Entry("Fast Pair", "Account-key / pairing support", Layer.ADVANCED, setOf(Evidence.APK_SOURCE, Evidence.INVENTORY_ONLY),
            note = "GATT service family is present; account-key provisioning is not implemented from UUID discovery alone."),
        Entry("0422", "Spatial audio command family", Layer.ADVANCED, setOf(Evidence.APK_SOURCE, Evidence.INVENTORY_ONLY),
            note = "Not Custom EQ. No generic write exposed."),
        Entry("0116/040E", "Hearing process data query/write", Layer.FEATURE, setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x0116, 0x040E, true,
            "Payload codecs recovered from HeadsetCoreService.Y/B0/v1. Hardware capability and semantic action values remain model-specific."),
        Entry("0135/0432", "GMN voice-assistant config query/control type", Layer.FEATURE, setOf(Evidence.APK_SOURCE, Evidence.IMPLEMENTED_IN_BUDSY, Evidence.HARDWARE_UNVERIFIED), 0x0135, 0x0432, true,
            "Query response 0x8103 is [status, flags]; flags map 0x01/0x02/0x04 to app control types 0/1/2 and bit 0x80 indicates connected. Set mapping 0->1, 1->2, 2->4."),
    )

    fun byLayer(layer: Layer) = entries.filter { it.layer == layer }
}
