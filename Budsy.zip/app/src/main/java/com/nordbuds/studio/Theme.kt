package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily

/** Visual identities are independent from Light / Dark / AMOLED appearance. */
object ThemeMode {
    const val LIQUID = 0
    const val NOTHING = 1
    const val AURORA = 2
    const val SONY = 3
    const val SPATIAL = 4
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    /** Readable content colour on top of an accent fill (lime accents need dark text, red/blue need white). */
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

/** Accents are tuned for dark surfaces; on Light they are deepened so text and icons keep contrast. */
private fun lightAccent(style: Int): Pair<Color, Color> = when (style) {
    ThemeMode.NOTHING -> Color(0xFF5E7A00) to Color(0xFF3F5200)
    ThemeMode.AURORA -> Color(0xFFD62F24) to Color(0xFFB4231A)
    ThemeMode.SONY -> Color(0xFF1B6FD1) to Color(0xFF0E8A94)
    ThemeMode.SPATIAL -> Color(0xFF6A4BE0) to Color(0xFF1D8FB8)
    else -> Color(0xFF0A74D9) to Color(0xFF6B54D9)
}

private fun styleColors(mode: Int): Pal = when (mode) {
    ThemeMode.NOTHING -> Pal(true, true, Color(0xFF050505), Color(0xFF171717), Color(0xFF252525), Color(0xFFF6F6F2), Color(0xFF9C9C95), Color(0xFF303030), Color(0xFF424242), Color(0xFFD8FF54), Color(0xFFD8FF54), Color(0xFFFFC857), Color(0xFFFF655B), Color(0xF20D0D0D), Color(0xFF9CC72D))
    ThemeMode.AURORA -> Pal(true, false, Color(0xFF0B0B0D), Color(0xFF1B1A1D), Color(0xFF292427), Color(0xFFFAF9F7), Color(0xFFA4A1A5), Color(0xFF353236), Color(0xFF474348), Color(0xFFE84135), Color(0xFF5ED6A0), Color(0xFFFFB454), Color(0xFFFF6258), Color(0xF2131315), Color(0xFFFF786D))
    ThemeMode.SONY -> Pal(true, false, Color(0xFF09111A), Color(0xFF142131), Color(0xFF21354A), Color(0xFFF2F7FD), Color(0xFF96A9BC), Color(0xFF2B4054), Color(0xFF38516B), Color(0xFF84B8FF), Color(0xFF66D9B0), Color(0xFFFFC16C), Color(0xFFFF716C), Color(0xF2111D2B), Color(0xFF5FE0E8))
    ThemeMode.SPATIAL -> Pal(true, false, Color(0xFF090B1B), Color(0xFF171B32), Color(0xFF292B4B), Color(0xFFF5F3FF), Color(0xFFA4A5C8), Color(0xFF343655), Color(0xFF43466D), Color(0xFFB5A1FF), Color(0xFF75E5C2), Color(0xFFFFC37B), Color(0xFFFF7893), Color(0xF2101328), Color(0xFF6DDCFF))
    else -> Pal(true, false, Color(0xFF080B12), Color(0xFF171C28), Color(0xFF242D3E), Color(0xFFF5F7FC), Color(0xFFA4AEC0), Color(0xFF2A3344), Color(0xFF39465B), Color(0xFF62B7FF), Color(0xFF30D158), Color(0xFFFF9F0A), Color(0xFFFF453A), Color(0xF2161C29), Color(0xFF9C8CFF))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK): Pal {
    val b = styleColors(style)
    return when (appearance) {
        AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF101010), Color(0xFF1D1D1D), b.text, b.sub, Color(0xFF292929), Color(0xFF3A3A3A), b.accent, b.green, b.amber, b.red, Color(0xFF080808), b.accent2)
        AppearanceMode.LIGHT -> Pal(false, false, Color(0xFFF4F6FA), Color(0xFFE7EBF2), Color(0xFFD9E0EA), Color(0xFF151923), Color(0xFF586273), Color(0xFFD4DAE4), Color(0xFFBCC5D3), lightAccent(style).first, Color(0xFF16834B), Color(0xFF9A5A00), Color(0xFFB42318), Color(0xF9FFFFFF), lightAccent(style).second)
        else -> Pal(true, false, b.bg, b.tile, b.thumb, b.text, b.sub, b.line, b.track, b.accent, b.green, b.amber, b.red, b.sheet, b.accent2)
    }
}

/**
 * Per-theme typography used by [Txt]. Monospace (Nothing Dot Matrix) glyphs are ~20% wider than the sans
 * face, so at the same sp size every label overflowed or ellipsised; the mono theme therefore scales type
 * down (never below a readable floor) and tightens tracking so layouts keep the same widths in every theme.
 */
@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) =
    if (mode == ThemeMode.NOTHING) TypeSpec(FontFamily.Monospace, 0.86f, -0.15f) else TypeSpec(FontFamily.SansSerif, 1f, 0f)

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.LIQUID) }

val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.LIQUID, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, content: @Composable () -> Unit) {
    // Everything below is cached: a fresh Pal / Typography on every recomposition would invalidate the
    // whole UI (LocalPal is a static local) and made the animated themes stutter.
    val p = remember(mode, appearance) { makePal(mode, appearance) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val themedTypography = remember(mode) {
        val typeface = if (mode == ThemeMode.NOTHING) FontFamily.Monospace else FontFamily.SansSerif
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = typeface), displayMedium = t.displayMedium.copy(fontFamily = typeface),
            displaySmall = t.displaySmall.copy(fontFamily = typeface), headlineLarge = t.headlineLarge.copy(fontFamily = typeface),
            headlineMedium = t.headlineMedium.copy(fontFamily = typeface), headlineSmall = t.headlineSmall.copy(fontFamily = typeface),
            titleLarge = t.titleLarge.copy(fontFamily = typeface), titleMedium = t.titleMedium.copy(fontFamily = typeface),
            titleSmall = t.titleSmall.copy(fontFamily = typeface), bodyLarge = t.bodyLarge.copy(fontFamily = typeface),
            bodyMedium = t.bodyMedium.copy(fontFamily = typeface), bodySmall = t.bodySmall.copy(fontFamily = typeface),
            labelLarge = t.labelLarge.copy(fontFamily = typeface), labelMedium = t.labelMedium.copy(fontFamily = typeface),
            labelSmall = t.labelSmall.copy(fontFamily = typeface)
        )
    }
    val typeSpec = remember(mode) { typeSpecFor(mode) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val reduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(LocalPal provides p, LocalTypeSpec provides typeSpec, LocalReduceMotion provides reduce) { MaterialTheme(colorScheme = cs, typography = themedTypography, content = content) }
}
