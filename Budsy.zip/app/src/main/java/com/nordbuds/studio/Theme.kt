package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily

/** One permanent Stock Budsy identity; appearance switches Light, Dark and AMOLED. */
object ThemeMode {
    /** The only built-in theme. Imported themes will be managed separately. */
    const val AURORA = 0 // legacy IDs retained only for source compatibility
    const val CRYSTAL = 1
    const val NOTHING = 2
    const val TITANIUM = 3
    const val STOCK = 4
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

private fun stockPal(appearance: Int): Pal = when (appearance) {
    AppearanceMode.LIGHT, AppearanceMode.SYSTEM -> Pal(false, false,
        Color(0xFFF5F5F7), Color.White, Color(0xFFE9E9ED), Color(0xFF17171A),
        Color(0xFF77777D), Color(0xFFE5E5E9), Color(0xFFD6D6DC), Color(0xFF3478F6),
        Color(0xFF28A66A), Color(0xFFE0A12D), Color(0xFFE05252), Color(0xF9FFFFFF), Color(0xFF79A9FF))
    AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF101012), Color(0xFF1B1B1F),
        Color(0xFFF5F5F7), Color(0xFF9A9AA2), Color(0xFF29292E), Color(0xFF393940), Color(0xFF6C9FFF),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xFF09090B), Color(0xFF91B5FF))
    else -> Pal(true, false, Color(0xFF17181B), Color(0xFF222328), Color(0xFF2C2D33),
        Color(0xFFF5F5F7), Color(0xFF9A9AA2), Color(0xFF34353B), Color(0xFF414249), Color(0xFF6C9FFF),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xF9222328), Color(0xFF91B5FF))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK, imported: ThemePalette? = null): Pal {
    val base = stockPal(appearance)
    if (imported == null) return base
    val bg = if (appearance == AppearanceMode.LIGHT || appearance == AppearanceMode.SYSTEM) imported.lightBg else imported.darkBg
    val card = if (appearance == AppearanceMode.LIGHT || appearance == AppearanceMode.SYSTEM) imported.lightCard else imported.darkCard
    return Pal(base.dark, base.amoled, bg?.let(::Color) ?: base.bg, card?.let(::Color) ?: base.tile,
        base.thumb, imported.text?.let(::Color) ?: base.text, imported.sub?.let(::Color) ?: base.sub,
        base.line, base.track, imported.accent?.let(::Color) ?: base.accent, base.green, base.amber, base.red,
        card?.let(::Color) ?: base.sheet, imported.accent?.let(::Color) ?: base.accent2)
}

@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) = if (mode == ThemeMode.NOTHING)
    TypeSpec(FontFamily.Monospace, 0.86f, -0.15f) else TypeSpec(FontFamily.SansSerif, 1f, 0f)

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.AURORA) }
val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.AURORA, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, imported: ThemePalette? = null, content: @Composable () -> Unit) {
    val safeMode = ThemeMode.STOCK
    val p = remember(safeMode, appearance, imported) { makePal(safeMode, appearance, imported) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val themedTypography = remember(safeMode) {
        val typeface = FontFamily.SansSerif
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = typeface), displayMedium = t.displayMedium.copy(fontFamily = typeface),
            displaySmall = t.displaySmall.copy(fontFamily = typeface), headlineLarge = t.headlineLarge.copy(fontFamily = typeface),
            headlineMedium = t.headlineMedium.copy(fontFamily = typeface), headlineSmall = t.headlineSmall.copy(fontFamily = typeface),
            titleLarge = t.titleLarge.copy(fontFamily = typeface), titleMedium = t.titleMedium.copy(fontFamily = typeface),
            titleSmall = t.titleSmall.copy(fontFamily = typeface), bodyLarge = t.bodyLarge.copy(fontFamily = typeface),
            bodyMedium = t.bodyMedium.copy(fontFamily = typeface), bodySmall = t.bodySmall.copy(fontFamily = typeface),
            labelLarge = t.labelLarge.copy(fontFamily = typeface), labelMedium = t.labelMedium.copy(fontFamily = typeface),
            labelSmall = t.labelSmall.copy(fontFamily = typeface)
        )
    }
    val typeSpec = remember(safeMode) { typeSpecFor(safeMode) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val reduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(
        LocalPal provides p,
        LocalTypeSpec provides typeSpec,
        LocalReduceMotion provides reduce,
        LocalThemeMode provides safeMode
    ) {
        MaterialTheme(colorScheme = cs, typography = themedTypography, content = content)
    }
}
