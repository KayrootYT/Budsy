package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily

/** Four complete visual identities replacing the previous theme collection. */
object ThemeMode {
    const val AURORA = 0
    const val CRYSTAL = 1
    const val NOTHING = 2
    const val TITANIUM = 3
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

private fun accents(style: Int): Pair<Color, Color> = when (style) {
    ThemeMode.AURORA -> Color(0xFF16BFFF) to Color(0xFF246BFF)
    ThemeMode.CRYSTAL -> Color(0xFF087DEB) to Color(0xFF65B8FF)
    ThemeMode.NOTHING -> Color(0xFFFF453A) to Color(0xFFFF6A5F)
    else -> Color(0xFFE8C58A) to Color(0xFFB88A4B)
}

private fun styleColors(mode: Int): Pal = when (mode) {
    ThemeMode.CRYSTAL -> Pal(false, false, Color(0xFFEAF2FF), Color(0xFFFFFFFF), Color(0xFFDCE8F8),
        Color(0xFF111827), Color(0xFF657187), Color(0xFFD2DCEB), Color(0xFFCCD8E9), Color(0xFF087DEB),
        Color(0xFF159B65), Color(0xFFB7791F), Color(0xFFC43B42), Color(0xDFFFFFFF), Color(0xFF70BFFF))
    ThemeMode.NOTHING -> Pal(true, true, Color(0xFF050505), Color(0xFF151515), Color(0xFF252525),
        Color(0xFFF5F5F2), Color(0xFF9B9B96), Color(0xFF353535), Color(0xFF414141), Color(0xFFFF5148),
        Color(0xFF66E6A6), Color(0xFFFFC857), Color(0xFFFF655B), Color(0xF20D0D0D), Color(0xFFFF8A80))
    ThemeMode.TITANIUM -> Pal(true, false, Color(0xFF17191D), Color(0xFF292B30), Color(0xFF3B3D42),
        Color(0xFFF7F2E9), Color(0xFFB8B0A4), Color(0xFF55504A), Color(0xFF61594F), Color(0xFFE8C58A),
        Color(0xFF72D6A3), Color(0xFFE8B66C), Color(0xFFFF716C), Color(0xF225272B), Color(0xFFB88A4B))
    else -> Pal(true, false, Color(0xFF050D1B), Color(0xFF12243A), Color(0xFF203B59),
        Color(0xFFF4F8FF), Color(0xFFA7B9D0), Color(0xFF294765), Color(0xFF355675), Color(0xFF20BFFF),
        Color(0xFF37D99A), Color(0xFFFFC16C), Color(0xFFFF716C), Color(0xF20D1C30), Color(0xFF397DFF))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK): Pal {
    val b = styleColors(style.coerceIn(0, 3))
    return when (appearance) {
        AppearanceMode.LIGHT -> {
            val a = accents(style)
            if (style == ThemeMode.NOTHING) Pal(false, false, Color(0xFFF5F5F3), Color.White, Color(0xFFE8E8E5),
                Color(0xFF151515), Color(0xFF666660), Color(0xFFDADAD5), Color(0xFFE1E1DC), Color(0xFFCF3029),
                Color(0xFF16834B), Color(0xFF9A5A00), Color(0xFFB42318), Color(0xF9FFFFFF), Color(0xFF9E211C))
            else Pal(false, false, Color(0xFFF1F5FA), Color.White, Color(0xFFE3EAF2), Color(0xFF151923),
                Color(0xFF586273), Color(0xFFD4DAE4), Color(0xFFBCC5D3), a.first, Color(0xFF16834B),
                Color(0xFF9A5A00), Color(0xFFB42318), Color(0xF9FFFFFF), a.second)
        }
        AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF101010), Color(0xFF1D1D1D),
            b.text, b.sub, Color(0xFF292929), Color(0xFF3A3A3A), b.accent, b.green, b.amber, b.red, Color(0xFF080808), b.accent2)
        else -> b
    }
}

@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) = if (mode == ThemeMode.NOTHING)
    TypeSpec(FontFamily.Monospace, 0.86f, -0.15f) else TypeSpec(FontFamily.SansSerif, 1f, 0f)

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.AURORA) }
val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.AURORA, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, content: @Composable () -> Unit) {
    val safeMode = mode.coerceIn(0, 3)
    val p = remember(safeMode, appearance) { makePal(safeMode, appearance) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val themedTypography = remember(safeMode) {
        val typeface = if (safeMode == ThemeMode.NOTHING) FontFamily.Monospace else FontFamily.SansSerif
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = typeface), displayMedium = t.displayMedium.copy(fontFamily = typeface),
            displaySmall = t.displaySmall.copy(fontFamily = typeface), headlineLarge = t.headlineLarge.copy(fontFamily = typeface),
            headlineMedium = t.headlineMedium.copy(fontFamily = typeface), headlineSmall = t.headlineSmall.copy(fontFamily = typeface),
            titleLarge = t.titleLarge.copy(fontFamily = typeface), titleMedium = t.titleMedium.copy(fontFamily = typeface),
            titleSmall = t.titleSmall.copy(fontFamily = typeface), bodyLarge = t.bodyLarge.copy(fontFamily = typeface),
            bodyMedium = t.bodyMedium.copy(fontFamily = typeface), bodySmall = t.bodySmall.copy(fontFamily = typeface),
            labelLarge = t.labelLarge.copy(fontFamily = typeface), labelMedium = t.labelMedium.copy(fontFamily = typeface),
            labelSmall = t.labelSmall.copy(fontFamily = typeface)
        )
    }
    val typeSpec = remember(safeMode) { typeSpecFor(safeMode) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val reduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(
        LocalPal provides p,
        LocalTypeSpec provides typeSpec,
        LocalReduceMotion provides reduce,
        LocalThemeMode provides safeMode
    ) {
        MaterialTheme(colorScheme = cs, typography = themedTypography, content = content)
    }
}
