package com.nordbuds.studio

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext

@Composable
fun ImportedThemeImage(
    themeId: String?,
    slot: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alpha: Float = 1f
) {
    val ctx = LocalContext.current
    val bitmap = remember(themeId, slot) {
        try {
            val file = ThemeStore.assetFile(ctx, themeId, slot) ?: return@remember null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth !in 1..4096 || bounds.outHeight !in 1..4096) null
            else {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = maxOf(1, maxOf(bounds.outWidth / 2048, bounds.outHeight / 2048))
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeFile(file.absolutePath, opts)
            }
        } catch (_: Exception) { null }
    }
    if (bitmap != null) Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        modifier = modifier,
        contentScale = contentScale,
        alpha = alpha
    )
}
