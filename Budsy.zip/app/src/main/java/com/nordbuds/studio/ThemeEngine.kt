package com.nordbuds.studio

import java.io.File
import java.util.Properties

/**
 * Budsy Theme Engine.
 *
 * A theme is a declarative [ThemeSpec] (colours, shapes, typography, motion, card style, icons, artwork).
 * Specs come from `.budsytheme` / `.mtz` ZIP packages. No code is ever executed from a package.
 *
 * Resolution order inside a package (first match wins, later layers only fill gaps):
 *   1. `budsy/theme.json`  or  `theme.json`        (full Budsy spec, recommended)
 *   2. `theme.properties`                         (legacy flat palette, still supported)
 *   3. `description.xml`  (MIUI / HyperOS MTZ)    -> name, author, version
 *   4. MTZ standard resources: `fonts/`, `wallpaper/default_wallpaper.*`
 */

/** Per-appearance colour overrides. Every field is optional; null keeps the Stock value. */
data class ColorSet(
    val bg: Long? = null, val card: Long? = null, val thumb: Long? = null,
    val text: Long? = null, val sub: Long? = null, val line: Long? = null, val track: Long? = null,
    val accent: Long? = null, val accent2: Long? = null,
    val green: Long? = null, val amber: Long? = null, val red: Long? = null, val sheet: Long? = null
) {
    val isEmpty get() = listOf(bg, card, thumb, text, sub, line, track, accent, accent2, green, amber, red, sheet).all { it == null }
}

/** Corner radii in dp. */
data class ShapeSpec(val panel: Float = 26f, val card: Float = 20f, val tile: Float = 22f, val button: Float = 16f, val pill: Float = 50f)

enum class CardStyle { SOLID, GLASS, GRADIENT, OUTLINE, FLAT }

data class CardSpec(
    val style: CardStyle = CardStyle.SOLID,
    val borderWidth: Float = 1f,
    val borderAlpha: Float = 0.8f,
    val fillAlpha: Float = 1f,
    val glow: Boolean = true,
    val gradientFrom: Long? = null,
    val gradientTo: Long? = null
)

data class FontSpec(val file: String? = null, val boldFile: String? = null, val family: String = "sans", val scale: Float = 1f, val tracking: Float = 0f)

data class MotionSpec(
    val enabled: Boolean = true,
    val speed: Float = 1f,          // 0.25 .. 3.0, higher = faster
    val enter: Boolean = true,      // staggered card entrance
    val bounce: Boolean = true,     // springy tap feedback
    val glowPulse: Boolean = true,
    val tabTransition: String = "slide" // slide | fade | none
)

data class BackgroundSpec(
    val image: String? = null, val imageAlpha: Float = 0.92f, val overlayAlpha: Float = 0f,
    val blobs: Boolean = false, val dotMatrix: Boolean = false
)

/** Icon pack: logical icon key -> relative file inside the package (PNG/WebP/SVG-free). */
data class IconSpec(val tintAccent: Boolean = true, val map: Map<String, String> = emptyMap())

data class ThemeSpec(
    val schema: Int = 1,
    val name: String = "Imported Budsy Theme",
    val author: String = "Unknown",
    val description: String = "",
    val version: String = "1.0",
    val source: String = "budsytheme",
    val light: ColorSet = ColorSet(),
    val dark: ColorSet = ColorSet(),
    val amoled: ColorSet = ColorSet(),
    val shapes: ShapeSpec = ShapeSpec(),
    val card: CardSpec = CardSpec(),
    val font: FontSpec = FontSpec(),
    val motion: MotionSpec = MotionSpec(),
    val background: BackgroundSpec = BackgroundSpec(),
    val icons: IconSpec = IconSpec(),
    /** Which pieces this package actually customised; shown as badges in Theme Manager. */
    val features: Set<String> = emptySet()
) {
    companion object { val STOCK = ThemeSpec(name = "Stock Budsy", author = "Budsy", description = "Built-in theme", source = "stock") }

    fun colorsFor(appearance: Int): ColorSet = when (appearance) {
        AppearanceMode.AMOLED -> amoled.takeUnless { it.isEmpty } ?: dark
        AppearanceMode.DARK -> dark
        else -> light
    }
}

/** Logical icon keys a theme may override (see THEME_PACKAGE_FORMAT.md). */
object IconKeys {
    const val DEVICE = "tab_device"; const val SOUND = "tab_sound"; const val CONTROLS = "tab_controls"; const val SETTINGS = "tab_settings"
    const val BATTERY = "battery"; const val APP = "app_header"
    val all = listOf(DEVICE, SOUND, CONTROLS, SETTINGS, BATTERY, APP)
}

object ThemeParser {
    private val HEX = Regex("#?[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?")

    fun color(raw: String?): Long? {
        val s = raw?.trim() ?: return null
        if (!HEX.matches(s)) return null
        val v = s.removePrefix("#").toLongOrNull(16) ?: return null
        return if (s.removePrefix("#").length == 6) 0xFF000000L or v else v
    }

    private fun f(v: Float?, lo: Float, hi: Float, def: Float) = (v ?: def).coerceIn(lo, hi)
    private fun String?.num(): Float? = this?.trim()?.toFloatOrNull()
    private fun String?.bool(def: Boolean): Boolean = when (this?.trim()?.lowercase()) { "true", "1", "yes", "on" -> true; "false", "0", "no", "off" -> false; else -> def }
    private fun safeRel(p: String?): String? = p?.trim()?.replace('\\', '/')?.takeIf {
        it.isNotBlank() && !it.startsWith("/") && it.split('/').none { s -> s == ".." || s == "." } && it.length <= 120
    }

    /**
     * Flat key/value view of the spec. theme.json is flattened to dotted keys by [flattenJson]; theme.properties
     * already uses the same dotted names, so one reader serves both formats.
     * Legacy keys (lightBg, darkCard, accent, text, sub) are mapped too.
     */
    fun fromFlat(p: Map<String, String>, fallbackName: String = "Imported Budsy Theme", source: String = "budsytheme"): ThemeSpec {
        fun g(k: String) = p[k]
        fun set(prefix: String, legacyBg: String?, legacyCard: String?): ColorSet = ColorSet(
            bg = color(g("$prefix.bg") ?: legacyBg?.let(::g)), card = color(g("$prefix.card") ?: legacyCard?.let(::g)),
            thumb = color(g("$prefix.thumb")), text = color(g("$prefix.text") ?: g("text")), sub = color(g("$prefix.sub") ?: g("sub")),
            line = color(g("$prefix.line")), track = color(g("$prefix.track")),
            accent = color(g("$prefix.accent") ?: g("accent")), accent2 = color(g("$prefix.accent2") ?: g("accent2")),
            green = color(g("$prefix.green")), amber = color(g("$prefix.amber")), red = color(g("$prefix.red")),
            sheet = color(g("$prefix.sheet"))
        )
        val light = set("colors.light", "lightBg", "lightCard")
        val dark = set("colors.dark", "darkBg", "darkCard")
        val amoled = set("colors.amoled", null, null)
        val shapes = ShapeSpec(
            panel = f(g("shapes.panel").num(), 0f, 48f, 26f), card = f(g("shapes.card").num(), 0f, 40f, 20f),
            tile = f(g("shapes.tile").num(), 0f, 40f, 22f), button = f(g("shapes.button").num(), 0f, 30f, 16f),
            pill = f(g("shapes.pill").num(), 0f, 60f, 50f)
        )
        val style = runCatching { CardStyle.valueOf((g("card.style") ?: "solid").trim().uppercase()) }.getOrDefault(CardStyle.SOLID)
        val card = CardSpec(
            style = style, borderWidth = f(g("card.borderWidth").num(), 0f, 4f, 1f), borderAlpha = f(g("card.borderAlpha").num(), 0f, 1f, 0.8f),
            fillAlpha = f(g("card.fillAlpha").num(), 0.05f, 1f, 1f), glow = g("card.glow").bool(true),
            gradientFrom = color(g("card.gradientFrom")), gradientTo = color(g("card.gradientTo"))
        )
        val family = (g("font.family") ?: "sans").trim().lowercase().let { if (it in setOf("sans", "serif", "mono", "cursive")) it else "sans" }
        val font = FontSpec(safeRel(g("font.file")), safeRel(g("font.boldFile")), family, f(g("font.scale").num(), 0.8f, 1.3f, 1f), f(g("font.tracking").num(), -1f, 2f, 0f))
        val tab = (g("motion.tabTransition") ?: "slide").trim().lowercase().let { if (it in setOf("slide", "fade", "none")) it else "slide" }
        val motion = MotionSpec(
            enabled = g("motion.enabled").bool(true), speed = f(g("motion.speed").num(), 0.25f, 3f, 1f), enter = g("motion.enter").bool(true),
            bounce = g("motion.bounce").bool(true), glowPulse = g("motion.glowPulse").bool(true), tabTransition = tab
        )
        val bg = BackgroundSpec(
            image = safeRel(g("background.image")), imageAlpha = f(g("background.imageAlpha").num(), 0f, 1f, 0.92f),
            overlayAlpha = f(g("background.overlayAlpha").num(), 0f, 0.9f, 0f), blobs = g("background.blobs").bool(false), dotMatrix = g("background.dotMatrix").bool(false)
        )
        val iconMap = IconKeys.all.mapNotNull { k -> safeRel(g("icons.$k"))?.let { k to it } }.toMap()
        val icons = IconSpec(g("icons.tintAccent").bool(true), iconMap)

        val feats = buildSet {
            if (!light.isEmpty || !dark.isEmpty || !amoled.isEmpty) add("colors")
            if (font.file != null || font.family != "sans" || font.scale != 1f) add("font")
            if (shapes != ShapeSpec()) add("shapes")
            if (card != CardSpec()) add("cards")
            if (motion != MotionSpec()) add("animation")
            if (bg.image != null || bg.blobs || bg.dotMatrix) add("background")
            if (iconMap.isNotEmpty()) add("icons")
        }
        return ThemeSpec(
            name = (g("name") ?: fallbackName).trim().take(48).ifBlank { fallbackName },
            author = (g("author") ?: "Unknown").trim().take(48), description = (g("description") ?: "").trim().take(180),
            version = (g("version") ?: "1.0").trim().take(16), source = g("source")?.trim()?.take(16) ?: source,
            light = light, dark = dark, amoled = amoled, shapes = shapes, card = card, font = font, motion = motion,
            background = bg, icons = icons, features = feats
        )
    }

    /** Flattens nested JSON into dotted keys. Uses org.json (part of Android). */
    fun flattenJson(text: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        fun walk(prefix: String, v: Any?) {
            when (v) {
                is org.json.JSONObject -> v.keys().forEach { k -> walk(if (prefix.isEmpty()) k else "$prefix.$k", v.opt(k)) }
                null, org.json.JSONObject.NULL -> Unit
                else -> out[prefix] = v.toString()
            }
        }
        walk("", org.json.JSONObject(text))
        return out
    }

    /** MIUI/HyperOS description.xml: pull title / author / version with a tolerant regex (no XML parser needed). */
    fun parseMtzDescription(xml: String): Map<String, String> {
        fun tag(vararg names: String): String? = names.firstNotNullOfOrNull { n ->
            Regex("<$n[^>]*>\\s*(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?\\s*</$n>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
        }
        return buildMap {
            tag("title", "name")?.let { put("name", it) }
            tag("author", "designer")?.let { put("author", it) }
            tag("description")?.let { put("description", it) }
            tag("version")?.let { put("version", it) }
        }
    }

}

/** Reads the normalised spec stored for an installed theme (`theme.json` in its private folder). */
object ThemeSpecIO {
    /** `theme.properties` is the normalised spec written by the importer; `theme.json` is only a fallback for hand-placed folders. */
    fun read(dir: File): ThemeSpec? = try {
        val props = File(dir, "theme.properties")
        if (props.isFile) {
            val p = Properties().apply { props.inputStream().use { load(it) } }
            ThemeParser.fromFlat(p.stringPropertyNames().associateWith { p.getProperty(it) }, dir.name)
        } else {
            val json = File(dir, "theme.json")
            if (json.isFile) ThemeParser.fromFlat(ThemeParser.flattenJson(json.readText())) else null
        }
    } catch (_: Exception) { null }
}
