package com.nordbuds.studio

import java.io.File
import java.util.Properties

/**
 * Budsy Theme Engine.
 *
 * A theme is a declarative [ThemeSpec] (colours, shapes, typography, motion, card style, icons, artwork).
 * Specs come from `.budsytheme` / `.mtz` ZIP packages. No code is ever executed from a package.
 *
 * Resolution order inside a package (first match wins, later layers only fill gaps):
 *   1. `budsy/theme.json`  or  `theme.json`        (full Budsy spec, recommended)
 *   2. `theme.properties`                         (legacy flat palette, still supported)
 *   3. `description.xml`  (MIUI / HyperOS MTZ)    -> name, author, version
 *   4. MTZ standard resources: font files under `fonts/`, plus the default wallpaper
 */


/** Theme-controlled global layout tokens (dp). */
data class LayoutSpec(
    val pageHorizontal: Float = 16f, val pageTop: Float = 4f, val pageBottom: Float = 28f,
    val sectionGap: Float = 10f, val panelPadding: Float = 14f, val sectionInset: Float = 4f,
    val rowHeight: Float = 64f, val tileHeight: Float = 72f, val navHeight: Float = 64f,
    val contentMaxWidth: Float = 0f, val gridColumns: Int = 2
)

/** Visual language for reusable UI primitives; values are safe named presets, never executable code. */
data class ComponentSpec(
    val panel: String = "default", val tile: String = "default", val button: String = "default",
    val switch: String = "ios", val dialog: String = "default", val navigation: String = "floating",
    val iconShape: String = "circle", val iconScale: Float = 1f, val elevation: Float = 0f,
    val dividerStyle: String = "hairline"
)

/** Decorative effects can be enabled independently from motion/accessibility settings. */
data class EffectSpec(
    val glass: Float = 0f, val blur: Float = 0f, val shadow: Float = 0f,
    val glow: Float = 1f, val grain: Float = 0f, val scanlines: Boolean = false,
    val animatedGradient: Boolean = false, val parallax: Boolean = false
)

/** Screen-specific arrangement presets; feature behaviour remains owned by the app. */
data class ScreenLayoutSpec(
    val overview: String = "default", val sound: String = "default",
    val controls: String = "default", val settings: String = "default"
)


/** Per-appearance colour overrides. Every field is optional; null keeps the Stock value. */
data class ColorSet(
    val bg: Long? = null, val card: Long? = null, val thumb: Long? = null,
    val text: Long? = null, val sub: Long? = null, val line: Long? = null, val track: Long? = null,
    val accent: Long? = null, val accent2: Long? = null,
    val green: Long? = null, val amber: Long? = null, val red: Long? = null, val sheet: Long? = null
) {
    val isEmpty get() = listOf(bg, card, thumb, text, sub, line, track, accent, accent2, green, amber, red, sheet).all { it == null }
}

/** Corner radii in dp. */
data class ShapeSpec(val panel: Float = 26f, val card: Float = 20f, val tile: Float = 22f, val button: Float = 16f, val pill: Float = 50f)

enum class CardStyle { SOLID, GLASS, GRADIENT, OUTLINE, FLAT }

data class CardSpec(
    val style: CardStyle = CardStyle.SOLID,
    val borderWidth: Float = 1f,
    val borderAlpha: Float = 0.8f,
    val fillAlpha: Float = 1f,
    val glow: Boolean = true,
    val gradientFrom: Long? = null,
    val gradientTo: Long? = null
)

data class FontSpec(val file: String? = null, val boldFile: String? = null, val family: String = "sans", val scale: Float = 1f, val tracking: Float = 0f)

data class MotionSpec(
    val enabled: Boolean = true,
    val speed: Float = 1f,          // 0.25 .. 3.0, higher = faster
    val enter: Boolean = true,      // staggered card entrance
    val bounce: Boolean = true,     // springy tap feedback
    val glowPulse: Boolean = true,
    val tabTransition: String = "slide" // slide | fade | none
)

data class BackgroundSpec(
    val image: String? = null, val imageAlpha: Float = 0.92f, val overlayAlpha: Float = 0f,
    val blobs: Boolean = false, val dotMatrix: Boolean = false
)

/** Icon pack: logical icon key -> relative file inside the package (PNG/WebP/SVG-free). */
data class IconSpec(val tintAccent: Boolean = true, val map: Map<String, String> = emptyMap())

data class ThemeSpec(
    val schema: Int = 2,
    val name: String = "Imported Budsy Theme",
    val author: String = "Unknown",
    val description: String = "",
    val version: String = "1.0",
    val source: String = "budsytheme",
    val light: ColorSet = ColorSet(),
    val dark: ColorSet = ColorSet(),
    val amoled: ColorSet = ColorSet(),
    val shapes: ShapeSpec = ShapeSpec(),
    val card: CardSpec = CardSpec(),
    val font: FontSpec = FontSpec(),
    val motion: MotionSpec = MotionSpec(),
    val background: BackgroundSpec = BackgroundSpec(),
    val icons: IconSpec = IconSpec(),
    val layout: LayoutSpec = LayoutSpec(),
    val components: ComponentSpec = ComponentSpec(),
    val effects: EffectSpec = EffectSpec(),
    val screens: ScreenLayoutSpec = ScreenLayoutSpec(),
    /** Which pieces this package actually customised; shown as badges in Theme Manager. */
    val features: Set<String> = emptySet()
) {
    companion object { val STOCK = ThemeSpec(name = "Stock Budsy", author = "Budsy", description = "Built-in theme", source = "stock") }

    fun colorsFor(appearance: Int): ColorSet = when (appearance) {
        AppearanceMode.AMOLED -> amoled.takeUnless { it.isEmpty } ?: dark
        AppearanceMode.DARK -> dark
        else -> light
    }
}

/** Logical icon keys a theme may override (see THEME_PACKAGE_FORMAT.md). */
object IconKeys {
    const val DEVICE = "tab_device"; const val SOUND = "tab_sound"; const val CONTROLS = "tab_controls"; const val SETTINGS = "tab_settings"
    const val BATTERY = "battery"; const val APP = "app_header"
    const val CONNECT = "connect"; const val DISCONNECT = "disconnect"; const val ANC = "anc"
    const val TRANSPARENCY = "transparency"; const val GAME_MODE = "game_mode"; const val FIND_BUDS = "find_buds"
    const val EQUALIZER = "equalizer"; const val FIRMWARE = "firmware"; const val BLUETOOTH = "bluetooth"
    const val CALL = "call"; const val NOISE_CONTROL = "noise_control"; const val BATTERY_CASE = "battery_case"
    const val BATTERY_LEFT = "battery_left"; const val BATTERY_RIGHT = "battery_right"
    const val PRESET = "preset"; const val CUSTOM_EQ = "custom_eq"; const val TOUCH_CONTROLS = "touch_controls"
    const val SETTINGS_GENERAL = "settings_general"; const val SETTINGS_ABOUT = "settings_about"
    val all = listOf(DEVICE, SOUND, CONTROLS, SETTINGS, BATTERY, APP, CONNECT, DISCONNECT, ANC,
        TRANSPARENCY, GAME_MODE, FIND_BUDS, EQUALIZER, FIRMWARE, BLUETOOTH, CALL, NOISE_CONTROL,
        BATTERY_CASE, BATTERY_LEFT, BATTERY_RIGHT, PRESET, CUSTOM_EQ, TOUCH_CONTROLS,
        SETTINGS_GENERAL, SETTINGS_ABOUT)
}

object ThemeParser {
    private val HEX = Regex("#?[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?")

    fun color(raw: String?): Long? {
        val s = raw?.trim() ?: return null
        if (!HEX.matches(s)) return null
        val v = s.removePrefix("#").toLongOrNull(16) ?: return null
        return if (s.removePrefix("#").length == 6) 0xFF000000L or v else v
    }

    private fun f(v: Float?, lo: Float, hi: Float, def: Float) = (v ?: def).coerceIn(lo, hi)
    private fun String?.num(): Float? = this?.trim()?.toFloatOrNull()
    private fun String?.bool(def: Boolean): Boolean = when (this?.trim()?.lowercase()) { "true", "1", "yes", "on" -> true; "false", "0", "no", "off" -> false; else -> def }
    private fun safeRel(p: String?): String? = p?.trim()?.replace('\\', '/')?.takeIf {
        it.isNotBlank() && !it.startsWith("/") && it.split('/').none { s -> s == ".." || s == "." } && it.length <= 120
    }

    /**
     * Flat key/value view of the spec. theme.json is flattened to dotted keys by [flattenJson]; theme.properties
     * already uses the same dotted names, so one reader serves both formats.
     * Legacy keys (lightBg, darkCard, accent, text, sub) are mapped too.
     */
    fun fromFlat(p: Map<String, String>, fallbackName: String = "Imported Budsy Theme", source: String = "budsytheme"): ThemeSpec {
        fun g(k: String) = p[k]
        fun set(prefix: String, legacyBg: String?, legacyCard: String?): ColorSet = ColorSet(
            bg = color(g("$prefix.bg") ?: legacyBg?.let(::g)), card = color(g("$prefix.card") ?: legacyCard?.let(::g)),
            thumb = color(g("$prefix.thumb")), text = color(g("$prefix.text") ?: g("text")), sub = color(g("$prefix.sub") ?: g("sub")),
            line = color(g("$prefix.line")), track = color(g("$prefix.track")),
            accent = color(g("$prefix.accent") ?: g("accent")), accent2 = color(g("$prefix.accent2") ?: g("accent2")),
            green = color(g("$prefix.green")), amber = color(g("$prefix.amber")), red = color(g("$prefix.red")),
            sheet = color(g("$prefix.sheet"))
        )
        val light = set("colors.light", "lightBg", "lightCard")
        val dark = set("colors.dark", "darkBg", "darkCard")
        val amoled = set("colors.amoled", null, null)
        val shapes = ShapeSpec(
            panel = f(g("shapes.panel").num(), 0f, 48f, 26f), card = f(g("shapes.card").num(), 0f, 40f, 20f),
            tile = f(g("shapes.tile").num(), 0f, 40f, 22f), button = f(g("shapes.button").num(), 0f, 30f, 16f),
            pill = f(g("shapes.pill").num(), 0f, 60f, 50f)
        )
        val style = runCatching { CardStyle.valueOf((g("card.style") ?: "solid").trim().uppercase()) }.getOrDefault(CardStyle.SOLID)
        val card = CardSpec(
            style = style, borderWidth = f(g("card.borderWidth").num(), 0f, 4f, 1f), borderAlpha = f(g("card.borderAlpha").num(), 0f, 1f, 0.8f),
            fillAlpha = f(g("card.fillAlpha").num(), 0.05f, 1f, 1f), glow = g("card.glow").bool(true),
            gradientFrom = color(g("card.gradientFrom")), gradientTo = color(g("card.gradientTo"))
        )
        val family = (g("font.family") ?: "sans").trim().lowercase().let { if (it in setOf("sans", "serif", "mono", "cursive")) it else "sans" }
        val font = FontSpec(safeRel(g("font.file")), safeRel(g("font.boldFile")), family, f(g("font.scale").num(), 0.8f, 1.3f, 1f), f(g("font.tracking").num(), -1f, 2f, 0f))
        val tab = (g("motion.tabTransition") ?: "slide").trim().lowercase().let { if (it in setOf("slide", "fade", "none")) it else "slide" }
        val motion = MotionSpec(
            enabled = g("motion.enabled").bool(true), speed = f(g("motion.speed").num(), 0.25f, 3f, 1f), enter = g("motion.enter").bool(true),
            bounce = g("motion.bounce").bool(true), glowPulse = g("motion.glowPulse").bool(true), tabTransition = tab
        )
        val bg = BackgroundSpec(
            image = safeRel(g("background.image")), imageAlpha = f(g("background.imageAlpha").num(), 0f, 1f, 0.92f),
            overlayAlpha = f(g("background.overlayAlpha").num(), 0f, 0.9f, 0f), blobs = g("background.blobs").bool(false), dotMatrix = g("background.dotMatrix").bool(false)
        )
        val iconMap = IconKeys.all.mapNotNull { k -> safeRel(g("icons.$k"))?.let { k to it } }.toMap()
        val icons = IconSpec(g("icons.tintAccent").bool(true), iconMap)

        val layout = LayoutSpec(
            pageHorizontal = f(g("layout.pageHorizontal").num(), 0f, 40f, 16f),
            pageTop = f(g("layout.pageTop").num(), 0f, 40f, 4f),
            pageBottom = f(g("layout.pageBottom").num(), 0f, 80f, 28f),
            sectionGap = f(g("layout.sectionGap").num(), 0f, 40f, 10f),
            panelPadding = f(g("layout.panelPadding").num(), 0f, 40f, 14f),
            sectionInset = f(g("layout.sectionInset").num(), 0f, 24f, 4f),
            rowHeight = f(g("layout.rowHeight").num(), 40f, 120f, 64f),
            tileHeight = f(g("layout.tileHeight").num(), 48f, 160f, 72f),
            navHeight = f(g("layout.navHeight").num(), 48f, 96f, 64f),
            contentMaxWidth = f(g("layout.contentMaxWidth").num(), 0f, 900f, 0f),
            gridColumns = (g("layout.gridColumns").num() ?: 2f).toInt().coerceIn(1, 4)
        )
        fun preset(key: String, allowed: Set<String>, default: String): String =
            (g(key) ?: default).trim().lowercase().takeIf { it in allowed } ?: default
        val components = ComponentSpec(
            panel = preset("components.panel", setOf("default","glass","solid","outline","flat","hud","soft","square"), "default"),
            tile = preset("components.tile", setOf("default","glass","solid","outline","flat","hud","minimal"), "default"),
            button = preset("components.button", setOf("default","pill","rounded","square","outline","soft"), "default"),
            switch = preset("components.switch", setOf("ios","pill","square","minimal"), "ios"),
            dialog = preset("components.dialog", setOf("default","glass","sheet","square","minimal"), "default"),
            navigation = preset("components.navigation", setOf("floating","bar","rail","minimal","pill"), "floating"),
            iconShape = preset("components.iconShape", setOf("circle","rounded","square","squircle"), "circle"),
            iconScale = f(g("components.iconScale").num(), 0.65f, 1.6f, 1f),
            elevation = f(g("components.elevation").num(), 0f, 24f, 0f),
            dividerStyle = preset("components.dividerStyle", setOf("hairline","solid","gradient","none"), "hairline")
        )
        val effects = EffectSpec(
            glass = f(g("effects.glass").num(), 0f, 1f, 0f), blur = f(g("effects.blur").num(), 0f, 32f, 0f),
            shadow = f(g("effects.shadow").num(), 0f, 1f, 0f), glow = f(g("effects.glow").num(), 0f, 2f, 1f),
            grain = f(g("effects.grain").num(), 0f, 1f, 0f), scanlines = g("effects.scanlines").bool(false),
            animatedGradient = g("effects.animatedGradient").bool(false), parallax = g("effects.parallax").bool(false)
        )
        val screens = ScreenLayoutSpec(
            overview = preset("screens.overview", setOf("default","compact","editorial","dashboard","immersive","minimal"), "default"),
            sound = preset("screens.sound", setOf("default","compact","editorial","dashboard","immersive","minimal"), "default"),
            controls = preset("screens.controls", setOf("default","compact","editorial","dashboard","immersive","minimal"), "default"),
            settings = preset("screens.settings", setOf("default","compact","editorial","dashboard","immersive","minimal"), "default")
        )

        val feats = buildSet {
            if (!light.isEmpty || !dark.isEmpty || !amoled.isEmpty) add("colors")
            if (font.file != null || font.family != "sans" || font.scale != 1f) add("font")
            if (shapes != ShapeSpec()) add("shapes")
            if (card != CardSpec()) add("cards")
            if (motion != MotionSpec()) add("animation")
            if (bg.image != null || bg.blobs || bg.dotMatrix) add("background")
            if (iconMap.isNotEmpty()) add("icons")
            if (layout != LayoutSpec()) add("layout")
            if (components != ComponentSpec()) add("components")
            if (effects != EffectSpec()) add("effects")
            if (screens != ScreenLayoutSpec()) add("screen layouts")
        }
        return ThemeSpec(
            name = (g("name") ?: fallbackName).trim().take(48).ifBlank { fallbackName },
            author = (g("author") ?: "Unknown").trim().take(48), description = (g("description") ?: "").trim().take(180),
            version = (g("version") ?: "1.0").trim().take(16), source = g("source")?.trim()?.take(16) ?: source,
            light = light, dark = dark, amoled = amoled, shapes = shapes, card = card, font = font, motion = motion,
            background = bg, icons = icons, layout = layout, components = components, effects = effects, screens = screens, features = feats
        )
    }

    /** Flattens nested JSON into dotted keys. Uses org.json (part of Android). */
    fun flattenJson(text: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        fun walk(prefix: String, v: Any?) {
            when (v) {
                is org.json.JSONObject -> v.keys().forEach { k -> walk(if (prefix.isEmpty()) k else "$prefix.$k", v.opt(k)) }
                null, org.json.JSONObject.NULL -> Unit
                else -> out[prefix] = v.toString()
            }
        }
        walk("", org.json.JSONObject(text))
        return out
    }

    /** MIUI/HyperOS description.xml: pull title / author / version with a tolerant regex (no XML parser needed). */
    fun parseMtzDescription(xml: String): Map<String, String> {
        fun tag(vararg names: String): String? = names.firstNotNullOfOrNull { n ->
            Regex("<$n[^>]*>\\s*(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?\\s*</$n>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
        }
        return buildMap {
            tag("title", "name")?.let { put("name", it) }
            tag("author", "designer")?.let { put("author", it) }
            tag("description")?.let { put("description", it) }
            tag("version")?.let { put("version", it) }
        }
    }

}

/** Reads the normalised spec stored for an installed theme (`theme.json` in its private folder). */
object ThemeSpecIO {
    /** `theme.properties` is the normalised spec written by the importer; `theme.json` is only a fallback for hand-placed folders. */
    fun read(dir: File): ThemeSpec? = try {
        val props = File(dir, "theme.properties")
        if (props.isFile) {
            val p = Properties().apply { props.inputStream().use { load(it) } }
            ThemeParser.fromFlat(p.stringPropertyNames().associateWith { p.getProperty(it) }, dir.name)
        } else {
            val json = File(dir, "theme.json")
            if (json.isFile) ThemeParser.fromFlat(ThemeParser.flattenJson(json.readText())) else null
        }
    } catch (_: Exception) { null }
}
