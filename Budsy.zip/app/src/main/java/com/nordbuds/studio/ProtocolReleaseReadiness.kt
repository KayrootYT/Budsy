package com.nordbuds.studio

/** Final-phase evidence and transmission gate. This module never sends Bluetooth packets. */
object ProtocolReleaseReadiness {
    enum class Decision { BLOCKED, NEEDS_EVIDENCE, MANUAL_REVIEW_ONLY }

    data class GateResult(val decision: Decision, val reasons: List<String>) {
        val canProceedToManualReview: Boolean get() = decision == Decision.MANUAL_REVIEW_ONLY
    }

    data class Report(
        val profile: String,
        val total: Int,
        val observed: Int,
        val verified: Int,
        val transports: Set<String>,
        val releaseStatus: String,
        val blockers: List<String>
    ) {
        fun asText(): String = buildString {
            appendLine("Budsy Protocol Laboratory · Final Readiness Report")
            appendLine("Profile: $profile")
            appendLine("Entries: $total · OBSERVED: $observed · VERIFIED: $verified")
            appendLine("Transports: ${transports.ifEmpty { setOf("none") }.joinToString()}")
            appendLine("Release status: $releaseStatus")
            appendLine("Blockers:")
            if (blockers.isEmpty()) appendLine("- None recorded") else blockers.forEach { appendLine("- $it") }
            appendLine("Bluetooth packet replay: disabled")
            appendLine("Hardware validation: not asserted by this report")
        }
    }

    fun assessTransmission(
        profile: String,
        command: String,
        transport: String,
        databaseVerified: Boolean,
        positiveCaptureCount: Int,
        negativeControlPassed: Boolean,
        serviceUuid: String = "",
        characteristicUuid: String = ""
    ): GateResult {
        val reasons = mutableListOf<String>()
        if (profile == "Unassigned") reasons += "Select a specific earbuds model profile."
        if (command.isBlank()) reasons += "A command identifier is required."
        if (!databaseVerified) reasons += "Command is not marked VERIFIED in the evidence database."
        if (positiveCaptureCount < 2) reasons += "At least two distinct positive captures are required."
        if (!negativeControlPassed) reasons += "A negative-control capture has not passed."
        if (transport.contains("GATT", true)) {
            if (serviceUuid.isBlank()) reasons += "GATT service UUID is not confirmed."
            if (characteristicUuid.isBlank()) reasons += "GATT write characteristic UUID is not confirmed."
        }
        if (reasons.isNotEmpty()) return GateResult(Decision.NEEDS_EVIDENCE, reasons)
        // Even with evidence, this tool only permits human review. Framing, auth, ACK and firmware behavior
        // must be independently validated before any future write path is implemented.
        return GateResult(Decision.MANUAL_REVIEW_ONLY, listOf(
            "Evidence gate passed; manual engineering review only.",
            "No packet is transmitted. Confirm framing, checksum, response semantics and firmware compatibility separately."
        ))
    }

    fun buildReport(profile: String, summary: ProtocolCommandDatabase.ProfileSummary,
                    hasImportedCapture: Boolean, hasBaseline: Boolean): Report {
        val blockers = mutableListOf<String>()
        if (profile == "Unassigned") blockers += "No target model selected."
        if (!hasImportedCapture) blockers += "No real HCI snoop capture imported."
        if (!hasBaseline) blockers += "No baseline capture selected for differential analysis."
        if (summary.verified == 0) blockers += "No commands verified with target-device evidence."
        if (summary.observed > 0) blockers += "${summary.observed} command entries remain OBSERVED."
        blockers += "Physical Nord Buds 3 / Nord Buds 3 Pro validation is not recorded in this archive."
        blockers += "Release APK build and device installation are not verified in this environment."
        return Report(profile, summary.total, summary.observed, summary.verified, summary.transports,
            if (blockers.isEmpty()) "READY FOR HARDWARE TEST" else "ENGINEERING PREVIEW · NOT HARDWARE-VERIFIED", blockers)
    }
}
