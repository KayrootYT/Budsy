package com.nordbuds.studio

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.Properties
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Light-weight row for the Theme Manager list. */
data class ImportedTheme(
    val id: String, val name: String, val author: String, val description: String, val source: String,
    val version: String = "1.0", val features: Set<String> = emptySet()
)

object ThemeStore {
    private const val MAX_ENTRIES = 400
    private const val MAX_BYTES = 48L * 1024L * 1024L
    private const val MAX_FILE = 16L * 1024L * 1024L
    /** Only these file types are ever written to disk. Everything else in a package (MTZ native modules, binaries, scripts) is skipped. */
    private val ALLOWED_EXT = setOf("png", "webp", "jpg", "jpeg", "ttf", "otf", "json", "properties", "xml", "txt")
    private val IMAGE_EXT = listOf("png", "webp", "jpg", "jpeg")
    private val ID = Regex("theme_[a-z0-9_]+")

    private fun root(ctx: Context) = File(ctx.filesDir, "budsy_themes").apply { mkdirs() }
    fun themeDir(ctx: Context, id: String): File? = if (id.matches(ID)) File(root(ctx), id).takeIf { it.isDirectory } else null

    fun list(ctx: Context): List<ImportedTheme> = root(ctx).listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.mapNotNull { d ->
        val spec = ThemeSpecIO.read(d) ?: return@mapNotNull null
        ImportedTheme(d.name, spec.name, spec.author, spec.description, spec.source, spec.version, spec.features)
    }?.sortedBy { it.name.lowercase() } ?: emptyList()

    /** Returns the parsed spec of an installed theme, or null (= Stock). */
    fun spec(ctx: Context, id: String?): ThemeSpec? {
        if (id.isNullOrBlank()) return null
        val d = themeDir(ctx, id) ?: return null
        return ThemeSpecIO.read(d)
    }

    /**
     * Imports a `.budsytheme` or `.mtz` package.
     * Safety: path traversal, duplicate paths, size/entry limits are enforced; only [ALLOWED_EXT] files are
     * extracted; nothing is ever executed.
     */
    fun importPackage(ctx: Context, uri: Uri): ImportedTheme {
        val temp = File(root(ctx), ".import_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val seen = HashSet<String>()
            var total = 0L; var count = 0; var kept = 0
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        count++
                        require(count <= MAX_ENTRIES) { "Theme has too many files" }
                        val raw = entry.name.replace('\\', '/')
                        require(raw.isNotBlank() && !raw.startsWith("/") && !Regex("^[A-Za-z]:").containsMatchIn(raw) &&
                            raw.split('/').none { it == ".." || it == "." }) { "Unsafe theme path" }
                        require(seen.add(raw.lowercase())) { "Theme archive contains duplicate paths" }
                        if (entry.isDirectory) continue
                        val name = raw.substringAfterLast('/')
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (ext !in ALLOWED_EXT) continue          // skipped, never written
                        val out = File(temp, raw).canonicalFile
                        require(out.path.startsWith(temp.canonicalPath + File.separator)) { "Unsafe theme path" }
                        out.parentFile?.mkdirs()
                        var copied = 0L
                        out.outputStream().use { output ->
                            val buf = ByteArray(8192)
                            while (true) {
                                val n = zip.read(buf)
                                if (n < 0) break
                                copied += n; total += n
                                require(copied <= MAX_FILE) { "A file inside the theme is too large" }
                                require(total <= MAX_BYTES) { "Theme package is too large" }
                                output.write(buf, 0, n)
                            }
                        }
                        kept++
                    }
                }
            } ?: error("Cannot open selected file")
            require(kept > 0) { "The selected file is not a valid theme package" }

            val isMtz = uri.lastPathSegment?.endsWith(".mtz", true) == true || File(temp, "description.xml").isFile
            val flat = LinkedHashMap<String, String>()
            // Lowest priority first, so later layers overwrite earlier ones.
            File(temp, "description.xml").takeIf { it.isFile }?.let { flat.putAll(ThemeParser.parseMtzDescription(it.readText())) }
            // MTZ standard resources
            File(temp, "fonts").takeIf { it.isDirectory }?.listFiles { f -> f.extension.lowercase() in setOf("ttf", "otf") }
                ?.sortedBy { it.name }?.firstOrNull()?.let { flat["font.file"] = "fonts/${it.name}" }
            File(temp, "wallpaper").takeIf { it.isDirectory }?.listFiles { f -> f.extension.lowercase() in IMAGE_EXT }
                ?.sortedByDescending { it.name.startsWith("default_wallpaper") }?.firstOrNull()?.let { flat["background.image"] = "wallpaper/${it.name}" }
            // Legacy flat properties
            File(temp, "theme.properties").takeIf { it.isFile }?.let { f ->
                runCatching { val p = Properties().apply { f.inputStream().use { load(it) } }; p.stringPropertyNames().forEach { flat[it] = p.getProperty(it) } }
            }
            // Full Budsy spec (highest priority)
            val jsonFile = listOf("budsy/theme.json", "theme.json").map { File(temp, it) }.firstOrNull { it.isFile }
            if (jsonFile != null) {
                val base = jsonFile.parentFile!!.relativeTo(temp).invariantSeparatorsPath
                val j = ThemeParser.flattenJson(jsonFile.readText())
                j.forEach { (k, v) ->
                    // paths inside budsy/theme.json are relative to that folder; store them relative to the package root
                    val isPath = k == "font.file" || k == "font.boldFile" || k == "background.image" || k.startsWith("icons.") && k != "icons.tintAccent"
                    flat[k] = if (isPath && base.isNotEmpty() && !File(temp, v).isFile && File(temp, "$base/$v").isFile) "$base/$v" else v
                }
            }
            flat["source"] = if (isMtz) "mtz" else "budsytheme"

            // Validate referenced files; drop the reference rather than failing the whole import.
            fun ok(rel: String?) = rel != null && File(temp, rel).canonicalFile.let { it.isFile && it.path.startsWith(temp.canonicalPath + File.separator) }
            listOf("font.file", "font.boldFile", "background.image").forEach { k -> if (!ok(flat[k])) flat.remove(k) }
            IconKeys.all.forEach { k -> if (!ok(flat["icons.$k"])) flat.remove("icons.$k") }
            val spec = ThemeParser.fromFlat(flat, "Imported Budsy Theme", if (isMtz) "mtz" else "budsytheme")
            if (spec.schema >= 2) {
                require(spec.ui.complete) { "Theme Engine V2 package must declare ui.complete=true" }
                require(spec.features.containsAll(setOf("colors", "layout", "full-ui", "icons"))) { "Theme is missing complete UI definitions" }
                require(IconKeys.all.all { spec.icons.map.containsKey(it) }) { "Complete theme must provide all six Budsy navigation and system icons" }
                require(listOf(spec.ui.overviewLayout, spec.ui.soundLayout, spec.ui.controlsLayout, spec.ui.settingsLayout).all { it.isNotBlank() }) {
                    "Complete theme must define all four screen layouts"
                }
                require(listOf("colors.light.bg", "colors.dark.bg", "colors.amoled.bg").all { !flat[it].isNullOrBlank() }) { "Complete theme must define Light, Dark and AMOLED palettes" }
                require(ok(flat["background.image"])) { "Complete theme must provide its own wallpaper" }
                require(ok(flat["font.file"])) { "Complete theme must provide its own font" }
                val heroSlots = listOf("hero_case_closed", "hero_case_open", "hero_both_out", "hero_left_out", "hero_right_out")
                require(heroSlots.all { slot -> listOf("png", "webp", "jpg", "jpeg").any { ext -> File(temp, "assets/$slot.$ext").isFile } }) {
                    "Complete theme must provide all five earbuds/case hero states"
                }
            }
            flat["name"] = spec.name

            val id = "theme_" + spec.name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "imported" } +
                "_" + System.currentTimeMillis().toString().takeLast(6)
            val props = Properties().apply { flat.forEach { (k, v) -> setProperty(k, v) } }
            File(temp, "theme.properties").outputStream().use { props.store(it, "Budsy Theme (normalised)") }
            check(temp.renameTo(File(root(ctx), id))) { "Unable to save imported theme" }
            return list(ctx).first { it.id == id }
        } catch (e: Exception) {
            temp.deleteRecursively()
            throw e
        }
    }

    /** Resolve one of the fixed artwork slots (hero images, background). Theme-specified background wins. */
    fun assetFile(ctx: Context, id: String?, slot: String): File? {
        val dir = id?.let { themeDir(ctx, it) } ?: return null
        if (slot == "background") {
            ThemeSpecIO.read(dir)?.background?.image?.let { resolve(dir, it) }?.let { return it }
        }
        val aliases = when (slot) {
            "background" -> listOf("background", "wallpaper", "bg", "default_wallpaper")
            "hero_case_closed" -> listOf("hero_case_closed", "case_closed", "case")
            "hero_case_open" -> listOf("hero_case_open", "case_open", "open_case", "hero_both_in")
            "hero_both_out" -> listOf("hero_both_out", "buds", "earbuds", "hero")
            "hero_left_out" -> listOf("hero_left_out", "left_bud")
            "hero_right_out" -> listOf("hero_right_out", "right_bud")
            else -> listOf(slot)
        }
        for (alias in aliases) for (ext in IMAGE_EXT) {
            val file = File(dir, "assets/$alias.$ext")
            if (file.isFile && file.length() in 1..MAX_FILE) return file
            val nested = dir.walkTopDown().maxDepth(4).firstOrNull { it.isFile && it.name.equals("$alias.$ext", true) && it.length() in 1..MAX_FILE }
            if (nested != null) return nested
        }
        return null
    }

    /** Resolves a spec-relative path (font, icon, background) safely inside the theme folder. */
    fun resolve(dir: File, rel: String): File? {
        val base = dir.canonicalFile
        for (prefix in listOf("", "budsy/", "assets/")) {
            val f = File(base, prefix + rel).canonicalFile
            if (f.path.startsWith(base.path + File.separator) && f.isFile && f.length() in 1..MAX_FILE) return f
        }
        return null
    }

    fun iconFile(ctx: Context, id: String?, key: String): File? {
        val dir = id?.let { themeDir(ctx, it) } ?: return null
        val rel = ThemeSpecIO.read(dir)?.icons?.map?.get(key) ?: return null
        return resolve(dir, rel)
    }

    /** Whole theme folder is exported as-is (valid .budsytheme, also readable by this importer as a ZIP). */
    fun export(ctx: Context, id: String, uri: Uri) {
        val dir = themeDir(ctx, id) ?: error("Theme no longer exists")
        ctx.contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output).use { zip ->
                dir.walkTopDown().filter { it.isFile }.forEach { file ->
                    zip.putNextEntry(ZipEntry(file.relativeTo(dir).invariantSeparatorsPath))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        } ?: error("Cannot create export file")
    }

    /** Independent editable copy including all artwork, fonts and icons. */
    fun duplicate(ctx: Context, id: String): ImportedTheme {
        val source = themeDir(ctx, id) ?: error("Theme no longer exists")
        val old = ThemeSpecIO.read(source) ?: error("Theme no longer exists")
        val newName = (old.name + " Copy").take(48)
        val baseId = "theme_" + newName.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24)
        var newId = baseId + "_" + System.currentTimeMillis().toString().takeLast(6)
        while (File(root(ctx), newId).exists()) newId = baseId + "_" + java.util.UUID.randomUUID().toString().take(8).replace("-", "")
        val temp = File(root(ctx), ".duplicate_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val target = File(temp, file.relativeTo(source).path)
                target.parentFile?.mkdirs()
                file.copyTo(target, overwrite = true)
            }
            val pf = File(temp, "theme.properties")
            val props = Properties().apply { pf.inputStream().use { load(it) } }
            props.setProperty("name", newName)
            pf.outputStream().use { props.store(it, "Duplicated Budsy Theme") }
            check(temp.renameTo(File(root(ctx), newId))) { "Unable to duplicate theme" }
            return list(ctx).first { it.id == newId }
        } catch (e: Exception) { temp.deleteRecursively(); throw e }
    }

    fun delete(ctx: Context, id: String) {
        val d = themeDir(ctx, id) ?: return
        d.deleteRecursively()
    }
}
