package com.nordbuds.studio

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.Properties
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ImportedTheme(val id: String, val name: String, val author: String, val description: String, val source: String)
data class ThemePalette(val lightBg: Long?, val lightCard: Long?, val darkBg: Long?, val darkCard: Long?, val accent: Long?, val text: Long?, val sub: Long?)

object ThemeStore {
    private const val MAX_ENTRIES = 180
    private const val MAX_BYTES = 24L * 1024L * 1024L
    private fun root(ctx: Context) = File(ctx.filesDir, "budsy_themes").apply { mkdirs() }

    fun list(ctx: Context): List<ImportedTheme> = root(ctx).listFiles()?.filter { it.isDirectory }?.mapNotNull { dir ->
        val meta = File(dir, "theme.properties")
        if (!meta.isFile) null else try {
            val p = Properties().apply { meta.inputStream().use { load(it) } }
            ImportedTheme(dir.name, p.getProperty("name", dir.name), p.getProperty("author", "Unknown"),
                p.getProperty("description", ""), p.getProperty("source", "budsytheme"))
        } catch (_: Exception) { null }
    }?.sortedBy { it.name.lowercase() } ?: emptyList()

    /** Imports .budsytheme or compatible MTZ ZIP packages. No scripts or executable content are accepted. */
    fun importPackage(ctx: Context, uri: Uri): ImportedTheme {
        val temp = File(root(ctx), ".import_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val seen = HashSet<String>()
            var total = 0L
            var count = 0
            val manifest = Properties()
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        count++
                        require(count <= MAX_ENTRIES) { "Theme has too many files" }
                        val raw = entry.name.replace('\\', '/')
                        require(raw.isNotBlank() && !raw.startsWith("/") &&
                            !Regex("^[A-Za-z]:").containsMatchIn(raw) &&
                            raw.split('/').none { it == ".." || it == "." }) { "Unsafe theme path" }
                        require(seen.add(raw)) { "Theme archive contains duplicate paths" }
                        val name = raw.substringAfterLast('/')
                        val lower = name.lowercase()
                        require(!lower.endsWith(".apk") && !lower.endsWith(".dex") && !lower.endsWith(".so") &&
                            !lower.endsWith(".jar") && !lower.endsWith(".js") && !lower.endsWith(".html")) { "Executable content is not allowed" }
                        if (entry.isDirectory) continue
                        val fileName = raw.trimStart('/')
                        if (fileName.isBlank()) continue
                        val out = File(temp, fileName).canonicalFile
                        require(out.path.startsWith(temp.canonicalPath + File.separator)) { "Unsafe theme path" }
                        out.parentFile?.mkdirs()
                        var copied = 0L
                        out.outputStream().use { output ->
                            val buf = ByteArray(8192)
                            while (true) {
                                val n = zip.read(buf)
                                if (n < 0) break
                                copied += n; total += n
                                require(total <= MAX_BYTES) { "Theme package is too large" }
                                output.write(buf, 0, n)
                            }
                        }
                        if (name.equals("theme.properties", true) || name.equals("manifest.properties", true)) {
                            try { out.inputStream().use { manifest.load(it) } } catch (_: Exception) { }
                        }
                        // Path was registered before extraction to prevent duplicate-entry overwrite.
                    }
                }
            } ?: error("Cannot open selected file")
            require(seen.isNotEmpty()) { "The selected file is not a valid theme archive" }
            val name = (manifest.getProperty("name") ?: manifest.getProperty("title") ?: "Imported Budsy Theme")
                .trim().take(48).ifBlank { "Imported Budsy Theme" }
            val id = "theme_" + name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24) +
                "_" + System.currentTimeMillis().toString().takeLast(6)
            val props = Properties().apply {
                setProperty("name", name)
                setProperty("author", (manifest.getProperty("author") ?: "Unknown").take(48))
                setProperty("description", (manifest.getProperty("description") ?: "Imported theme package").take(180))
                setProperty("source", if (manifest.getProperty("source")?.contains("mtz", true) == true || uri.lastPathSegment?.endsWith(".mtz", true) == true) "mtz" else "budsytheme")
                listOf("lightBg", "lightCard", "darkBg", "darkCard", "accent", "text", "sub").forEach { key ->
                    manifest.getProperty(key)?.trim()?.takeIf { it.matches(Regex("#?[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?")) }?.let {
                        setProperty(key, if (it.startsWith("#")) it else "#$it")
                    }
                }
            }
            File(temp, "theme.properties").outputStream().use { props.store(it, "Budsy Theme") }
            val target = File(root(ctx), id)
            check(temp.renameTo(target)) { "Unable to save imported theme" }
            return list(ctx).first { it.id == id }
        } catch (e: Exception) {
            temp.deleteRecursively()
            throw e
        }
    }



    /** Resolve supported artwork slots from imported package assets. */
    fun assetFile(ctx: Context, id: String?, slot: String): File? {
        if (id.isNullOrBlank() || !id.matches(Regex("theme_[a-z0-9_]+"))) return null
        val dir = File(root(ctx), id)
        if (!dir.isDirectory) return null
        val aliases = when (slot) {
            "background" -> listOf("background", "wallpaper", "bg")
            "hero_case_closed" -> listOf("hero_case_closed", "case_closed", "case")
            "hero_case_open" -> listOf("hero_case_open", "case_open", "open_case", "hero_both_in")
            "hero_both_out" -> listOf("hero_both_out", "buds", "earbuds", "hero")
            "hero_left_out" -> listOf("hero_left_out", "left_bud")
            "hero_right_out" -> listOf("hero_right_out", "right_bud")
            else -> listOf(slot)
        }
        val extensions = listOf("png", "webp", "jpg", "jpeg")
        for (alias in aliases) for (ext in extensions) {
            val file = File(dir, "assets/$alias.$ext")
            if (file.isFile && file.length() in 1..(12L * 1024L * 1024L)) return file
            val nested = dir.walkTopDown().firstOrNull {
                it.isFile && it.name.equals("$alias.$ext", true) && it.length() in 1..(12L * 1024L * 1024L)
            }
            if (nested != null) return nested
        }
        return null
    }

    fun palette(ctx: Context, id: String): ThemePalette? {
        val file = File(File(root(ctx), id), "theme.properties")
        if (!file.isFile) return null
        return try {
            val p = Properties().apply { file.inputStream().use { load(it) } }
            fun color(key: String): Long? = p.getProperty(key)?.removePrefix("#")?.toLongOrNull(16)?.let {
                if (p.getProperty(key).length <= 7) 0xFF000000L or it else it
            }
            ThemePalette(color("lightBg"), color("lightCard"), color("darkBg"), color("darkCard"),
                color("accent"), color("text"), color("sub"))
        } catch (_: Exception) { null }
    }

    fun export(ctx: Context, id: String, uri: Uri) {
        val dir = File(root(ctx), id)
        require(dir.isDirectory) { "Theme no longer exists" }
        ctx.contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output).use { zip ->
                dir.walkTopDown().filter { it.isFile && it.name != "theme.properties" }.forEach { file ->
                    val relative = file.relativeTo(dir).invariantSeparatorsPath
                    val exportPath = if (relative.startsWith("assets/")) relative else "assets/$relative"
                    zip.putNextEntry(ZipEntry(exportPath))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry("theme.properties"))
                File(dir, "theme.properties").inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        } ?: error("Cannot create export file")
    }


    /** Creates an independent editable copy of an imported theme, including its artwork. */
    fun duplicate(ctx: Context, id: String): ImportedTheme {
        require(id.matches(Regex("theme_[a-z0-9_]+"))) { "Invalid theme id" }
        val source = File(root(ctx), id)
        require(source.isDirectory && File(source, "theme.properties").isFile) { "Theme no longer exists" }
        val old = Properties().apply { File(source, "theme.properties").inputStream().use { load(it) } }
        val originalName = old.getProperty("name", "Imported Budsy Theme")
        val newName = (originalName + " Copy").take(48)
        val baseId = "theme_" + newName.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24)
        var newId = baseId + "_" + System.currentTimeMillis().toString().takeLast(6)
        while (File(root(ctx), newId).exists()) newId = baseId + "_" + java.util.UUID.randomUUID().toString().take(8)
        val temp = File(root(ctx), ".duplicate_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(source)
                val target = File(temp, relative.path)
                target.parentFile?.mkdirs()
                file.copyTo(target, overwrite = true)
            }
            val propsFile = File(temp, "theme.properties")
            val props = Properties().apply { propsFile.inputStream().use { load(it) } }
            props.setProperty("name", newName)
            props.setProperty("description", (props.getProperty("description", "") + " · Copy").take(180))
            propsFile.outputStream().use { props.store(it, "Duplicated Budsy Theme") }
            val target = File(root(ctx), newId)
            check(temp.renameTo(target)) { "Unable to duplicate theme" }
            return list(ctx).first { it.id == newId }
        } catch (e: Exception) {
            temp.deleteRecursively()
            throw e
        }
    }

    fun delete(ctx: Context, id: String) {
        require(id.matches(Regex("theme_[a-z0-9_]+"))) { "Invalid theme id" }
        File(root(ctx), id).deleteRecursively()
    }
}
