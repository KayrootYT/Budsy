package com.nordbuds.studio.protocol

/** Conservative payload decoder. It labels only layouts already observed in captures. */
object ProtocolDecoder {
    data class Decoded(val title: String, val detail: String, val confidence: String = "Observed layout")

    fun decode(command: Int, group: Int, payload: IntArray): Decoded {
        val reply = (group and 0x80) != 0
        if (!reply) return Decoded(Protocol.commandName(command), describeRequest(command, payload), "Command identity")
        val status = payload.firstOrNull()
        if (status != null && status != 0) {
            return Decoded("${Protocol.commandName(command)} · error", "Status=0x${Protocol.hex(status)}; raw payload retained")
        }
        return when (command) {
            0x0106 -> {
                val items = Protocol.parseBattery(payload).joinToString { b ->
                    val side = when (b.slot) { 0 -> "Left"; 1 -> "Right"; else -> "Case" }
                    "$side=${if (b.percent < 0) "unknown" else "${b.percent}%"}${if (b.charging) " charging" else ""}"
                }
                Decoded("Battery response", items.ifBlank { "No valid battery entries" })
            }
            0x0109 -> {
                val items = Protocol.parseWear(payload).joinToString { "slot${it.slot + 1}=0x${Protocol.hex(it.flags)}" }
                Decoded("Wear-state response", items.ifBlank { "No valid wear entries" })
            }
            0x010D -> {
                val items = Protocol.parseFlags(payload).joinToString { "0x${Protocol.hex(it.first)}=${Protocol.hex(it.second)}" }
                Decoded("Feature flags response", items.ifBlank { "No non-padding feature pairs" })
            }
            0x0108 -> Decoded("Gesture table response", "${Protocol.parseGestureEntries(payload).size} gesture entries")
            0x010C -> Decoded("Noise / hold response", "Raw mode payload: ${hex(payload.drop(1).toIntArray())}", "Raw only; mode mapping unverified")
            0x0105 -> Decoded("Firmware response", Protocol.parseFirmware(payload) ?: "Firmware string not present")
            0x010F -> Decoded("EQ preset response", "Raw payload: ${hex(payload.drop(1).toIntArray())}", "Raw only; preset mapping unverified")
            0x0124 -> Decoded("BassWave response", "Raw payload: ${hex(payload.drop(1).toIntArray())}", "Raw only; scale unverified")
            0x0204 -> Decoded("Device event", "Event payload: ${hex(payload)}", "Event subcode mapping partially observed")
            else -> Decoded(Protocol.commandName(command), "Status=${status?.let { "0x${Protocol.hex(it)}" } ?: "n/a"} · payload=${hex(payload)}", "Raw payload")
        }
    }

    private fun describeRequest(command: Int, p: IntArray): String = when (command) {
        0x010D -> if (p.size >= 1) "Query ${p[0]} feature IDs: ${hex(p.drop(1).toIntArray())}" else "Feature query"
        0x010C -> "Mode query: ${hex(p)}"
        0x0403 -> "Feature write payload: ${hex(p)}"
        0x0404 -> "Noise / hold write payload: ${hex(p)}"
        0x0401 -> "Gesture write payload: ${hex(p)}"
        0x0418 -> "Custom EQ write payload (${p.size} bytes)"
        0x041B -> "BassWave write payload: ${hex(p)}"
        else -> "Payload: ${hex(p)}"
    }

    private fun hex(values: IntArray): String = if (values.isEmpty()) "(empty)" else values.joinToString(" ") { Protocol.hex(it) }
}
