package com.nordbuds.studio.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.nordbuds.studio.Buds
import com.nordbuds.studio.MainActivity
import com.nordbuds.studio.R

class BudsWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = update(ctx, mgr, ids)
    companion object {
        fun notifyUpdate(ctx: Context) { val mgr = AppWidgetManager.getInstance(ctx); val ids = mgr.getAppWidgetIds(ComponentName(ctx, BudsWidgetProvider::class.java)); if (ids.isNotEmpty()) update(ctx, mgr, ids) }
        private fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_buds)
            val l = Buds.battery[0]; val r = Buds.battery[1]; val c = Buds.battery[2]; val waiting = ctx.getString(R.string.widget_waiting)
            views.setTextViewText(R.id.w_left, if (l >= 0) "$l%" else waiting); views.setTextViewText(R.id.w_right, if (r >= 0) "$r%" else waiting); views.setTextViewText(R.id.w_case, if (c >= 0) "$c%" else waiting)
            views.setTextViewText(R.id.w_status, if (Buds.connected) ctx.getString(R.string.widget_connected) else ctx.getString(R.string.widget_disconnected))
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            views.setOnClickPendingIntent(R.id.w_title, pi); ids.forEach { mgr.updateAppWidget(it, views) }
        }
    }
}
