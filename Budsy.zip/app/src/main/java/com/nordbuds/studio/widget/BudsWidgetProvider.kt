package com.nordbuds.studio.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.nordbuds.studio.Buds
import com.nordbuds.studio.MainActivity
import com.nordbuds.studio.R

class BudsWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = update(ctx, mgr, ids)
    companion object {
        fun notifyUpdate(ctx: Context) { val mgr = AppWidgetManager.getInstance(ctx); val ids = mgr.getAppWidgetIds(ComponentName(ctx, BudsWidgetProvider::class.java)); if (ids.isNotEmpty()) update(ctx, mgr, ids) }
        private fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val views = RemoteViews(ctx.packageName, R.layout.widget_buds)
            val waiting = ctx.getString(R.string.widget_waiting)
            fun slot(valueId: Int, barId: Int, pct: Int) {
                views.setTextViewText(valueId, if (pct >= 0) "$pct%" else waiting)
                views.setProgressBar(barId, 100, pct.coerceAtLeast(0), false)
                views.setTextColor(valueId, if (pct in 0..19) 0xFFFF9F0A.toInt() else 0xFFFFFFFF.toInt())
            }
            slot(R.id.w_left, R.id.w_left_bar, Buds.battery[0])
            slot(R.id.w_right, R.id.w_right_bar, Buds.battery[1])
            slot(R.id.w_case, R.id.w_case_bar, Buds.battery[2])
            views.setTextViewText(R.id.w_status, if (Buds.connected) ctx.getString(R.string.widget_connected) else ctx.getString(R.string.widget_disconnected))
            views.setTextColor(R.id.w_status, if (Buds.connected) 0xFF30D158.toInt() else 0xFF8E93A6.toInt())
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            views.setOnClickPendingIntent(R.id.w_root, pi)
            ids.forEach { mgr.updateAppWidget(it, views) }
        }
    }
}
