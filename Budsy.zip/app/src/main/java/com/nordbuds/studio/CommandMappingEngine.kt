package com.nordbuds.studio

/**
 * Compares two captures and surfaces protocol signals that changed.
 * It deliberately does not assign semantic feature names: the operator must
 * repeat one controlled action and verify the candidate before labelling it.
 */
object CommandMappingEngine {
    data class Candidate(
        val transport: String,
        val signature: String,
        val baselineCount: Int,
        val currentCount: Int,
        val delta: Int,
        val samples: List<String>
    ) {
        fun line(): String = "$transport · $signature · ${baselineCount}→${currentCount} (Δ${if (delta >= 0) "+" else ""}$delta)" +
            if (samples.isNotEmpty()) " · ${samples.joinToString(" | ")}" else ""
    }

    fun compare(
        baseline: HciSnoopImporter.Report,
        current: HciSnoopImporter.Report,
        limit: Int = 40
    ): List<Candidate> {
        val before = linkedMapOf<String, MutableList<String>>()
        val after = linkedMapOf<String, MutableList<String>>()

        fun vendorKey(f: HciSnoopImporter.VendorFrame) =
            "CMD 0x${f.command.toString(16).padStart(4,'0')} group=0x${f.group.toString(16).padStart(2,'0')}"
        baseline.vendorFrames.forEach { frame ->
            before.getOrPut("RFCOMM|${frame.direction} ${vendorKey(frame)}") { mutableListOf() }
                .add(frame.payload.joinToString("") { b -> "%02x".format(b) })
        }
        current.vendorFrames.forEach { frame ->
            after.getOrPut("RFCOMM|${frame.direction} ${vendorKey(frame)}") { mutableListOf() }
                .add(frame.payload.joinToString("") { b -> "%02x".format(b) })
        }

        fun gattKey(e: HciSnoopImporter.GattEvent): String {
            val h = e.handle?.let { "handle=0x${it.toString(16).padStart(4,'0')}" } ?: "handle=?"
            return "${e.direction} ATT ${e.opcodeName} $h uuid=${e.uuid ?: "unknown"}"
        }
        baseline.gattEvents.forEach { event ->
            before.getOrPut("BLE/GATT|${gattKey(event)}") { mutableListOf() }
                .add(event.value.joinToString("") { b -> "%02x".format(b) })
        }
        current.gattEvents.forEach { event ->
            after.getOrPut("BLE/GATT|${gattKey(event)}") { mutableListOf() }
                .add(event.value.joinToString("") { b -> "%02x".format(b) })
        }

        val keys = before.keys + after.keys
        return keys.mapNotNull { key ->
            val a = before[key].orEmpty()
            val b = after[key].orEmpty()
            val delta = b.size - a.size
            if (delta == 0 && a.toSet() == b.toSet()) null else {
                val transport = key.substringBefore('|')
                Candidate(transport, key.substringAfter('|'), a.size, b.size, delta,
                    b.distinct().take(3).map { if (it.length > 64) it.take(64) + "…" else it })
            }
        }.sortedWith(compareByDescending<Candidate> { kotlin.math.abs(it.delta) }
            .thenByDescending { it.currentCount }).take(limit.coerceIn(1,100))
    }
}
