package com.nordbuds.studio

import com.nordbuds.studio.buds.Prefs

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val prefs: Prefs, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit,
    val theme: Int, val setTheme: (Int) -> Unit,
    val appearance: Int, val setAppearance: (Int) -> Unit,
    val audio: Set<String>, val audioKnown: Boolean,
    val askNotifPerm: () -> Unit = {}, val notifGranted: Boolean = true,
    val askScanPerm: () -> Unit = {}, val scanPerm: Boolean = false
)
