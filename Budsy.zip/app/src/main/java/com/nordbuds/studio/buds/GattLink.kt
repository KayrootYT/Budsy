package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import com.nordbuds.studio.protocol.Protocol
import java.util.UUID

/**
 * HeyMelody BLE/GATT transport discovered in the supplied APK (GattDevice.smali).
 * This is deliberately a separate transport from RFCOMM Link: the same UUID family
 * must not cause the app to silently switch transports or assume identical firmware support.
 *
 * Diagnostic-only: discovers the vendor service and subscribes to notifications. No control
 * writes are exposed until model-specific ATT framing/fragmentation has been captured.
 */
@SuppressLint("MissingPermission")
class GattLink(
    private val context: Context,
    private val onState: (State, String?) -> Unit,
    private val onFrame: (Protocol.Frame) -> Unit
) : BluetoothGattCallback() {
    enum class State { DISCONNECTED, CONNECTING, DISCOVERING, READY, FAILED }

    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var notifyCharacteristic: BluetoothGattCharacteristic? = null
    private val parser = Protocol.Parser()

    fun connect(device: BluetoothDevice) {
        close()
        onState(State.CONNECTING, null)
        gatt = if (Build.VERSION.SDK_INT >= 23) {
            device.connectGatt(context, false, this, BluetoothDevice.TRANSPORT_LE)
        } else {
            device.connectGatt(context, false, this)
        }
    }

    override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
        if (status != BluetoothGatt.GATT_SUCCESS) {
            onState(State.FAILED, "GATT connection status=$status")
            closeGatt(g)
            return
        }
        when (newState) {
            BluetoothProfile.STATE_CONNECTED -> {
                onState(State.DISCOVERING, null)
                if (!g.discoverServices()) onState(State.FAILED, "GATT service discovery could not start")
            }
            BluetoothProfile.STATE_DISCONNECTED -> {
                notifyCharacteristic = null
                onState(State.DISCONNECTED, null)
            }
        }
    }

    override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
        if (status != BluetoothGatt.GATT_SUCCESS) {
            onState(State.FAILED, "GATT service discovery status=$status")
            return
        }
        val service = g.getService(SERVICE_UUID)
        val write = service?.getCharacteristic(WRITE_UUID)
        val notify = service?.getCharacteristic(NOTIFY_UUID)
        if (write == null || notify == null) {
            onState(State.FAILED, "Expected HeyMelody service/write/notify characteristics not found")
            return
        }
        if ((write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) == 0 &&
            (write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) == 0) {
            onState(State.FAILED, "Write characteristic has no supported write property")
            return
        }
        if ((notify.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) == 0) {
            onState(State.FAILED, "Notify characteristic has no notify/indicate property")
            return
        }
        notifyCharacteristic = notify
        if (!g.setCharacteristicNotification(notify, true)) {
            onState(State.FAILED, "Could not enable local GATT notifications")
            return
        }
        val cccd = notify.getDescriptor(CCCD_UUID)
        if (cccd == null) {
            onState(State.FAILED, "Notify characteristic has no CCCD descriptor")
            return
        }
        val value = if ((notify.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        val started = if (Build.VERSION.SDK_INT >=  writeDescriptorApi()) {
            g.writeDescriptor(cccd, value) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            cccd.value = value
            @Suppress("DEPRECATION")
            g.writeDescriptor(cccd)
        }
        if (!started) onState(State.FAILED, "Could not subscribe to GATT notifications")
    }

    // API 33 introduced the value-taking writeDescriptor overload.
    private fun writeDescriptorApi() = 33

    override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
        if (descriptor.uuid == CCCD_UUID) {
            if (status == BluetoothGatt.GATT_SUCCESS) onState(State.READY, null)
            else onState(State.FAILED, "CCCD subscription failed: $status")
        }
    }

    override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
        if (characteristic.uuid == NOTIFY_UUID) characteristic.value?.let { acceptNotification(it) }
    }

    override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
        if (characteristic.uuid == NOTIFY_UUID) acceptNotification(value)
    }

    private fun acceptNotification(bytes: ByteArray) {
        synchronized(parser) { parser.feed(bytes).forEach(onFrame) }
    }

    // No GATT control-write API is exposed here yet. The supplied APK establishes the
    // service/characteristic UUIDs, but Nord Buds 3/3 Pro captures are still required to
    // prove ATT framing, command routing and fragmentation before enabling writes.

    fun close() {
        val old = gatt
        gatt = null
        notifyCharacteristic = null
        if (old != null) closeGatt(old)
        onState(State.DISCONNECTED, null)
    }

    private fun closeGatt(g: BluetoothGatt) {
        try { g.disconnect() } catch (_: Exception) { }
        try { g.close() } catch (_: Exception) { }
        if (gatt === g) gatt = null
    }

    companion object {
        // Exact UUID constants read from decoded GattDevice.smali in the supplied APK.
        val SERVICE_UUID: UUID = UUID.fromString("0000079A-D102-11E1-9B23-00025B00A5A5")
        val WRITE_UUID: UUID = UUID.fromString("0100079A-D102-11E1-9B23-00025B00A5A5")
        val NOTIFY_UUID: UUID = UUID.fromString("0200079A-D102-11E1-9B23-00025B00A5A5")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
    }
}
