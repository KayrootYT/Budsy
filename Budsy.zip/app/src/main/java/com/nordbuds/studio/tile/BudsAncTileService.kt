package com.nordbuds.studio.tile

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.nordbuds.studio.Buds
import com.nordbuds.studio.MainActivity
import com.nordbuds.studio.R

/** Quick Settings tile: tap to cycle Noise cancel -> Transparency -> Off. */
class BudsAncTileService : TileService() {
    override fun onStartListening() { super.onStartListening(); refresh() }

    override fun onClick() {
        super.onClick()
        if (!Buds.connected) { openApp(); return }
        val next = when (Buds.ancMode) { Buds.ANC_ON -> Buds.ANC_TRANSP; Buds.ANC_TRANSP -> Buds.ANC_OFF; else -> Buds.ANC_ON }
        Buds.setAnc(next)
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        else startActivityAndCollapse(i)
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = getString(R.string.tile_anc_label)
        if (Buds.connected) {
            t.state = if (Buds.ancMode == Buds.ANC_OFF || Buds.ancMode < 0) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
            if (Build.VERSION.SDK_INT >= 29) t.subtitle = getString(when (Buds.ancMode) {
                Buds.ANC_ON -> R.string.noise_cancel; Buds.ANC_TRANSP -> R.string.hold_transparency; else -> R.string.hold_off
            })
        } else {
            t.state = Tile.STATE_UNAVAILABLE
            if (Build.VERSION.SDK_INT >= 29) t.subtitle = getString(R.string.notif_disconnected)
        }
        t.updateTile()
    }
}
