package com.nordbuds.studio

import com.nordbuds.studio.protocol.Protocol

/**
 * Read-only btsnoop/HCI H4 analyzer.
 * Reassembles HCI ACL -> L2CAP -> RFCOMM UIH data and extracts proprietary
 * AA-framed Budsy/HeyMelody control messages when they are present in RFCOMM DLCI data.
 * Unsupported captures are reported as metadata only; no packets are transmitted.
 */
object HciSnoopImporter {
    private val MAGIC = byteArrayOf(0x62,0x74,0x73,0x6e,0x6f,0x6f,0x70,0x00)
    private const val HEADER_SIZE = 16
    private const val RECORD_HEADER_SIZE = 24
    private const val MAX_FILE_BYTES = 20 * 1024 * 1024
    private const val MAX_RECORDS = 100_000
    private const val MAX_L2CAP_PDU = 65_535
    private const val MAX_REASSEMBLY = 131_072
    private const val RFCOMM_PSM = 0x0003

    data class VendorFrame(
        val direction: String,
        val command: Int,
        val group: Int,
        val sequence: Int,
        val payload: List<Int>
    ) {
        fun line(): String = "$direction 0x${Protocol.hex(command ushr 8)}${Protocol.hex(command)} seq=${Protocol.hex(sequence)} group=${Protocol.hex(group)} payload=${payload.joinToString(" ") { Protocol.hex(it) }}"
    }

    data class GattCharacteristic(
        val valueHandle: Int,
        val uuid: String,
        val properties: Int = 0
    )

    data class GattEvent(
        val direction: String,
        val opcode: Int,
        val opcodeName: String,
        val handle: Int?,
        val uuid: String?,
        val value: List<Int>
    ) {
        fun line(): String = "$direction $opcodeName" +
            (handle?.let { " handle=0x${it.toString(16).padStart(4,'0')}" } ?: "") +
            (uuid?.let { " uuid=$it" } ?: "") +
            (if (value.isNotEmpty()) " value=${value.take(48).joinToString(" ") { Protocol.hex(it) }}" else "")
    }

    data class Report(
        val fileName: String,
        val version: Long,
        val dataLinkType: Long,
        val totalRecords: Int,
        val sentRecords: Int,
        val receivedRecords: Int,
        val droppedRecords: Long,
        val commandPackets: Int,
        val eventPackets: Int,
        val aclPackets: Int,
        val otherPackets: Int,
        val opcodeCounts: Map<Int, Int>,
        val eventCodeCounts: Map<Int, Int>,
        val warnings: List<String>,
        val vendorFrames: List<VendorFrame> = emptyList(),
        val l2capPackets: Int = 0,
        val rfcommFrames: Int = 0,
        val gattEvents: List<GattEvent> = emptyList(),
        val gattCharacteristics: List<GattCharacteristic> = emptyList(),
        val attPackets: Int = 0
    ) {
        fun summary(): String = "HCI=$totalRecords · TX=$sentRecords RX=$receivedRecords · CMD=$commandPackets EVT=$eventPackets ACL=$aclPackets · L2CAP=$l2capPackets RFCOMM=$rfcommFrames · ATT=$attPackets GATT events=${gattEvents.size} · vendor=${vendorFrames.size}"
    }

    data class Diff(val addedOpcodes: List<Int>, val removedOpcodes: List<Int>, val changedOpcodes: List<Pair<Int, Pair<Int, Int>>>, val recordDelta: Int)

    private class StreamExtractor {
        private data class Fragment(var bytes: ByteArray, var expected: Int)
        private data class PendingConnection(val direction: String, val sourceCid: Int)
        private val aclFragments = mutableMapOf<String, Fragment>()
        private val pendingConnections = mutableMapOf<Int, PendingConnection>()
        private val rfcommChannels = mutableMapOf<String, Boolean>()
        private val rfcommBuffers = mutableMapOf<String, ByteArray>()
        private val vendorParsers = mutableMapOf<String, Protocol.Parser>()
        private val readRequests = mutableMapOf<String, Int>()
        private val readTypeRequests = mutableMapOf<String, String>()
        private val uuidByHandle = mutableMapOf<Int, String>()
        private val characteristicByHandle = linkedMapOf<Int, GattCharacteristic>()
        val gattEvents = mutableListOf<GattEvent>()
        val gattCharacteristics: List<GattCharacteristic> get() = characteristicByHandle.values.toList()
        var attPackets = 0
            private set
        val vendorFrames = mutableListOf<VendorFrame>()
        var l2capPackets = 0
            private set
        var rfcommFrames = 0
            private set
        val warnings = mutableListOf<String>()

        fun accept(direction: String, packet: ByteArray, recordIndex: Int) {
            if (packet.size < 5 || (packet[0].toInt() and 0xff) != 0x02) return
            val handleFlags = le16(packet,1)
            val handle = handleFlags and 0x0fff
            val pb = (handleFlags ushr 12) and 0x03
            val dataLen = le16(packet,3)
            if (dataLen > packet.size - 5) {
                warnings += "ACL record $recordIndex truncated (${packet.size-5}/$dataLen)"
                return
            }
            val key = "$direction:$handle"
            val data = packet.copyOfRange(5,5+dataLen)
            if (pb == 0 || pb == 2 || pb == 3) {
                if (data.size < 4) { warnings += "Short L2CAP start at ACL record $recordIndex"; return }
                val l2len = le16(data,0)
                if (l2len > MAX_L2CAP_PDU) { warnings += "Oversized L2CAP PDU"; return }
                val expected = 4 + l2len
                if (data.size >= expected) consumeL2cap(direction, data.copyOfRange(0,expected))
                else aclFragments[key] = Fragment(data,expected)
            } else if (pb == 1) {
                val old = aclFragments[key] ?: return
                if (old.bytes.size + data.size > MAX_REASSEMBLY) {
                    aclFragments.remove(key); warnings += "ACL reassembly limit exceeded"; return
                }
                old.bytes += data
                if (old.bytes.size >= old.expected) {
                    aclFragments.remove(key)
                    consumeL2cap(direction, old.bytes.copyOfRange(0,old.expected))
                }
            }
        }

        private fun consumeL2cap(direction: String, pdu: ByteArray) {
            if (pdu.size < 4) return
            val length = le16(pdu,0)
            val cid = le16(pdu,2)
            if (length > pdu.size - 4) return
            val payload = pdu.copyOfRange(4,4+length)
            l2capPackets++
            if (cid == 0x0001) {
                parseSignaling(direction,payload)
                return
            }
            if (cid == 0x0004) {
                parseAtt(direction,payload)
                return
            }
            if (rfcommChannels["$direction:$cid"] == true) parseRfcomm(direction,payload)
        }

        private fun parseSignaling(direction: String, payload: ByteArray) {
            var i=0
            while (i+4 <= payload.size) {
                val code=payload[i].toInt() and 0xff
                val id=payload[i+1].toInt() and 0xff
                val len=le16(payload,i+2)
                if (len > payload.size-i-4) return
                val b=i+4
                when (code) {
                    0x02 -> if (len >= 4) {
                        val psm=le16(payload,b); val scid=le16(payload,b+2)
                        if (psm == RFCOMM_PSM) pendingConnections[id]=PendingConnection(direction,scid)
                    }
                    0x03 -> if (len >= 8) {
                        val dcid=le16(payload,b); val scid=le16(payload,b+2)
                        val result=le16(payload,b+4)
                        val pending=pendingConnections.remove(id)
                        if (pending != null && result == 0) {
                            rfcommChannels["${pending.direction}:$dcid"]=true
                            val reverse=if (pending.direction=="TX") "RX" else "TX"
                            rfcommChannels["$reverse:$scid"]=true
                        }
                    }
                }
                i += 4+len
            }
        }



        private fun opposite(direction: String) = if (direction == "TX") "RX" else "TX"

        private fun uuid(bytes: ByteArray, offset: Int, size: Int): String {
            if (size == 2 && offset + 2 <= bytes.size) return "0000%04x-0000-1000-8000-00805f9b34fb".format(le16(bytes, offset))
            if (size != 16 || offset + 16 > bytes.size) return "unknown"
            val b = bytes.copyOfRange(offset, offset + 16).reversedArray()
            val h = b.joinToString("") { "%02x".format(it.toInt() and 255) }
            return "${h.substring(0,8)}-${h.substring(8,12)}-${h.substring(12,16)}-${h.substring(16,20)}-${h.substring(20)}"
        }

        private fun attName(op: Int): String = when (op) {
            0x01 -> "ERROR"; 0x02 -> "EXCHANGE_MTU_REQ"; 0x03 -> "EXCHANGE_MTU_RSP"
            0x04 -> "FIND_INFO_REQ"; 0x05 -> "FIND_INFO_RSP"; 0x06 -> "FIND_BY_TYPE_REQ"
            0x07 -> "FIND_BY_TYPE_RSP"; 0x08 -> "READ_BY_TYPE_REQ"; 0x09 -> "READ_BY_TYPE_RSP"
            0x0A -> "READ_REQ"; 0x0B -> "READ_RSP"; 0x0C -> "READ_BLOB_REQ"; 0x0D -> "READ_BLOB_RSP"
            0x0E -> "READ_MULTIPLE_REQ"; 0x0F -> "READ_MULTIPLE_RSP"; 0x10 -> "READ_BY_GROUP_REQ"
            0x11 -> "READ_BY_GROUP_RSP"; 0x12 -> "WRITE_REQ"; 0x13 -> "WRITE_RSP"
            0x16 -> "PREPARE_WRITE_REQ"; 0x17 -> "PREPARE_WRITE_RSP"; 0x18 -> "EXECUTE_WRITE_REQ"
            0x19 -> "EXECUTE_WRITE_RSP"; 0x1B -> "NOTIFICATION"; 0x1D -> "INDICATION"
            0x1E -> "CONFIRMATION"; 0x52 -> "WRITE_COMMAND"; 0xD2 -> "SIGNED_WRITE"
            else -> "ATT_0x%02X".format(op)
        }

        private fun parseAtt(direction: String, p: ByteArray) {
            if (p.isEmpty()) return
            val op = p[0].toInt() and 255
            attPackets++
            fun add(handle: Int?, value: ByteArray, forcedUuid: String? = null) {
                val id = handle?.let { uuidByHandle[it] }
                if (gattEvents.size < 5000) gattEvents += GattEvent(
                    direction, op, attName(op), handle, forcedUuid ?: id,
                    value.map { it.toInt() and 255 }
                )
            }
            when (op) {
                0x04 -> { /* Find Information request: range only */ }
                0x05 -> if (p.size >= 2) {
                    val format = p[1].toInt() and 255
                    val step = if (format == 1) 4 else if (format == 2) 18 else 0
                    if (step > 0) {
                        var i = 2
                        while (i + step <= p.size) {
                            val h = le16(p, i)
                            val u = uuid(p, i + 2, step - 2)
                            uuidByHandle[h] = u
                            add(h, byteArrayOf(), u)
                            i += step
                        }
                    }
                }
                0x08 -> if (p.size >= 7) {
                    // ATT Read By Type request: start handle, end handle, then UUID.
                    val requested = uuid(p, 5, p.size - 5)
                    readTypeRequests[opposite(direction)] = requested
                    add(null, p.copyOfRange(1, p.size), requested)
                }
                0x09 -> if (p.size >= 2) {
                    val requested = readTypeRequests.remove(direction)
                    val isCharacteristicDeclaration = requested == "00002803-0000-1000-8000-00805f9b34fb"
                    val entryLen = p[1].toInt() and 255
                    if (entryLen >= 3) {
                        var i = 2
                        while (i + entryLen <= p.size) {
                            val h = le16(p, i)
                            val value = p.copyOfRange(i + 2, i + entryLen)
                            if (isCharacteristicDeclaration && value.size >= 5) {
                                val props = value[0].toInt() and 255
                                val valueHandle = le16(value, 1)
                                val charUuid = uuid(value, 3, value.size - 3)
                                uuidByHandle[valueHandle] = charUuid
                                characteristicByHandle[valueHandle] = GattCharacteristic(valueHandle, charUuid, props)
                                add(valueHandle, value, charUuid)
                            } else {
                                add(h, value)
                            }
                            i += entryLen
                        }
                    }
                }
                0x0A, 0x0C -> if (p.size >= 3) readRequests[opposite(direction)] = le16(p, 1)
                0x0B, 0x0D -> {
                    val h = readRequests.remove(direction)
                    add(h, p.copyOfRange(1, p.size))
                }
                0x12, 0x52, 0x16, 0x1B, 0x1D, 0xD2 -> if (p.size >= 3) {
                    val h = le16(p, 1)
                    add(h, p.copyOfRange(3, p.size))
                }
                0x01 -> if (p.size >= 5) {
                    val h = le16(p, 2)
                    add(h, p.copyOfRange(1, p.size))
                }
                else -> add(null, p.copyOfRange(1, p.size))
            }
        }

        private fun parseRfcomm(direction: String, payload: ByteArray) {
            val key="$direction:rfcomm"
            var buffer=(rfcommBuffers[key] ?: byteArrayOf()) + payload
            var cursor=0
            while (cursor+4 <= buffer.size) {
                val address=buffer[cursor].toInt() and 0xff
                val control=buffer[cursor+1].toInt() and 0xff
                val len1=buffer[cursor+2].toInt() and 0xff
                val headerLen: Int
                val dataLen: Int
                if ((len1 and 1) != 0) {
                    headerLen=3; dataLen=len1 ushr 1
                } else {
                    if (cursor+4 > buffer.size) break
                    val len2=buffer[cursor+3].toInt() and 0xff
                    headerLen=4; dataLen=(len1 ushr 1) or (len2 shl 7)
                }
                val total=headerLen+dataLen+1 // RFCOMM FCS byte
                if (total > 16_384) { cursor++; continue }
                if (cursor+total > buffer.size) break
                rfcommFrames++
                val dlci=(address ushr 2) and 0x3f
                // UIH (P/F bit may be set); DLCI 0 is the multiplexer control channel.
                if (dlci != 0 && (control and 0xEF) == 0xEF && dataLen > 0) {
                    val userData=buffer.copyOfRange(cursor+headerLen,cursor+headerLen+dataLen)
                    val parser=vendorParsers.getOrPut(key) { Protocol.Parser() }
                    parser.feed(userData).forEach { f ->
                        if (vendorFrames.size < 5000) {
                            vendorFrames += VendorFrame(direction,f.cmd,f.hi,f.seq,f.payload.toList())
                        }
                    }
                }
                cursor += total
            }
            if (cursor > 0) buffer=buffer.copyOfRange(cursor,buffer.size)
            if (buffer.size > 32_768) {
                warnings += "RFCOMM stream buffer reset after malformed/oversized frame"
                buffer=byteArrayOf()
            }
            rfcommBuffers[key]=buffer
        }
    }

    fun parse(fileName: String, bytes: ByteArray): Report {
        require(bytes.size in (HEADER_SIZE + 1)..MAX_FILE_BYTES) { "File size is outside supported limits" }
        require(MAGIC.indices.all { bytes[it] == MAGIC[it] }) { "Not a btsnoop file (header magic mismatch)" }
        val version=u32(bytes,8); val linkType=u32(bytes,12)
        require(version==1L) { "Unsupported btsnoop version: $version" }
        require(linkType in 1001L..1003L) { "Unsupported btsnoop datalink type: $linkType (expected HCI H4 capture)" }

        var offset=HEADER_SIZE
        var records=0; var sent=0; var received=0; var drops=0L
        var commands=0; var events=0; var acl=0; var other=0
        val opcodes=linkedMapOf<Int,Int>(); val eventCodes=linkedMapOf<Int,Int>()
        val warnings=mutableListOf<String>()
        val streams=StreamExtractor()
        while (offset < bytes.size) {
            require(records < MAX_RECORDS) { "Capture contains too many records" }
            require(bytes.size-offset >= RECORD_HEADER_SIZE) { "Truncated btsnoop record header at byte $offset" }
            val originalLen=u32(bytes,offset).toInt()
            val includedLen=u32(bytes,offset+4).toInt()
            val flags=u32(bytes,offset+8); val dropCount=u32(bytes,offset+12)
            require(includedLen in 1..1_048_576) { "Invalid HCI record length at record $records" }
            require(includedLen <= bytes.size-offset-RECORD_HEADER_SIZE) { "Truncated HCI packet at record $records" }
            if (originalLen > includedLen) warnings += "Record $records was truncated ($includedLen/$originalLen bytes)"
            drops += dropCount
            val direction=if ((flags and 1L)==0L) "TX" else "RX"
            if (direction=="TX") sent++ else received++
            val packetOffset=offset+RECORD_HEADER_SIZE
            val packet=bytes.copyOfRange(packetOffset,packetOffset+includedLen)
            when (packet[0].toInt() and 0xff) {
                0x01 -> {
                    commands++
                    if (includedLen>=4) { val opcode=le16(packet,1); opcodes[opcode]=(opcodes[opcode]?:0)+1 }
                    else warnings += "Short HCI command packet at record $records"
                }
                0x04 -> {
                    events++
                    if (includedLen>=3) { val code=packet[1].toInt() and 0xff; eventCodes[code]=(eventCodes[code]?:0)+1 }
                    else warnings += "Short HCI event packet at record $records"
                }
                0x02 -> { acl++; streams.accept(direction,packet,records) }
                else -> other++
            }
            records++
            offset += RECORD_HEADER_SIZE+includedLen
        }
        if (records==0) warnings += "Capture contains no HCI records"
        warnings += streams.warnings
        return Report(fileName,version,linkType,records,sent,received,drops,commands,events,acl,other,
            opcodes,eventCodes,warnings.distinct().take(40),streams.vendorFrames.toList(),streams.l2capPackets,streams.rfcommFrames,
            streams.gattEvents.toList(),streams.gattCharacteristics,streams.attPackets)
    }

    fun diff(baseline: Report,current: Report): Diff {
        val a=baseline.opcodeCounts; val b=current.opcodeCounts
        val added=b.keys.filter { it !in a }.sorted()
        val removed=a.keys.filter { it !in b }.sorted()
        val changed=a.keys.intersect(b.keys).filter { a[it]!=b[it] }.sorted().map { it to ((a[it]?:0) to (b[it]?:0)) }
        return Diff(added,removed,changed,current.totalRecords-baseline.totalRecords)
    }

    private fun u32(b: ByteArray,i: Int): Long =
        ((b[i].toLong() and 255) shl 24) or ((b[i+1].toLong() and 255) shl 16) or
        ((b[i+2].toLong() and 255) shl 8) or (b[i+3].toLong() and 255)
    private fun le16(b: ByteArray,i: Int): Int=(b[i].toInt() and 255) or ((b[i+1].toInt() and 255) shl 8)
}
