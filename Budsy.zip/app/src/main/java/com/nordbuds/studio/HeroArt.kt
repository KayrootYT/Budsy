package com.nordbuds.studio

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.snapshots.Snapshot
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/** Maps a 320x210 design space onto the canvas, centred, so every layer shares one geometry. */
private class Frame(val w: Float, val h: Float) {
    val u = minOf(w / 320f, h / 210f)
    private val ox = (w - 320f * u) / 2f
    private val oy = (h - 210f * u) / 2f
    fun x(v: Float) = ox + v * u
    fun y(v: Float) = oy + v * u
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private val Blue = Color(0xFF4AA8FF)

private fun accentFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> Color(0xFFD8FF54)
    ThemeMode.AURORA -> Color(0xFFE84135)
    ThemeMode.SONY -> Color(0xFF84B8FF)
    ThemeMode.SPATIAL -> Color(0xFFB5A1FF)
    else -> Color(0xFF7DE3FF)
}

private fun shellStopsFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> listOf(Color(0xFFF4F4EB), Color(0xFFB9BAB1), Color(0xFF4F504B), Color(0xFFE4E5DC))
    ThemeMode.AURORA -> listOf(Color(0xFFFAFAF7), Color(0xFFB6B6B4), Color(0xFF626266), Color(0xFFE1E1DF))
    ThemeMode.SONY -> listOf(Color(0xFFF1F7FF), Color(0xFFB1C5D9), Color(0xFF526B84), Color(0xFFDDEBFA))
    ThemeMode.SPATIAL -> listOf(Color(0xFFF3F0FF), Color(0xFFB7B1D2), Color(0xFF5D5B80), Color(0xFFE1DCFF))
    else -> listOf(Color(0xFFF5FCFF), Color(0xFFB7D1DE), Color(0xFF536A7D), Color(0xFFDCECF4))
}

// Geometry of the 960x960 hero canvas, in canvas units (every layer shares this space).
private const val CANVAS = 960f
private const val BUD_SCALE = 0.60f
private const val BUD_BOX_W = 340f   // bud PNGs are ~320-332 px wide, 540 px tall
private const val BUD_BOX_H = 540f
// Cradle centres of the real case photo, hover spots above the case, and the case's front lip (clips a resting bud).
private const val START_LX = 330f; private const val START_RX = 612f; private const val START_Y = 492f
private const val HOVER_LX = 345f; private const val HOVER_RX = 615f; private const val HOVER_Y = 150f
private const val REST_SC = 0.56f; private const val LIP_Y = 512f
private const val PAIR_LX = 335f; private const val PAIR_RX = 625f; private const val PAIR_Y = 470f
// Closed-case photo: lid dome spans DOME_TOP..SEAM_Y, the body is below the seam.
private const val DOME_TOP = 228f; private const val SEAM_Y = 413f

private fun smooth(x: Float, a: Float, b: Float): Float {
    val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3f - 2f * t)
}

/**
 * Hero artwork built only from the real product photos.
 *  - Disconnected: closed case. Connected: the lid flips up (dome foreshortens around its back hinge while the
 *    open-case photo fades in underneath) with a small spring overshoot.
 *  - One photo per bud state (both in / left out / right out) sit on top of the empty open case, so the bud that
 *    stays is the real photographed bud. The bud that leaves is a separate layer: it lifts out of its cradle on a
 *    spring (soft overshoot), tilts with its velocity, then floats and sways above the case; the case sinks a bit
 *    to give it room and a contact shadow shrinks as it rises.
 *  - Both out: the case fades and shrinks away, the buds drift to the centre under a soft glow and a OnePlus wordmark.
 *  - Putting a bud back reverses everything: the bud drops in first, the photo swaps once it has landed, and the lid
 *    only closes after the buds are inside.
 * Which state to show is decided by [HeroResolver]; this composable never inspects Bluetooth data.
 */
@Composable
fun DeviceHeroArt(theme: Int, hero: HeroState, modifier: Modifier = Modifier, dashed: Boolean = false, appearance: Int = AppearanceMode.DARK) {
    val dark = appearance == AppearanceMode.DARK || appearance == AppearanceMode.AMOLED ||
        (appearance == AppearanceMode.SYSTEM && androidx.compose.foundation.isSystemInDarkTheme())
    // Dark/AMOLED UI => white product; light UI => black product.
    val isBlack = !dark
    val leftOut = hero == HeroState.LEFT_OUT || hero == HeroState.BOTH_OUT
    val rightOut = hero == HeroState.RIGHT_OUT || hero == HeroState.BOTH_OUT
    val bothOut = hero == HeroState.BOTH_OUT
    val closed = hero == HeroState.CASE_CLOSED

    // ---- Physics-ish drivers -------------------------------------------------------------------------------------
    val lid = remember { Animatable(if (closed) 0f else 1f) }
    val pL = remember { Animatable(if (leftOut) 1f else 0f) }
    val pR = remember { Animatable(if (rightOut) 1f else 0f) }
    val outSpec = spring<Float>(dampingRatio = 0.60f, stiffness = 55f)   // pops out of the magnet, overshoots, settles
    val inSpec = spring<Float>(dampingRatio = 0.90f, stiffness = 90f)    // drops back in, no bounce
    LaunchedEffect(closed) {
        if (closed) {
            if (pL.value > 0.02f || pR.value > 0.02f) delay(700)           // buds must be inside before the lid shuts
            lid.animateTo(0f, tween(580, easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)))
        } else lid.animateTo(1f, spring(dampingRatio = 0.68f, stiffness = 100f))
    }
    LaunchedEffect(leftOut) {
        if (leftOut) { if (lid.value < 0.85f) delay(320); pL.animateTo(1f, outSpec) } else pL.animateTo(0f, inSpec)
    }
    LaunchedEffect(rightOut) {
        if (rightOut) { if (lid.value < 0.85f) delay(320); pR.animateTo(1f, outSpec) } else pR.animateTo(0f, inSpec)
    }
    val q = animateFloatAsState(if (bothOut) 1f else 0f, tween(900, easing = FastOutSlowInEasing), label = "bothOut")
    val single = animateFloatAsState(if ((leftOut || rightOut) && !bothOut) 1f else 0f, tween(700, easing = FastOutSlowInEasing), label = "singleOut")

    // A photo that contains a bud may only fade in after that bud has landed in its cradle.
    val landing = Snapshot.withoutReadObservation { pL.value > 0.05f || pR.value > 0.05f }
    val inDelay = if (landing) 520 else 0
    fun overlay(on: Boolean) = if (on) tween<Float>(240, delayMillis = inDelay) else tween<Float>(160)
    val bothIn = hero == HeroState.BOTH_IN || hero == HeroState.UNVERIFIED
    val aBoth = animateFloatAsState(if (bothIn) 1f else 0f, overlay(bothIn), label = "photoBoth")
    val aLout = animateFloatAsState(if (hero == HeroState.LEFT_OUT) 1f else 0f, overlay(hero == HeroState.LEFT_OUT), label = "photoLeftOut")
    val aRout = animateFloatAsState(if (hero == HeroState.RIGHT_OUT) 1f else 0f, overlay(hero == HeroState.RIGHT_OUT), label = "photoRightOut")

    val inf = rememberInfiniteTransition(label = "heroFloat")
    val floatA = inf.animateFloat(-9f, 9f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatA")
    val floatB = inf.animateFloat(9f, -9f, infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatB")
    // How far the case group sinks so the lifted buds have room above it (canvas units).
    val shiftU = { 100f * single.value + 120f * q.value }

    val closedRes = if (isBlack) R.drawable.hero_case_closed_black else R.drawable.hero_case_closed_white
    val emptyRes = if (isBlack) R.drawable.hero_case_empty_black else R.drawable.hero_case_empty_white
    val bothRes = if (isBlack) R.drawable.hero_case_both_black else R.drawable.hero_case_both_white
    val loutRes = if (isBlack) R.drawable.hero_case_lout_black else R.drawable.hero_case_lout_white
    val routRes = if (isBlack) R.drawable.hero_case_rout_black else R.drawable.hero_case_rout_white
    val budLRes = if (isBlack) R.drawable.hero_bud_left_black else R.drawable.hero_bud_left_white
    val budRRes = if (isBlack) R.drawable.hero_bud_right_black else R.drawable.hero_bud_right_white
    val desc = when (hero) {
        HeroState.CASE_CLOSED -> "OnePlus Nord Buds 3 closed charging case"
        HeroState.BOTH_IN -> "OnePlus Nord Buds 3 open charging case with both earbuds inside"
        HeroState.LEFT_OUT -> "OnePlus Nord Buds 3 left earbud outside the case"
        HeroState.RIGHT_OUT -> "OnePlus Nord Buds 3 right earbud outside the case"
        HeroState.BOTH_OUT -> "OnePlus Nord Buds 3 left and right earbuds outside the case"
        HeroState.UNVERIFIED -> "OnePlus Nord Buds 3 charging case; position not verified"
    }
    val density = LocalDensity.current

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight)
        val k = with(density) { side.toPx() } / CANVAS
        Box(Modifier.requiredSize(side).semantics { contentDescription = desc }) {
            // Accent halo behind the buds once the case is gone.
            Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = q.value }) {
                val accent = accentFor(theme)
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .16f), Color.Transparent), center = center, radius = size.minDimension * .46f),
                    radius = size.minDimension * .46f, center = center)
            }
            // ---- Case group ----
            Box(Modifier.fillMaxSize().graphicsLayer {
                val qv = q.value
                translationY = shiftU() * k + floatA.value * k * (1f - qv)
                scaleX = 1f - 0.16f * qv; scaleY = scaleX
                alpha = (1f - qv * 1.15f).coerceIn(0f, 1f)
            }) {
                // Open case (empty) is the base for every open state; it fades in as the lid lifts.
                Image(painterResource(emptyRes), null, Modifier.fillMaxSize().graphicsLayer {
                    val e = lid.value
                    alpha = smooth(e, 0.30f, 0.80f)
                    val sc = 0.955f + 0.045f * e; scaleX = sc; scaleY = sc
                }, contentScale = ContentScale.Fit)
                // Real photos with the bud(s) that are in the case.
                for ((res, a) in listOf(bothRes to aBoth, loutRes to aLout, routRes to aRout)) {
                    Image(painterResource(res), null, Modifier.fillMaxSize().graphicsLayer {
                        val e = lid.value
                        alpha = a.value * smooth(e, 0.30f, 0.80f)
                        val sc = 0.955f + 0.045f * e; scaleX = sc; scaleY = sc
                    }, contentScale = ContentScale.Fit)
                }
                // Closed body (below the seam) fades out as the case opens.
                Image(painterResource(closedRes), null, Modifier.fillMaxSize().graphicsLayer {
                    alpha = 1f - smooth(lid.value, 0.05f, 0.55f)
                }.drawWithContent {
                    clipRect(0f, SEAM_Y * k, size.width, size.height) { this@drawWithContent.drawContent() }
                }, contentScale = ContentScale.Fit)
                // Lid dome: pivots on its back (top) edge, so the seam swings up and the dome foreshortens.
                Image(painterResource(closedRes), null, Modifier.fillMaxSize().graphicsLayer {
                    val e = smooth(lid.value, 0f, 0.8f)
                    transformOrigin = TransformOrigin(0.5f, DOME_TOP / CANVAS)
                    scaleY = 1f - 0.80f * e
                    scaleX = 1f - 0.03f * e
                    translationY = -34f * k * e
                    alpha = 1f - smooth(lid.value, 0.35f, 0.85f)
                }.drawWithContent {
                    clipRect(0f, 0f, size.width, SEAM_Y * k) { this@drawWithContent.drawContent() }
                }, contentScale = ContentScale.Fit)
            }
            // ---- Soft contact shadows of the lifted buds on the case ----
            Canvas(Modifier.fillMaxSize()) {
                fun shadow(cx: Float, p: Float) {
                    val a = (p.coerceIn(0f, 1f) * (1f - q.value)) * 0.30f
                    if (a <= 0.01f) return
                    val sy = (LIP_Y + 4f + shiftU()) * k
                    val w = (74f - 20f * p.coerceIn(0f, 1.2f)) * k
                    drawOval(
                        Brush.radialGradient(listOf(Color.Black.copy(alpha = a), Color.Transparent), center = Offset(cx * k, sy), radius = w),
                        topLeft = Offset(cx * k - w, sy - w * 0.28f), size = Size(w * 2f, w * 0.56f)
                    )
                }
                shadow(START_LX, pL.value); shadow(START_RX, pR.value)
            }
            // ---- Flying earbuds ----
            FlyingBud(budLRes, pL, q, lid, shiftU, START_LX, HOVER_LX, PAIR_LX, -1f, floatA, floatB, k)
            FlyingBud(budRRes, pR, q, lid, shiftU, START_RX, HOVER_RX, PAIR_RX, 1f, floatB, floatA, k)
            // ---- OnePlus wordmark appears once the case is gone ----
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).graphicsLayer { alpha = smooth(q.value, 0.55f, 1f) }) {
                Txt("ONEPLUS", 11, FontWeight.Bold, P.sub, spacing = 6f)
            }
        }
    }
}

/**
 * One earbud. At rest it is hidden (the case photo already shows the real bud); when taken out it rises straight up
 * out of its cradle (clipped at the front lip), then arcs to the hover spot above the case (or the centre if both are
 * out). Its tilt follows the spring velocity, so it leans into the motion and swings back as it settles.
 */
@Composable
private fun BoxScope.FlyingBud(
    res: Int, p: Animatable<Float, AnimationVector1D>, q: State<Float>, lid: Animatable<Float, AnimationVector1D>, shiftU: () -> Float,
    startX: Float, hoverX: Float, pairX: Float, side: Float, float: State<Float>, sway: State<Float>, k: Float
) {
    val density = LocalDensity.current
    // Wrapper (not transformed) so the lip clip stays a straight horizontal line on screen.
    Box(Modifier.fillMaxSize().drawWithContent {
        val inCradle = p.value < 0.35f
        val bottom = if (inCradle) ((LIP_Y + shiftU()) * k).coerceIn(0f, size.height) else size.height
        clipRect(0f, 0f, size.width, bottom) { this@drawWithContent.drawContent() }
    }) {
        Image(
            painterResource(res), null,
            Modifier.align(Alignment.Center)
                .size(with(density) { (BUD_BOX_W * BUD_SCALE * k).toDp() }, with(density) { (BUD_BOX_H * BUD_SCALE * k).toDp() })
                .graphicsLayer {
                    val pv = p.value
                    val pc = pv.coerceIn(0f, 1f)
                    val tx = lerpF(hoverX, pairX, q.value)
                    val ty = lerpF(HOVER_Y, PAIR_Y, q.value)
                    // rise straight up first, then drift sideways (natural arc, not a diagonal slide)
                    val xe = FastOutSlowInEasing.transform(((pv - 0.30f) / 0.70f).coerceIn(0f, 1f))
                    val x = lerpF(startX, tx, if (pv > 1f) 1f else xe)
                    val y = lerpF(START_Y + shiftU(), ty, pv)
                    translationX = (x - CANVAS / 2f) * k
                    translationY = (y - CANVAS / 2f) * k + float.value * k * pc
                    val sc = lerpF(REST_SC, BUD_SCALE, pv.coerceIn(0f, 1.2f)) / BUD_SCALE
                    scaleX = sc; scaleY = sc
                    val vel = p.velocity.coerceIn(-4f, 4f)
                    // base lean in the cradle -> free-floating sway; velocity adds a lag-like lean
                    rotationZ = side * 7f * (1f - pc) + side * 3f * pc + sway.value * 0.35f - vel * 2.4f * side
                    // only visible while the bud is actually out (the case photo shows it while it rests inside)
                    alpha = smooth(pv, 0.0f, 0.10f) * smooth(lid.value, 0.4f, 0.8f)
                },
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
fun HeroCaption(r: ResolvedHero) {
    val tag = when (r.source) {
        HeroSource.HARDWARE -> "VERIFIED"; HeroSource.ESTIMATED -> "ESTIMATED"; HeroSource.PRESENTATION -> "PRESENTATION"
        HeroSource.PREVIEW -> "PREVIEW"; HeroSource.UNVERIFIED -> "UNVERIFIED"
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(tag, 10, FontWeight.Bold, if (r.source == HeroSource.HARDWARE) P.green else P.accent, spacing = 1.4f)
        Txt(r.note, 12, color = P.sub, align = TextAlign.Center, lineHeight = 16, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Settings → Diagnostics: manually drive the hero without earbuds. Nothing here is hardware detection. */
@Composable
fun HeroPreviewPicker() {
    SectionLabel("Hero preview (debug)", detail = "Manually show any home-screen state. Preview only; never treated as detected hardware.")
    val options: List<Pair<HeroState?, String>> = listOf(
        null to "Live (follow device data)",
        HeroState.CASE_CLOSED to "1 · Case closed",
        HeroState.BOTH_IN to "2 · Open, both buds inside",
        HeroState.LEFT_OUT to "3 · Left bud outside",
        HeroState.RIGHT_OUT to "4 · Right bud outside",
        HeroState.BOTH_OUT to "5 · Both buds outside",
        HeroState.UNVERIFIED to "Unknown / unverified"
    )
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((state, label) in options) {
            val sel = HeroPreview.selected == state
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (sel) P.accent.copy(alpha = 0.22f) else P.tile)
                    .clickable { HeroPreview.selected = state }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) { Txt(label, 14, if (sel) FontWeight.Bold else FontWeight.Normal, if (sel) P.accent else P.text) }
        }
    }
}
