package com.nordbuds.studio

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Maps a 320x210 design space onto the canvas, centred, so every layer shares one geometry. */
private class Frame(val w: Float, val h: Float) {
    val u = minOf(w / 320f, h / 210f)
    private val ox = (w - 320f * u) / 2f
    private val oy = (h - 210f * u) / 2f
    fun x(v: Float) = ox + v * u
    fun y(v: Float) = oy + v * u
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private val Blue = Color(0xFF4AA8FF)

private fun accentFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> Color(0xFFD8FF54)
    ThemeMode.AURORA -> Color(0xFFE84135)
    ThemeMode.SONY -> Color(0xFF84B8FF)
    ThemeMode.SPATIAL -> Color(0xFFB5A1FF)
    else -> Color(0xFF7DE3FF)
}

private fun shellStopsFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> listOf(Color(0xFFF4F4EB), Color(0xFFB9BAB1), Color(0xFF4F504B), Color(0xFFE4E5DC))
    ThemeMode.AURORA -> listOf(Color(0xFFFAFAF7), Color(0xFFB6B6B4), Color(0xFF626266), Color(0xFFE1E1DF))
    ThemeMode.SONY -> listOf(Color(0xFFF1F7FF), Color(0xFFB1C5D9), Color(0xFF526B84), Color(0xFFDDEBFA))
    ThemeMode.SPATIAL -> listOf(Color(0xFFF3F0FF), Color(0xFFB7B1D2), Color(0xFF5D5B80), Color(0xFFE1DCFF))
    else -> listOf(Color(0xFFF5FCFF), Color(0xFFB7D1DE), Color(0xFF536A7D), Color(0xFFDCECF4))
}

/**
 * Hero artwork for the six presentation states. State changes animate lid opening and each bud's
 * lift independently, so the scene morphs instead of cutting. Which state to show is decided by
 * [HeroResolver]; this composable never inspects Bluetooth or protocol data itself.
 */
@Composable
fun DeviceHeroArt(theme: Int, hero: HeroState, modifier: Modifier = Modifier) {
    val accent = accentFor(theme)
    val shellStops = shellStopsFor(theme)
    val dragX = remember { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val pulse = rememberInfiniteTransition(label = "heroAccent$theme").animateFloat(
        0.28f, 0.58f,
        infiniteRepeatable(tween(if (theme == ThemeMode.NOTHING) 850 else 1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "heroPulse$theme"
    )
    val spec = tween<Float>(550, easing = FastOutSlowInEasing)
    val lid = animateFloatAsState(when (hero) { HeroState.CASE_CLOSED -> 0f; HeroState.UNVERIFIED -> 0.5f; else -> 1f }, spec, label = "lid")
    val budVis = animateFloatAsState(if (hero == HeroState.BOTH_IN || hero == HeroState.LEFT_OUT || hero == HeroState.RIGHT_OUT || hero == HeroState.BOTH_OUT) 1f else 0f, spec, label = "budVis")
    val lLift = animateFloatAsState(if (hero == HeroState.LEFT_OUT || hero == HeroState.BOTH_OUT) 1f else 0f, spec, label = "lLift")
    val rLift = animateFloatAsState(if (hero == HeroState.RIGHT_OUT || hero == HeroState.BOTH_OUT) 1f else 0f, spec, label = "rLift")
    val glowAll = animateFloatAsState(if (hero == HeroState.BOTH_OUT) 1f else 0f, spec, label = "glowAll")
    val unv = animateFloatAsState(if (hero == HeroState.UNVERIFIED) 1f else 0f, spec, label = "unv")

    // Independent 3D rotation tracks (different periods per axis and per bud).
    val spin = rememberInfiniteTransition(label = "budSpin")
    val lRotY = spinTrack(spin, -32f, 32f, 3100, "lRotY"); val lRotX = spinTrack(spin, -14f, 18f, 2300, "lRotX"); val lRotZ = spinTrack(spin, -10f, 6f, 3700, "lRotZ")
    val rRotY = spinTrack(spin, 30f, -36f, 3700, "rRotY"); val rRotX = spinTrack(spin, 16f, -12f, 2700, "rRotX"); val rRotZ = spinTrack(spin, 8f, -12f, 4100, "rRotZ")
    val lBob = spinTrack(spin, -1f, 1f, 2200, "lBob"); val rBob = spinTrack(spin, 1f, -1f, 2600, "rBob")

    Box(
        modifier.pointerInput(theme) {
            detectDragGestures(
                onDragEnd = { scope.launch { launch { dragX.animateTo(0f, spring(dampingRatio = 0.68f, stiffness = 190f)) }; launch { dragY.animateTo(0f, spring(dampingRatio = 0.68f, stiffness = 190f)) } } },
                onDragCancel = { scope.launch { launch { dragX.animateTo(0f, spring()) }; launch { dragY.animateTo(0f, spring()) } } },
                onDrag = { change, amount ->
                    change.consume()
                    scope.launch { dragX.snapTo((dragX.value + amount.x).coerceIn(-28f, 28f)); dragY.snapTo((dragY.value + amount.y).coerceIn(-18f, 18f)) }
                }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            translationX = dragX.value; translationY = dragY.value
            alpha = lerpF(1f, 0.55f, unv.value)
        }) {
            Canvas(Modifier.fillMaxSize()) {
                val f = Frame(size.width, size.height); val u = f.u; val t = lid.value; val p = pulse.value
                val w = size.width; val h = size.height; val cx = w * .5f; val cy = h * .5f
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = p * .26f), accent.copy(alpha = 0f)), center = Offset(cx, cy), radius = w * .43f), radius = w * .43f, center = Offset(cx, cy))
                when (theme) {
                    ThemeMode.NOTHING -> for (ix in 0..10) for (iy in 0..6) drawCircle(accent.copy(alpha = if ((ix + iy) % 3 == 0) .38f else .12f), radius = 1.1f * u, center = Offset(w * .06f + ix * w * .088f, h * .08f + iy * h * .13f))
                    ThemeMode.SPATIAL -> {
                        drawCircle(accent.copy(alpha = .28f), radius = w * .34f, center = Offset(cx, cy), style = Stroke(1.1f * u))
                        drawCircle(accent.copy(alpha = .16f), radius = w * .25f, center = Offset(cx, cy), style = Stroke(1.1f * u))
                        drawCircle(accent.copy(alpha = .7f), radius = 2.3f * u, center = Offset(w * .82f, h * .24f))
                    }
                    ThemeMode.AURORA -> {
                        drawLine(accent.copy(alpha = .7f), Offset(w * .08f, h * .78f), Offset(w * .24f, h * .78f), 2f * u, cap = StrokeCap.Round)
                        drawCircle(accent, radius = 2.2f * u, center = Offset(w * .26f, h * .78f))
                    }
                    ThemeMode.SONY -> for (i in 0..3) drawArc(accent.copy(alpha = .18f + i * .07f), 200f, 140f, false, Offset(cx - w * (.25f + i * .04f), cy - h * .38f), Size(w * (.5f + i * .08f), h * .76f), style = Stroke(1f * u))
                    else -> {
                        drawCircle(accent.copy(alpha = .24f), radius = w * .33f, center = Offset(cx, cy), style = Stroke(1.2f * u))
                        drawCircle(accent.copy(alpha = .58f), radius = 2f * u, center = Offset(w * .82f, h * .24f))
                    }
                }
                val shell = Brush.linearGradient(shellStops, Offset(w * .28f, h * .2f), Offset(w * .72f, h * .8f))
                val caseW = 144f * u; val caseH = 46f * u; val caseX = f.x(160f) - caseW / 2f; val top = f.y(126f)
                drawCircle(accent.copy(alpha = p * .12f), radius = caseW * .72f, center = Offset(f.x(160f), top + caseH * .55f))
                drawRoundRect(Color.Black.copy(alpha = .45f), Offset(caseX, top + 5f * u), Size(caseW, caseH), CornerRadius(17f * u, 17f * u))
                drawRoundRect(shell, Offset(caseX, top), Size(caseW, caseH), CornerRadius(17f * u, 17f * u))
                // Lid: closed it covers the top half of the body; open it rises behind the slots.
                val inset = lerpF(1f * u, 8f * u, t); val r = lerpF(16f * u, 10f * u, t)
                drawRoundRect(Brush.linearGradient(listOf(Color(0xFFF2F5F6), Color(0xFFBFC9D2), Color(0xFF8B99A7)), Offset(caseX, top - 28f * u), Offset(caseX + caseW, top + caseH)),
                    Offset(caseX + inset, top + lerpF(0f, -28f * u, t)), Size(caseW - 2f * inset, lerpF(caseH * .49f, 31f * u, t)), CornerRadius(r, r))
                if (t < 1f) drawLine(Color(0xFF566474).copy(alpha = .8f * (1f - t)), Offset(caseX + 2f * u, top + caseH * .49f), Offset(caseX + caseW - 2f * u, top + caseH * .49f), 1.2f * u)
                if (t > 0.01f) {
                    drawRoundRect(Brush.linearGradient(listOf(Color(0xFF52667D), Color(0xFF26384D)), Offset(caseX, top), Offset(caseX + caseW, top + caseH)),
                        Offset(caseX + 7f * u, top + 2f * u), Size(caseW - 14f * u, caseH * .62f), CornerRadius(13f * u, 13f * u), alpha = t)
                    for (sx in floatArrayOf(141f, 179f)) {
                        drawOval(Color(0xFF111A24), Offset(f.x(sx) - 11f * u, f.y(144f) - 14f * u), Size(22f * u, 28f * u), alpha = t)
                        drawOval(accent.copy(alpha = .35f * t), Offset(f.x(sx) - 11f * u, f.y(144f) - 14f * u), Size(22f * u, 28f * u), style = Stroke(1f * u))
                    }
                }
                drawLine(Color.White.copy(alpha = .78f), Offset(caseX + 20f * u, top + 8f * u), Offset(caseX + caseW - 20f * u, top + 8f * u), 1.3f * u, cap = StrokeCap.Round)
                drawCircle(accent.copy(alpha = .22f), radius = 3f * u, center = Offset(f.x(160f), top + caseH * .78f))
                if (unv.value > 0.01f) drawRoundRect(accent.copy(alpha = unv.value * .85f), Offset(caseX - 4f * u, top - 34f * u), Size(caseW + 8f * u, caseH + 38f * u), CornerRadius(20f * u, 20f * u),
                    style = Stroke(1.5f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f * u, 5f * u))))
            }
            BudLayer(true, lLift, budVis, glowAll, lRotX, lRotY, lRotZ, lBob, pulse, shellStops, accent)
            BudLayer(false, rLift, budVis, glowAll, rRotX, rRotY, rRotZ, rBob, pulse, shellStops, accent)
        }
    }
}

@Composable
private fun spinTrack(t: InfiniteTransition, a: Float, b: Float, ms: Int, name: String): State<Float> =
    t.animateFloat(a, b, infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = name)

/** One earbud on its own layer so it can rotate in 3D (about its own centre) independently of the other. */
@Composable
private fun BudLayer(
    left: Boolean, lift: State<Float>, vis: State<Float>, glow: State<Float>,
    rotX: State<Float>, rotY: State<Float>, rotZ: State<Float>, bob: State<Float>,
    pulse: State<Float>, shellStops: List<Color>, accent: Color
) {
    val homeX = if (left) 141f else 179f; val homeY = 142f
    val awayX = if (left) 100f else 220f; val awayY = if (left) 58f else 50f
    Canvas(Modifier.fillMaxSize().graphicsLayer {
        val f = Frame(size.width, size.height); val t = lift.value
        translationX = (awayX - homeX) * t * f.u
        translationY = (awayY - homeY) * t * f.u + bob.value * 4f * f.u * t
        transformOrigin = TransformOrigin(f.x(homeX) / size.width, f.y(homeY) / size.height)
        val s = 0.72f + 0.28f * t; scaleX = s; scaleY = s
        rotationX = rotX.value * t; rotationY = rotY.value * t; rotationZ = rotZ.value * t
        cameraDistance = 14f * density
        alpha = vis.value
    }) {
        val f = Frame(size.width, size.height); val u = f.u; val g = glow.value * lift.value
        val c = Offset(f.x(homeX), f.y(homeY))
        val tl = Offset(c.x - 14f * u, c.y - 19.5f * u); val sz = Size(28f * u, 39f * u)
        val shell = Brush.linearGradient(shellStops, tl, Offset(c.x + 14f * u, c.y + 19.5f * u))
        val stem = Brush.linearGradient(listOf(Color(0xFFF8FAFC), Color(0xFF9AA7B5), Color(0xFF465464)), Offset.Zero, Offset(size.width, size.height))
        if (g > 0.01f) {
            val p = pulse.value
            drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha = g * (0.18f + p * 0.2f)), Color.Transparent), c, 44f * u), 44f * u, c)
            for (k in 3 downTo 1) drawOval(Blue.copy(alpha = g * 0.10f * (4 - k)), Offset(tl.x - k * 2.4f * u, tl.y - k * 2.4f * u), Size(sz.width + k * 4.8f * u, sz.height + k * 4.8f * u), style = Stroke(2.4f * u))
        }
        drawRoundRect(stem, Offset(c.x - 1f * u, c.y + 3.5f * u), Size(10f * u, 42f * u), CornerRadius(5f * u, 5f * u))
        drawOval(shell, tl, sz)
        drawCircle(Color(0xFF252D37), 8f * u, Offset(c.x, c.y - 1.5f * u))
        drawCircle(Color(0xFF596675), 4f * u, Offset(c.x - 2f * u, c.y - 4.5f * u))
        drawLine(Color.White.copy(alpha = .82f), Offset(c.x + 5f * u, c.y + 14.5f * u), Offset(c.x + 7f * u, c.y + 38.5f * u), 1.6f * u, cap = StrokeCap.Round)
        if (g > 0.01f) drawOval(Blue.copy(alpha = g * (0.65f + pulse.value * 0.3f)), tl, sz, style = Stroke(1.5f * u))
        if (lift.value < 0.5f) drawLine(accent.copy(alpha = pulse.value * (1f - lift.value * 2f)), Offset(c.x - 8f * u, c.y - 16f * u), Offset(c.x + 8f * u, c.y - 16f * u), 1.1f * u, cap = StrokeCap.Round)
    }
}

/** Always-visible provenance line: says whether the hero is hardware-reported, a presentation, a preview or unverified. */
@Composable
fun HeroCaption(r: ResolvedHero) {
    val tag = when (r.source) {
        HeroSource.HARDWARE -> "VERIFIED"; HeroSource.PRESENTATION -> "PRESENTATION"
        HeroSource.PREVIEW -> "PREVIEW"; HeroSource.UNVERIFIED -> "UNVERIFIED"
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(tag, 10, FontWeight.Bold, if (r.source == HeroSource.HARDWARE) P.green else P.accent, spacing = 1.4f)
        Txt(r.note, 12, color = P.sub, align = TextAlign.Center, lineHeight = 16, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Settings → Diagnostics: manually drive the hero without earbuds. Nothing here is hardware detection. */
@Composable
fun HeroPreviewPicker() {
    SectionLabel("Hero preview (debug)", detail = "Manually show any home-screen state. Preview only; never treated as detected hardware.")
    val options: List<Pair<HeroState?, String>> = listOf(
        null to "Live (follow device data)",
        HeroState.CASE_CLOSED to "1 · Case closed",
        HeroState.BOTH_IN to "2 · Open, both buds inside",
        HeroState.LEFT_OUT to "3 · Left bud outside",
        HeroState.RIGHT_OUT to "4 · Right bud outside",
        HeroState.BOTH_OUT to "5 · Both buds outside",
        HeroState.UNVERIFIED to "Unknown / unverified"
    )
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((state, label) in options) {
            val sel = HeroPreview.selected == state
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (sel) P.accent.copy(alpha = 0.22f) else P.tile)
                    .clickable { HeroPreview.selected = state }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) { Txt(label, 14, if (sel) FontWeight.Bold else FontWeight.Normal, if (sel) P.accent else P.text) }
        }
    }
}
