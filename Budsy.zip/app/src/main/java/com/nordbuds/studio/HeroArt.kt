package com.nordbuds.studio

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** Maps a 320x210 design space onto the canvas, centred, so every layer shares one geometry. */
private class Frame(val w: Float, val h: Float) {
    val u = minOf(w / 320f, h / 210f)
    private val ox = (w - 320f * u) / 2f
    private val oy = (h - 210f * u) / 2f
    fun x(v: Float) = ox + v * u
    fun y(v: Float) = oy + v * u
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private val Blue = Color(0xFF4AA8FF)

private fun accentFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> Color(0xFFD8FF54)
    ThemeMode.AURORA -> Color(0xFFE84135)
    ThemeMode.SONY -> Color(0xFF84B8FF)
    ThemeMode.SPATIAL -> Color(0xFFB5A1FF)
    else -> Color(0xFF7DE3FF)
}

private fun shellStopsFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> listOf(Color(0xFFF4F4EB), Color(0xFFB9BAB1), Color(0xFF4F504B), Color(0xFFE4E5DC))
    ThemeMode.AURORA -> listOf(Color(0xFFFAFAF7), Color(0xFFB6B6B4), Color(0xFF626266), Color(0xFFE1E1DF))
    ThemeMode.SONY -> listOf(Color(0xFFF1F7FF), Color(0xFFB1C5D9), Color(0xFF526B84), Color(0xFFDDEBFA))
    ThemeMode.SPATIAL -> listOf(Color(0xFFF3F0FF), Color(0xFFB7B1D2), Color(0xFF5D5B80), Color(0xFFE1DCFF))
    else -> listOf(Color(0xFFF5FCFF), Color(0xFFB7D1DE), Color(0xFF536A7D), Color(0xFFDCECF4))
}

/**
 * Hero artwork for the six presentation states. State changes animate lid opening and each bud's
 * lift independently, so the scene morphs instead of cutting. Which state to show is decided by
 * [HeroResolver]; this composable never inspects Bluetooth or protocol data itself.
 */
@Composable
fun DeviceHeroArt(theme: Int, hero: HeroState, modifier: Modifier = Modifier, dashed: Boolean = false, appearance: Int = AppearanceMode.DARK) {
    val dark = appearance == AppearanceMode.DARK || appearance == AppearanceMode.AMOLED ||
        (appearance == AppearanceMode.SYSTEM && androidx.compose.foundation.isSystemInDarkTheme())
    // Required artwork rule: dark/AMOLED UI => white product PNGs; light UI => black product PNGs.
    val isBlack = !dark
    val imageRes = when (hero) {
        HeroState.CASE_CLOSED -> if (isBlack) R.drawable.hero_case_closed_black else R.drawable.hero_case_closed_white
        HeroState.BOTH_IN, HeroState.UNVERIFIED -> if (isBlack) R.drawable.hero_case_open_black else R.drawable.hero_case_open_white
        HeroState.LEFT_OUT -> if (isBlack) R.drawable.hero_bud_left_black else R.drawable.hero_bud_left_white
        HeroState.RIGHT_OUT -> if (isBlack) R.drawable.hero_bud_right_black else R.drawable.hero_bud_right_white
        HeroState.BOTH_OUT -> if (isBlack) R.drawable.hero_buds_pair_black else R.drawable.hero_buds_pair_white
    }
    val scale by animateFloatAsState(if (hero == HeroState.BOTH_OUT || hero == HeroState.LEFT_OUT || hero == HeroState.RIGHT_OUT) 1.12f else 1.08f,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = 115f), label = "realBudsScale")
    val floatY = rememberInfiniteTransition(label = "realBudsFloat").animateFloat(
        -2.5f, 2.5f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "realBudsFloatY")
    val glow = rememberInfiniteTransition(label = "realBudsGlow").animateFloat(
        0.97f, 1.015f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "realBudsGlowScale")
    Box(modifier, contentAlignment = Alignment.Center) {
        Crossfade(targetState = hero, animationSpec = tween(520, easing = FastOutSlowInEasing), label = "heroStateCrossfade") { target ->
            val targetRes = when (target) {
                HeroState.CASE_CLOSED -> if (isBlack) R.drawable.hero_case_closed_black else R.drawable.hero_case_closed_white
                HeroState.BOTH_IN, HeroState.UNVERIFIED -> if (isBlack) R.drawable.hero_case_open_black else R.drawable.hero_case_open_white
                HeroState.LEFT_OUT -> if (isBlack) R.drawable.hero_bud_left_black else R.drawable.hero_bud_left_white
                HeroState.RIGHT_OUT -> if (isBlack) R.drawable.hero_bud_right_black else R.drawable.hero_bud_right_white
                HeroState.BOTH_OUT -> if (isBlack) R.drawable.hero_buds_pair_black else R.drawable.hero_buds_pair_white
            }
            val lift by animateFloatAsState(
                targetValue = when (target) { HeroState.LEFT_OUT, HeroState.RIGHT_OUT, HeroState.BOTH_OUT -> -20f; else -> 0f },
                animationSpec = spring(dampingRatio = 0.62f, stiffness = 120f), label = "budLift"
            )
            Image(
                painter = androidx.compose.ui.res.painterResource(targetRes),
                contentDescription = when (target) {
                    HeroState.CASE_CLOSED -> "OnePlus Nord Buds 3 closed charging case"
                    HeroState.BOTH_IN -> "OnePlus Nord Buds 3 open charging case with both earbuds inside"
                    HeroState.LEFT_OUT -> "OnePlus Nord Buds 3 left earbud outside the case"
                    HeroState.RIGHT_OUT -> "OnePlus Nord Buds 3 right earbud outside the case"
                    HeroState.BOTH_OUT -> "OnePlus Nord Buds 3 left and right earbuds outside the case"
                    HeroState.UNVERIFIED -> "OnePlus Nord Buds 3 charging case; position not verified"
                },
                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = scale * glow.value
                    scaleY = scale * glow.value
                    translationY = floatY.value + lift
                }
            )
        }
        if (hero == HeroState.BOTH_OUT && !dashed) {
            // A restrained accent halo keeps the real transparent PNG artwork crisp.
            Canvas(Modifier.fillMaxSize()) {
                val accent = accentFor(theme)
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .11f), Color.Transparent), center = center, radius = size.minDimension * .43f),
                    radius = size.minDimension * .43f, center = center)
            }
        }
    }
}

@Composable
fun HeroCaption(r: ResolvedHero) {
    val tag = when (r.source) {
        HeroSource.HARDWARE -> "VERIFIED"; HeroSource.ESTIMATED -> "ESTIMATED"; HeroSource.PRESENTATION -> "PRESENTATION"
        HeroSource.PREVIEW -> "PREVIEW"; HeroSource.UNVERIFIED -> "UNVERIFIED"
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(tag, 10, FontWeight.Bold, if (r.source == HeroSource.HARDWARE) P.green else P.accent, spacing = 1.4f)
        Txt(r.note, 12, color = P.sub, align = TextAlign.Center, lineHeight = 16, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Settings → Diagnostics: manually drive the hero without earbuds. Nothing here is hardware detection. */
@Composable
fun HeroPreviewPicker() {
    SectionLabel("Hero preview (debug)", detail = "Manually show any home-screen state. Preview only; never treated as detected hardware.")
    val options: List<Pair<HeroState?, String>> = listOf(
        null to "Live (follow device data)",
        HeroState.CASE_CLOSED to "1 · Case closed",
        HeroState.BOTH_IN to "2 · Open, both buds inside",
        HeroState.LEFT_OUT to "3 · Left bud outside",
        HeroState.RIGHT_OUT to "4 · Right bud outside",
        HeroState.BOTH_OUT to "5 · Both buds outside",
        HeroState.UNVERIFIED to "Unknown / unverified"
    )
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((state, label) in options) {
            val sel = HeroPreview.selected == state
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (sel) P.accent.copy(alpha = 0.22f) else P.tile)
                    .clickable { HeroPreview.selected = state }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) { Txt(label, 14, if (sel) FontWeight.Bold else FontWeight.Normal, if (sel) P.accent else P.text) }
        }
    }
}
