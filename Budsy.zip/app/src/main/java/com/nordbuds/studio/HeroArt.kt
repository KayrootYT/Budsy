package com.nordbuds.studio

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/** Maps a 320x210 design space onto the canvas, centred, so every layer shares one geometry. */
private class Frame(val w: Float, val h: Float) {
    val u = minOf(w / 320f, h / 210f)
    private val ox = (w - 320f * u) / 2f
    private val oy = (h - 210f * u) / 2f
    fun x(v: Float) = ox + v * u
    fun y(v: Float) = oy + v * u
}

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t
private val Blue = Color(0xFF4AA8FF)

private fun accentFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> Color(0xFFD8FF54)
    ThemeMode.AURORA -> Color(0xFFE84135)
    ThemeMode.SONY -> Color(0xFF84B8FF)
    ThemeMode.SPATIAL -> Color(0xFFB5A1FF)
    else -> Color(0xFF7DE3FF)
}

private fun shellStopsFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> listOf(Color(0xFFF4F4EB), Color(0xFFB9BAB1), Color(0xFF4F504B), Color(0xFFE4E5DC))
    ThemeMode.AURORA -> listOf(Color(0xFFFAFAF7), Color(0xFFB6B6B4), Color(0xFF626266), Color(0xFFE1E1DF))
    ThemeMode.SONY -> listOf(Color(0xFFF1F7FF), Color(0xFFB1C5D9), Color(0xFF526B84), Color(0xFFDDEBFA))
    ThemeMode.SPATIAL -> listOf(Color(0xFFF3F0FF), Color(0xFFB7B1D2), Color(0xFF5D5B80), Color(0xFFE1DCFF))
    else -> listOf(Color(0xFFF5FCFF), Color(0xFFB7D1DE), Color(0xFF536A7D), Color(0xFFDCECF4))
}

// Geometry of the 960x960 hero canvas, in canvas units (every layer shares this space).
private const val CANVAS = 960f
private const val BUD_SCALE = 0.62f
private const val BUD_BOX_W = 340f   // bud PNGs are ~320-332 px wide, 540 px tall
private const val BUD_BOX_H = 540f
// Sprite crops cut from the open-case artwork: left/right bud resting in its cradle.
private const val SPR_Y = 363f; private const val SPR_W = 244f; private const val SPR_H = 154f
private const val SPR_LX = 236f; private const val SPR_RX = 481f
// Where a bud starts (in its cradle) and where it ends up.
private const val START_LX = 358f; private const val START_RX = 603f; private const val START_Y = 440f
private const val HOVER_LX = 355f; private const val HOVER_RX = 605f; private const val HOVER_Y = 160f
private const val PAIR_LX = 340f; private const val PAIR_RX = 620f; private const val PAIR_Y = 480f

/**
 * Hero artwork. The case is built from layers (closed case, empty open case, one resting-bud sprite per
 * cradle) and each earbud is a separate flying layer. When a bud is taken out of the case its sprite
 * disappears from the cradle while the real bud lifts out and floats above the case; when both buds
 * are out the case fades away and the two buds settle in the middle. Putting a bud back reverses it.
 * Which state to show is decided by [HeroResolver]; this composable never inspects Bluetooth data.
 */
@Composable
fun DeviceHeroArt(theme: Int, hero: HeroState, modifier: Modifier = Modifier, dashed: Boolean = false, appearance: Int = AppearanceMode.DARK) {
    val dark = appearance == AppearanceMode.DARK || appearance == AppearanceMode.AMOLED ||
        (appearance == AppearanceMode.SYSTEM && androidx.compose.foundation.isSystemInDarkTheme())
    // Required artwork rule: dark/AMOLED UI => white product PNGs; light UI => black product PNGs.
    val isBlack = !dark
    val leftOut = hero == HeroState.LEFT_OUT || hero == HeroState.BOTH_OUT
    val rightOut = hero == HeroState.RIGHT_OUT || hero == HeroState.BOTH_OUT
    val bothOut = hero == HeroState.BOTH_OUT
    val closed = hero == HeroState.CASE_CLOSED

    val pop = remember { CubicBezierEasing(0.2f, 0.9f, 0.3f, 1.12f) }
    val outSpec = tween<Float>(900, easing = pop)
    val inSpec = tween<Float>(560, easing = FastOutSlowInEasing)
    val pL = animateFloatAsState(if (leftOut) 1f else 0f, if (leftOut) outSpec else inSpec, label = "budLeftOut")
    val pR = animateFloatAsState(if (rightOut) 1f else 0f, if (rightOut) outSpec else inSpec, label = "budRightOut")
    val q = animateFloatAsState(if (bothOut) 1f else 0f, tween(800, easing = FastOutSlowInEasing), label = "bothOut")
    val single = animateFloatAsState(if ((leftOut || rightOut) && !bothOut) 1f else 0f, tween(650, easing = FastOutSlowInEasing), label = "singleOut")
    val open = animateFloatAsState(if (closed) 0f else 1f, tween(520, easing = FastOutSlowInEasing), label = "lidOpen")
    val inf = rememberInfiniteTransition(label = "heroFloat")
    val floatA = inf.animateFloat(-9f, 9f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatA")
    val floatB = inf.animateFloat(9f, -9f, infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatB")
    // How far the case group is pushed down so the lifted buds have room above it (canvas units).
    val shiftU = { 55f * single.value + 110f * q.value }

    val closedRes = if (isBlack) R.drawable.hero_case_closed_black else R.drawable.hero_case_closed_white
    val emptyRes = if (isBlack) R.drawable.hero_case_empty_black else R.drawable.hero_case_empty_white
    val openRes = if (isBlack) R.drawable.hero_case_open_black else R.drawable.hero_case_open_white
    val sprLRes = if (isBlack) R.drawable.hero_spr_left_black else R.drawable.hero_spr_left_white
    val sprRRes = if (isBlack) R.drawable.hero_spr_right_black else R.drawable.hero_spr_right_white
    val budLRes = if (isBlack) R.drawable.hero_bud_left_black else R.drawable.hero_bud_left_white
    val budRRes = if (isBlack) R.drawable.hero_bud_right_black else R.drawable.hero_bud_right_white
    val desc = when (hero) {
        HeroState.CASE_CLOSED -> "OnePlus Nord Buds 3 closed charging case"
        HeroState.BOTH_IN -> "OnePlus Nord Buds 3 open charging case with both earbuds inside"
        HeroState.LEFT_OUT -> "OnePlus Nord Buds 3 left earbud outside the case"
        HeroState.RIGHT_OUT -> "OnePlus Nord Buds 3 right earbud outside the case"
        HeroState.BOTH_OUT -> "OnePlus Nord Buds 3 left and right earbuds outside the case"
        HeroState.UNVERIFIED -> "OnePlus Nord Buds 3 charging case; position not verified"
    }
    val density = LocalDensity.current

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight)
        val k = with(density) { side.toPx() } / CANVAS
        Box(Modifier.requiredSize(side).semantics { contentDescription = desc }) {
            // Accent halo behind the buds once the case is gone.
            Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = q.value }) {
                val accent = accentFor(theme)
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .13f), Color.Transparent), center = center, radius = size.minDimension * .45f),
                    radius = size.minDimension * .45f, center = center)
            }
            // ---- Case group: closed case, empty open case, resting-bud sprites ----
            Box(Modifier.fillMaxSize().graphicsLayer {
                val qv = q.value
                translationY = shiftU() * k + floatA.value * k * (1f - qv)
                scaleX = 1f - 0.14f * qv; scaleY = scaleX
                alpha = (1f - qv * 1.15f).coerceIn(0f, 1f)
            }) {
                Image(painterResource(closedRes), null, Modifier.fillMaxSize().graphicsLayer {
                    alpha = 1f - ((open.value - 0.35f) / 0.65f).coerceIn(0f, 1f)
                }, contentScale = ContentScale.Fit)
                Image(painterResource(emptyRes), null, Modifier.fillMaxSize().graphicsLayer {
                    alpha = (open.value * 1.6f).coerceIn(0f, 1f)
                    val sc = 0.965f + 0.035f * open.value.coerceIn(0f, 1f); scaleX = sc; scaleY = sc
                }, contentScale = ContentScale.Fit)
                CradleBud(sprLRes, SPR_LX, k, density, pL, open)
                CradleBud(sprRRes, SPR_RX, k, density, pR, open)
                // Original open-case artwork (both buds inside) shown while nothing has been taken out.
                Image(painterResource(openRes), null, Modifier.fillMaxSize().graphicsLayer {
                    val moved = maxOf(pL.value, pR.value).coerceIn(0f, 1f)
                    alpha = (open.value * 1.6f).coerceIn(0f, 1f) * (1f - (moved / 0.05f).coerceIn(0f, 1f))
                    val sc = 0.965f + 0.035f * open.value.coerceIn(0f, 1f); scaleX = sc; scaleY = sc
                }, contentScale = ContentScale.Fit)
            }
            // ---- Flying earbuds ----
            FlyingBud(budLRes, pL, q, shiftU, START_LX, HOVER_LX, PAIR_LX, -14f, floatA, k)
            FlyingBud(budRRes, pR, q, shiftU, START_RX, HOVER_RX, PAIR_RX, 14f, floatB, k)
        }
    }
}

/** The bud as it rests in its cradle. Fades out and lifts a little as the real bud takes over. */
@Composable
private fun CradleBud(res: Int, x0: Float, k: Float, density: androidx.compose.ui.unit.Density, out: State<Float>, open: State<Float>) {
    Image(
        painterResource(res), null,
        Modifier.offset { IntOffset((x0 * k).roundToInt(), (SPR_Y * k).roundToInt()) }
            .size(with(density) { (SPR_W * k).toDp() }, with(density) { (SPR_H * k).toDp() })
            .graphicsLayer {
                val p = out.value.coerceIn(0f, 1f)
                alpha = (open.value * 1.6f).coerceIn(0f, 1f) * (1f - (p / 0.35f).coerceIn(0f, 1f))
                translationY = -60f * k * p
            },
        contentScale = ContentScale.Fit
    )
}

/** One earbud travelling from its cradle to the hover spot above the case (or to the centre if both are out). */
@Composable
private fun BoxScope.FlyingBud(
    res: Int, p: State<Float>, q: State<Float>, shiftU: () -> Float,
    startX: Float, hoverX: Float, pairX: Float, tilt: Float, float: State<Float>, k: Float
) {
    val density = LocalDensity.current
    Image(
        painterResource(res), null,
        Modifier.align(Alignment.Center)
            .size(with(density) { (BUD_BOX_W * BUD_SCALE * k).toDp() }, with(density) { (BUD_BOX_H * BUD_SCALE * k).toDp() })
            .graphicsLayer {
                val pv = p.value
                val pc = pv.coerceIn(0f, 1f)
                val tx = lerpF(hoverX, pairX, q.value)
                val ty = lerpF(HOVER_Y, PAIR_Y, q.value)
                val x = lerpF(startX, tx, pv)
                val y = lerpF(START_Y + shiftU(), ty, pv)
                translationX = (x - CANVAS / 2f) * k
                translationY = (y - CANVAS / 2f) * k + float.value * k * pc
                val sc = lerpF(0.42f, BUD_SCALE, pv.coerceIn(0f, 1.2f)) / BUD_SCALE
                scaleX = sc; scaleY = sc
                rotationZ = lerpF(tilt, 0f, pc)
                alpha = (pv / 0.22f).coerceIn(0f, 1f)
            },
        contentScale = ContentScale.Fit
    )
}

@Composable
fun HeroCaption(r: ResolvedHero) {
    val tag = when (r.source) {
        HeroSource.HARDWARE -> "VERIFIED"; HeroSource.ESTIMATED -> "ESTIMATED"; HeroSource.PRESENTATION -> "PRESENTATION"
        HeroSource.PREVIEW -> "PREVIEW"; HeroSource.UNVERIFIED -> "UNVERIFIED"
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(tag, 10, FontWeight.Bold, if (r.source == HeroSource.HARDWARE) P.green else P.accent, spacing = 1.4f)
        Txt(r.note, 12, color = P.sub, align = TextAlign.Center, lineHeight = 16, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Settings → Diagnostics: manually drive the hero without earbuds. Nothing here is hardware detection. */
@Composable
fun HeroPreviewPicker() {
    SectionLabel("Hero preview (debug)", detail = "Manually show any home-screen state. Preview only; never treated as detected hardware.")
    val options: List<Pair<HeroState?, String>> = listOf(
        null to "Live (follow device data)",
        HeroState.CASE_CLOSED to "1 · Case closed",
        HeroState.BOTH_IN to "2 · Open, both buds inside",
        HeroState.LEFT_OUT to "3 · Left bud outside",
        HeroState.RIGHT_OUT to "4 · Right bud outside",
        HeroState.BOTH_OUT to "5 · Both buds outside",
        HeroState.UNVERIFIED to "Unknown / unverified"
    )
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((state, label) in options) {
            val sel = HeroPreview.selected == state
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(if (sel) P.accent.copy(alpha = 0.22f) else P.tile)
                    .clickable { HeroPreview.selected = state }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) { Txt(label, 14, if (sel) FontWeight.Bold else FontWeight.Normal, if (sel) P.accent else P.text) }
        }
    }
}
