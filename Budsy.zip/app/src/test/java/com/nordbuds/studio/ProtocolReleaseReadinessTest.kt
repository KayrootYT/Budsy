package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolReleaseReadinessTest {
    @Test fun gattWriteIsBlockedWithoutUuidAndEvidence() {
        val result = ProtocolReleaseReadiness.assessTransmission(
            "OnePlus Nord Buds 3", "0x0418", "BLE/GATT", false, 0, false
        )
        assertEquals(ProtocolReleaseReadiness.Decision.NEEDS_EVIDENCE, result.decision)
        assertTrue(result.reasons.any { it.contains("service UUID") })
        assertTrue(result.reasons.any { it.contains("characteristic UUID") })
        assertFalse(result.canProceedToManualReview)
    }

    @Test fun evidenceGateOnlyAllowsManualReviewNeverTransmit() {
        val result = ProtocolReleaseReadiness.assessTransmission(
            "OnePlus Nord Buds 3", "0x0106", "RFCOMM", true, 2, true
        )
        assertEquals(ProtocolReleaseReadiness.Decision.MANUAL_REVIEW_ONLY, result.decision)
        assertTrue(result.canProceedToManualReview)
        assertTrue(result.reasons.any { it.contains("No packet is transmitted") })
    }

    @Test fun unassignedProfileCannotPassEvidenceGate() {
        val result = ProtocolReleaseReadiness.assessTransmission(
            "Unassigned", "0x0106", "RFCOMM", true, 2, true
        )
        assertEquals(ProtocolReleaseReadiness.Decision.NEEDS_EVIDENCE, result.decision)
    }
}
