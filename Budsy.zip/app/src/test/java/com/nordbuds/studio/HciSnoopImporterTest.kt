package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream

class HciSnoopImporterTest {
    private fun be32(out: ByteArrayOutputStream, value: Long) {
        out.write(byteArrayOf((value ushr 24).toByte(), (value ushr 16).toByte(), (value ushr 8).toByte(), value.toByte()))
    }
    private fun record(out: ByteArrayOutputStream, flags: Long, packet: ByteArray) {
        be32(out,packet.size.toLong()); be32(out,packet.size.toLong()); be32(out,flags); be32(out,0)
        out.write(byteArrayOf(0,0,0,0,0,0,0,1)); out.write(packet)
    }
    private fun l2cap(cid: Int, payload: ByteArray): ByteArray =
        byteArrayOf(payload.size.toByte(),(payload.size ushr 8).toByte(),cid.toByte(),(cid ushr 8).toByte())+payload
    private fun acl(handle: Int, direction: Long, cid: Int, payload: ByteArray): Pair<Long,ByteArray> {
        val pdu=l2cap(cid,payload)
        val handleFlags=handle or 0x2000 // PB=2: first, non-flushable ACL fragment
        val packet=byteArrayOf(2,handleFlags.toByte(),(handleFlags ushr 8).toByte(),pdu.size.toByte(),(pdu.size ushr 8).toByte())+pdu
        return direction to packet
    }
    private fun vendorFrame(): ByteArray {
        // Protocol.Parser frame: AA, LEB128(7+payload), two pad bytes, cmd lo/hi, seq, payload length LE, payload.
        val payload=byteArrayOf(0,3,1,100,2,100,3,0)
        return byteArrayOf(0xAA.toByte(),(7+payload.size).toByte(),0,0,0x06,0x01,0x21,payload.size.toByte(),0)+payload
    }
    private fun fixture(withVendor: Boolean = true): ByteArray {
        val out=ByteArrayOutputStream()
        out.write("btsnoop\u0000".toByteArray(Charsets.ISO_8859_1)); be32(out,1); be32(out,1002)
        // L2CAP connection request for RFCOMM PSM 3, source CID 0x40.
        val req=byteArrayOf(0x02,0x01,0x04,0x00,0x03,0x00,0x40,0x00)
        record(out,0,acl(1,0,1,req).second)
        // Successful response: destination CID 0x41, source CID 0x40, result/status 0.
        val rsp=byteArrayOf(0x03,0x01,0x08,0x00,0x41,0x00,0x40,0x00,0x00,0x00,0x00,0x00)
        record(out,1,acl(1,1,1,rsp).second)
        if (withVendor) {
            val v=vendorFrame()
            val rfcomm=byteArrayOf(0x07,0xEF.toByte(),((v.size shl 1) or 1).toByte())+v+byteArrayOf(0xFF.toByte())
            record(out,0,acl(1,0,0x41,rfcomm).second)
        }
        // ATT Read By Type request for characteristic declaration UUID 0x2803.
        val readByType = byteArrayOf(0x08,0x01,0x00,0xFF.toByte(),0xFF.toByte(),0x03,0x28)
        record(out,0,acl(1,0,0x0004,readByType).second)
        // Response: properties=0x12, value handle=0x000B, characteristic UUID=0xFF01.
        val characteristic = byteArrayOf(0x09,0x07,0x0A,0x00,0x12,0x0B,0x00,0x01,0xFF.toByte())
        record(out,1,acl(1,1,0x0004,characteristic).second)
        // Notification on discovered value handle 0x000B.
        val notification = byteArrayOf(0x1B,0x0B,0x00,0x02,0x64)
        record(out,1,acl(1,1,0x0004,notification).second)
        return out.toByteArray()
    }

    @Test fun parsesHciPacketTypesAndDirections() {
        val r=HciSnoopImporter.parse("capture.log",fixture(false))
        assertEquals(5,r.totalRecords)
        assertEquals(2,r.sentRecords); assertEquals(3,r.receivedRecords)
        assertEquals(5,r.aclPackets); assertEquals(5,r.l2capPackets)
        assertEquals(3,r.attPackets)
    }

    @Test fun reassemblesL2capRfcommAndExtractsVendorFrame() {
        val r=HciSnoopImporter.parse("hey.log",fixture())
        assertEquals(1,r.rfcommFrames)
        assertEquals(1,r.vendorFrames.size)
        val f=r.vendorFrames.single()
        assertEquals("TX",f.direction)
        assertEquals(0x0106,f.command)
        assertEquals(0x21,f.sequence)
        assertEquals(listOf(0,3,1,100,2,100,3,0),f.payload)
    }

    @Test fun discoversGattCharacteristicAndNotification() {
        val r=HciSnoopImporter.parse("ble.log",fixture(false))
        assertEquals(1,r.gattCharacteristics.size)
        val c=r.gattCharacteristics.single()
        assertEquals(0x000B,c.valueHandle)
        assertEquals("0000ff01-0000-1000-8000-00805f9b34fb",c.uuid)
        assertEquals(1,r.gattEvents.count { it.opcode == 0x1B })
        assertEquals("0000ff01-0000-1000-8000-00805f9b34fb",r.gattEvents.single { it.opcode == 0x1B }.uuid)
    }

    @Test fun diffReportsChangedOpcodes() {
        val a=HciSnoopImporter.parse("a",fixture())
        val b=HciSnoopImporter.parse("b",fixture()+fixture().copyOfRange(16,fixture().size))
        val d=HciSnoopImporter.diff(a,b)
        assertTrue(d.recordDelta>0)
    }

    @Test(expected=IllegalArgumentException::class)
    fun rejectsNonBtsnoopFiles() { HciSnoopImporter.parse("bad",byteArrayOf(1,2,3,4)) }
}
