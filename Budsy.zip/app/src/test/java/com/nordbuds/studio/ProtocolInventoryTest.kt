package com.nordbuds.studio

import com.nordbuds.studio.protocol.ProtocolInventory
import org.junit.Assert.*
import org.junit.Test

class ProtocolInventoryTest {
    @Test fun coreFeatureAndAdvancedLayersAreSeparated() {
        assertTrue(ProtocolInventory.byLayer(ProtocolInventory.Layer.CORE).any { it.id == "BLE/GATT" })
        assertTrue(ProtocolInventory.byLayer(ProtocolInventory.Layer.FEATURE).any { it.id == "0122/0418" })
        assertTrue(ProtocolInventory.byLayer(ProtocolInventory.Layer.ADVANCED).any { it.id == "OTA" })
    }

    @Test fun otaAndFastPairRemainInventoryOnly() {
        val advanced = ProtocolInventory.byLayer(ProtocolInventory.Layer.ADVANCED)
        listOf("OTA", "Fast Pair").forEach { id ->
            val entry = advanced.single { it.id == id }
            assertTrue(entry.evidence.contains(ProtocolInventory.Evidence.INVENTORY_ONLY))
            assertFalse(entry.writable)
        }
    }

    @Test fun customEqIs0418Not0422() {
        val eq = ProtocolInventory.entries.single { it.id == "0122/0418" }
        assertEquals(0x0418, eq.responseCommand)
        assertFalse(ProtocolInventory.entries.any { it.id == "0422" && it.label.contains("Custom EQ") })
    }
}
