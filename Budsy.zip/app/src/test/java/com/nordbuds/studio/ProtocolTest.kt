package com.nordbuds.studio

import com.nordbuds.studio.protocol.Protocol
import org.junit.Assert.*
import org.junit.Test

class ProtocolTest {
    @Test fun buildFrame_matchesLayout() {
        val f = Protocol.buildFrame(0x06, 1, 0x20, intArrayOf())
        assertArrayEquals(byteArrayOf(0xAA.toByte(), 7, 0, 0, 6, 1, 0x20, 0, 0), f)
    }
    @Test fun parser_handlesSplitAndGarbage() {
        val frame = byteArrayOf(0xAA.toByte(), 13, 0, 0, 6, 0x81.toByte(), 0x20, 6, 0, 0, 2, 1, 80, 2, (65 or 0x80).toByte())
        val p = Protocol.Parser()
        assertTrue(p.feed(byteArrayOf(0, 0)).isEmpty())
        assertTrue(p.feed(frame.copyOfRange(0, 4)).isEmpty())
        val out = p.feed(frame.copyOfRange(4, frame.size))
        assertEquals(1, out.size); assertEquals(0x0106, out[0].cmd); assertFalse(out[0].isPush); assertEquals(0, out[0].status); assertEquals(80, out[0].payload[3])
    }
    @Test fun parseBattery_decodesFlags() {
        val bats = Protocol.parseBattery(intArrayOf(0, 2, 1, 80, 2, 65 or 0x80))
        assertEquals(listOf(Protocol.Battery(0, 80, false), Protocol.Battery(1, 65, true)), bats)
    }
    @Test fun parseGestureTable_skipsDisabledEntries() {
        val t = Protocol.parseGestureTable(intArrayOf(0, 2, 2, 1, 3, 6, 1, 0, 1, 1))
        assertEquals(6, t[2 * 16 + 3]); assertNull(t[1 * 16 + 1])
    }
    @Test fun parsePeers_readsMacAndName() {
        val peers = Protocol.parsePeers(intArrayOf(0, 1, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0, 2, 1, 4, 'T'.code, 'V'.code, 'P'.code, 'C'.code))
        assertEquals("AA:BB:CC:DD:EE:FF", peers[0].mac); assertEquals("TVPC", peers[0].name)
    }
    @Test fun customEq_roundTrips() {
        val payload = Protocol.buildCustomEqPayload(Protocol.CustomEqProfile("Joe", true, listOf(100 to 3, 1000 to -5)), -10, 10)
        val profs = Protocol.parseCustomEq(intArrayOf(0) + payload)
        assertEquals(1, profs.size); assertEquals("Joe", profs[0].name); assertTrue(profs[0].active); assertEquals(listOf(100 to 3, 1000 to -5), profs[0].bands)
    }
    @Test fun gattCustomEq_usesSeparateDocumentedPayloadLayout() {
        val payload = Protocol.buildGattCustomEqPayload(
            p3 = 2, min = -6, max = 6, eqId = 7, name = "EQ",
            bands = listOf(100 to 3, 1000 to -5)
        )
        assertArrayEquals(
            intArrayOf(2, 250, 6, 7, 2, 'E'.code, 'Q'.code, 2,
                100, 0, 3, 0xE8, 3, 0xFB),
            payload
        )
    }

    @Test fun customEqProfileName_roundTripsUtf8() {
        val payload = Protocol.buildCustomEqPayload(
            Protocol.CustomEqProfile("ÉQ", true, listOf(1000 to 2)), -6, 6
        )
        val decoded = Protocol.parseCustomEq(intArrayOf(0) + payload)
        assertEquals("ÉQ", decoded.single().name)
    }

    @Test fun gattCustomEq_rejectsOutOfRangeFrequency() {
        assertThrows(IllegalArgumentException::class.java) {
            Protocol.buildGattCustomEqPayload(0, -6, 6, 1, "Custom", listOf(70000 to 0))
        }
    }

    @Test fun decodeAnc_mapsMasks() {
        assertEquals(Protocol.ANC_TRANSP, Protocol.decodeAnc(0x0200)); assertEquals(Protocol.ANC_OFF, Protocol.decodeAnc(0x08)); assertEquals(Protocol.ANC_ON, Protocol.decodeAnc(0x08F2)); assertEquals(-1, Protocol.decodeAnc(0))
    }
    @Test fun hex_padsToTwo() { assertEquals("00", Protocol.hex(0)); assertEquals("ff", Protocol.hex(255)); assertEquals("0a", Protocol.hex(10)) }
}
