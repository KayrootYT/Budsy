package com.nordbuds.studio

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolCommandDatabaseTest {
    @Test fun acceptsEvenLengthHexCommandIds() {
        assertTrue(ProtocolCommandDatabase.isValidCommandHex("0106"))
        assertTrue(ProtocolCommandDatabase.isValidCommandHex("0x0418"))
        assertTrue(ProtocolCommandDatabase.isValidCommandHex("AABBCCDD"))
    }

    @Test fun rejectsMalformedCommandIds() {
        assertFalse(ProtocolCommandDatabase.isValidCommandHex("106"))
        assertFalse(ProtocolCommandDatabase.isValidCommandHex("01GG"))
        assertFalse(ProtocolCommandDatabase.isValidCommandHex(""))
        assertFalse(ProtocolCommandDatabase.isValidCommandHex("1234567890"))
    }

    @Test fun verificationRequiresDeviceProfileTwoCapturesAndNegativeControl() {
        ProtocolCommandDatabase.entries.clear()
        ProtocolCommandDatabase.selectProfile("Unassigned")
        assertTrue(ProtocolCommandDatabase.addObserved("RFCOMM", "0106", "Battery candidate", "Observed in raw trace"))
        val unassigned = ProtocolCommandDatabase.visibleEntries().first()
        assertFalse(ProtocolCommandDatabase.verifyWithCaptureEvidence(unassigned.id,
            "Confirmed battery mapping after controlled tests", "capture-a.log", "capture-b.log", true))

        ProtocolCommandDatabase.selectProfile("OnePlus Nord Buds 3")
        assertTrue(ProtocolCommandDatabase.addObserved("RFCOMM", "0106", "Battery candidate", "Observed in raw trace"))
        val target = ProtocolCommandDatabase.visibleEntries().first()
        assertFalse(ProtocolCommandDatabase.verifyWithCaptureEvidence(target.id,
            "Confirmed battery mapping after controlled tests", "capture-a.log", "capture-a.log", true))
        assertFalse(ProtocolCommandDatabase.verifyWithCaptureEvidence(target.id,
            "Confirmed battery mapping after controlled tests", "capture-a.log", "capture-b.log", false))
        assertTrue(ProtocolCommandDatabase.verifyWithCaptureEvidence(target.id,
            "Confirmed battery mapping after controlled tests", "capture-a.log", "capture-b.log", true))
        assertTrue(ProtocolCommandDatabase.visibleEntries().first { it.id == target.id }.status == "VERIFIED")
        ProtocolCommandDatabase.entries.clear()
        ProtocolCommandDatabase.selectProfile("Unassigned")
    }

}
