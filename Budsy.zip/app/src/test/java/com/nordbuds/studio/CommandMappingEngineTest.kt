package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandMappingEngineTest {
    private fun report(
        vendor: List<HciSnoopImporter.VendorFrame> = emptyList(),
        gatt: List<HciSnoopImporter.GattEvent> = emptyList()
    ) = HciSnoopImporter.Report(
        fileName = "fixture", version = 1, dataLinkType = 1002,
        totalRecords = 0, sentRecords = 0, receivedRecords = 0, droppedRecords = 0,
        commandPackets = 0, eventPackets = 0, aclPackets = 0, otherPackets = 0,
        opcodeCounts = emptyMap(), eventCodeCounts = emptyMap(), warnings = emptyList(),
        vendorFrames = vendor, gattEvents = gatt
    )

    @Test fun detectsNewVendorCommandAndKeepsTransportDirection() {
        val baseline = report()
        val current = report(vendor = listOf(
            HciSnoopImporter.VendorFrame("TX", 0x0106, 1, 7, listOf(0, 3, 1, 100))
        ))
        val rows = CommandMappingEngine.compare(baseline, current)
        assertEquals(1, rows.size)
        assertTrue(rows.single().signature.contains("TX CMD 0x0106"))
        assertEquals(1, rows.single().delta)
    }

    @Test fun detectsChangedGattValueEvenWhenPacketCountIsSame() {
        val a = report(gatt = listOf(HciSnoopImporter.GattEvent(
            "RX", 0x1B, "NOTIFICATION", 12, "uuid-test", listOf(0)
        )))
        val b = report(gatt = listOf(HciSnoopImporter.GattEvent(
            "RX", 0x1B, "NOTIFICATION", 12, "uuid-test", listOf(1)
        )))
        val rows = CommandMappingEngine.compare(a, b)
        assertEquals(1, rows.size)
        assertEquals(0, rows.single().delta)
        assertTrue(rows.single().samples.contains("01"))
    }

    @Test fun unchangedSignalsProduceNoCandidates() {
        val f = HciSnoopImporter.VendorFrame("TX", 0x0106, 1, 7, listOf(1, 2))
        assertTrue(CommandMappingEngine.compare(report(listOf(f)), report(listOf(f))).isEmpty())
    }
}
