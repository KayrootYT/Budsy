package com.nordbuds.studio

import com.nordbuds.studio.protocol.ProtocolDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolDecoderTest {
    @Test fun batteryReply_isDecodedWithoutInventingCasePercent() {
        val decoded = ProtocolDecoder.decode(0x0106, 0x81, intArrayOf(0, 3, 1, 100, 2, 100, 3, 0))
        assertEquals("Battery response", decoded.title)
        assertTrue(decoded.detail.contains("Left=100%"))
        assertTrue(decoded.detail.contains("Right=100%"))
        assertTrue(decoded.detail.contains("Case=unknown"))
    }

    @Test fun featureReply_ignoresZeroPaddingAndShowsObservedPairs() {
        val decoded = ProtocolDecoder.decode(0x010D, 0x81,
            intArrayOf(0, 7, 0x06, 0, 0x0B, 1, 0x11, 1, 0x1B, 1, 0x1D, 1, 0, 0, 0, 0))
        assertEquals("Feature flags response", decoded.title)
        assertTrue(decoded.detail.contains("0b=01"))
        assertTrue(decoded.detail.contains("1d=01"))
        assertTrue(!decoded.detail.contains("00="))
    }

    @Test fun unverifiedAncPayload_staysExplicitlyRaw() {
        val decoded = ProtocolDecoder.decode(0x010C, 0x81, intArrayOf(0, 1, 2))
        assertTrue(decoded.detail.contains("Raw mode payload"))
        assertTrue(decoded.confidence.contains("unverified"))
    }
}
