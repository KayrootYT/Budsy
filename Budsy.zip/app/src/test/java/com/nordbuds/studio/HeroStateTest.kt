package com.nordbuds.studio

import org.junit.Assert.*
import org.junit.Test

class HeroStateTest {
    private fun r(c: Boolean, lid: LidState, l: BudPos, rt: BudPos) = HeroResolver.resolve(HeroInput(c, lid, l, rt))
    private val O = LidState.OPEN; private val IN = BudPos.INSIDE; private val OUT = BudPos.OUTSIDE; private val UN = BudPos.UNKNOWN

    @Test fun disconnected_isPresentationNotHardware() {
        val x = r(false, LidState.UNKNOWN, UN, UN)
        assertEquals(HeroState.CASE_CLOSED, x.state); assertEquals(HeroSource.PRESENTATION, x.source)
    }
    @Test fun confirmedClosedLid_isHardwareState1() {
        val x = r(true, LidState.CLOSED, IN, IN)
        assertEquals(HeroState.CASE_CLOSED, x.state); assertEquals(HeroSource.HARDWARE, x.source)
    }
    @Test fun openLid_fourBudCombinations() {
        assertEquals(HeroState.BOTH_IN, r(true, O, IN, IN).state)
        assertEquals(HeroState.LEFT_OUT, r(true, O, OUT, IN).state)
        assertEquals(HeroState.RIGHT_OUT, r(true, O, IN, OUT).state)
        assertEquals(HeroState.BOTH_OUT, r(true, O, OUT, OUT).state)
        assertEquals(HeroSource.HARDWARE, r(true, O, OUT, OUT).source)
    }
    @Test fun unknownLid_knownBuds_isEstimatedNeverHardware() {
        val x = r(true, LidState.UNKNOWN, OUT, IN)
        assertEquals(HeroState.LEFT_OUT, x.state); assertEquals(HeroSource.ESTIMATED, x.source)
        assertNotEquals(HeroSource.HARDWARE, r(true, LidState.UNKNOWN, IN, IN).source)
    }
    @Test fun unknownLid_unknownBuds_isUnverified() {
        val x = r(true, LidState.UNKNOWN, UN, UN)
        assertEquals(HeroState.UNVERIFIED, x.state); assertEquals(HeroSource.UNVERIFIED, x.source)
    }
    @Test fun unknownBud_withOpenLid_isUnverified() {
        assertEquals(HeroState.UNVERIFIED, r(true, O, IN, UN).state)
    }
    @Test fun closedLidWithBudOutside_isConflict() {
        assertEquals(HeroState.UNVERIFIED, r(true, LidState.CLOSED, OUT, IN).state)
    }
    @Test fun wearFlags_mapToPosition() {
        assertEquals(BudPos.UNKNOWN, budPosFromWear(-1))
        assertEquals(BudPos.INSIDE, budPosFromWear(0))
        assertEquals(BudPos.OUTSIDE, budPosFromWear(1))
        assertEquals(BudPos.OUTSIDE, budPosFromWear(2))
    }
    @Test fun preview_isNeverHardware() {
        for (s in HeroState.values()) assertEquals(HeroSource.PREVIEW, HeroResolver.preview(s).source)
    }
}
