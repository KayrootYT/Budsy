package com.nordbuds.studio

import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolCandidateImportTest {
    @Test fun candidateIsStoredAsObservedNotVerified() {
        ProtocolCommandDatabase.entries.clear()
        ProtocolCommandDatabase.selectProfile("OnePlus Nord Buds 3")
        val candidate = CommandMappingEngine.Candidate(
            "RFCOMM", "TX CMD 0x0106 group=0x01", 2, 4, 2, listOf("00030164")
        )
        assertTrue(ProtocolCommandDatabase.addCandidate(candidate, "controlled-capture.log"))
        val entry = ProtocolCommandDatabase.visibleEntries().first()
        assertTrue(entry.command == "0x0106")
        assertTrue(entry.status == "OBSERVED")
        assertTrue(entry.evidence.contains("controlled-capture.log"))
        ProtocolCommandDatabase.entries.clear()
        ProtocolCommandDatabase.selectProfile("Unassigned")
    }
}
