package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolLiveMonitorTest {
    private fun event(direction: String, command: Int, title: String = "Known", matched: Boolean = false) =
        ProtocolLab.Event(
            time = 1L, direction = direction, command = command, group = 0,
            payload = listOf(0x01, 0x64), decodedTitle = title,
            decodedDetail = "sample payload", matched = matched
        )

    @Test fun filtersByDirectionAndUnknownStatus() {
        val rows = listOf(event("TX", 0x0106), event("RX", 0x0106, matched = true), event("RX", 0x010D, "Unknown command"))
        assertEquals(1, ProtocolLiveMonitor.filter(rows, ProtocolLiveMonitor.Filter.TX).size)
        assertEquals(2, ProtocolLiveMonitor.filter(rows, ProtocolLiveMonitor.Filter.RX).size)
        assertEquals(1, ProtocolLiveMonitor.filter(rows, ProtocolLiveMonitor.Filter.UNKNOWN).size)
    }

    @Test fun searchesCommandAndPayload() {
        val rows = listOf(event("TX", 0x0106), event("RX", 0x010D))
        assertEquals(1, ProtocolLiveMonitor.filter(rows, ProtocolLiveMonitor.Filter.ALL, "010d").size)
        assertEquals(2, ProtocolLiveMonitor.filter(rows, ProtocolLiveMonitor.Filter.ALL, "64").size)
    }

    @Test fun summaryCountsTrafficAndMatchedReplies() {
        val summary = ProtocolLiveMonitor.summarize(listOf(
            event("TX", 0x0106), event("RX", 0x0106, matched = true), event("RX", 0x010D, "Unknown command")
        ))
        assertEquals(3, summary.visible)
        assertEquals(1, summary.tx)
        assertEquals(2, summary.rx)
        assertEquals(1, summary.matched)
        assertEquals(1, summary.unknown)
        assertEquals(0x010D, summary.latestCommand)
    }
}
