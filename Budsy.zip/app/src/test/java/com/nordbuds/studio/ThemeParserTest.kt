package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeParserTest {
    @Test fun parsesRgbAndArgbColours() {
        assertEquals(0xFF6B4EFFL, ThemeParser.color("#6B4EFF"))
        assertEquals(0x80112233L, ThemeParser.color("80112233"))
        assertNull(ThemeParser.color("not-a-colour"))
        assertNull(ThemeParser.color(null))
    }

    @Test fun legacyPropertiesStillMapToPalette() {
        val s = ThemeParser.fromFlat(mapOf("name" to "Ocean", "lightBg" to "#F4F7FC", "darkCard" to "#242B38", "accent" to "#397BEA", "text" to "#18202D"))
        assertEquals("Ocean", s.name)
        assertEquals(0xFFF4F7FCL, s.light.bg)
        assertEquals(0xFF242B38L, s.dark.card)
        assertEquals(0xFF397BEAL, s.light.accent)
        assertEquals(0xFF18202DL, s.dark.text)
        assertTrue("colors" in s.features)
    }

    @Test fun fullSpecIsClampedAndValidated() {
        val s = ThemeParser.fromFlat(mapOf(
            "shapes.panel" to "999", "shapes.card" to "-5", "motion.speed" to "50", "font.scale" to "0.1",
            "card.style" to "glass", "motion.tabTransition" to "spin", "font.family" to "comic",
            "font.file" to "../evil.ttf", "icons.tab_device" to "/abs/path.png", "icons.battery" to "icons/b.png"
        ))
        assertEquals(48f, s.shapes.panel, 0f)
        assertEquals(0f, s.shapes.card, 0f)
        assertEquals(3f, s.motion.speed, 0f)
        assertEquals(0.8f, s.font.scale, 0f)
        assertEquals(CardStyle.GLASS, s.card.style)
        assertEquals("slide", s.motion.tabTransition)
        assertEquals("sans", s.font.family)
        assertNull("path traversal must be rejected", s.font.file)
        assertFalse("absolute icon path must be rejected", s.icons.map.containsKey("tab_device"))
        assertEquals("icons/b.png", s.icons.map["battery"])
    }

    @Test fun amoledFallsBackToDarkWhenNotProvided() {
        val s = ThemeParser.fromFlat(mapOf("colors.dark.bg" to "#101010"))
        assertEquals(0xFF101010L, s.colorsFor(AppearanceMode.AMOLED).bg)
        val s2 = ThemeParser.fromFlat(mapOf("colors.dark.bg" to "#101010", "colors.amoled.bg" to "#000000"))
        assertEquals(0xFF000000L, s2.colorsFor(AppearanceMode.AMOLED).bg)
    }


    @Test fun schemaTwoParsesCompleteUiContract() {
        val s = ThemeParser.fromFlat(mapOf(
            "schema" to "2", "ui.complete" to "true", "ui.profile" to "nothing",
            "ui.pageHorizontal" to "13", "ui.navStyle" to "underline",
            "ui.headerStyle" to "console", "ui.panelStyle" to "console",
            "ui.tileStyle" to "outlined", "ui.iconStyle" to "pixel",
            "ui.interactionStyle" to "mechanical", "ui.backgroundEffect" to "scanlines",
            "ui.overviewLayout" to "console", "ui.soundLayout" to "mixer",
            "ui.controlsLayout" to "list", "ui.settingsLayout" to "console"
        ))
        assertEquals(2, s.schema)
        assertTrue(s.ui.complete)
        assertEquals("nothing", s.ui.profile)
        assertEquals(13f, s.ui.pageHorizontal, 0f)
        assertEquals("underline", s.ui.navStyle)
        assertEquals("console", s.ui.overviewLayout)
        assertTrue("full-ui" in s.features)
    }

    @Test fun readsMtzDescriptionXml() {
        val d = ThemeParser.parseMtzDescription("<MIUI-Theme><title>Sky</title><designer>Aman</designer><version>2.1</version></MIUI-Theme>")
        assertEquals("Sky", d["name"]); assertEquals("Aman", d["author"]); assertEquals("2.1", d["version"])
    }
}
