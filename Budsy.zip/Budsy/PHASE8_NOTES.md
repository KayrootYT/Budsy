# Budsy 2.0 — Phase 8: Smart Auto-Reconnect

## Changes
- Coalesces duplicate Android ACL_CONNECTED and A2DP_CONNECTED broadcasts into one recovery worker.
- Uses the app-owned coroutine scope so receiver lifetime does not cancel connection recovery.
- Adds a bounded retry schedule (initial attempt, then 2s and 5s backoff) rather than rapid repeated reconnect attempts.
- Stops retrying after a successful protocol connection, when auto-connect is paused, or after the bounded attempts are exhausted.
- Explicit Disconnect cancels any pending auto-recovery job and persists the paused state.
- Keeps the remembered-device address check and existing GATT-first / RFCOMM fallback behavior.

## Protocol compatibility
No UUIDs, command IDs, payload layouts, sequence generation, BLE characteristics, RFCOMM service UUIDs, or protocol parsing were intentionally changed in this phase.

## Verification
- Source-level inspection completed.
- ZIP archive integrity check completed after packaging.
- Android Gradle build and physical-earbud reconnect tests remain required; this environment has no project Gradle wrapper and no confirmed Android SDK build environment.
