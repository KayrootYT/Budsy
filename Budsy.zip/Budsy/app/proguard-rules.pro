# Budsy release shrinking rules.
# Manifest components (activities, services, receivers, tile services) are kept automatically by AGP.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-dontwarn kotlinx.coroutines.**
