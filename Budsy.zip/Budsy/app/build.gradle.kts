import java.io.File
import java.net.URI
import java.util.zip.ZipInputStream

import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.nordbuds.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nordbuds.studio"
        minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    signingConfigs {
        val propsFile = rootProject.file("app/keystore.properties")
        if (propsFile.exists()) {
            val props = Properties()
            propsFile.inputStream().use { stream -> props.load(stream) }
            create("release") {
                storeFile = rootProject.file("app/${props.getProperty("storeFile")}")
                storePassword = props.getProperty("storePassword")
                keyAlias = props.getProperty("keyAlias")
                keyPassword = props.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (rootProject.file("app/keystore.properties").exists()) signingConfig = signingConfigs.getByName("release")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")   // real org.json for JVM unit tests (android.jar stubs throw "not mocked")
}

// ---- Open-source assets fetched at build time (needs internet; the app falls back to system font/Material icons if absent)
// Inter font (SIL OFL 1.1) -> assets/fonts ; Phosphor Icons (MIT) -> assets/icons
val interDir = layout.projectDirectory.dir("src/main/assets/fonts").asFile
val phosphorDir = layout.projectDirectory.dir("src/main/assets/icons").asFile

val fetchInterFonts by tasks.registering {
    outputs.dir(interDir)
    doLast {
        val want = mapOf("Inter-Regular" to "inter_regular.ttf", "Inter-Medium" to "inter_medium.ttf",
            "Inter-SemiBold" to "inter_semibold.ttf", "Inter-Bold" to "inter_bold.ttf")
        interDir.mkdirs()
        if (want.values.all { File(interDir, it).length() > 0L }) return@doLast
        try {
            val url = URI("https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip").toURL()
            ZipInputStream(url.openStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val base = e.name.substringAfterLast('/')
                    val ext = base.substringAfterLast('.', "")
                    val target = want[base.substringBeforeLast('.')]
                    if (!e.isDirectory && target != null && (ext == "ttf" || ext == "otf")) {
                        val out = File(interDir, target)
                        if (out.length() == 0L) out.outputStream().use { zin.copyTo(it) }
                    }
                    e = zin.nextEntry
                }
            }
        } catch (ex: Exception) { logger.warn("Inter font download failed, using system font: " + ex.message) }
    }
}

val fetchPhosphorIcons by tasks.registering {
    outputs.dir(phosphorDir)
    doLast {
        val want = setOf("arrow-counter-clockwise", "arrows-clockwise", "battery-charging", "battery-full", "bell", "bell-ringing", "bluetooth", "plus", "bluetooth-slash", "broadcast", "bug", "caret-left", "caret-right", "check", "check-circle", "circle", "circle-half", "copy", "cpu", "crosshair", "devices", "dots-three", "download-simple", "ear", "equalizer", "eye", "fingerprint", "flag", "floppy-disk", "folder-open", "game-controller", "gear-six", "globe", "graduation-cap", "hand", "hand-tap", "headphones", "identification-badge", "info", "lightning", "link", "link-break", "magnifying-glass", "microphone", "microphone-stage", "moon-stars", "music-note", "number-circle-one", "number-circle-three", "number-circle-two", "palette", "pencil-simple", "phone", "phone-disconnect", "play", "prohibit", "share-network", "skip-back", "skip-forward", "sliders-horizontal", "sparkle", "speaker-hifi", "speaker-high", "speaker-low", "stop", "sun", "timer", "trash", "vibrate", "warning", "waveform", "waves", "x")
        phosphorDir.mkdirs()
        if (want.all { File(phosphorDir, "$it.svg").length() > 0L }) return@doLast
        try {
            val url = URI("https://github.com/phosphor-icons/core/archive/refs/heads/main.zip").toURL()
            ZipInputStream(url.openStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    if (!e.isDirectory && e.name.contains("/assets/regular/") && e.name.endsWith(".svg")) {
                        val slug = e.name.substringAfterLast('/').removeSuffix(".svg")
                        if (slug in want) File(phosphorDir, "$slug.svg").outputStream().use { zin.copyTo(it) }
                    }
                    e = zin.nextEntry
                }
            }
        } catch (ex: Exception) { logger.warn("Phosphor icon download failed, using Material icons: " + ex.message) }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchInterFonts, fetchPhosphorIcons) }
