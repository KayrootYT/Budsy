package com.nordbuds.studio

import com.nordbuds.studio.protocol.VendorAdvancedHandlers
import org.junit.Assert.*
import org.junit.Test

class MultiDeviceProtocolTest {
    @Test fun decodesMultiConnectPeerRecord() {
        // status=0, count=1, MAC, tailLength=3+nameLen, state, flags, nameLen, name
        val payload = byteArrayOf(
            0, 1,
            0x10, 0x20, 0x30, 0x40, 0x50, 0x60,
            0x06, // 3 fixed tail bytes + 3 UTF-8 name bytes
            0x02, // connection state
            0x0F, // current + main audio + audio active + deviceType=1
            0x03, 'P'.code.toByte(), 'h'.code.toByte(), '1'.code.toByte()
        )
        val peers = VendorAdvancedHandlers.MultiDevice.decodeResponse(payload)
        assertEquals(1, peers.size)
        val peer = peers.single()
        assertEquals("10:20:30:40:50:60", peer.address)
        assertEquals(2, peer.connectionState)
        assertTrue(peer.isCurrentDevice)
        assertTrue(peer.isMainAudioDevice)
        assertTrue(peer.isAudioActive)
        assertEquals(1, peer.deviceType)
        assertEquals("Ph1", peer.name)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTruncatedMultiConnectRecord() {
        VendorAdvancedHandlers.MultiDevice.decodeResponse(byteArrayOf(0, 1, 1, 2, 3))
    }
}
