package com.nordbuds.studio

import com.nordbuds.studio.protocol.VendorAdvancedHandlers
import org.junit.Assert.*
import org.junit.Test

class VendorAdvancedHandlersTest {
    @Test fun voiceAssistantControlTypeUsesHeyMelodyWireValues() {
        assertArrayEquals(byteArrayOf(1), VendorAdvancedHandlers.VoiceAssistant.encodeControlType(0))
        assertArrayEquals(byteArrayOf(2), VendorAdvancedHandlers.VoiceAssistant.encodeControlType(1))
        assertArrayEquals(byteArrayOf(4), VendorAdvancedHandlers.VoiceAssistant.encodeControlType(2))
        assertThrows(IllegalArgumentException::class.java) { VendorAdvancedHandlers.VoiceAssistant.encodeControlType(3) }
    }

    @Test fun voiceAssistantQueryResponseDecodesStatusAndFlagBits() {
        val config = VendorAdvancedHandlers.VoiceAssistant.decodeQueryResponse(byteArrayOf(0, 0x84.toByte()))
        assertEquals(0, config.status)
        assertEquals(2, config.controlType)
        assertEquals(1, config.earphoneConnectState)
        assertEquals(0x84, config.rawFlags)
        assertThrows(IllegalArgumentException::class.java) { VendorAdvancedHandlers.VoiceAssistant.decodeQueryResponse(byteArrayOf(1, 4)) }
    }

    @Test fun hearingDetectionRecordsAreThreeBytes() {
        val point = VendorAdvancedHandlers.HearingPoint(1, 2, -5)
        assertArrayEquals(byteArrayOf(1, 2, -5), point.encode())
        assertEquals(listOf(point), VendorAdvancedHandlers.Hearing.decodePoints(byteArrayOf(1, 2, -5)))
    }

    @Test fun hearingQueryUsesCountRecordsAndBigEndianUid() {
        val payload = VendorAdvancedHandlers.Hearing.encodeQuery(listOf(VendorAdvancedHandlers.HearingPoint(1, 2, 3)), 0x01020304)
        assertArrayEquals(byteArrayOf(1, 1, 2, 3, 1, 2, 3, 4), payload)
    }

    @Test fun hearingProcessPayloadHasActionCountRecordsUidAndUtf8Name() {
        val payload = VendorAdvancedHandlers.Hearing.encodeProcess(3, listOf(VendorAdvancedHandlers.HearingPoint(1, 2, -4)), 0x01020304, "A")
        assertArrayEquals(byteArrayOf(3, 1, 1, 2, -4, 1, 2, 3, 4, 65), payload)
        assertArrayEquals(byteArrayOf(3, 1, 1, 2, -4), VendorAdvancedHandlers.Hearing.encodeDetectionParameter(VendorAdvancedHandlers.HearingPoint(1, 2, -4)))
    }

    @Test fun otaSyncConfirmationReadsLittleEndianFields() {
        val data = byteArrayOf(0, 3, 0, 1, 0x78, 0x56, 0x34, 0x12, 0x00, 0x10, 0, 0, 0, 0)
        val decoded = VendorAdvancedHandlers.FirmwareOta.decodeSyncConfirmation(data)
        assertEquals(0, decoded.status)
        assertEquals(3, decoded.deviceType)
        assertEquals(0, decoded.resumePoint)
        assertEquals(0x12345678L, decoded.resumeOffset)
        assertEquals(0x1000, decoded.blockSize)
    }

    @Test fun otaSyncAndMtuRequestLayoutsAreExact() {
        assertArrayEquals(byteArrayOf(0x11, 0x22, 0x33, 0x44, 3), VendorAdvancedHandlers.FirmwareOta.encodeLegacySync(byteArrayOf(0x11, 0x22, 0x33, 0x44), 3))
        assertArrayEquals(byteArrayOf(0, 0, 0, 0, 3, 2), VendorAdvancedHandlers.FirmwareOta.encodeSectionSync(3, 2))
        assertArrayEquals(byteArrayOf(3), VendorAdvancedHandlers.FirmwareOta.encodeMtuRequest(3))
    }

    @Test fun otaStartMetadataLegacyAndExtendedSizesAreExact() {
        val legacy = VendorAdvancedHandlers.FirmwareOta.encodeStartMetadata(3, 1, 0x12345678)
        assertArrayEquals(byteArrayOf(3, 1, 0x78, 0x56, 0x34, 0x12), legacy)
        val extended = VendorAdvancedHandlers.FirmwareOta.encodeStartMetadata(
            3, 1, 100, 2, 200, 7, 8, ByteArray(32), ByteArray(3), ByteArray(24), ByteArray(32), ByteArray(32)
        )
        assertEquals(142, extended.size)
    }

    @Test fun otaStartDataAndMtuConfirmationsDecodeSourceLayout() {
        val start = VendorAdvancedHandlers.FirmwareOta.decodeStartConfirmation(byteArrayOf(0, 0, 0, 4, 3, 2, 1))
        assertEquals(0, start.status); assertEquals(0, start.resumePoint); assertEquals(0x01020304L, start.fileOffset)
        val data = VendorAdvancedHandlers.FirmwareOta.decodeDataConfirmation(byteArrayOf(0, 0x34, 0x12))
        assertEquals(0x1234, data.retryDelayMs)
        val mtu = VendorAdvancedHandlers.FirmwareOta.decodeMtuConfirmation(byteArrayOf(0, 3, 0x00, 0x10))
        assertEquals(3, mtu.deviceType); assertEquals(0x1000, mtu.mtu)
    }

    @Test fun otaBlockVerifyAndControlPayloadsMatchStateMachine() {
        val retry = VendorAdvancedHandlers.FirmwareOta.decodeBlockVerifyConfirmation(byteArrayOf(0x13, 4, 3, 2, 1))
        assertEquals(0x01020304L, retry.requestedResumeOffset)
        assertTrue(VendorAdvancedHandlers.FirmwareOta.decodeBlockVerifyConfirmation(byteArrayOf(0x11)).retryCurrentBlock)
        assertArrayEquals(byteArrayOf(0), VendorAdvancedHandlers.FirmwareOta.encodeTransferCompleteResponse())
        assertArrayEquals(byteArrayOf(2), VendorAdvancedHandlers.FirmwareOta.encodeSwitchRequest(2))
        assertArrayEquals(byteArrayOf(), VendorAdvancedHandlers.FirmwareOta.emptyControlPayload())
    }

    @Test fun otaDataAndBlockVerifyUseLittleEndianOffsetAndCrc() {
        assertArrayEquals(byteArrayOf(4, 3, 2, 1, 0x55), VendorAdvancedHandlers.FirmwareOta.encodeDataChunk(0x01020304, byteArrayOf(0x55)))
        assertArrayEquals(byteArrayOf(4, 3, 2, 1, 8, 7, 6, 5), VendorAdvancedHandlers.FirmwareOta.encodeBlockVerification(0x01020304, 0x05060708))
    }
}
