package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Test

class ProtocolAutoTesterTest {
    private fun base(events: List<ProtocolLab.Event>) = ProtocolAutoTester.evaluate(
        events = events, since = 100L, connected = true, deviceName = "Nord Buds 3",
        deviceAddress = "00:11:22:33:44:55", ancMode = 1,
        eqPreset = 3, gameMode = false, bassLevel = 0, firmware = "1.0.0",
        peerCount = 0, gattState = "Not checked"
    )

    @Test fun noCapturedTrafficNeverClaimsFeaturePass() {
        val results = base(emptyList())
        assertEquals(ProtocolAutoTester.Status.PASS, results.first().status) // connection is live
        assertEquals(ProtocolAutoTester.Status.UNVERIFIED, results.first { it.feature == "Battery read-back" }.status)
        assertEquals(ProtocolAutoTester.Status.UNVERIFIED, results.first { it.feature == "ANC state read-back" }.status)
    }

    @Test fun matchedBatteryReplyIsPass() {
        val event = ProtocolLab.Event(101L, "RX", 0x0106, 0x81, listOf(0, 1, 1, 80), 1,
            "Battery response", "Left=80%", "Observed", 12L, true)
        val results = base(listOf(event))
        assertEquals(ProtocolAutoTester.Status.PASS, results.first { it.feature == "Battery read-back" }.status)
    }

    @Test fun transmittedQueryWithoutMatchedReplyIsFail() {
        val event = ProtocolLab.Event(101L, "TX", 0x0106, 0x01, emptyList(), 1)
        val results = base(listOf(event))
        assertEquals(ProtocolAutoTester.Status.FAIL, results.first { it.feature == "Battery read-back" }.status)
    }
}
