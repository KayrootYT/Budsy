package com.nordbuds.studio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The four built-in worlds are pure data: id, palette and appearance fallbacks must stay consistent. */
class WorldThemesTest {
    @Test fun fourWorldsAreRegistered() {
        assertEquals(4, World.all.size)
        val ids = World.all.map { WorldThemes.idOf(it) }
        assertEquals("world ids must be unique", ids.size, ids.toSet().size)

        World.all.forEach { w ->
            val spec = WorldThemes.spec(w)
            assertNotNull("world $w must have a spec", spec)
            assertEquals("spec.world must match its registry key", w, spec!!.world)
            assertTrue(spec.hasWorld)
            assertFalse("light palette missing for $w", spec.light.isEmpty)
            assertFalse("dark palette missing for $w", spec.dark.isEmpty)
            assertFalse("amoled palette missing for $w", spec.amoled.isEmpty)
            assertEquals(w, WorldThemes.worldOf(WorldThemes.idOf(w)))
            assertEquals(spec.name, WorldThemes.byId(WorldThemes.idOf(w))?.name)
        }

        assertNull("Stock has no spec", WorldThemes.spec(World.NONE))
        assertEquals(World.NONE, WorldThemes.worldOf(null))
        assertEquals(World.NONE, WorldThemes.worldOf("world_does_not_exist"))
        assertNull(WorldThemes.byId("world_does_not_exist"))
    }

    @Test fun appearanceColorsResolveWithoutLosingOwnValues() {
        World.all.forEach { w ->
            val s = WorldThemes.spec(w)!!
            assertEquals(s.light.bg, s.colorsFor(AppearanceMode.LIGHT).bg)
            assertEquals(s.dark.bg, s.colorsFor(AppearanceMode.DARK).bg)
            assertEquals(s.amoled.bg, s.colorsFor(AppearanceMode.AMOLED).bg)
        }
    }

    @Test fun worldsLookDifferent() {
        val names = World.all.map { WorldThemes.spec(it)!!.name }
        assertEquals("world names must be unique", names.size, names.toSet().size)
        val accents = World.all.map { WorldThemes.spec(it)!!.dark.accent }
        assertEquals("each world needs its own accent", accents.size, accents.toSet().size)
        val ids = World.all.map { WorldThemes.idOf(it)!! }
        assertEquals(listOf("world_forest", "world_snow", "world_registaan", "world_samundar"), ids)
    }
}
