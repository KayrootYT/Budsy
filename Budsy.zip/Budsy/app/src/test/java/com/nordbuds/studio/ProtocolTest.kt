package com.nordbuds.studio

import com.nordbuds.studio.protocol.Protocol
import org.junit.Assert.*
import org.junit.Test

class ProtocolTest {
    @Test fun featureIdsPerFrame_fitsAttPayload() {
        assertEquals(10, Protocol.maxFeatureIdsPerFrame(20))   // MTU 23
        assertEquals(15, Protocol.maxFeatureIdsPerFrame(244))  // MTU 247
        for (limit in listOf(20, 30, 100)) {
            val n = Protocol.maxFeatureIdsPerFrame(limit)
            assertTrue(Protocol.buildFrame(0x0d, 1, 0x20, IntArray(n + 1)).size <= limit)
        }
    }
    @Test fun formatFirmware_groupsTriples() {
        assertEquals("L 111/110/110  ·  R 111/110/110  ·  Case 111/100/100",
            Protocol.formatFirmware("1,1,111,1,2,110,1,3,110,2,1,111,2,2,110,2,3,110,3,1,111,3,2,100,3,3,100"))
        assertEquals("V1.2", Protocol.formatFirmware("V1.2"))
        assertNull(Protocol.formatFirmware(null))
    }
    @Test fun buildFrame_matchesLayout() {
        val f = Protocol.buildFrame(0x06, 1, 0x20, intArrayOf())
        assertArrayEquals(byteArrayOf(0xAA.toByte(), 7, 0, 0, 6, 1, 0x20, 0, 0), f)
    }
    @Test fun parser_handlesSplitAndGarbage() {
        val frame = byteArrayOf(0xAA.toByte(), 13, 0, 0, 6, 0x81.toByte(), 0x20, 6, 0, 0, 2, 1, 80, 2, (65 or 0x80).toByte())
        val p = Protocol.Parser()
        assertTrue(p.feed(byteArrayOf(0, 0)).isEmpty())
        assertTrue(p.feed(frame.copyOfRange(0, 4)).isEmpty())
        val out = p.feed(frame.copyOfRange(4, frame.size))
        assertEquals(1, out.size); assertEquals(0x0106, out[0].cmd); assertFalse(out[0].isPush); assertEquals(0, out[0].status); assertEquals(80, out[0].payload[3])
    }
    @Test fun parseBattery_decodesFlags() {
        val bats = Protocol.parseBattery(intArrayOf(0, 2, 1, 80, 2, 65 or 0x80))
        assertEquals(listOf(Protocol.Battery(0, 80, false), Protocol.Battery(1, 65, true)), bats)
    }
    @Test fun parseGestureTable_skipsDisabledEntries() {
        val t = Protocol.parseGestureTable(intArrayOf(0, 2, 2, 1, 3, 6, 1, 0, 1, 1))
        assertEquals(6, t[2 * 16 + 3]); assertNull(t[1 * 16 + 1])
    }
    @Test fun parseGestureTable_readsLongHoldFromNonMainSlot() {
        // right-bud long-hold (gesture 6) stored under button 2 must be visible for read-back; the on-call group (button 6) still must not
        val t = Protocol.parseGestureTable(intArrayOf(0, 2, 2, 2, 6, 0x0B, 2, 6, 6, 0))
        assertEquals(0x0B, t[2 * 16 + 6])
    }
    @Test fun buildGestureSet_layout() {
        assertArrayEquals(intArrayOf(1, 2, 1, 3, 0x11), Protocol.buildGestureSet(2, 3, 0x11))
        val f = Protocol.buildFrame(0x01, Protocol.GRP_SET, 0x22, Protocol.buildGestureSet(1, 2, 5))
        assertArrayEquals(byteArrayOf(0xAA.toByte(), 12, 0, 0, 1, 4, 0x22, 5, 0, 1, 1, 1, 2, 5), f)
    }
    @Test fun parsePeers_readsMacAndName() {
        val peers = Protocol.parsePeers(intArrayOf(0, 1, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0, 2, 1, 4, 'T'.code, 'V'.code, 'P'.code, 'C'.code))
        assertEquals("AA:BB:CC:DD:EE:FF", peers[0].mac); assertEquals("TVPC", peers[0].name)
    }
    /** A 0x0122 list reply built from a 0x0418 payload: the action byte becomes the "selected" flag. */
    private fun asListReply(payload: IntArray) = intArrayOf(0, 1, 1) + payload.copyOfRange(1, payload.size)
    @Test fun customEq_roundTrips() {
        val payload = Protocol.buildCustomEqPayload(Protocol.EQ_SAVE_SELECT, Protocol.CustomEqProfile("Joe", true, listOf(100 to 3, 1000 to -5), id = 2, min = -10, max = 10))
        assertEquals(Protocol.EQ_SAVE_SELECT, payload[0])
        val profs = Protocol.parseCustomEq(asListReply(payload))
        assertEquals(1, profs.size); assertEquals("Joe", profs[0].name); assertTrue(profs[0].active); assertEquals(listOf(100 to 3, 1000 to -5), profs[0].bands)
        assertEquals(2, profs[0].id); assertEquals(-10, profs[0].min); assertEquals(10, profs[0].max)
    }
    @Test fun legacyCustomEqAlias_matches0418PayloadLayout() {
        val payload = Protocol.buildCustomEqSetPayload(
            p3 = 2, min = -6, max = 6, eqId = 7, name = "EQ",
            bands = listOf(100 to 3, 1000 to -5)
        )
        assertArrayEquals(
            intArrayOf(2, 250, 6, 7, 2, 'E'.code, 'Q'.code, 2,
                100, 0, 3, 0xE8, 3, 0xFB),
            payload
        )
    }


    @Test fun heymelody0418_matchesHeadsetCoreServiceM0PayloadLayout() {
        // APK source: byte[0]=action, [1..3]=min/max/id, [4]=UTF-8 name bytes,
        // then band count and (frequency LE16, gain byte) triplets.
        val payload = Protocol.buildCustomEqSetPayload(
            p3 = 2, min = -10, max = 10, eqId = 3, name = "EQ",
            bands = listOf(100 to 3, 1000 to -5)
        )
        assertArrayEquals(
            intArrayOf(2, 246, 10, 3, 2, 'E'.code, 'Q'.code, 2,
                100, 0, 3, 0xE8, 3, 0xFB),
            payload
        )
        val frame = Protocol.buildFrame(0x18, Protocol.GRP_SET, 0x22, payload)
        assertEquals(0x18.toByte(), frame[4])
        assertEquals(Protocol.GRP_SET.toByte(), frame[5])
    }

    @Test fun customEqPayload_validatesWireFieldWidths() {
        assertThrows(IllegalArgumentException::class.java) {
            Protocol.buildCustomEqSetPayload(1, -6, 6, 0, "Custom", listOf(70000 to 0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            Protocol.buildCustomEqSetPayload(1, -6, 6, 0, "Custom", listOf(100 to 128))
        }
    }

    @Test fun customEqProfileName_roundTripsUtf8() {
        val payload = Protocol.buildCustomEqPayload(
            Protocol.EQ_SAVE_SELECT, Protocol.CustomEqProfile("ÉQ", true, listOf(1000 to 2))
        )
        val decoded = Protocol.parseCustomEq(asListReply(payload))
        assertEquals("ÉQ", decoded.single().name)
    }

    @Test fun customEqSetPayload_rejectsOutOfRangeFrequency() {
        assertThrows(IllegalArgumentException::class.java) {
            Protocol.buildCustomEqSetPayload(0, -6, 6, 1, "Custom", listOf(70000 to 0))
        }
    }

    @Test fun decodeAnc_mapsMasks() {
        assertEquals(Protocol.ANC_TRANSP, Protocol.decodeAnc(0x0200)); assertEquals(Protocol.ANC_OFF, Protocol.decodeAnc(0x08)); assertEquals(Protocol.ANC_ON, Protocol.decodeAnc(0x08F2)); assertEquals(-1, Protocol.decodeAnc(0))
    }
    @Test fun hex_padsToTwo() { assertEquals("00", Protocol.hex(0)); assertEquals("ff", Protocol.hex(255)); assertEquals("0a", Protocol.hex(10)) }

    // ---- fixes verified against the OPOv1 captures (see PROTOCOL.md)
    @Test fun frame_lengthIsLeb128_roundTripsLongPayload() {
        val payload = IntArray(130) { it and 0x7f }
        val f = Protocol.buildFrame(0x0122 and 0xff, 0x81, 7, payload)
        // total = 137 -> LEB128 89 01, then 00 00 pad
        assertEquals(0x89.toByte(), f[1]); assertEquals(0x01.toByte(), f[2]); assertEquals(0.toByte(), f[3]); assertEquals(0.toByte(), f[4])
        val out = Protocol.Parser().feed(f)
        assertEquals(1, out.size); assertEquals(130, out[0].payload.size); assertEquals(0x0122, out[0].cmd); assertEquals(7, out[0].seq)
        assertArrayEquals(payload, out[0].payload)
    }
    @Test fun parser_splitLongFrameAcrossReads() {
        val payload = IntArray(200) { 0x55 }
        val f = Protocol.buildFrame(0x08, 0x81, 3, payload)
        val p = Protocol.Parser()
        assertTrue(p.feed(f.copyOfRange(0, 2)).isEmpty())
        assertTrue(p.feed(f.copyOfRange(2, 100)).isEmpty())
        assertEquals(1, p.feed(f.copyOfRange(100, f.size)).size)
    }
    @Test fun parser_twoFramesInOneRead() {
        val a = Protocol.buildFrame(6, 0x81, 1, intArrayOf(0, 1, 1, 90)); val b = Protocol.buildFrame(9, 0x81, 2, intArrayOf(0, 0))
        val out = Protocol.Parser().feed(a + b)
        assertEquals(listOf(0x0106, 0x0109), out.map { it.cmd })
    }
    @Test fun gestureTable_onCallEntriesDoNotOverwriteMainGestures() {
        // left main: double=0x11 ; left on-call double=0 ; right main long-hold=0x0B ; right on-call long-hold=0
        val t = Protocol.parseGestureTable(intArrayOf(0, 4, 1, 1, 2, 0x11, 1, 6, 2, 0, 2, 1, 6, 0x0B, 2, 6, 6, 0))
        assertEquals(0x11, t[1 * 16 + 2]); assertEquals(0x0B, t[2 * 16 + 6])
        assertEquals(2, t.size)
    }
    @Test fun gestureWrite_coversEveryMainSlotAndSkipsOnCall() {
        val table = Protocol.parseGestureEntries(intArrayOf(0, 3, 1, 1, 2, 0x11, 1, 6, 2, 0, 2, 1, 2, 0))
        assertArrayEquals(intArrayOf(1, 1, 1, 2, 0x05), Protocol.buildGestureWrite(table, 1, 2, 0x05))
        assertArrayEquals(intArrayOf(1, 1, 1, 3, 0x06), Protocol.buildGestureWrite(table, 1, 3, 0x06))   // slot not listed -> button 1
    }
    @Test fun battery_caseZeroIsUnknown_budZeroIsReal() {
        val b = Protocol.parseBattery(intArrayOf(0, 3, 1, 0, 2, 50, 3, 0))
        assertEquals(0, b[0].percent); assertEquals(50, b[1].percent); assertEquals(-1, b[2].percent)
    }
    @Test fun seq_staysInOneToFE() {
        assertEquals(1, Protocol.nextSeq(0xFE)); assertEquals(2, Protocol.nextSeq(1)); assertEquals(0xFE, Protocol.nextSeq(0xFD)); assertEquals(1, Protocol.nextSeq(0))
    }
    @Test fun requestFromBuds_timeIsAnswered() {
        val req = Protocol.Parser().feed(Protocol.buildFrame(0x00, 0x05, 9, intArrayOf(0, 0, 0, 0, 0))).single()
        assertEquals(0x0500, req.cmd); assertTrue(req.isRequestFromBuds); assertFalse(req.isPush); assertFalse(req.isReply)
        assertArrayEquals(intArrayOf(0, 0xB5, 0x50, 0xA0, 0x69), Protocol.replyToRequest(req, 0x69A050B5L))
    }
    @Test fun push_isNotARequest_andF2IsAcked() {
        val push = Protocol.Frame(0x04, 0x02, 0xFF, intArrayOf(0xF2, 0))
        assertTrue(push.isPush); assertFalse(push.isRequestFromBuds)
        assertArrayEquals(intArrayOf(0, 0xF2), Protocol.ackForPush(push))
        assertNull(Protocol.ackForPush(Protocol.Frame(0x04, 0x02, 0xFF, intArrayOf(1, 1, 1, 80))))
    }
    @Test fun replies_areNeverRequests() {
        assertFalse(Protocol.Frame(0x06, 0x81, 1, intArrayOf(0)).isRequestFromBuds)
        assertTrue(Protocol.Frame(0x06, 0x81, 1, intArrayOf(0)).isReply)
    }
    @Test fun subscribe_onlyOfferedEvents() {
        assertArrayEquals(intArrayOf(2, 1, 2), Protocol.buildSubscribe(Protocol.parseOfferedEvents(intArrayOf(0, 2, 2, 1))))
        assertArrayEquals(intArrayOf(4, 1, 2, 3, 5), Protocol.buildSubscribe(setOf(1, 2, 3, 4, 5, 0xF1)))
        assertArrayEquals(intArrayOf(0), Protocol.buildSubscribe(emptyList()))
    }
    @Test fun customEqWrite_usesCommand0418Layout() {
        // action, -6, 6, id, name length, name, band count, bands (freq LE16 + signed gain)
        val p = Protocol.buildCustomEqPayload(Protocol.EQ_CREATE, Protocol.CustomEqProfile("A", true, listOf(250 to -2), id = 0))
        assertArrayEquals(intArrayOf(1, 0xFA, 6, 0, 1, 'A'.code, 1, 250, 0, 0xFE), p)
    }
    @Test fun anc_pushSubtypesAreNotModes() {
        // push 03 02 01 <mask> is the hold-cycle mask: the ANC decoder must not be fed it (guarded in Buds); decodeAnc itself stays pure
        assertEquals(Protocol.ANC_OFF, Protocol.decodeAnc(0x0008)); assertEquals(Protocol.ANC_ON, Protocol.decodeAnc(0x0002)); assertEquals(Protocol.ANC_TRANSP, Protocol.decodeAnc(0x0100))
    }
    @Test fun featureRequest_asksForWearDetectNotGoldenSoundOnly() {
        assertEquals(Protocol.FEATURE_REQUEST[0], Protocol.FEATURE_REQUEST.size - 1)
        assertTrue(Protocol.FLAG_WEAR_DETECT in Protocol.FEATURE_REQUEST.drop(1))
    }

    // Frames copied from the published OPOv1 captures: our encoder must reproduce them byte for byte.
    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
    @Test fun capture_handshakeFrame() { assertArrayEquals(bytes(0xAA, 7, 0, 0, 0x00, 0x01, 0x01, 0, 0), Protocol.buildFrame(0x00, 0x01, 1, intArrayOf())) }
    @Test fun capture_setAncOffFrame() { assertArrayEquals(bytes(0xAA, 0x0A, 0, 0, 0x04, 0x04, 0x06, 3, 0, 1, 1, 1), Protocol.buildFrame(0x04, Protocol.GRP_SET, 6, intArrayOf(1, 1, 1))) }
    @Test fun capture_batteryPushParses() {
        val push = Protocol.Parser().feed(bytes(0xAA, 0x0F, 0, 0, 0x04, 0x02, 0xFF, 8, 0, 1, 3, 1, 0x64, 2, 0x64, 3, 0x50)).single()
        assertTrue(push.isPush); assertEquals(0xFF, push.seq)
        assertEquals(listOf(Protocol.Battery(0, 100, false), Protocol.Battery(1, 100, false), Protocol.Battery(2, 80, false)), Protocol.parseBattery(push.payload))
    }
    @Test fun capture_wearPushOpenLidParses() {
        val w = Protocol.parseWear(intArrayOf(2, 3, 1, 4, 2, 4, 3, 4))
        assertEquals(listOf(Protocol.Wear(0, 4), Protocol.Wear(1, 4), Protocol.Wear(2, 4)), w)
    }
    @Test fun gestureWrite_forBothSidesKeepsEachSideSeparate() {
        val table = Protocol.parseGestureEntries(intArrayOf(0, 4, 1, 1, 2, 0x11, 1, 6, 2, 0, 2, 1, 2, 0, 2, 6, 2, 0))
        assertArrayEquals(intArrayOf(1, 2, 1, 2, 0x05), Protocol.buildGestureWrite(table, 2, 2, 0x05))
    }
    @Test fun informationalPushes_areNotAnswered() {
        for (c in intArrayOf(0x0501, 0x0502, 0x0504, 0x0510)) assertNull(Protocol.replyToRequest(Protocol.Frame(c and 0xff, c shr 8, 1, intArrayOf(3)), 0L))
        assertArrayEquals(intArrayOf(1), Protocol.replyToRequest(Protocol.Frame(0x20, 0x05, 1, intArrayOf()), 0L))   // unknown request -> 01
        assertArrayEquals(intArrayOf(0, 1, 0), Protocol.replyToRequest(Protocol.Frame(0x0C, 0x05, 1, intArrayOf()), 0L))
    }
    @Test fun nordBudsFeatureDiscoveryIgnoresZeroPadding() {
        val reply = intArrayOf(0, 7, 0x06, 0, 0x0B, 1, 0x11, 1, 0x1B, 1, 0x1D, 1, 0, 0, 0, 0)
        assertEquals(listOf(0x06 to 0, 0x0B to 1, 0x11 to 1, 0x1B to 1, 0x1D to 1), Protocol.parseFlags(reply))
    }

}
