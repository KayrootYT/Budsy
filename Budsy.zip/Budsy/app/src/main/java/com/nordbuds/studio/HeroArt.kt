package com.nordbuds.studio

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.snapshots.Snapshot
import kotlinx.coroutines.delay
import androidx.compose.runtime.DisposableEffect
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun accentFor(theme: Int) = when (theme) {
    ThemeMode.NOTHING -> Color(0xFFFF5148)
    ThemeMode.AURORA -> Color(0xFF20BFFF)
    ThemeMode.CRYSTAL -> Color(0xFF1688EF)
    ThemeMode.TITANIUM -> Color(0xFFE8C58A)
    else -> Color(0xFF62B7FF)
}

// Geometry of the 960x960 hero canvas, in canvas units (every layer shares this space).
private const val CANVAS = 960f
private const val BUD_SCALE = 0.60f
private const val BUD_BOX_W = 340f   // bud PNGs are ~320-332 px wide, 540 px tall
private const val BUD_BOX_H = 540f
// Cradle centres of the real case photo, hover spots above the case, and the case's front lip (clips a resting bud).
private const val START_LX = 332f; private const val START_RX = 629f; private const val REST_HEAD_Y = 440f
private const val HOVER_HEAD_Y = 95f; private const val PAIR_HEAD_Y = 420f
private const val SPRITE_HEAD_OFFSET = 95f   // standing-sprite head centre is ~95px (at scale 1) above its box centre
private const val REST_SC_PHOTO = 1f
private const val HOVER_LX = 345f; private const val HOVER_RX = 615f; private const val HOVER_Y = 150f
private const val REST_SC = 0.66f; private const val LIP_Y = 516f
private const val PAIR_LX = 335f; private const val PAIR_RX = 625f; private const val PAIR_Y = 470f
// Closed-case photo: lid dome spans DOME_TOP..SEAM_Y, the body is below the seam.
private const val DOME_TOP = 228f; private const val SEAM_Y = 413f

private fun smooth(x: Float, a: Float, b: Float): Float {
    val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3f - 2f * t)
}

/**
 * Hero artwork built only from the real product photos.
 *  - Disconnected: closed case. Connected: the lid flips up (dome foreshortens around its back hinge while the
 *    open-case photo fades in underneath) with a small spring overshoot.
 *  - One photo per bud state (both in / left out / right out) sit on top of the empty open case, so the bud that
 *    stays is the real photographed bud. The bud that leaves is a separate layer: it lifts out of its cradle on a
 *    spring (soft overshoot), tilts with its velocity, then floats and sways above the case; the case sinks a bit
 *    to give it room and a contact shadow shrinks as it rises.
 *  - Both out: the case fades and shrinks away, the buds drift to the centre under a soft glow and a OnePlus wordmark.
 *  - Putting a bud back reverses everything: the bud drops in first, the photo swaps once it has landed, and the lid
 *    only closes after the buds are inside.
 * Which state to show is decided by [HeroResolver]; this composable never inspects Bluetooth data.
 */
@Composable
fun DeviceHeroArt(theme: Int, hero: HeroState, modifier: Modifier = Modifier, dashed: Boolean = false, appearance: Int = AppearanceMode.DARK, connecting: Boolean = false) {
    val dark = appearance == AppearanceMode.DARK || appearance == AppearanceMode.AMOLED ||
        (appearance == AppearanceMode.SYSTEM && androidx.compose.foundation.isSystemInDarkTheme())
    // Dark/AMOLED UI => white product; light UI => black product.
    val isBlack = !dark
    val leftOut = hero == HeroState.LEFT_OUT || hero == HeroState.BOTH_OUT
    val rightOut = hero == HeroState.RIGHT_OUT || hero == HeroState.BOTH_OUT
    val bothOut = hero == HeroState.BOTH_OUT
    val closed = hero == HeroState.CASE_CLOSED

    val reduce = LocalReduceMotion.current
    val scope = rememberCoroutineScope()
    val dragX = remember { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val intro = remember { Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(Unit) { if (!reduce) intro.animateTo(1f, tween(850, easing = FastOutSlowInEasing)) }
    val dragBack = {
        scope.launch { dragX.animateTo(0f, spring(0.55f, 140f)) }
        scope.launch { dragY.animateTo(0f, spring(0.55f, 140f)) }
        Unit
    }
    // ---- Physics-ish drivers -------------------------------------------------------------------------------------
    val lid = remember { Animatable(if (closed) 0f else 1f) }
    val pL = remember { Animatable(if (leftOut) 1f else 0f) }
    val pR = remember { Animatable(if (rightOut) 1f else 0f) }
    val outSpec = spring<Float>(dampingRatio = 0.60f, stiffness = 55f)   // pops out of the magnet, overshoots, settles
    val inSpec = spring<Float>(dampingRatio = 0.90f, stiffness = 90f)    // drops back in, no bounce
    LaunchedEffect(closed) {
        if (closed) {
            if (pL.value > 0.02f || pR.value > 0.02f) delay(700)           // buds must be inside before the lid shuts
            lid.animateTo(0f, tween(580, easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)))
        } else lid.animateTo(1f, spring(dampingRatio = 0.68f, stiffness = 100f))
    }
    LaunchedEffect(leftOut) {
        if (leftOut) { if (lid.value < 0.85f) delay(320); pL.animateTo(1f, outSpec) } else pL.animateTo(0f, inSpec)
    }
    LaunchedEffect(rightOut) {
        if (rightOut) { if (lid.value < 0.85f) delay(320); pR.animateTo(1f, outSpec) } else pR.animateTo(0f, inSpec)
    }
    val q = animateFloatAsState(if (bothOut) 1f else 0f, tween(900, easing = FastOutSlowInEasing), label = "bothOut")
    val single = animateFloatAsState(if ((leftOut || rightOut) && !bothOut) 1f else 0f, tween(700, easing = FastOutSlowInEasing), label = "singleOut")

    // A photo that contains a bud may only fade in after that bud has landed in its cradle.
    val landing = Snapshot.withoutReadObservation { pL.value > 0.05f || pR.value > 0.05f }
    val inDelay = if (landing) 520 else 0
    fun overlay(on: Boolean) = if (on) tween<Float>(240, delayMillis = inDelay) else tween<Float>(160)
    val bothIn = hero == HeroState.BOTH_IN || hero == HeroState.UNVERIFIED
    val aBoth = animateFloatAsState(if (bothIn) 1f else 0f, overlay(bothIn), label = "photoBoth")
    val aLout = animateFloatAsState(if (hero == HeroState.LEFT_OUT) 1f else 0f, overlay(hero == HeroState.LEFT_OUT), label = "photoLeftOut")
    val aRout = animateFloatAsState(if (hero == HeroState.RIGHT_OUT) 1f else 0f, overlay(hero == HeroState.RIGHT_OUT), label = "photoRightOut")

    // The real-photo cutout stays on screen until the photo with that bud has faded back in (no blink when a bud returns).
    fun hold(out: Boolean) = if (out) tween<Float>(1) else tween<Float>(140, delayMillis = 640)
    val cutHoldL = animateFloatAsState(if (leftOut) 1f else 0f, hold(leftOut), label = "cutHoldL")
    val cutHoldR = animateFloatAsState(if (rightOut) 1f else 0f, hold(rightOut), label = "cutHoldR")
    val tilt = rememberTilt()
    val inf = rememberInfiniteTransition(label = "heroFloat")
    val amp = if (reduce) 0f else 9f
    val floatA = inf.animateFloat(-amp, amp, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatA")
    val floatB = inf.animateFloat(amp, -amp, infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "floatB")
    // How far the case group sinks so the lifted buds have room above it (canvas units).
    val shiftU = { 115f * single.value + 120f * q.value }

    val closedRes = if (isBlack) R.drawable.hero_case_closed_black else R.drawable.hero_case_closed_white
    val emptyRes = if (isBlack) R.drawable.hero_case_empty_black else R.drawable.hero_case_empty_white
    val bothRes = if (isBlack) R.drawable.hero_case_both_black else R.drawable.hero_case_both_white
    val loutRes = if (isBlack) R.drawable.hero_case_lout_black else R.drawable.hero_case_lout_white
    val routRes = if (isBlack) R.drawable.hero_case_rout_black else R.drawable.hero_case_rout_white
    val cutLRes = if (isBlack) R.drawable.hero_cut_l_black else R.drawable.hero_cut_l_white
    val cutRRes = if (isBlack) R.drawable.hero_cut_r_black else R.drawable.hero_cut_r_white
    val budLRes = if (isBlack) R.drawable.hero_bud_left_black else R.drawable.hero_bud_left_white
    val budRRes = if (isBlack) R.drawable.hero_bud_right_black else R.drawable.hero_bud_right_white
    val desc = when (hero) {
        HeroState.CASE_CLOSED -> "OnePlus Nord Buds 3 closed charging case"
        HeroState.BOTH_IN -> "OnePlus Nord Buds 3 open charging case with both earbuds inside"
        HeroState.LEFT_OUT -> "OnePlus Nord Buds 3 left earbud outside the case"
        HeroState.RIGHT_OUT -> "OnePlus Nord Buds 3 right earbud outside the case"
        HeroState.BOTH_OUT -> "OnePlus Nord Buds 3 left and right earbuds outside the case"
        HeroState.UNVERIFIED -> "OnePlus Nord Buds 3 charging case; position not verified"
    }
    val density = LocalDensity.current

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight)
        val k = with(density) { side.toPx() } / CANVAS
        Box(
            Modifier.requiredSize(side)
                .graphicsLayer {
                    translationX = dragX.value * 0.55f
                    translationY = dragY.value * 0.55f + (1f - intro.value) * 36f
                    val s = 0.9f + 0.1f * intro.value; scaleX = s; scaleY = s
                    alpha = intro.value.coerceIn(0f, 1f)
                }
                .pointerInput(Unit) {
                    detectDragGestures(onDragEnd = { dragBack() }, onDragCancel = { dragBack() }) { change, amt ->
                        change.consume()
                        scope.launch { dragX.snapTo((dragX.value + amt.x).coerceIn(-260f, 260f)) }
                        scope.launch { dragY.snapTo((dragY.value + amt.y).coerceIn(-260f, 260f)) }
                    }
                }
                .semantics { contentDescription = desc }
        ) {
            // Accent halo behind the buds once the case is gone.
            Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = q.value }) {
                val accent = accentFor(theme)
                drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .16f), Color.Transparent), center = center, radius = size.minDimension * .46f),
                    radius = size.minDimension * .46f, center = center)
            }
            // Estimated state outline (diagnostics only)
            if (dashed) Canvas(Modifier.fillMaxSize()) {
                drawRoundRect(
                    accentFor(theme).copy(alpha = 0.35f), Offset(size.width * 0.06f, size.height * 0.06f), Size(size.width * 0.88f, size.height * 0.88f),
                    CornerRadius(48.dp.toPx()), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 12f)))
                )
            }
            // Connecting: a light sweep orbits the case while the control channel is being opened.
            if (connecting && !reduce) {
                val ct = rememberInfiniteTransition(label = "heroConnecting")
                val ang by ct.animateFloat(0f, 360f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "heroConnectingAngle")
                Canvas(Modifier.fillMaxSize()) {
                    val acc = accentFor(theme)
                    val r = size.minDimension * 0.42f
                    rotate(ang) {
                        drawArc(
                            Brush.sweepGradient(listOf(Color.Transparent, acc.copy(alpha = 0.9f)), center = center),
                            startAngle = 0f, sweepAngle = 300f, useCenter = false,
                            topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2f, r * 2f),
                            style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }
            // ---- Case group ----
            Box(Modifier.fillMaxSize().graphicsLayer {
                val qv = q.value
                translationY = shiftU() * k + floatA.value * k * (1f - qv)
                scaleX = 1f - 0.16f * qv; scaleY = scaleX
                alpha = (1f - qv * 1.15f).coerceIn(0f, 1f)
                cameraDistance = 16f * density.density
                rotationY = tilt.value.x * 7f; rotationX = -tilt.value.y * 7f
                translationX = tilt.value.x * -6f * k
            }) {
                // Open case (empty) is the base for every open state; it fades in as the lid lifts.
                Image(painterResource(emptyRes), null, Modifier.fillMaxSize().graphicsLayer {
                    val e = lid.value
                    alpha = smooth(e, 0.30f, 0.80f)
                    val sc = 0.955f + 0.045f * e; scaleX = sc; scaleY = sc
                }, contentScale = ContentScale.Fit)
                // Real photos with the bud(s) that are in the case.
                for ((res, a) in listOf(bothRes to aBoth, loutRes to aLout, routRes to aRout)) {
                    Image(painterResource(res), null, Modifier.fillMaxSize().graphicsLayer {
                        val e = lid.value
                        alpha = a.value * smooth(e, 0.30f, 0.80f)
                        val sc = 0.955f + 0.045f * e; scaleX = sc; scaleY = sc
                    }, contentScale = ContentScale.Fit)
                }
                // Closed body (below the seam) fades out as the case opens.
                Image(painterResource(closedRes), null, Modifier.fillMaxSize().graphicsLayer {
                    alpha = 1f - smooth(lid.value, 0.05f, 0.55f)
                }.drawWithContent {
                    clipRect(0f, SEAM_Y * k, size.width, size.height) { this@drawWithContent.drawContent() }
                }, contentScale = ContentScale.Fit)
                // Lid dome: pivots on its back (top) edge, so the seam swings up and the dome foreshortens.
                Image(painterResource(closedRes), null, Modifier.fillMaxSize().graphicsLayer {
                    val e = smooth(lid.value, 0f, 0.8f)
                    transformOrigin = TransformOrigin(0.5f, DOME_TOP / CANVAS)
                    scaleY = 1f - 0.80f * e
                    scaleX = 1f - 0.03f * e
                    translationY = -34f * k * e
                    alpha = 1f - smooth(lid.value, 0.35f, 0.85f)
                }.drawWithContent {
                    clipRect(0f, 0f, size.width, SEAM_Y * k) { this@drawWithContent.drawContent() }
                }, contentScale = ContentScale.Fit)
            }
            // ---- Soft contact shadows of the lifted buds on the case ----
            Canvas(Modifier.fillMaxSize()) {
                fun shadow(cx: Float, p: Float) {
                    val a = (p.coerceIn(0f, 1f) * (1f - q.value)) * 0.30f
                    if (a <= 0.01f) return
                    val sy = (LIP_Y + 4f + shiftU()) * k
                    val w = (74f - 20f * p.coerceIn(0f, 1.2f)) * k
                    drawOval(
                        Brush.radialGradient(listOf(Color.Black.copy(alpha = a), Color.Transparent), center = Offset(cx * k, sy), radius = w),
                        topLeft = Offset(cx * k - w, sy - w * 0.28f), size = Size(w * 2f, w * 0.56f)
                    )
                }
                shadow(START_LX, pL.value); shadow(START_RX, pR.value)
            }
            // ---- Flying earbuds ----
            FlyingBud(budLRes, cutLRes, pL, cutHoldL, q, lid, shiftU, START_LX, HOVER_LX, PAIR_LX, -1f, floatA, floatB, tilt, k)
            FlyingBud(budRRes, cutRRes, pR, cutHoldR, q, lid, shiftU, START_RX, HOVER_RX, PAIR_RX, 1f, floatB, floatA, tilt, k)
            // ---- OnePlus wordmark appears once the case is gone ----
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).graphicsLayer { alpha = smooth(q.value, 0.55f, 1f) }) {
                Txt("ONEPLUS", 11, FontWeight.Bold, P.sub, spacing = 6f)
            }
        }
    }
}

/** Phone tilt (-1..1 each axis, relative to how the phone is being held) for gyro-style parallax. */
@Composable
private fun rememberTilt(): State<Offset> {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val reduceMotion = LocalReduceMotion.current
    val tilt = remember { mutableStateOf(Offset.Zero) }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var active by remember { mutableStateOf(true) }
    DisposableEffect(owner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) active = false else if (e == androidx.lifecycle.Lifecycle.Event.ON_START) active = true
        }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    DisposableEffect(ctx, active, reduceMotion) {
        val sm = ctx.getSystemService(android.content.Context.SENSOR_SERVICE) as? android.hardware.SensorManager
        val sensor = sm?.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER)
        var bx = Float.NaN; var by = Float.NaN
        val l = object : android.hardware.SensorEventListener {
            override fun onSensorChanged(e: android.hardware.SensorEvent) {
                val x = (e.values[0] / 9.8f).coerceIn(-1f, 1f); val y = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
                if (bx.isNaN()) { bx = x; by = y }
                bx += (x - bx) * 0.01f; by += (y - by) * 0.01f          // slow baseline = the way the phone is held
                val t = tilt.value
                tilt.value = Offset(t.x + ((x - bx) * 3f - t.x) * 0.12f, t.y + ((y - by) * 3f - t.y) * 0.12f)
            }
            override fun onAccuracyChanged(s: android.hardware.Sensor?, a: Int) {}
        }
        if (active && !reduceMotion && sensor != null) sm.registerListener(l, sensor, android.hardware.SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm?.unregisterListener(l) }
    }
    return tilt
}

/**
 * One earbud, two bodies that hand over to each other in 3D:
 *  - the CUTOUT is the real bud pixels cut from the case photo (so lift-off starts pixel-identical, no pop);
 *  - the SPRITE is the standing studio render of the bud.
 * While rising, the cutout turns in perspective (rotationY/X) and cross-fades into the sprite, which arrives
 * turning from the opposite angle and settles facing the viewer. Once floating, the bud keeps a slow 3D wobble and
 * reacts to phone tilt with parallax (closer layers move more).
 */
@Composable
private fun BoxScope.FlyingBud(
    res: Int, cutRes: Int, p: Animatable<Float, AnimationVector1D>, cutHold: State<Float>, q: State<Float>, lid: Animatable<Float, AnimationVector1D>,
    shiftU: () -> Float, restX: Float, hoverX: Float, pairX: Float, side: Float, float: State<Float>, sway: State<Float>, tilt: State<Offset>, k: Float
) {
    val density = LocalDensity.current
    val cam = 14f * density.density
    // Head-centre path shared by both bodies: cradle -> straight up -> arc to hover (or to the centre pair spot).
    fun headX(pv: Float): Float {
        val tx = lerpF(hoverX, pairX, q.value)
        val xe = FastOutSlowInEasing.transform(((pv - 0.30f) / 0.70f).coerceIn(0f, 1f))
        return lerpF(restX, tx, if (pv > 1f) 1f else xe)
    }
    fun headY(pv: Float): Float = lerpF(REST_HEAD_Y + shiftU(), lerpF(HOVER_HEAD_Y, PAIR_HEAD_Y, q.value), pv)
    // ---- real-photo cutout (full 960 canvas, positioned exactly where the bud sits in the case) ----
    Image(
        painterResource(cutRes), null,
        Modifier.fillMaxSize().graphicsLayer {
            val pv = p.value; val pc = pv.coerceIn(0f, 1f)
            cameraDistance = cam
            transformOrigin = TransformOrigin(restX / CANVAS, REST_HEAD_Y / CANVAS)
            translationX = (headX(pv) - restX) * k + tilt.value.x * 14f * k * pc
            translationY = (headY(pv) - REST_HEAD_Y) * k + tilt.value.y * 10f * k * pc
            val turn = smooth(pv, 0f, 0.45f)
            rotationY = side * 38f * turn
            rotationX = -22f * turn
            rotationZ = side * -6f * turn - p.velocity.coerceIn(-4f, 4f) * 1.6f * side
            val sc = lerpF(1f, 0.92f * REST_SC_PHOTO, turn); scaleX = sc; scaleY = sc
            alpha = cutHold.value * smooth(lid.value, 0.4f, 0.8f) * (1f - smooth(pv, 0.16f, 0.46f))
        },
        contentScale = ContentScale.Fit
    )
    // ---- standing studio sprite ----
    Image(
        painterResource(res), null,
        Modifier.align(Alignment.Center)
            .size(with(density) { (BUD_BOX_W * BUD_SCALE * k).toDp() }, with(density) { (BUD_BOX_H * BUD_SCALE * k).toDp() })
            .graphicsLayer {
                val pv = p.value; val pc = pv.coerceIn(0f, 1f)
                cameraDistance = cam
                val spriteHeadOffset = SPRITE_HEAD_OFFSET * BUD_SCALE      // head centre sits above the sprite's box centre
                translationX = (headX(pv) - CANVAS / 2f) * k + tilt.value.x * 20f * k * pc
                translationY = (headY(pv) + spriteHeadOffset - CANVAS / 2f) * k + float.value * k * pc + tilt.value.y * 14f * k * pc
                val arrive = smooth(pv, 0.16f, 0.95f)
                // arrives turning from the opposite side, settles facing us, then wobbles in 3D while floating
                rotationY = side * -34f * (1f - arrive) + float.value * 1.1f + tilt.value.x * 9f * pc
                rotationX = 18f * (1f - arrive) + sway.value * 0.9f - tilt.value.y * 9f * pc
                rotationZ = side * 3f * pc + sway.value * 0.35f - p.velocity.coerceIn(-4f, 4f) * 2.0f * side
                val sc = lerpF(0.92f, 1f, arrive); scaleX = sc; scaleY = sc
                alpha = smooth(pv, 0.16f, 0.46f) * smooth(lid.value, 0.4f, 0.8f)
            },
        contentScale = ContentScale.Fit
    )
}

@Composable
fun HeroCaption(r: ResolvedHero) {
    val tag = when (r.source) {
        HeroSource.HARDWARE -> "VERIFIED"; HeroSource.ESTIMATED -> "ESTIMATED"; HeroSource.PRESENTATION -> "PRESENTATION"
        HeroSource.PREVIEW -> "PREVIEW"; HeroSource.UNVERIFIED -> "UNVERIFIED"
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Txt(tag, 10, FontWeight.Bold, if (r.source == HeroSource.HARDWARE) P.green else P.accent, spacing = 1.4f)
        Txt(r.note, 12, color = P.sub, align = TextAlign.Center, lineHeight = 16, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Settings → Diagnostics: manually drive the hero without earbuds. Nothing here is hardware detection. */
@Composable
fun HeroPreviewPicker() {
    SectionLabel("Hero preview (debug)", detail = "Manually show any home-screen state. Preview only; never treated as detected hardware.")
    val options: List<Pair<HeroState?, String>> = listOf(
        null to "Live (follow device data)",
        HeroState.CASE_CLOSED to "1 · Case closed",
        HeroState.BOTH_IN to "2 · Open, both buds inside",
        HeroState.LEFT_OUT to "3 · Left bud outside",
        HeroState.RIGHT_OUT to "4 · Right bud outside",
        HeroState.BOTH_OUT to "5 · Both buds outside",
        HeroState.UNVERIFIED to "Unknown / unverified"
    )
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((state, label) in options) {
            val sel = HeroPreview.selected == state
            val src = remember(state) { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val liquid = isLiquid()
            Box(
                Modifier.fillMaxWidth()
                    .then(if (liquid) Modifier.glassTile3D(14.dp, sel, 5.dp, pressed)
                          else Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) P.accent.copy(alpha = 0.22f) else P.tile))
                    .clickable(interactionSource = src, indication = null) { HeroPreview.selected = state }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) { Txt(label, 14, if (sel) FontWeight.Bold else FontWeight.Normal, if (liquid) P.text else if (sel) P.accent else P.text) }
        }
    }
}
