package com.nordbuds.studio

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource

import androidx.compose.foundation.Image

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.animation.animateColorAsState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Card-tile design system: gradient glass cards, icon chips that bounce on touch, and a glowing
// gradient border on whatever is active. All continuous animation is read in the draw phase only,
// so idle screens do not recompose.

/** True when the system animation scale is 0 (Developer options / Accessibility: remove animations). */
val LocalReduceMotion = staticCompositionLocalOf { false }
val LocalThemeMode = staticCompositionLocalOf { ThemeMode.AURORA }

/** One size for every tile / row in the app so grids line up on every screen. */
val TILE_H = 78.dp
val ROW_H = 56.dp

/**
 * Tap tones. A ToneGenerator used to be constructed on the UI thread for every tap (tens of ms of blocking
 * native init) which janked every touch, most visibly when switching themes. Now one generator lives on a
 * dedicated background thread and the UI thread only posts a message.
 */
private object ToneEngine {
    private val tones = intArrayOf(ToneGenerator.TONE_PROP_ACK, ToneGenerator.TONE_PROP_BEEP, ToneGenerator.TONE_PROP_NACK, ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_7, ToneGenerator.TONE_DTMF_9)
    private val thread by lazy { android.os.HandlerThread("budsy-tone").apply { start() } }
    private val handler by lazy { android.os.Handler(thread.looper) }
    private var gen: ToneGenerator? = null
    private val release = Runnable { try { gen?.release() } catch (_: Exception) {}; gen = null }

    fun play(seed: Int) {
        handler.post {
            try {
                handler.removeCallbacks(release)
                val g = gen ?: ToneGenerator(AudioManager.STREAM_SYSTEM, 35).also { gen = it }
                g.startTone(tones[kotlin.math.abs(seed) % tones.size], 65)
                handler.postDelayed(release, 4000)   // free the native generator when idle
            } catch (_: Exception) { gen = null }
            Unit
        }
    }
}

private fun playBudsyTone(seed: Int = 0) {
    if (!Fx.sound) return
    ToneEngine.play(seed)
}

/** Returns a function that gives haptic + tone feedback for a tap. */
@Composable
fun rememberFeedback(): (Int) -> Unit {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    return remember(ctx) {
        { seed: Int ->
            Fx.tick(ctx)
            playBudsyTone(seed)
        }
    }
}

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) {
    val t = LocalTypeSpec.current
    val sz = t.size(size.toFloat())
    Text(
        text, modifier, color, sz.sp, fontWeight = weight, fontFamily = t.family, textAlign = align,
        // line height follows the (possibly scaled) font size so multi-line labels keep their rhythm
        lineHeight = if (lineHeight > 0) (lineHeight * sz / size).sp else TextUnit.Unspecified,
        letterSpacing = (spacing + t.tracking + (if (size >= 15 && spacing == 0f) -0.25f else 0f)).sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

// ---------------------------------------------------------------- motion helpers

/** Fade + slide-up entrance, staggered by [index]. Replays whenever the screen is opened. */
fun Modifier.enter(index: Int = 0): Modifier = composed {
    val m = LocalThemeSpec.current.motion
    val off = !m.enter || !m.enabled
    val a = remember { Animatable(if (off) 1f else 0f) }
    val dur = ms(420)
    LaunchedEffect(Unit) { if (!off) { delay((index * 55L / m.speed).toLong()); a.animateTo(1f, tween(dur, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) } }
    this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 22f; val sc = 0.97f + 0.03f * a.value; scaleX = sc; scaleY = sc }
}

/** 0..1 glow level, pulsing while [active]. Returned as a lambda so it is only read while drawing. */
@Composable
fun rememberGlow(active: Boolean): () -> Float {
    val level = remember { Animatable(0f) }
    val reduce = LocalReduceMotion.current || !LocalThemeSpec.current.motion.glowPulse
    val glowMs = ms(900)
    LaunchedEffect(active, reduce, glowMs) {
        if (!active) {
            level.animateTo(0f, tween(260))
        } else if (reduce) {
            level.animateTo(0.55f, tween(200))
        } else {
            while (true) {
                level.animateTo(0.72f, tween(glowMs, easing = FastOutSlowInEasing))
                level.animateTo(0.30f, tween(glowMs, easing = FastOutSlowInEasing))
            }
        }
    }
    // Stable lambda: the animated value is sampled by drawBehind instead of rebuilding
    // the whole tile on every animation frame.
    return remember(level) { { level.value } }
}

/** Soft animated glow around the active card. The brush is cached; only its alpha changes per frame. */
fun Modifier.glowBorder(radius: Dp, c1: Color, c2: Color, glow: () -> Float): Modifier = drawWithCache {
    val r = radius.toPx(); val inset = 1.5.dp.toPx(); val sw = 3.dp.toPx()
    val brush = Brush.linearGradient(listOf(c1.copy(alpha = 0.55f), c2.copy(alpha = 0.45f)))
    onDrawBehind {
        val level = glow().coerceIn(0f, 1f)
        if (level > 0f) drawRoundRect(
            brush = brush, topLeft = Offset(inset, inset), size = Size(size.width - inset * 2, size.height - inset * 2),
            cornerRadius = CornerRadius(r, r), alpha = level, style = Stroke(width = sw)
        )
    }
}

/** iOS-style soft bloom around a selected tile: stacked, fading strokes drawn outside the tile bounds. */
fun Modifier.softGlow(radius: Dp, color: Color, level: () -> Float): Modifier = drawBehind {
    val l = level().coerceIn(0f, 1f)
    if (l > 0f) {
        val r = radius.toPx(); val spread = 12.dp.toPx(); val n = 9
        val step = spread / n
        for (i in 1..n) {
            val t = i / n.toFloat()
            val grow = spread * t
            val a = (0.30f * (1f - t) * (1f - t) * l).coerceIn(0f, 1f)
            drawRoundRect(
                color = color.copy(alpha = a),
                topLeft = Offset(-grow, -grow),
                size = Size(size.width + grow * 2f, size.height + grow * 2f),
                cornerRadius = CornerRadius(r + grow, r + grow),
                style = Stroke(width = step * 1.6f)
            )
        }
    }
}

/** Clean iOS-style slider: thin rounded track, white round thumb. Replaces the Material slider (whose bar thumb glitched). */
@Composable
fun IosSlider(
    value: Float, onValueChange: (Float) -> Unit, onFinished: () -> Unit,
    range: ClosedFloatingPointRange<Float>, steps: Int, enabled: Boolean = true, modifier: Modifier = Modifier
) {
    val accent = P.accent; val accent2 = P.accent2; val track = P.track
    var widthPx by remember { mutableStateOf(1f) }
    val liquid = isLiquid()
    val thumbDp = if (liquid) 30.dp else 28.dp
    val thumbPx = with(LocalDensity.current) { thumbDp.toPx() }
    val onChange by rememberUpdatedState(onValueChange)
    val onDone by rememberUpdatedState(onFinished)
    val span = (range.endInclusive - range.start).coerceAtLeast(0.0001f)
    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
    fun toValue(x: Float): Float {
        val usable = (widthPx - thumbPx).coerceAtLeast(1f)
        val f = ((x - thumbPx / 2f) / usable).coerceIn(0f, 1f)
        var v = range.start + f * span
        if (steps > 0) {
            val n = (steps + 1).toFloat()
            v = range.start + Math.round((v - range.start) / span * n) / n * span
        }
        return v
    }
    Box(
        modifier.fillMaxWidth().height(36.dp).alpha(if (enabled) 1f else 0.4f)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(enabled, steps) {
                if (enabled) detectTapGestures(onTap = { onChange(toValue(it.x)); onDone() })
            }
            .pointerInput(enabled, steps) {
                if (enabled) detectHorizontalDragGestures(
                    onDragStart = { onChange(toValue(it.x)) },
                    onDragEnd = { onDone() },
                    onDragCancel = { onDone() },
                    onHorizontalDrag = { change, _ -> change.consume(); onChange(toValue(change.position.x)) }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val r = thumbDp.toPx() / 2f
            val cx = r + frac * (size.width - 2f * r)
            if (liquid) {
                // glass slider: inset groove, glowing blue fill, glossy bead thumb
                val th = 7.dp.toPx()
                drawRoundRect(track, Offset(0f, cy - th / 2f), Size(size.width, th), CornerRadius(th / 2f, th / 2f))
                drawRoundRect(accent.copy(alpha = 0.22f), Offset(0f, cy - th), Size(cx, th * 2f), CornerRadius(th, th))
                drawRoundRect(Brush.horizontalGradient(listOf(accent2, accent)), Offset(0f, cy - th / 2f), Size(cx, th), CornerRadius(th / 2f, th / 2f))
                drawCircle(Color.Black.copy(alpha = 0.14f), r + 2.5.dp.toPx(), Offset(cx, cy + 3.dp.toPx()))
                drawCircle(Brush.verticalGradient(listOf(Color.White, Color(0xFFDDE8F7)), cy - r, cy + r), r, Offset(cx, cy))
                drawCircle(Color.White.copy(alpha = 0.85f), r * 0.58f, Offset(cx, cy - r * 0.28f))
                drawCircle(accent.copy(alpha = 0.55f), r - 0.75.dp.toPx(), Offset(cx, cy), style = Stroke(1.5.dp.toPx()))
            } else {
                val th = 4.dp.toPx()
                // iOS slider: thin groove, solid accent fill, white thumb with a soft shadow.
                drawRoundRect(track, Offset(0f, cy - th / 2f), Size(size.width, th), CornerRadius(th / 2f, th / 2f))
                drawRoundRect(accent, Offset(0f, cy - th / 2f), Size(cx, th), CornerRadius(th / 2f, th / 2f))
                drawCircle(Color.Black.copy(alpha = 0.10f), r + 2.dp.toPx(), Offset(cx, cy + 2.dp.toPx()))
                drawCircle(Color.Black.copy(alpha = 0.16f), r + 0.5.dp.toPx(), Offset(cx, cy + 1.dp.toPx()))
                drawCircle(Color.White, r, Offset(cx, cy))
            }
        }
    }
}

@Composable
private fun cardBrush(): Brush = if (LocalThemed.current) themedCardBrush() else when (LocalThemeMode.current) {
    ThemeMode.STOCK -> Brush.linearGradient(
        if (P.dark) listOf(P.tile.copy(alpha = 0.98f), P.tile.copy(alpha = 0.90f))
        else listOf(Color.White.copy(alpha = 0.98f), Color(0xFFF7F9FD).copy(alpha = 0.96f))
    )
    ThemeMode.NOTHING -> Brush.linearGradient(listOf(Color(0xFF1A1A1A), Color(0xFF090909)))
    ThemeMode.TITANIUM -> Brush.linearGradient(listOf(Color(0xFF3A3B3F), Color(0xFF202226), Color(0xFF302C26)))
    ThemeMode.CRYSTAL -> Brush.linearGradient(listOf(Color.White.copy(alpha = 0.98f), Color(0xFFEAF2FC).copy(alpha = 0.94f)))
    else -> Brush.linearGradient(listOf(P.tile, P.tile))
}

/** Standard card chrome: glow (when active), clip, gradient fill and a gradient border when active. */
@Composable
private fun Modifier.card(radius: Dp, active: Boolean, glow: () -> Float, pressed: Boolean = false): Modifier {
    val themed = LocalThemed.current
    val spec = LocalThemeSpec.current
    val r = if (themed) (spec.shapes.card * radius.value / 20f).dp else radius
    val shape = RoundedCornerShape(r)
    val accent = P.accent; val accent2 = P.accent2
    if (isLiquid()) return this.glassTile3D(if (radius < 22.dp) 22.dp else radius, active, 8.dp, pressed)
    val bw = if (themed) spec.card.borderWidth else 1f
    val ba = if (themed) spec.card.borderAlpha else 0.8f
    val border: Brush = if (active) Brush.linearGradient(listOf(accent, accent2)) else SolidColor(P.line.copy(alpha = ba))
    val g: () -> Float = if (themed && !spec.card.glow) ({ 0f }) else glow
    return this.glowBorder(r, accent, accent2, g).clip(shape).background(cardBrush())
        .then(if (bw > 0f || active) Modifier.border(if (active) (bw + 0.5f).dp else bw.dp, border, shape) else Modifier)
}

// ---------------------------------------------------------------- touch feedback

/** Row tap: springy squash while pressed. */
fun Modifier.tapRow(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val bounce = LocalThemeSpec.current.motion.bounce
    val s by animateFloatAsState(if (pressed && enabled && bounce) 0.975f else 1f, spring(0.62f, 600f), label = "rowTap")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .background(if (pressed && enabled) P.line.copy(alpha = 0.35f) else Color.Transparent)
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { fb(0); onClick() } }
}

/** Button tap: bounces down and springs back past 1.0. */
fun Modifier.tapFade(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val bounce = LocalThemeSpec.current.motion.bounce
    val s by animateFloatAsState(if (pressed && enabled && bounce) 0.95f else 1f, spring(0.55f, 600f), label = "tapBounce")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { fb(0); onClick() } }
}


// ---------------------------------------------------------------- layout

/** Scrollable page body used by every tab. */
@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = if (isLiquid()) 16.dp else 20.dp).padding(top = 4.dp, bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(if (isLiquid()) 4.dp else 10.dp),
    content = content
)

/** Heading above a group of cards: accent icon, small caps title and an optional one-line detail. */
@Composable
fun SectionLabel(
    text: String,
    icon: ImageVector? = null,
    detail: String? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth().padding(start = 6.dp, top = 10.dp, bottom = 0.dp).enter(1)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Icon(icon, null, tint = P.accent, modifier = Modifier.size(if (isLiquid()) 24.dp else 18.dp)); Spacer(Modifier.width(if (isLiquid()) 10.dp else 7.dp)) }
            if (isLiquid()) Txt(text, 20, FontWeight.Bold, P.text, Modifier.weight(1f, fill = false), maxLines = 1)
            else Txt(text.uppercase(), 11, FontWeight.SemiBold, P.sub, Modifier.weight(1f, fill = false), spacing = 0.6f, maxLines = 1)
            if (trailing != null) { Spacer(Modifier.width(10.dp)); trailing() }
        }
        if (!detail.isNullOrBlank()) Txt(detail, 11, color = P.sub, modifier = Modifier.padding(top = 2.dp), lineHeight = 14)
    }
}

/** Small grey note under a group of cards. */
@Composable
fun SectionNote(text: String) {
    Txt(text, 12, FontWeight.Normal, P.sub, Modifier.padding(start = 6.dp, end = 6.dp), lineHeight = 17)
}

@Composable
fun Divider() = HorizontalDivider(color = P.line, thickness = 0.5.dp, modifier = Modifier.padding(start = 16.dp))

@Composable
fun FullDivider() = HorizontalDivider(color = P.line, thickness = 0.5.dp)

/** Gradient glass card that groups tiles and controls. */
@Composable
fun GlassPanel(modifier: Modifier = Modifier, index: Int = 0, content: @Composable ColumnScope.() -> Unit) {
    val mode = LocalThemeMode.current
    val themed = LocalThemed.current
    val spec = LocalThemeSpec.current
    val radius = if (themed) spec.shapes.panel.dp else when (mode) { ThemeMode.NOTHING -> 14.dp; ThemeMode.TITANIUM -> 22.dp; else -> 22.dp }
    val shape = RoundedCornerShape(radius)
    val fill = if (themed) themedCardBrush() else when (mode) {
        ThemeMode.STOCK -> Brush.linearGradient(listOf(P.tile, P.tile))
        ThemeMode.NOTHING -> Brush.linearGradient(listOf(Color(0xFF101010), Color(0xFF1A1A1A), Color(0xFF090909)))
        ThemeMode.TITANIUM -> Brush.linearGradient(listOf(Color(0xFF34363A), Color(0xFF202226), Color(0xFF3A352D)))
        ThemeMode.CRYSTAL -> Brush.linearGradient(listOf(Color.White.copy(alpha = 0.96f), Color(0xFFE7F0FC).copy(alpha = 0.88f)))
        else -> Brush.linearGradient(listOf(Color(0xFF1A304A).copy(alpha = 0.98f), Color(0xFF0C1B2D).copy(alpha = 0.92f)))
    }
    val outline = if (themed) P.line.copy(alpha = spec.card.borderAlpha) else when (mode) {
        ThemeMode.STOCK -> P.line
        ThemeMode.NOTHING -> Color.White.copy(alpha = 0.20f)
        ThemeMode.TITANIUM -> Color(0xFFE8C58A).copy(alpha = 0.42f)
        ThemeMode.CRYSTAL -> Color(0xFF8FBCEB).copy(alpha = 0.72f)
        else -> Color(0xFF36BFFF).copy(alpha = 0.42f)
    }
    val liquid = isLiquid()
    Column(
        modifier.fillMaxWidth().enter(index)
            .then(if (liquid) Modifier.glassSurface(28.dp) else Modifier
                .clip(shape)
                .background(fill)
                .then(if (themed && spec.card.borderWidth <= 0f) Modifier
                      else Modifier.border((if (themed) spec.card.borderWidth else 1f).dp, Brush.linearGradient(listOf(outline, P.line, P.accent2.copy(alpha = 0.24f))), shape)))
            .padding(if (liquid) 12.dp else 14.dp),
        content = content
    )
}

// ---------------------------------------------------------------- icons

/**
 * Round icon chip. Bounces (squash + tilt) while pressed, pops with an overshoot when it becomes active,
 * and shows a radial glow behind it while glowing.
 */
@Composable
fun BounceIcon(
    icon: ImageVector, active: Boolean, box: Dp = 44.dp, pressed: Boolean = false,
    glow: () -> Float = { 0f }, idleTint: Color = P.sub, plain: Boolean = false
) {
    val pop = remember { Animatable(1f) }
    LaunchedEffect(active) {
        if (active) { pop.snapTo(0.55f); pop.animateTo(1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessLow)) }
    }
    val ios = isLiquid()
    val press by animateFloatAsState(if (pressed) (if (ios) 0.94f else 0.88f) else 1f, spring(0.5f, 700f), label = "iconPress")
    val tilt by animateFloatAsState(if (pressed && !ios) -6f else 0f, spring(0.4f, 500f), label = "iconTilt")
    val accent = P.accent; val accent2 = P.accent2
    val showOn = active || (ios && pressed)          // glass chip previews the ON look while pressed
    val tintOn by animateFloatAsState(if (ios && showOn) 1f else 0f, tween(260), label = "chipTint")
    val chip: Brush = when {
        ios -> Brush.verticalGradient(listOf((if (active) accent else Color(0xFF8E8E93)).copy(alpha = 0.84f).compositeOver(Color.White), if (active) accent else Color(0xFF8E8E93)))
        active -> Brush.linearGradient(listOf(accent, accent2))
        plain -> SolidColor(Color.Transparent)
        else -> SolidColor(idleTint.copy(alpha = 0.14f))
    }
    Box(
        Modifier.size(box)
            .graphicsLayer { val s = pop.value * press; scaleX = s; scaleY = s; rotationZ = tilt }
            .then(if (ios) Modifier.glassChip(box, showOn) else Modifier.clip(RoundedCornerShape(box * 0.30f)).background(chip)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = if (ios) androidx.compose.ui.graphics.lerp(glassTokens().chipInk, Color.White, tintOn) else if (active) P.onAccent else if (plain) P.sub else idleTint, modifier = Modifier.size(box * 0.58f))
    }
}

/** Connection dot with an expanding ring while [pulsing]. */
@Composable
fun PulseDot(color: Color, pulsing: Boolean, dot: Dp = 8.dp) {
    // Only a pulsing dot runs an infinite animation; idle dots are static and cost nothing per frame.
    val reduce = LocalReduceMotion.current
    val phase: State<Float> = if (pulsing && !reduce) {
        rememberInfiniteTransition(label = "statusPulse").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
            label = "statusPulsePhase"
        )
    } else remember { mutableStateOf(0f) }
    Canvas(Modifier.size(dot * 2.4f)) {
        val r = dot.toPx() / 2f
        if (pulsing && !reduce) {
            val ph = phase.value
            val ringRadius = r + (size.minDimension * 0.42f * ph)
            drawCircle(color.copy(alpha = (1f - ph) * 0.52f), ringRadius, center, style = Stroke(width = 1.2.dp.toPx()))
        }
        drawCircle(color, r, center)
    }
}

// ---------------------------------------------------------------- tiles

/** Selectable card tile: icon chip, title, subtitle. Bounces on touch, glows with a gradient border when active. */
@Composable
fun FeatureTile(
    title: String, subtitle: String, icon: ImageVector, active: Boolean, modifier: Modifier = Modifier,
    toneSeed: Int = title.hashCode(), height: Dp = TILE_H, number: Int? = null, onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val bounceOn = LocalThemeSpec.current.motion.bounce
    val scale by animateFloatAsState(if (pressed && bounceOn) 0.95f else 1f, spring(0.55f, 600f), label = "tileBounce")
    val glow = rememberGlow(active)
    val fb = rememberFeedback()
    val mode = LocalThemeMode.current
    val themed = LocalThemed.current
    val tspec = LocalThemeSpec.current
    val shape = RoundedCornerShape(if (themed) tspec.shapes.tile.dp else if (mode == ThemeMode.NOTHING) 12.dp else if (mode == ThemeMode.TITANIUM) 16.dp else 16.dp)
    val accent = P.accent; val accent2 = P.accent2
    val idleFill = if (themed) themedCardBrush() else when (mode) {
        ThemeMode.STOCK -> Brush.linearGradient(
            if (P.dark) listOf(P.tile, P.tile.copy(alpha = 0.94f))
            else listOf(Color.White.copy(alpha = 0.98f), Color(0xFFF8FAFF).copy(alpha = 0.96f))
        )
        ThemeMode.NOTHING -> Brush.linearGradient(listOf(Color(0xFF171717), Color(0xFF090909)))
        ThemeMode.TITANIUM -> Brush.linearGradient(listOf(Color(0xFF414044), Color(0xFF242529), Color(0xFF34302A)))
        ThemeMode.CRYSTAL -> Brush.linearGradient(listOf(Color.White, Color(0xFFF0F6FF)))
        else -> Brush.linearGradient(listOf(P.tile, P.tile))
    }
    val border: Brush = if (active) Brush.linearGradient(listOf(accent, accent2)) else SolidColor(P.line.copy(alpha = 0.8f))
    val liquid = isLiquid()
    if (liquid) {
        // 3D glass tile: solid edge, glossy face, luminous blue when active, check badge.
        val fg = P.text
        Box(
            modifier.heightIn(min = height)
                .glassTile3D(20.dp, active, 6.dp, pressed)
                .semantics(mergeDescendants = true) { role = Role.Button; selected = active }
                .clickable(interactionSource = src, indication = null) { fb(toneSeed); onClick() }
                .padding(horizontal = 6.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                // Icon sits in the same glass badge as the rows; it previews the ON look while pressed (reference video).
                val badgeOn = active || pressed
                Box(Modifier.size(36.dp).glassChip(36.dp, badgeOn), contentAlignment = Alignment.Center) {
                    val ink = if (badgeOn) Color.White else glassTokens().chipInk
                    if (number != null) NumberRing(number, ink, 24.dp) else Icon(icon, null, tint = ink, modifier = Modifier.size(20.dp))
                }
                Txt(title, 13, if (active) FontWeight.SemiBold else FontWeight.Medium, fg, maxLines = if (subtitle.isBlank()) 2 else 1, align = TextAlign.Center, lineHeight = 15)
                if (subtitle.isNotBlank()) Txt(subtitle, 10, color = fg.copy(alpha = 0.7f), maxLines = 1, lineHeight = 12, align = TextAlign.Center)
            }
            GlassCheck(active, Modifier.align(Alignment.TopEnd).padding(top = 5.dp, end = 5.dp), size = 18.dp, preview = pressed && !active)
        }
        return
    }
    Box(
        modifier.heightIn(min = height)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .softGlow(16.dp, accent, glow)
            .clip(shape)
            .background(idleFill)
            .background(if (active) Brush.linearGradient(
                if (mode == ThemeMode.STOCK && !P.dark)
                    listOf(accent.copy(alpha = 0.12f), accent2.copy(alpha = 0.08f))
                else listOf(accent.copy(alpha = 0.22f), accent2.copy(alpha = 0.12f))
            ) else SolidColor(Color.Transparent))
            .border(if (active) 1.5.dp else (if (themed) tspec.card.borderWidth.dp else 1.dp), if (active) SolidColor(accent) else border, shape)
            .semantics(mergeDescendants = true) { role = Role.Button; selected = active }
            .clickable(interactionSource = src, indication = null) { fb(toneSeed); onClick() }
                 .padding(horizontal = 6.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Icon(icon, null, tint = if (active) accent else accent.copy(alpha = 0.55f), modifier = Modifier.size(26.dp))
            Txt(title, 12, if (active) FontWeight.SemiBold else FontWeight.Medium, if (active) P.text else P.sub, maxLines = 1, align = TextAlign.Center)
            if (subtitle.isNotBlank()) Txt(subtitle, 10, color = P.sub.copy(alpha = if (active) 1f else 0.75f), maxLines = 1, lineHeight = 12, align = TextAlign.Center)
        }
    }
}

private fun rowIcon(title: String): ImageVector = when {
    title.contains("single", true) -> Icons.Rounded.TouchApp
    title.contains("double", true) -> Icons.Rounded.Fingerprint
    title.contains("triple", true) -> Icons.Rounded.MoreHoriz
    title.contains("hold", true) -> Icons.Rounded.PanTool
    title.contains("noise", true) -> Icons.Rounded.Waves
    title.contains("find", true) -> Icons.Rounded.LocationSearching
    title.contains("game", true) -> Icons.Rounded.SportsEsports
    title.contains("equal", true) || title.contains("sound", true) -> Icons.Rounded.GraphicEq
    title.contains("firmware", true) || title.contains("update", true) -> Icons.Rounded.SystemUpdate
    title.contains("connect", true) || title.contains("bluetooth", true) -> Icons.Rounded.Bluetooth
    title.contains("tutorial", true) || title.contains("learn", true) -> Icons.Rounded.School
    else -> Icons.Rounded.Tune
}

/** Card row: icon chip, title, value and an optional chevron. Pass [onClick] to make it tappable. */
@Composable
fun ValueRow(title: String, value: String, chevron: Boolean = true, icon: ImageVector? = null, glow: Boolean = false, onClick: (() -> Unit)? = null) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(glow)
    val bounceOn = LocalThemeSpec.current.motion.bounce
    val scale by animateFloatAsState(if (pressed && onClick != null && bounceOn && !isLiquid()) 0.975f else 1f, spring(0.62f, 600f), label = "rowBounce")
    Row(
        Modifier.fillMaxWidth().enter().graphicsLayer { scaleX = scale; scaleY = scale }
            .card(16.dp, glow, g, pressed && onClick != null)
            .then(if (onClick != null) Modifier.clickable(interactionSource = src, indication = null) { fb(title.hashCode()); onClick() } else Modifier)
            .heightIn(min = if (isLiquid()) 68.dp else ROW_H).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon ?: rowIcon(title), glow, if (isLiquid()) 44.dp else 32.dp, pressed, g, P.accent)
        Spacer(Modifier.width(12.dp))
        Txt(title, 15, FontWeight.Medium, P.text, Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        if (value.isNotBlank()) Txt(value, 14, FontWeight.Normal, P.sub, Modifier.widthIn(max = 160.dp), align = TextAlign.End)
        if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = P.sub.copy(alpha = 0.7f), modifier = Modifier.size(22.dp))
    }
}

/** Stand-alone toggle (no row around it): the same glass tick badge as the rows, with an empty ring when off. [icon] is kept for source compatibility and no longer drawn. */
@Composable
fun IosSwitch(
    on: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
    icon: ImageVector = Icons.Rounded.PowerSettingsNew
) {
    val fb = rememberFeedback()
    Box(
        Modifier.size(44.dp).alpha(if (enabled) 1f else .48f)
            .toggleable(value = on, enabled = enabled, role = Role.Switch, interactionSource = remember { MutableInteractionSource() }, indication = null) {
                fb(if (on) 31 else 32)
                onChange(it)
            }
            .semantics { stateDescription = if (on) "On" else "Off" },
        contentAlignment = Alignment.Center
    ) { GlassCheck(on, size = 28.dp, showOff = true) }
}

/** Card row with icon chip and a toggle. Glows while on. */
@Composable
fun SwitchRow(title: String, sub: String?, on: Boolean, enabled: Boolean = true, icon: ImageVector? = null, badge: String? = null, onChange: (Boolean) -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(on && enabled)
    val scale by animateFloatAsState(if (pressed && enabled && !isLiquid()) 0.98f else 1f, spring(0.62f, 600f), label = "swRow")
    Row(
        Modifier.fillMaxWidth().enter().graphicsLayer { scaleX = scale; scaleY = scale }
            .card(16.dp, on && enabled, g, pressed && enabled)
            .clickable(interactionSource = src, indication = null, enabled = enabled) { fb(if (on) 31 else 32); onChange(!on) }
            .heightIn(min = if (isLiquid()) 72.dp else ROW_H).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon ?: rowIcon(title), on && enabled, if (isLiquid()) 44.dp else 32.dp, pressed, g, P.accent)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(title, 15, FontWeight.Medium, P.text, Modifier.weight(1f, fill = false), maxLines = 2)
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Txt(badge.uppercase(), 9, FontWeight.Bold, P.amber, Modifier.clip(CircleShape).background(P.amber.copy(alpha = 0.15f)).padding(horizontal = 7.dp, vertical = 2.dp), maxLines = 1, spacing = 0.6f)
                }
            }
            if (sub != null) Txt(sub, 11, lineHeight = 14)
        }
        Spacer(Modifier.width(10.dp))
        GlassCheck(on && enabled, size = 26.dp, showOff = !isLiquid(), preview = pressed && enabled && !on)
    }
}

// ---------------------------------------------------------------- buttons

/** Rounded-rectangle button. Filled = glowing gradient, otherwise a soft tile. */
@Composable
fun WideButton(text: String, filled: Boolean = true, enabled: Boolean = true, destructive: Boolean = false, icon: ImageVector? = null, spin: Boolean = false, onClick: () -> Unit) {
    val liquid = isLiquid()
    val fg = when { filled && liquid -> Color.White; filled -> P.onAccent; destructive -> P.red; liquid && !P.dark -> glassTokens().chipInk; else -> P.accent }
    val shape = RoundedCornerShape(if (liquid) 14.dp else LocalThemeSpec.current.shapes.button.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val idleBg: Brush = SolidColor(P.tile)
    val idleRim: Brush = SolidColor(P.line)
    val face: Modifier = if (liquid) Modifier.glassTile3D(16.dp, false, 6.dp, pressed, bold = filled)
        else Modifier.clip(shape)
            .background(if (filled) Brush.linearGradient(listOf(P.accent, P.accent2)) else idleBg)
            .then(if (!filled) Modifier.border(1.dp, idleRim, shape) else Modifier)
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f)
            .then(if (liquid) Modifier.clickable(interactionSource = src, indication = null, enabled = enabled) { fb(0); onClick() } else Modifier.tapFade(enabled, onClick))
            .then(face).height(46.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            val rot = if (spin) rememberInfiniteTransition(label = "btnSpin").animateFloat(0f, 360f, infiniteRepeatable(tween(850, easing = LinearEasing)), label = "btnSpinAngle").value else 0f
            Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp).graphicsLayer { rotationZ = rot })
            Spacer(Modifier.width(8.dp))
        }
        Txt(text, 15, FontWeight.SemiBold, fg, maxLines = 1)
    }
}

/** Compact pill button. */
@Composable
fun SmallButton(text: String, filled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    val liquid = isLiquid()
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val fg = if (filled) (if (liquid) Color.White else P.onAccent) else if (liquid && !P.dark) glassTokens().chipInk else P.accent
    val face: Modifier = if (liquid) Modifier.glassTile3D(22.dp, false, 5.dp, pressed, bold = filled)
        else Modifier.clip(RoundedCornerShape(LocalThemeSpec.current.shapes.pill.dp))
            .background(if (filled) Brush.linearGradient(listOf(P.accent, P.accent2)) else SolidColor(P.tile))
    Row(
        (if (liquid) Modifier.clickable(interactionSource = src, indication = null) { fb(0); onClick() } else Modifier.tapFade(onClick = onClick)).then(face).heightIn(min = 44.dp).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Txt(text, 14, FontWeight.SemiBold, fg, maxLines = 1)
    }
}

/** Large pill button with an optional icon. */
@Composable
fun AccentPill(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.tapFade(onClick = onClick)
            .clip(RoundedCornerShape(LocalThemeSpec.current.shapes.pill.dp)).background(Brush.linearGradient(listOf(P.accent, P.accent2))).padding(horizontal = 28.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = P.onAccent, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Txt(text, 16, FontWeight.SemiBold, P.onAccent, maxLines = 1)
    }
}

// ---------------------------------------------------------------- segmented control (icon tiles)

/** A row of equal icon tiles; the selected one glows. Items without an icon get a generic one. */
@Composable
fun Segmented(items: List<Pair<ImageVector?, String>>, sel: Int, modifier: Modifier = Modifier, onSel: (Int) -> Unit) {
    Row(modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, (icon, label) ->
            FeatureTile(label, "", icon ?: Icons.Rounded.Tune, i == sel, Modifier.weight(1f).fillMaxHeight(), toneSeed = 50 + i) { onSel(i) }
        }
    }
}

// ---------------------------------------------------------------- battery

/** Animated ring gauge with percentage, charging bolt and label. Three sit side by side (L, R, case). */
@Composable
fun BatteryStat(pct: Int, charging: Boolean, label: String, modifier: Modifier = Modifier, desc: String = label, icon: ImageVector = Icons.Rounded.Headphones) {
    val tint = if (charging) P.green else if (pct in 0..19) P.amber else P.green
    val target = if (pct < 0) 0f else pct.coerceAtMost(100) / 100f
    val prog by animateFloatAsState(target, tween(900, easing = FastOutSlowInEasing), label = "battery")
    val bolt = 1f
    val track = P.track
    Column(
        modifier.semantics(mergeDescendants = true) { contentDescription = desc }.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 5.dp.toPx()
                val inset = w / 2f + 3.dp.toPx()
                val d = size.minDimension - inset * 2f
                val tl = Offset(inset, inset)
                val sz = Size(d, d)
                drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                if (prog > 0f) {
                    drawArc(tint, -90f, 360f * prog, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Txt(if (pct < 0) "—" else "$pct%", 14, FontWeight.Bold, P.text, maxLines = 1)
                if (charging) Icon(Icons.Rounded.Bolt, null, tint = P.green, modifier = Modifier.size(13.dp))
            }
        }
        Spacer(Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ThemedIcon(IconKeys.BATTERY, icon, P.sub, Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Txt(label, 12, FontWeight.Medium, P.sub, maxLines = 1)
        }
    }
}

// ---------------------------------------------------------------- drawing

/**
 * The real earbud picture (left / right, white on dark UI, black on light UI) with a pulsing accent
 * marker on the touch pad, so people know where gestures are performed.
 */
@Composable
fun BudPhoto(right: Boolean, height: Dp, modifier: Modifier = Modifier, touchSpot: Boolean = false) {
    val res = when {
        P.dark && right -> R.drawable.gesture_bud_r_white
        P.dark -> R.drawable.gesture_bud_l_white
        right -> R.drawable.gesture_bud_r_black
        else -> R.drawable.gesture_bud_l_black
    }
    val accent = P.accent
    val reduceBud = LocalReduceMotion.current
    val t = rememberInfiniteTransition(label = "touchPad")
    val pulse = t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "touchPadPulse")
    // Gesture pictures (front view, cropped): touch pad = the long pill on the stem, at these fractions.
    val padX = if (right) 0.480f else 0.388f
    Box(modifier.size(height * (if (right) 0.6244f else 0.6222f), height)) {
        Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        if (touchSpot) Canvas(Modifier.fillMaxSize()) {
            val x = size.width * padX; val y = size.height * (if (right) 0.143f else 0.139f)
            val w = size.width * 0.129f; val h = size.height * (if (right) 0.364f else 0.367f)
            val p = if (reduceBud) 0f else pulse.value
            drawRoundRect(accent.copy(alpha = 0.28f * (1f - p)), Offset(x - w * p * 0.45f, y - w * p * 0.45f),
                Size(w * (1f + p * 0.9f), h + w * p * 0.9f), CornerRadius(w, w))
            drawRoundRect(Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f), accent.copy(alpha = 0.25f))), Offset(x, y), Size(w, h), CornerRadius(w / 2, w / 2))
        }
    }
}

/** Soft colour blobs behind every screen. Static, and the gradient brushes are cached per size/palette. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    if (isLiquid()) { LiquidBackground(modifier); return }
    val mode = LocalThemeMode.current
    val c1 = P.accent
    val c2 = P.accent2
    val isDark = P.dark
    val themedBg = LocalThemed.current
    val bgSpec = LocalThemeSpec.current.background
    val c3 = when (mode) {
        ThemeMode.STOCK -> P.bg
        ThemeMode.NOTHING -> Color(0xFFFF5148)
        ThemeMode.TITANIUM -> Color(0xFFE8C58A)
        ThemeMode.CRYSTAL -> Color(0xFF8EC9FF)
        else -> Color(0xFF16BFFF)
    }
    Box(modifier.fillMaxSize().drawWithCache {
        val w = size.width
        val h = size.height
        val strength = if (themedBg) (if (bgSpec.blobs) (if (isDark) 0.22f else 0.17f) else 0f) else if (mode == ThemeMode.STOCK) 0.015f else if (isDark) 0.22f else 0.17f
        val specs = listOf(
            Triple(c1, Offset(w * 0.22f, h * 0.16f), w * 0.82f),
            Triple(c2, Offset(w * 0.88f, h * 0.52f), w * 0.72f),
            Triple(c3, Offset(w * 0.30f, h * 0.88f), w * 0.66f)
        )
        val brushes = specs.map { (col, ctr, r) ->
            Brush.radialGradient(listOf(col.copy(alpha = strength), Color.Transparent), center = ctr, radius = r)
        }
        onDrawBehind {
            specs.forEachIndexed { i, (_, ctr, r) -> drawCircle(brushes[i], r, ctr) }
            if (themedBg) {
                if (bgSpec.dotMatrix) {
                    val step = 13.dp.toPx(); val dot = 1.dp.toPx()
                    val dc = c1.copy(alpha = 0.16f)
                    var y = step
                    while (y < size.height) { var x = step; while (x < size.width) { drawCircle(dc, dot, Offset(x, y)); x += step }; y += step }
                }
            } else when (mode) {
                ThemeMode.STOCK -> Unit
                ThemeMode.NOTHING -> {
                    // Restrained Nothing-style dot matrix texture.
                    val step = 13.dp.toPx()
                    val dot = 1.dp.toPx()
                    var y = step
                    while (y < size.height) {
                        var x = step
                        while (x < size.width) {
                            drawCircle(Color.White.copy(alpha = 0.075f), dot, Offset(x, y))
                            x += step
                        }
                        y += step
                    }
                    // A subtle signal-red edge glow anchors the selected state.
                    drawCircle(Color(0xFFFF5148).copy(alpha = 0.07f), size.width * 0.62f,
                        Offset(size.width * 0.92f, size.height * 0.38f))
                }
                ThemeMode.TITANIUM -> {
                    // Warm metallic reflections, rather than a generic blue aurora.
                    drawRect(Brush.linearGradient(listOf(Color(0xFFE8C58A).copy(alpha = 0.08f),
                        Color.Transparent, Color(0xFFB88A4B).copy(alpha = 0.07f))))
                }
                ThemeMode.CRYSTAL -> {
                    drawRect(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.22f),
                        Color.Transparent, Color(0xFFB7D8FF).copy(alpha = 0.12f))))
                }
                else -> {
                    // Electric-blue horizon ribbons for Aurora Glass.
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent,
                        Color(0xFF16BFFF).copy(alpha = 0.045f), Color.Transparent),
                        startY = size.height * 0.36f, endY = size.height * 0.72f))
                }
            }
        }
    })
}

// ---------------------------------------------------------------- sheets

/** Bottom sheet. Slides up with a spring, drags down to dismiss, kept clear of the bottom navigation bar. Content scrolls; footer stays pinned. */
@Composable
fun SheetDialog(onDismiss: () -> Unit, footer: (@Composable ColumnScope.() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val scope = rememberCoroutineScope()
        val enter = remember { Animatable(0f) }
        var dragY by remember { mutableFloatStateOf(0f) }
        LaunchedEffect(Unit) { enter.animateTo(1f, spring(0.8f, 420f)) }
        val close: () -> Unit = { scope.launch { enter.animateTo(0f, tween(170)); onDismiss() } }
        BoxWithConstraints(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = close)
                .navigationBarsPadding().padding(bottom = 64.dp),   // bottom nav bar height + margin, so the sheet sits above it
            contentAlignment = Alignment.BottomCenter
        ) {
            val shape = RoundedCornerShape(24.dp)
            Column(
                Modifier.fillMaxWidth().heightIn(max = maxHeight * 0.72f).padding(horizontal = 10.dp, vertical = 8.dp)
                    .graphicsLayer { translationY = (1f - enter.value) * 520f + dragY; alpha = enter.value.coerceIn(0f, 1f) }
                    .clip(shape).background(P.sheet.copy(alpha = 1f))
                    .glassSheen()
                    .border(1.dp, if (isLiquid()) Brush.linearGradient(listOf(glassTokens().panelRim, glassTokens().panelRim.copy(alpha = glassTokens().panelRim.alpha * 0.45f), glassTokens().panelRim.copy(alpha = glassTokens().panelRim.alpha * 0.85f))) else SolidColor(P.line), shape)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                    .padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 12.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().height(26.dp).pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (dragY > 160f) close() else dragY = 0f },
                            onDragCancel = { dragY = 0f },
                            onVerticalDrag = { _, d -> dragY = (dragY + d).coerceAtLeast(0f) }
                        )
                    },
                    contentAlignment = Alignment.Center
                ) { Box(Modifier.size(32.dp, 4.dp).background(P.track, CircleShape)) }
                Spacer(Modifier.height(6.dp))
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), content = content)
                if (footer != null) { Spacer(Modifier.height(10.dp)); footer() }
            }
        }
    }
}

/** Glass-style centred dialog (replaces the default Material AlertDialog). */
@Composable
fun GlassDialog(
    title: String, onDismiss: () -> Unit, confirm: String, onConfirm: () -> Unit,
    dismiss: String? = null, onDismissClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val p = remember { Animatable(0f) }
        LaunchedEffect(Unit) { p.animateTo(1f, spring(0.72f, 380f)) }
        val shape = RoundedCornerShape(28.dp)
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(
                Modifier.widthIn(max = 420.dp).fillMaxWidth()
                    .graphicsLayer { val s = 0.88f + 0.12f * p.value; scaleX = s; scaleY = s; alpha = p.value.coerceIn(0f, 1f) }
                    .clip(shape)
                    .background(Brush.linearGradient(listOf(P.sheet.copy(alpha = 1f), P.sheet.copy(alpha = 1f))))
                    .glassSheen()
                    .border(1.dp, if (isLiquid()) Brush.linearGradient(listOf(glassTokens().panelRim, glassTokens().panelRim.copy(alpha = 0.3f), glassTokens().panelRim.copy(alpha = 0.8f))) else Brush.linearGradient(listOf(P.accent.copy(alpha = 0.45f), P.line, P.accent2.copy(alpha = 0.35f))), shape)
                    .padding(20.dp)
            ) {
                Txt(title, 19, FontWeight.Bold, P.text, Modifier.padding(bottom = 10.dp))
                content()
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    if (dismiss != null) { SmallButton(dismiss, false) { (onDismissClick ?: onDismiss)() }; Spacer(Modifier.width(10.dp)) }
                    SmallButton(confirm, true) { onConfirm() }
                }
            }
        }
    }
}

/** Glass snackbar body, used by the Scaffold's SnackbarHost. */
@Composable
fun GlassSnack(message: String) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(P.sheet.copy(alpha = 1f), P.sheet.copy(alpha = 1f))))
            .glassSheen()
            .border(1.dp, if (isLiquid()) Brush.linearGradient(listOf(glassTokens().panelRim, glassTokens().panelRim.copy(alpha = 0.4f))) else Brush.linearGradient(listOf(P.accent.copy(alpha = 0.45f), P.line)), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Info, null, tint = P.accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Txt(message, 14, FontWeight.Medium, P.text, Modifier.weight(1f))
    }
}

/** Text field colours that match the glass surfaces. */
@Composable
fun budsyFieldColors(): androidx.compose.material3.TextFieldColors {
    // Stock look: inset glass field (tile face), same surface the 3D tiles use.
    val face = if (isLiquid()) glassTokens().tile[1].compositeOver(if (P.dark) Color.Black else Color.White) else P.tile
    return budsyFieldColorsFor(face)
}

@Composable
private fun budsyFieldColorsFor(face: Color) = TextFieldDefaults.colors(
    focusedContainerColor = face, unfocusedContainerColor = face, disabledContainerColor = face,
    focusedIndicatorColor = P.accent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = P.text, unfocusedTextColor = P.text, cursorColor = P.accent,
    focusedLabelColor = P.accent, unfocusedLabelColor = P.sub
)

/** Covers the screen with the previous theme's background and fades it out when the theme / appearance changes. */
@Composable
fun ThemeFadeOverlay(key: Int, bg: Color) {
    var prev by remember { mutableStateOf(bg) }
    var cur by remember { mutableStateOf(bg) }
    val a = remember { Animatable(0f) }
    val reduce = LocalReduceMotion.current
    val fadeMs = ms(380)
    LaunchedEffect(key) {
        if (cur != bg) {
            prev = cur; cur = bg
            if (!reduce) { a.snapTo(1f); a.animateTo(0f, tween(fadeMs, easing = FastOutSlowInEasing)) }
        }
    }
    if (a.value > 0.001f) Box(Modifier.fillMaxSize().graphicsLayer { alpha = a.value }.background(prev))
}

@Composable
fun SheetTitle(text: String) {
    Txt(text, 17, FontWeight.Bold, P.text, Modifier.fillMaxWidth().padding(bottom = 8.dp), align = TextAlign.Center)
}

/** Option card with an icon chip. The chosen one glows and shows a bouncing check. */
@Composable
fun OptionCard(title: String, sub: String?, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(selected)
    val bounceOn = LocalThemeSpec.current.motion.bounce
    val scale by animateFloatAsState(if (pressed && bounceOn && !isLiquid()) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "optBounce")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .card(16.dp, selected, g, pressed)
            .clickable(interactionSource = src, indication = null) { fb(title.hashCode()); onClick() }
            .heightIn(min = if (isLiquid()) 72.dp else 56.dp).padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon, selected, if (isLiquid()) 44.dp else 36.dp, pressed, g)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(title, 16, FontWeight.Medium, P.text)
            if (!sub.isNullOrBlank()) Txt(sub, 12, lineHeight = 16)
        }
        Spacer(Modifier.width(8.dp))
        GlassCheck(selected, size = 26.dp, showOff = !isLiquid(), preview = pressed && !selected)
    }
}

/** Single-choice option. */
@Composable
fun RadioRow(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) = OptionCard(label, null, icon, selected, onClick)

/** Multi-choice option. */
@Composable
fun CheckRow(title: String, sub: String, icon: ImageVector, checked: Boolean, onClick: () -> Unit) = OptionCard(title, sub, icon, checked, onClick)

// ---------------------------------------------------------------- navigation

/** Bottom tab bar. iOS style: bar surface with a hairline on top; the active tab is tinted with the accent. */
@Composable
fun BottomNav(items: List<Triple<Int, ImageVector, String>>, selected: Int, onSelect: (Int) -> Unit) {
    val liquid = isLiquid()
    if (liquid) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                Modifier.fillMaxWidth().height(60.dp).glassSurface(30.dp)
                    .background(glassTokens().sheet.copy(alpha = if (P.dark) 0.35f else 0.30f))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEach { (id, icon, label) -> NavItem(id, icon, label, id == selected, Modifier.weight(1f)) { onSelect(id) } }
            }
        }
        return
    }
    val shape = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().background(Color.Transparent).navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().height(58.dp).clip(shape)
                .background(Brush.verticalGradient(listOf(P.tile.copy(alpha = 0.98f), P.bg.copy(alpha = 0.98f))))
                .border(1.dp, P.line.copy(alpha = 0.9f), shape)
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { (id, icon, label) ->
                NavItem(id, icon, label, id == selected, Modifier.weight(1f)) { onSelect(id) }
            }
        }
    }
}

@Composable
private fun NavItem(id: Int, icon: ImageVector, label: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val fb = rememberFeedback()
    val liquid = isLiquid()
    val bg by animateColorAsState(if (sel) P.accent.copy(alpha = 0.18f) else Color.Transparent, tween(200), label = "navBg")
    val pillW by animateDpAsState(if (sel) 60.dp else 40.dp, spring(0.7f, 500f), label = "navPill")
    val tint = if (sel) P.accent else if (liquid) P.text.copy(alpha = 0.62f) else P.sub
    val iconTint = if (liquid && sel) Color.White else tint
    Column(
        modifier.fillMaxHeight().clip(RoundedCornerShape(22.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, role = androidx.compose.ui.semantics.Role.Tab) { fb(id + 1); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.width(if (liquid) 46.dp else pillW).height(if (liquid) 30.dp else 28.dp)
                .then(if (liquid && sel) Modifier.shadow(5.dp, CircleShape, clip = false, ambientColor = P.accent.copy(alpha = 0.3f), spotColor = P.accent.copy(alpha = 0.4f)) else Modifier)
                .clip(CircleShape)
                .background(if (liquid) (if (sel) Brush.linearGradient(listOf(Color(0xFF80C8FF), Color(0xFF2585E9))) else SolidColor(Color.Transparent)) else SolidColor(bg)),
            contentAlignment = Alignment.Center
        ) {
            ThemedIcon(when (id) { 0 -> IconKeys.DEVICE; 1 -> IconKeys.SOUND; 2 -> IconKeys.CONTROLS; else -> IconKeys.SETTINGS }, icon, iconTint, Modifier.size(24.dp))
        }
        Txt(label, 10, if (sel) FontWeight.SemiBold else FontWeight.Medium, tint, maxLines = 1)
    }
}
