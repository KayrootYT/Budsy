package com.nordbuds.studio

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntSize
import android.os.Build
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Liquid Glass design system (Light / Dark / AMOLED).
 *  - LiquidWallpaper : silk-ribbon "3D" wallpaper that sits behind every screen, drifting very slowly.
 *  - liquidGlass     : frosted translucent surface with soft shadow, specular top rim, sheen and a light-catching border.
 *  - glossFill       : glossy accent gradient (selected tiles, primary buttons, active nav pill).
 *  - glassOrb        : 3D glass sphere used as slider / EQ thumb.
 */

// ---------------------------------------------------------------- wallpaper

@Composable
fun LiquidWallpaper(modifier: Modifier = Modifier) {
    val dark = P.dark
    val amoled = P.amoled
    val layer = rememberGraphicsLayer()
    DisposableEffect(layer) {
        WallpaperHub.layer = layer
        onDispose { if (WallpaperHub.layer === layer) WallpaperHub.layer = null }
    }

    // base gradient, ribbon colours (a, b, c), glow colour
    val base: List<Color>; val ra: Color; val rb: Color; val rc: Color; val glow: Color
    when {
        amoled -> {
            base = listOf(Color(0xFF000000), Color(0xFF08031A), Color(0xFF000000))
            ra = Color(0xFF8B5CF6); rb = Color(0xFF4C1DDB); rc = Color(0xFFD2B8FF); glow = Color(0xFF7C3AED)
        }
        dark -> {
            base = listOf(Color(0xFF020B1F), Color(0xFF031B44), Color(0xFF020817))
            ra = Color(0xFF1EA7FF); rb = Color(0xFF2456E8); rc = Color(0xFF9BE3FF); glow = Color(0xFF1580FF)
        }
        else -> {
            base = listOf(Color(0xFFEAF3FF), Color(0xFFD9E8FB), Color(0xFFF3F8FF))
            ra = Color(0xFF9FC8FF); rb = Color(0xFF4F8FFF); rc = Color(0xFFFFFFFF); glow = Color(0xFFBBD7FF)
        }
    }
    val ribbonAlpha = if (dark) 1f else 0.9f

    Box(modifier.fillMaxSize().drawWithContent {
        layer.record(size = IntSize(size.width.toInt(), size.height.toInt())) { this@drawWithContent.drawContent() }
        drawLayer(layer)
    }.drawWithCache {
        val w = size.width
        val h = size.height
        val baseBrush = Brush.verticalGradient(base)

        // A tapering silk ribbon: centre curve from (right, a) to (left, b); the band is wider in the middle.
        fun ribbon(a: Float, b: Float, c1y: Float, c2y: Float, thick: Float): Pair<Path, Path> {
            val x0 = w * 1.30f; val x3 = -w * 0.30f
            val c1x = w * 0.80f; val c2x = w * 0.10f
            val top = Path().apply {
                moveTo(x0, h * a - thick * 0.15f)
                cubicTo(c1x, h * c1y - thick, c2x, h * c2y - thick, x3, h * b - thick * 0.15f)
            }
            val band = Path().apply {
                moveTo(x0, h * a - thick * 0.15f)
                cubicTo(c1x, h * c1y - thick, c2x, h * c2y - thick, x3, h * b - thick * 0.15f)
                lineTo(x3, h * b + thick * 0.15f)
                cubicTo(c2x, h * c2y + thick * 1.7f, c1x, h * c1y + thick * 1.7f, x0, h * a + thick * 0.15f)
                close()
            }
            return band to top
        }

        val r1 = ribbon(0.02f, 0.40f, 0.10f, 0.20f, h * 0.075f)
        val r2 = ribbon(0.10f, 0.58f, 0.24f, 0.36f, h * 0.050f)
        val r3 = ribbon(0.42f, 0.98f, 0.52f, 0.78f, h * 0.085f)
        val r4 = ribbon(0.62f, 1.08f, 0.70f, 0.92f, h * 0.040f)

        val diag0 = Offset(w, 0f); val diag1 = Offset(0f, h)
        fun fillBrush(c: Color, d: Color) = Brush.linearGradient(
            listOf(Color.Transparent, c.copy(alpha = 0.70f * ribbonAlpha), d.copy(alpha = 0.34f * ribbonAlpha), Color.Transparent),
            start = diag0, end = diag1
        )
        val f1 = fillBrush(ra, rb); val f2 = fillBrush(rb, ra); val f3 = fillBrush(ra, rc); val f4 = fillBrush(rc, rb)
        val glowTop = Brush.radialGradient(listOf(glow.copy(alpha = if (dark) 0.42f else 0.55f), Color.Transparent), Offset(w * 0.80f, h * 0.08f), w * 0.95f)
        val glowBottom = Brush.radialGradient(listOf(glow.copy(alpha = if (dark) 0.32f else 0.40f), Color.Transparent), Offset(w * 0.18f, h * 0.92f), w * 0.85f)
        val vignette = Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = if (dark) 0.30f else 0f), Color.Transparent, Color.Black.copy(alpha = if (dark) 0.38f else 0f))
        )
        val edgeCol = if (dark) rc else Color.White
        val edge1 = 1.4.dp.toPx(); val edge2 = 7.dp.toPx()

        onDrawBehind {
            drawRect(baseBrush)
            drawRect(glowTop); drawRect(glowBottom)
            run {
                drawPath(r3.first, f3); drawPath(r4.first, f4)
                drawPath(r1.first, f1); drawPath(r2.first, f2)
                // light catching the silk edges: soft wide pass, then a crisp thin pass
                for ((i, pr) in listOf(r1, r2, r3, r4).withIndex()) {
                    val a = if (i % 2 == 0) 1f else 0.7f
                    drawPath(pr.second, edgeCol.copy(alpha = (if (dark) 0.14f else 0.30f) * a), style = Stroke(edge2))
                    drawPath(pr.second, edgeCol.copy(alpha = (if (dark) 0.60f else 0.85f) * a), style = Stroke(edge1))
                }
            }
            drawRect(vignette)
        }
    })
}

// ---------------------------------------------------------------- glass surface

/** Holds the recorded wallpaper so every glass surface can draw a blurred copy of exactly what is behind it. */
object WallpaperHub { var layer by mutableStateOf<GraphicsLayer?>(null) }

/** CSS `backdrop-filter: blur() saturate()`: draws a blurred, saturated copy of the wallpaper region behind this surface (Android 12+). */
private fun Modifier.backdropBlur(sigma: Dp, saturation: Float): Modifier = composed {
    var pos by remember { mutableStateOf(Offset.Zero) }
    this.onGloballyPositioned { pos = it.positionInRoot() }
        .drawWithCache {
            val src = WallpaperHub.layer
            val layer = obtainGraphicsLayer()
            val s = sigma.toPx()
            val pad = (s * 3f).toInt() + 2
            onDrawBehind {
                if (src != null) {
                    layer.renderEffect = BlurEffect(s, s, TileMode.Clamp)
                    layer.colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(saturation) })
                    val p = pos
                    layer.record(size = IntSize(size.width.toInt() + pad * 2, size.height.toInt() + pad * 2)) {
                        translate(-p.x + pad, -p.y + pad) { drawLayer(src) }
                    }
                    translate(-pad.toFloat(), -pad.toFloat()) { drawLayer(layer) }
                }
            }
        }
}

/**
 * Liquid glass, ported from the CSS reference: real backdrop blur + saturate, a very light fill, 1.5dp white rim,
 * inset top highlight, inset bottom shade, big soft drop shadow. [gloss] = button style (160deg gradient + curved
 * top gloss, stronger blur/saturation); default = panel style.
 */
fun Modifier.liquidGlass(
    radius: Dp, tint: Color = Color.Unspecified, active: Boolean = false, depth: Float = 1f,
    gloss: Boolean = false, blur: Boolean = true
): Modifier = composed {
    val dark = P.dark
    val acc = P.accent
    val shape = RoundedCornerShape(radius)
    val canBlur = blur && Build.VERSION.SDK_INT >= 31
    this
        .drawBehind {
            // 0 30px 60px rgba(0,0,0,.10) -> layered soft shadow
            val r = radius.toPx()
            val col = if (dark) Color.Black else Color(0xFF14284F)
            val base = (if (dark) 0.20f else 0.085f) * depth
            for (i in 1..8) {
                val g = i * 3.4.dp.toPx()
                drawRoundRect(
                    col.copy(alpha = base * (1f - i / 9f)),
                    topLeft = Offset(-g * 0.6f, -g * 0.3f + 10.dp.toPx()),
                    size = Size(size.width + g * 1.2f, size.height + g * 1.2f),
                    cornerRadius = CornerRadius(r + g, r + g)
                )
            }
        }
        .clip(shape)
        .then(if (canBlur) Modifier.backdropBlur(if (gloss) 10.dp else 7.dp, if (gloss) 1.6f else 1.4f) else Modifier)
        .drawBehind {
            val w = size.width; val h = size.height
            val r = radius.toPx()
            // fill
            if (gloss) {
                drawRect(
                    Brush.linearGradient(
                        if (dark) listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.02f))
                        else listOf(Color.White.copy(alpha = if (canBlur) 0.50f else 0.72f), Color.White.copy(alpha = if (canBlur) 0.10f else 0.34f)),
                        start = Offset(w * 0.25f, 0f), end = Offset(w * 0.75f, h)
                    )
                )
            } else {
                drawRect(Color.White.copy(alpha = if (dark) (if (canBlur) 0.05f else 0.10f) else (if (canBlur) 0.16f else 0.55f)))
            }
            if (tint != Color.Unspecified) drawRect(tint.copy(alpha = if (dark) 0.18f else 0.14f))
            if (active) drawRect(Brush.verticalGradient(listOf(acc.copy(alpha = 0.26f), acc.copy(alpha = 0.06f))))
            // inset bottom shade (-6px 14px)
            val shadeH = minOf(h * 0.45f, 20.dp.toPx())
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.Transparent, if (gloss && !dark) Color.White.copy(alpha = 0.22f) else Color.Black.copy(alpha = if (dark) 0.28f else 0.05f)),
                    startY = h - shadeH, endY = h
                ),
                topLeft = Offset(0f, h - shadeH), size = Size(w, shadeH)
            )
            // curved top gloss (::before): inset 14dp, 40% high
            if (gloss) {
                val gh = h * 0.40f
                drawRoundRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = if (dark) 0.16f else 0.70f), Color.Transparent),
                        startY = 2.dp.toPx(), endY = 2.dp.toPx() + gh
                    ),
                    topLeft = Offset(minOf(14.dp.toPx(), w * 0.1f), 2.dp.toPx()),
                    size = Size(w - 2f * minOf(14.dp.toPx(), w * 0.1f), gh),
                    cornerRadius = CornerRadius(gh, gh)
                )
            }
            // inset top highlight (0 1px 1px white .9)
            val inset = 1.dp.toPx()
            drawRoundRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = if (dark) 0.22f else 0.95f), Color.Transparent),
                    startY = 0f, endY = minOf(h * 0.35f, 34.dp.toPx())
                ),
                topLeft = Offset(inset, inset), size = Size(w - inset * 2, h - inset * 2),
                cornerRadius = CornerRadius(r - inset, r - inset), style = Stroke(1.5.dp.toPx())
            )
        }
        // 1.5px rim: white .65 (buttons .75); dark .14
        .border(1.5.dp, Color.White.copy(alpha = if (dark) 0.16f else if (gloss) 0.80f else 0.70f), shape)
}

/** Glossy accent fill for the active state: lit gradient, curved top gloss, inset light, and a wide coloured glow. */
fun Modifier.glossFill(radius: Dp, alpha: Float = 1f, glow: Boolean = true): Modifier = composed {
    val acc = P.accent; val acc2 = P.accent2
    val shape = RoundedCornerShape(radius)
    this
        .drawBehind {
            if (glow && alpha > 0.01f) {
                val r = radius.toPx()
                // 0 18px 40px accent .45  +  0 0 60px 10px accent .35
                for (i in 1..9) {
                    val g = i * 4.dp.toPx()
                    drawRoundRect(
                        acc.copy(alpha = 0.30f * (1f - i / 10f) * alpha),
                        topLeft = Offset(-g, -g + 8.dp.toPx()),
                        size = Size(size.width + g * 2f, size.height + g * 2f),
                        cornerRadius = CornerRadius(r + g, r + g)
                    )
                }
            }
        }
        .clip(shape)
        .drawBehind {
            val w = size.width; val h = size.height
            val r = radius.toPx()
            drawRect(
                Brush.linearGradient(
                    listOf(acc2.copy(alpha = 0.95f), acc.copy(alpha = 0.95f), acc.copy(red = acc.red * 0.80f, green = acc.green * 0.80f, blue = acc.blue * 0.92f)),
                    start = Offset(w * 0.2f, 0f), end = Offset(w * 0.8f, h)
                ), alpha = alpha
            )
            // inset bottom colour (-10px 18px)
            val shadeH = minOf(h * 0.5f, 22.dp.toPx())
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, acc2.copy(alpha = 0.35f)), startY = h - shadeH, endY = h),
                topLeft = Offset(0f, h - shadeH), size = Size(w, shadeH), alpha = alpha
            )
            // curved top gloss
            val gh = h * 0.40f
            val gx = minOf(14.dp.toPx(), w * 0.1f)
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.65f), Color.Transparent), startY = 2.dp.toPx(), endY = 2.dp.toPx() + gh),
                topLeft = Offset(gx, 2.dp.toPx()), size = Size(w - 2f * gx, gh), cornerRadius = CornerRadius(gh, gh), alpha = alpha
            )
            // inset top highlight
            val inset = 1.dp.toPx()
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.90f), Color.Transparent), startY = 0f, endY = minOf(h * 0.35f, 34.dp.toPx())),
                topLeft = Offset(inset, inset), size = Size(w - inset * 2, h - inset * 2),
                cornerRadius = CornerRadius(r - inset, r - inset), style = Stroke(1.5.dp.toPx()), alpha = alpha
            )
        }
        .border(1.5.dp, Color.White.copy(alpha = 0.70f * alpha), shape)
}

// ---------------------------------------------------------------- 3D orb

/** A glass sphere with a refracted tint, rim light and a specular highlight. Used for slider and EQ thumbs. */
fun DrawScope.glassOrb(c: Offset, r: Float, tint: Color, ring: Boolean = true) {
    // contact shadow
    drawCircle(Color.Black.copy(alpha = 0.30f), r * 1.08f, c + Offset(0f, r * 0.32f))
    drawCircle(Color.Black.copy(alpha = 0.14f), r * 1.35f, c + Offset(0f, r * 0.42f))
    // coloured bloom
    drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = 0.42f), Color.Transparent), c, r * 2.3f), r * 2.3f, c)
    // body
    drawCircle(
        Brush.radialGradient(
            listOf(Color.White, Color(0xFFEAF2FF), tint.copy(alpha = 0.60f).compositeOver(Color.White)),
            center = c + Offset(-r * 0.25f, -r * 0.35f), radius = r * 1.45f
        ), r, c
    )
    if (ring) drawCircle(tint.copy(alpha = 0.85f), r * 0.80f, c, style = Stroke(r * 0.16f))
    // bottom refraction
    drawCircle(
        Brush.radialGradient(listOf(tint.copy(alpha = 0.45f), Color.Transparent), c + Offset(0f, r * 0.75f), r * 0.9f), r, c
    )
    // rim + specular
    drawCircle(Color.White.copy(alpha = 0.95f), r, c, style = Stroke(1.2f))
    drawOval(Color.White.copy(alpha = 0.92f), c + Offset(-r * 0.52f, -r * 0.82f), Size(r * 0.95f, r * 0.42f))
}
