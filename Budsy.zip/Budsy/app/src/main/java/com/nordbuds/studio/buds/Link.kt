package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.nordbuds.studio.protocol.Protocol
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/** RFCOMM transport for the reverse-engineered control channel. */
@SuppressLint("MissingPermission")
class Link(
    private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit,
    private val onTraffic: (String, Protocol.Frame) -> Unit = { _, _ -> }
) {
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    private var seq = 0x20
    private var lastWriteError: String? = null
    @Volatile var lastFailureReason: String? = null
        private set
    @Volatile private var generation = 0
    private val lock = Any()
    private data class PendingWrite(val bytes: ByteArray, val generation: Int)
    private val writes = Channel<PendingWrite>(capacity = 64)

    init {
        // A single IO consumer preserves RFCOMM byte order and keeps socket writes off the UI thread.
        scope.launch(Dispatchers.IO) {
            for (pending in writes) {
                val stream = synchronized(lock) {
                    if (active && pending.generation == generation) output else null
                } ?: continue
                try {
                    synchronized(lock) {
                        if (active && pending.generation == generation && output === stream) {
                            stream.write(pending.bytes)
                            stream.flush()
                        }
                    }
                } catch (e: Exception) {
                    lastWriteError = e.message
                    close(false)
                    onDropped("Bluetooth control connection lost while writing")
                }
            }
        }
    }

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = false)
        lastFailureReason = null
        expectedClose = false
        val token = synchronized(lock) { generation += 1; generation }

        // BLE advertisements are not necessarily bondable RFCOMM endpoints. The vendor
        // BR control channel requires an Android bond on many products, so request the
        // normal system pairing flow before SDP/RFCOMM instead of silently failing.
        if (device.bondState != BluetoothDevice.BOND_BONDED) {
            if (device.bondState == BluetoothDevice.BOND_NONE) {
                val started = try { device.createBond() } catch (_: Exception) { false }
                if (!started && device.bondState != BluetoothDevice.BOND_BONDING &&
                    device.bondState != BluetoothDevice.BOND_BONDED) {
                    lastFailureReason = "Android Bluetooth pairing could not be started"
                    return@withContext null
                }
            }
            var waited = 0
            while (device.bondState == BluetoothDevice.BOND_BONDING && waited < 30_000) {
                kotlinx.coroutines.delay(500)
                waited += 500
            }
            if (device.bondState != BluetoothDevice.BOND_BONDED) {
                lastFailureReason = "Pairing was not completed. Accept the Android Bluetooth pairing prompt and retry."
                return@withContext null
            }
        }

        val uuids = try { device.fetchUuidsWithSdp(); Thread.sleep(700); device.uuids?.map { it.uuid } ?: emptyList() } catch (_: Exception) { emptyList() }
        // The earbuds' OPPO control service goes first (it is the one that answers); the plain SPP UUID is the last resort.
        // It is always tried even when the cached SDP record list does not contain it yet.
        val vendor = uuids.filterNot { isAudioUuid(it) || it == SPP_UUID }
        val candidates = (listOf(OPO_UUID) + vendor + SPP_UUID).distinct()
        for (uuid in candidates) {
            var s: BluetoothSocket? = null
            try {
                s = device.createRfcommSocketToServiceRecord(uuid)
                try {
                    s.connect()
                } catch (secureFailure: Exception) {
                    try { s.close() } catch (_: Exception) {}
                    // Some legacy earbud control channels expose only insecure RFCOMM.
                    // Keep this fallback scoped to the standard SPP UUID; do not weaken
                    // arbitrary vendor services without evidence they support it.
                    if (uuid != SPP_UUID) throw secureFailure
                    s = device.createInsecureRfcommSocketToServiceRecord(uuid)
                    s.connect()
                }
                val input = s.inputStream
                socket = s; output = s.outputStream; active = true
                Thread({ reader(input, token) }, "Budsy-Bluetooth-reader-$token").apply { isDaemon = true; start() }
                return@withContext device
            } catch (_: Exception) { try { s?.close() } catch (_: Exception) {} }
        }
        lastFailureReason = "No supported RFCOMM control service accepted the connection"
        null
    }

    /** Sends a request with the next sequence number (always 0x01..0xFE; 0xFF means "push from the earbuds"). */
    fun write(cmd: Int, group: Int, payload: IntArray) {
        val bytes: ByteArray
        val frame: Protocol.Frame
        synchronized(lock) { seq = Protocol.nextSeq(seq); frame = Protocol.Frame(cmd and 0xff, group and 0xff, seq, payload.copyOf()); bytes = Protocol.buildFrame(cmd, group, seq, payload) }
        onTraffic("TX", frame)
        send(bytes)
    }

    /** Answers a request from the earbuds: same command with bit 7 set and the request's own sequence number. */
    fun reply(req: Protocol.Frame, payload: IntArray) {
        val reply = Protocol.Frame(req.lo, req.hi or 0x80, req.seq, payload.copyOf())
        onTraffic("TX", reply)
        send(Protocol.buildFrame(req.lo, req.hi or 0x80, req.seq, payload))
    }

    private fun send(bytes: ByteArray) {
        val token = synchronized(lock) {
            if (!active || output == null) return
            generation
        }
        if (writes.trySend(PendingWrite(bytes.copyOf(), token)).isFailure) {
            lastWriteError = "RFCOMM write queue is full"
            close(false)
            onDropped("Bluetooth command queue is full; connection reset")
        }
    }

    private fun reader(input: InputStream, token: Int) {
        val parser = Protocol.Parser(); val buf = ByteArray(512)
        try {
            while (active && token == generation) {
                val n = input.read(buf); if (n < 0) break
                parser.feed(buf.copyOf(n)).forEach { if (token == generation) { onTraffic("RX", it); onFrame(it) } }
            }
        } catch (_: Exception) { }
        if (token == generation && active) {
            val shouldNotify = !expectedClose
            close(false)
            if (shouldNotify) onDropped("Bluetooth disconnected")
        }
    }

    fun close(expected: Boolean = true) {
        expectedClose = expected; active = false
        synchronized(lock) { generation += 1 }
        try { socket?.close() } catch (_: Exception) { }
        socket = null; output = null
    }

    /** Standard Bluetooth-base audio/telephony profiles only (A2DP, HFP, AVRCP...). Vendor UUIDs such as 0000079A-D102-... are NOT audio. */
    private fun isAudioUuid(u: UUID): Boolean {
        val s = u.toString().uppercase()
        if (!s.endsWith("-0000-1000-8000-00805F9B34FB")) return false
        val short = s.substring(4, 8)
        return short.startsWith("110") || short.startsWith("111")
    }
    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        /** HeyMelody BR/RFCOMM control UUID from BaseBRDevice.smali (not the 079A GATT service). */
        private val OPO_UUID: UUID = UUID.fromString("00001107-D102-11E1-9B23-00025B00A5A5")
    }
}
