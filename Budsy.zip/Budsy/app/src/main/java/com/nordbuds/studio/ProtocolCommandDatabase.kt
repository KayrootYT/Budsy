package com.nordbuds.studio

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local evidence-backed command catalogue. "Verified" is an explicit user decision
 * after repeated controlled captures; the app never auto-promotes candidates.
 */
object ProtocolCommandDatabase {
    private const val PREFS = "budsy_protocol_command_db"
    private const val KEY_ENTRIES = "entries_v1"
    private const val KEY_PROFILE = "active_profile_v1"
    private var prefs: SharedPreferences? = null

    val profiles = listOf("Unassigned", "OnePlus Nord Buds 3", "OnePlus Nord Buds 3 Pro")
    var activeProfile = mutableStateOf(profiles.first())
        private set

    data class Entry(
        val id: Long,
        val profile: String,
        val transport: String,
        val command: String,
        val label: String,
        val status: String,
        val evidence: String,
        val sample: String,
        val createdAt: Long
    ) {
        fun line(): String = "$profile · $transport · $command · $label · $status"
    }

    val entries = mutableStateListOf<Entry>()

    fun attach(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        activeProfile.value = prefs?.getString(KEY_PROFILE, profiles.first())
            ?.takeIf { it in profiles } ?: profiles.first()
        restore()
        if (entries.isEmpty()) seedObserved()
    }

    fun selectProfile(profile: String) {
        if (profile !in profiles) return
        activeProfile.value = profile
        prefs?.edit()?.putString(KEY_PROFILE, profile)?.apply()
    }

    fun visibleEntries(): List<Entry> = entries.filter { it.profile == activeProfile.value }
        .sortedWith(compareByDescending<Entry> { it.status == "VERIFIED" }.thenByDescending { it.createdAt })


    data class ProfileSummary(
        val profile: String,
        val total: Int,
        val observed: Int,
        val verified: Int,
        val transports: Set<String>
    )

    fun profileSummary(profile: String = activeProfile.value): ProfileSummary {
        val rows = entries.filter { it.profile == profile }
        return ProfileSummary(profile, rows.size, rows.count { it.status != "VERIFIED" },
            rows.count { it.status == "VERIFIED" }, rows.map { it.transport }.toSet())
    }

    /** Import a differential signal as OBSERVED only; ATT signatures are not proprietary command IDs. */
    fun addCandidate(candidate: CommandMappingEngine.Candidate, captureLabel: String): Boolean {
        val profile = activeProfile.value
        val signature = candidate.signature
        val command = Regex("CMD 0x([0-9a-fA-F]{4})").find(signature)?.groupValues?.get(1)
            ?.let { "0x${it.uppercase()}" }
            ?: signature.take(72)
        val transport = candidate.transport.take(20)
        val label = "Differential candidate · ${candidate.transport}".take(100)
        val evidence = "Baseline/current comparison from ${captureLabel.ifBlank { "unnamed HCI capture" }}. " +
            "Count ${candidate.baselineCount}→${candidate.currentCount}; delta ${candidate.delta}. " +
            "This is correlation only; repeat controlled positive and negative captures before assigning meaning."
        if (entries.any { it.profile == profile && it.command == command && it.evidence.contains(captureLabel) }) return false
        val now = System.currentTimeMillis()
        entries += Entry(now * 1000L + entries.size, profile, transport, command, label,
            "OBSERVED", evidence.take(500), candidate.samples.joinToString(" | ").take(240), now)
        persist()
        return true
    }

    /** Promotion requires a target-device profile, two distinct positive capture references and a passed negative control. */
    fun verifyWithCaptureEvidence(
        id: Long,
        verificationNote: String,
        positiveCaptureA: String,
        positiveCaptureB: String,
        negativeControlPassed: Boolean
    ): Boolean {
        val i = entries.indexOfFirst { it.id == id }
        if (i < 0) return false
        val entry = entries[i]
        val a = positiveCaptureA.trim(); val b = positiveCaptureB.trim()
        val note = verificationNote.trim()
        if (entry.profile == "Unassigned" || a.isBlank() || b.isBlank() || a.equals(b, true) ||
            !negativeControlPassed || note.length < 12 || note.equals(entry.evidence.trim(), true)) return false
        entries[i] = entry.copy(status = "VERIFIED", evidence =
            (entry.evidence + "\nVerification: " + note + "\nPositive captures: " + a + ", " + b + "\nNegative control: PASS").take(800))
        persist()
        return true
    }

    fun isValidCommandHex(command: String): Boolean {
        val cmd = command.trim().uppercase().removePrefix("0X")
        return cmd.matches(Regex("[0-9A-F]{2,8}")) && cmd.length % 2 == 0
    }

    fun addObserved(transport: String, command: String, label: String, evidence: String, sample: String = ""): Boolean {
        val cmd = command.trim().uppercase().removePrefix("0X")
        if (!isValidCommandHex(cmd)) return false
        val cleanLabel = label.trim().take(100)
        val cleanEvidence = evidence.trim().take(500)
        if (cleanLabel.isBlank() || cleanEvidence.isBlank()) return false
        val now = System.currentTimeMillis()
        val entry = Entry(now * 1000L + entries.size, activeProfile.value, transport.take(20),
            "0x$cmd", cleanLabel, "OBSERVED", cleanEvidence, sample.trim().take(240), now)
        entries.add(entry)
        persist()
        return true
    }

    fun delete(id: Long) {
        entries.removeAll { it.id == id }
        persist()
    }

    fun exportJson(): String = JSONObject().apply {
        put("format", "budsy-command-database-v1")
        put("activeProfile", activeProfile.value)
        put("entries", JSONArray().apply {
            entries.forEach { e -> put(JSONObject().apply {
                put("id", e.id); put("profile", e.profile); put("transport", e.transport)
                put("command", e.command); put("label", e.label); put("status", e.status)
                put("evidence", e.evidence); put("sample", e.sample); put("createdAt", e.createdAt)
            }) }
        })
    }.toString(2)

    private fun seedObserved() {
        val now = System.currentTimeMillis()
        // These are observations from supplied protocol traces, not verified semantics
        // and not attributed to either Nord Buds model until a matching device capture exists.
        entries += Entry(now + 1, "Unassigned", "RFCOMM/BLE unknown", "0x0106",
            "Observed response · battery-like fields", "OBSERVED",
            "Trace shows fields 01=100, 02=100, 03=00. Case value meaning is unknown.",
            "RX 8106 00 03 01 64 02 64 03 00", now)
        entries += Entry(now + 2, "Unassigned", "RFCOMM/BLE unknown", "0x0109",
            "Observed response · wear-state candidate", "OBSERVED",
            "Repeated query/response observed; exact state semantics need controlled capture.",
            "RX 8109 00 03 01 03 02 03 03 04", now)
        entries += Entry(now + 3, "Unassigned", "RFCOMM/BLE unknown", "0x010C",
            "Observed response · mode/hold candidate", "OBSERVED",
            "Mode/hold bytes observed; mapping is not yet verified.",
            "RX 810c 00 01 01 02", now)
        entries += Entry(now + 4, "Unassigned", "RFCOMM/BLE unknown", "0x010D",
            "Observed response · gesture configuration candidate", "OBSERVED",
            "Feature ID/status pairs observed; individual IDs are not semantically labelled.",
            "RX 810d 00 07 06 00 0b 01 11 01 1b 01 1d 01", now)
        entries += Entry(now + 5, "Unassigned", "RFCOMM source evidence", "0x0418",
            "Custom EQ set-command · source-level candidate", "OBSERVED",
            "Confirmed from HeadsetCoreService.M0 / EqInfo: action, min, max, eqId, UTF-8 name length/name, band count and frequency-LE16/gain-byte records. This confirms the inner payload layout only; target-model support, outer-frame compatibility and live device behavior still require hardware read-back.",
            "HeyMelody SetCommandManager command id 1048 (0x0418)", now)
        persist()
    }

    private fun persist() {
        val array = JSONArray()
        entries.takeLast(2000).forEach { e ->
            array.put(JSONObject().apply {
                put("id",e.id); put("profile",e.profile); put("transport",e.transport)
                put("command",e.command); put("label",e.label); put("status",e.status)
                put("evidence",e.evidence); put("sample",e.sample); put("createdAt",e.createdAt)
            })
        }
        prefs?.edit()?.putString(KEY_ENTRIES,array.toString())
            ?.putString(KEY_PROFILE,activeProfile.value)?.apply()
    }

    private fun restore() {
        val raw = prefs?.getString(KEY_ENTRIES,null) ?: return
        runCatching {
            val a=JSONArray(raw)
            for (i in 0 until a.length()) {
                val o=a.getJSONObject(i)
                val profile=o.optString("profile","Unassigned")
                if (profile in profiles) entries += Entry(
                    o.optLong("id"),profile,o.optString("transport"),o.optString("command"),
                    o.optString("label"),o.optString("status","OBSERVED"),o.optString("evidence"),
                    o.optString("sample"),o.optLong("createdAt")
                )
            }
        }
    }
}
