package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper

/** Explicit BLE discovery. It is separate from classic bonded-device discovery and RFCOMM control. */
@SuppressLint("MissingPermission")
class BleScanner(
    context: Context,
    private val onResults: (List<FoundDevice>) -> Unit,
    private val onState: (Boolean, String?) -> Unit
) {
    data class FoundDevice(val device: BluetoothDevice, val name: String?, val rssi: Int, val lastSeenMs: Long)

    private val app = context.applicationContext
    private val adapter: BluetoothAdapter? = app.getSystemService(BluetoothManager::class.java)?.adapter
    private val main = Handler(Looper.getMainLooper())
    private val found = LinkedHashMap<String, FoundDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var running = false

    private val stopTask = Runnable { stopScan() }
    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device ?: return
            val name = result.scanRecord?.deviceName ?: try { d.name } catch (_: SecurityException) { null }
            synchronized(found) {
                val old = found[d.address]
                found[d.address] = FoundDevice(d, name ?: old?.name, result.rssi, System.currentTimeMillis())
            }
            publish()
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, it) }
        }

        override fun onScanFailed(errorCode: Int) {
            running = false
            main.removeCallbacks(stopTask)
            onState(false, "BLE scan failed (code $errorCode)")
        }
    }

    fun startScan(durationMs: Long = 15_000L): Boolean {
        if (running) stopScan()
        val a = adapter
        if (a == null || !a.isEnabled) {
            onState(false, "Bluetooth is unavailable or disabled")
            return false
        }
        val s = a.bluetoothLeScanner
        if (s == null) {
            onState(false, "BLE scanner unavailable")
            return false
        }
        synchronized(found) { found.clear() }
        scanner = s
        return try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0L)
                .build()
            s.startScan(null, settings, callback)
            running = true
            onState(true, null)
            main.removeCallbacks(stopTask)
            main.postDelayed(stopTask, durationMs.coerceIn(3_000L, 30_000L))
            true
        } catch (e: SecurityException) {
            onState(false, "Bluetooth scan permission denied")
            false
        } catch (e: Exception) {
            onState(false, e.message ?: "Unable to start BLE scan")
            false
        }
    }

    fun stopScan() {
        main.removeCallbacks(stopTask)
        val s = scanner
        scanner = null
        if (running && s != null) try { s.stopScan(callback) } catch (_: Exception) { }
        running = false
        onState(false, null)
    }

    private fun publish() {
        val snapshot = synchronized(found) {
            found.values.sortedWith(compareByDescending<FoundDevice> { isLikelyEarbud(it.name) }.thenByDescending { it.rssi })
        }
        main.post { onResults(snapshot) }
    }

    private fun isLikelyEarbud(name: String?): Boolean = name?.let {
        it.contains("bud", true) || it.contains("oppo", true) || it.contains("oneplus", true) || it.contains("heymelody", true)
    } == true
}
