package com.nordbuds.studio.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Source-grounded codecs for handlers recovered from the supplied HeyMelody APK.
 * These encode/decode payloads only; they do not open transports or send commands.
 * Firmware OTA is deliberately represented as an inspection-only protocol until
 * model-specific image validation, transfer acknowledgements and rollback are proven.
 */
object VendorAdvancedHandlers {
    object VoiceAssistant {
        const val QUERY = 0x0135 // HeadsetCoreService.V(): empty request payload
        const val QUERY_RESPONSE = 0x8103 // PollCommandManager.M() packed-switch -> parseGmnVoiceAssistConfig
        const val SET_CONTROL_TYPE = 0x0432 // HeadsetCoreService.S0(): one-byte payload
        const val SET_RESPONSE = 0x8432

        data class Config(val status: Int, val controlType: Int, val earphoneConnectState: Int, val rawFlags: Int)

        /** Query response is [status, flags]. Bit 0/1/2 map app control type 0/1/2; bit 7 means connected. */
        fun decodeQueryResponse(payload: ByteArray): Config {
            require(payload.size > 1) { "Voice-assistant query response needs status and flags" }
            val status = payload[0].toInt() and 0xff
            require(status == 0) { "Voice-assistant query failed with status $status" }
            val flags = payload[1].toInt() and 0xff
            val controlType = when {
                flags and 0x04 != 0 -> 2
                flags and 0x02 != 0 -> 1
                flags and 0x01 != 0 -> 0
                else -> -1
            }
            val connected = if (flags and 0x80 != 0) 1 else -1
            return Config(status, controlType, connected, flags)
        }

        /** HeyMelody maps app control types 0,1,2 to wire values 1,2,4 respectively. */
        fun encodeControlType(appControlType: Int): ByteArray = byteArrayOf(
            when (appControlType) {
                0 -> 1
                1 -> 2
                2 -> 4
                else -> throw IllegalArgumentException("Unsupported voice-assistant control type: $appControlType")
            }.toByte()
        )

        fun queryPayload(): ByteArray = byteArrayOf()

        /** Set-command response is status-only; zero means success in the source handler. */
        fun decodeSetStatus(payload: ByteArray): Int {
            require(payload.isNotEmpty()) { "Voice-assistant set response is empty" }
            return payload[0].toInt() and 0xff
        }
    }

    data class HearingPoint(val deviceType: Int, val frequencyType: Int, val dbValue: Int) {
        init {
            require(deviceType in 0..255)
            require(frequencyType in 0..255)
            require(dbValue in -128..127 || dbValue in 0..255)
        }
        fun encode(): ByteArray = byteArrayOf(deviceType.toByte(), frequencyType.toByte(), dbValue.toByte())
    }

    object Hearing {
        const val QUERY = 0x0116 // decimal 278
        const val SET_PROCESS = 0x040E // decimal 1038

        /** Query/list payload: count, N x (deviceType, frequencyType, dB), uid int32 big-endian. */
        fun encodeQuery(points: List<HearingPoint>, uid: Int): ByteArray {
            require(points.size <= 255)
            val out = ByteBuffer.allocate(1 + points.size * 3 + 4).order(ByteOrder.BIG_ENDIAN)
            out.put(points.size.toByte())
            points.forEach { out.put(it.encode()) }
            out.putInt(uid)
            return out.array()
        }

        /**
         * Process-hearing command payload from HeadsetCoreService.B0(). For action 1 or 3:
         * action, count, N x 3-byte records, uid int32 big-endian, optional platform-default
         * charset name bytes. Other action values are a one-byte action-only payload.
         */
        fun encodeProcess(action: Int, points: List<HearingPoint> = emptyList(), uid: Int = 0, name: String = ""): ByteArray {
            require(action in 0..255)
            if (action != 1 && action != 3) return byteArrayOf(action.toByte())
            require(points.isNotEmpty()) { "Hearing process action $action requires measurement records" }
            require(points.size <= 255)
            val nameBytes = name.toByteArray(Charsets.UTF_8)
            val out = ByteBuffer.allocate(1 + 1 + points.size * 3 + 4 + nameBytes.size).order(ByteOrder.BIG_ENDIAN)
            out.put(action.toByte())
            out.put(points.size.toByte())
            points.forEach { out.put(it.encode()) }
            out.putInt(uid)
            out.put(nameBytes)
            return out.array()
        }

        /** The lightweight switch path in HeadsetCoreService.v1(): [3, 1, device, freq, dB]. */
        fun encodeDetectionParameter(point: HearingPoint): ByteArray = byteArrayOf(3, 1) + point.encode()

        /** Decode fixed-size three-byte measurement records; trailing bytes are rejected. */
        fun decodePoints(bytes: ByteArray): List<HearingPoint> {
            require(bytes.size % 3 == 0) { "Hearing record payload must be a multiple of 3 bytes" }
            return bytes.asList().chunked(3).map {
                HearingPoint(it[0].toInt() and 0xff, it[1].toInt() and 0xff, it[2].toInt())
            }
        }
    }

    object MultiDevice {
        const val QUERY = 0x0112
        const val QUERY_RESPONSE = 0x8112

        /**
         * Peer operation (HeyMelody "operateMultiConnectHandheldDevice", command 0x0429, SET group).
         * Payload = [op, MAC[6]] with op 1 = connect, 2 = disconnect, 3 = unpair/remove (seen in the HeyMelody UI:
         * connect/disconnect confirm dialogs and unpairHandheldDevice). MAC is big-endian, as printed.
         */
        const val CMD_OPERATE = 0x0429
        const val OP_CONNECT = 1
        const val OP_DISCONNECT = 2
        const val OP_UNPAIR = 3

        fun buildOperatePayload(op: Int, address: String): ByteArray? {
            if (op !in OP_CONNECT..OP_UNPAIR) return null
            val parts = address.trim().split(":")
            if (parts.size != 6) return null
            val out = ByteArray(7)
            out[0] = op.toByte()
            for (i in 0..5) {
                val b = parts[i].toIntOrNull(16) ?: return null
                if (b !in 0..255) return null
                out[i + 1] = b.toByte()
            }
            return out
        }

        data class Peer(
            val address: String,
            val connectionState: Int,
            val isCurrentDevice: Boolean,
            val isMainAudioDevice: Boolean,
            val isAudioActive: Boolean,
            val deviceType: Int,
            val name: String
        )

        /**
         * Decodes the HeyMelody multi-connect response. The response's first byte is a
         * status code; on success the next byte is peer count. Each record is:
         * MAC[6], tailLength[1], connectionState[1], flags[1], nameLength[1], UTF-8 name.
         * tailLength is the length of state+flags+nameLength+name (3 + nameLength).
         * flags: bit0=current, bit1=main audio, bit2=audio active, bits3..5=device type.
         */
        fun decodeResponse(payload: ByteArray): List<Peer> {
            require(payload.size >= 2) { "Multi-device response needs status and count" }
            val status = payload[0].toInt() and 0xff
            require(status == 0) { "Multi-device query failed with status $status" }
            val count = payload[1].toInt() and 0xff
            var offset = 2
            val peers = ArrayList<Peer>(count)
            repeat(count) {
                require(offset + 10 <= payload.size) { "Truncated multi-device record header at $offset" }
                val address = payload.copyOfRange(offset, offset + 6).joinToString(":") { "%02X".format(it.toInt() and 0xff) }
                val tailLength = payload[offset + 6].toInt() and 0xff
                val state = payload[offset + 7].toInt() and 0xff
                val flags = payload[offset + 8].toInt() and 0xff
                val nameLength = payload[offset + 9].toInt() and 0xff
                require(tailLength == 3 + nameLength) { "Invalid multi-device record length $tailLength for name length $nameLength" }
                val end = offset + 10 + nameLength
                require(end <= payload.size) { "Truncated multi-device name at $offset" }
                val name = payload.copyOfRange(offset + 10, end).toString(Charsets.UTF_8)
                peers += Peer(
                    address = address,
                    connectionState = state,
                    isCurrentDevice = flags and 0x01 != 0,
                    isMainAudioDevice = flags and 0x02 != 0,
                    isAudioActive = flags and 0x04 != 0,
                    deviceType = (flags ushr 3) and 0x07,
                    name = name
                )
                offset = end
            }
            require(offset == payload.size) { "Unexpected trailing multi-device bytes: ${payload.size - offset}" }
            return peers
        }
    }

    object FirmwareOta {
        // UpgradeStateMachine command IDs from p250r8.d.
        const val SYNC_REQ = 0x0300
        const val SYNC_CFM = 0x8300
        const val START_REQ = 0x0301
        const val START_CFM = 0x8301
        const val DATA_REQ = 0x0302
        const val DATA_CFM = 0x8302
        const val BLOCK_VERIFY_REQ = 0x0303
        const val BLOCK_VERIFY_CFM = 0x8303
        const val VALIDATION_DONE_REQ = 0x0304
        const val VALIDATION_DONE_CFM = 0x8304
        const val TRANSFER_COMPLETE_IND = 0x0305
        const val TRANSFER_COMPLETE_RSP = 0x8305
        const val COMMIT_REQ = 0x0306
        const val COMMIT_CFM = 0x8306
        const val ABORT_REQ = 0x0307
        const val ABORT_CFM = 0x8307
        const val ERROR_IND = 0x0308
        const val ERROR_RSP = 0x8308
        const val SWITCH_REQ = 0x030A
        const val SWITCH_CFM = 0x830A
        const val MTU_REQ = 0x030B
        const val MTU_CFM = 0x830B

        /** Legacy sync payload: up to four trailing package-hash bytes, then device type. */
        fun encodeLegacySync(hashTail: ByteArray, deviceType: Int): ByteArray {
            require(deviceType in 0..255)
            val out = ByteArray(5)
            val copyCount = minOf(hashTail.size, 4)
            if (copyCount > 0) hashTail.copyInto(out, 0, hashTail.size - copyCount, hashTail.size)
            out[4] = deviceType.toByte()
            return out
        }

        /** New sync payload: four reserved zero bytes, device type, section count. */
        fun encodeSectionSync(deviceType: Int, sectionCount: Int): ByteArray {
            require(deviceType in 0..255 && sectionCount in 0..255)
            return byteArrayOf(0, 0, 0, 0, deviceType.toByte(), sectionCount.toByte())
        }

        /** Optional MTU request payload is the device type byte. */
        fun encodeMtuRequest(deviceType: Int): ByteArray {
            require(deviceType in 0..255)
            return byteArrayOf(deviceType.toByte())
        }

        data class SyncConfirmation(
            val status: Int,
            val deviceType: Int? = null,
            val resumePoint: Int? = null,
            val flags: Int? = null,
            val resumeOffset: Long? = null,
            val blockSize: Int? = null
        )
        data class StartConfirmation(val status: Int, val resumePoint: Int? = null, val fileOffset: Long? = null)
        data class DataConfirmation(val status: Int, val retryDelayMs: Int? = null)
        data class MtuConfirmation(val status: Int, val deviceType: Int? = null, val mtu: Int? = null)
        data class BlockVerifyConfirmation(val status: Int, val requestedResumeOffset: Long? = null, val retryCurrentBlock: Boolean = false)

        fun emptyControlPayload(): ByteArray = byteArrayOf()
        fun encodeSwitchRequest(target: Int): ByteArray {
            require(target in 0..255)
            return byteArrayOf(target.toByte())
        }
        fun encodeTransferCompleteResponse(): ByteArray = byteArrayOf(0)

        /** Block CFM status 0 succeeds; status 0x13 carries an explicit retry offset LE32. */
        fun decodeBlockVerifyConfirmation(payload: ByteArray): BlockVerifyConfirmation {
            require(payload.isNotEmpty()) { "OTA block-verify confirmation is empty" }
            val status = payload[0].toInt() and 0xff
            if (status == 0x13) {
                require(payload.size >= 5) { "OTA block-verify retry response needs a 4-byte offset" }
                return BlockVerifyConfirmation(status, u32le(payload, 1))
            }
            if (status == 0x11) return BlockVerifyConfirmation(status, retryCurrentBlock = true)
            return BlockVerifyConfirmation(status)
        }

        /** DATA CFM is exactly [status, retryDelay LE16]. */
        fun decodeDataConfirmation(payload: ByteArray): DataConfirmation {
            require(payload.isNotEmpty()) { "OTA data confirmation is empty" }
            val status = payload[0].toInt() and 0xff
            if (status != 0) return DataConfirmation(status)
            require(payload.size == 3) { "OTA data confirmation must be exactly 3 bytes" }
            return DataConfirmation(status, u16le(payload, 1))
        }

        /** GET_MTU CFM is [status, deviceType, mtu LE16]. */
        fun decodeMtuConfirmation(payload: ByteArray): MtuConfirmation {
            require(payload.size >= 4) { "OTA MTU confirmation must be at least 4 bytes" }
            return MtuConfirmation(payload[0].toInt() and 0xff, payload[1].toInt() and 0xff, u16le(payload, 2))
        }

        /** START CFM fields used by the source state machine: status, byte1, resumePoint, offset LE32. */
        fun decodeStartConfirmation(payload: ByteArray): StartConfirmation {
            require(payload.isNotEmpty()) { "OTA start confirmation is empty" }
            val status = payload[0].toInt() and 0xff
            if (status != 0) return StartConfirmation(status)
            require(payload.size >= 7) { "OTA start confirmation must be at least 7 bytes" }
            val resume = payload[2].toInt() and 0xff
            val offset = u32le(payload, 3)
            return StartConfirmation(status, resume, offset)
        }

        /** Sync CFM fields verified in source: status, device type, resume point, flags, offset LE32, block size LE16. */
        fun decodeSyncConfirmation(payload: ByteArray): SyncConfirmation {
            require(payload.isNotEmpty()) { "OTA sync confirmation is empty" }
            val status = payload[0].toInt() and 0xff
            if (status != 0) return SyncConfirmation(status)
            require(payload.size >= 14) { "OTA sync confirmation must be at least 14 bytes" }
            val deviceType = payload[1].toInt() and 0xff
            val resumePoint = payload[2].toInt() and 0xff
            val offset = u32le(payload, 4)
            val blockSize = u16le(payload, 8)
            return SyncConfirmation(status, deviceType, resumePoint, payload[3].toInt() and 0xff, offset, blockSize)
        }

        /**
         * START request metadata format observed in UpgradeStateMachine. The six-byte legacy
         * form is [deviceType, upgradeType, compressedSize LE32]. Newer 142-byte form appends
         * package type, raw size, section id, package hash id, 32-byte section hash, 3-byte
         * software version, 24-byte build time, 32-byte name and 32-byte compressed hash.
         */
        fun encodeStartMetadata(
            deviceType: Int, upgradeType: Int, compressedSize: Long,
            pkgType: Int? = null, rawSize: Long? = null, sectionId: Long? = null,
            packageHashId: Long? = null, sectionHash: ByteArray? = null,
            softwareVersion: ByteArray? = null, buildTime: ByteArray? = null,
            name: ByteArray? = null, compressedHash: ByteArray? = null
        ): ByteArray {
            require(deviceType in 0..255 && upgradeType in 0..255)
            require(compressedSize in 0..0xffffffffL)
            val extended = pkgType != null || rawSize != null || sectionId != null || packageHashId != null ||
                sectionHash != null || softwareVersion != null || buildTime != null || name != null || compressedHash != null
            if (!extended) {
                return ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN)
                    .put(deviceType.toByte()).put(upgradeType.toByte()).putInt(compressedSize.toInt()).array()
            }
            require(pkgType != null && rawSize != null && sectionId != null && packageHashId != null &&
                sectionHash != null && softwareVersion != null && buildTime != null && name != null && compressedHash != null) {
                "All extended OTA metadata fields must be supplied together"
            }
            require(pkgType in 0..255 && rawSize in 0..0xffffffffL && sectionId in 0..0xffffffffL && packageHashId in 0..0xffffffffL)
            require(sectionHash.size == 32 && softwareVersion.size == 3 && buildTime.size == 24 && name.size == 32 && compressedHash.size == 32)
            return ByteBuffer.allocate(142).order(ByteOrder.LITTLE_ENDIAN)
                .put(deviceType.toByte()).put(upgradeType.toByte()).putInt(compressedSize.toInt())
                .put(pkgType.toByte()).putInt(rawSize.toInt()).putInt(sectionId.toInt()).putInt(packageHashId.toInt())
                .put(sectionHash).put(softwareVersion).put(buildTime).put(name).put(compressedHash).array()
        }

        /** Data request prefix is a 4-byte little-endian absolute file offset. Not a transport sender. */
        fun encodeDataChunk(offset: Long, data: ByteArray): ByteArray {
            require(offset in 0..0xffffffffL)
            require(data.isNotEmpty())
            return ByteBuffer.allocate(4 + data.size).order(ByteOrder.LITTLE_ENDIAN).putInt(offset.toInt()).put(data).array()
        }

        /** Block verification request is [blockOffset LE32, CRC32 LE32] in the recovered state machine. */
        fun encodeBlockVerification(offset: Long, crc32: Long): ByteArray {
            require(offset in 0..0xffffffffL && crc32 in 0..0xffffffffL)
            return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(offset.toInt()).putInt(crc32.toInt()).array()
        }

        fun decodeStatus(payload: ByteArray): Int {
            require(payload.isNotEmpty()) { "OTA response has no status byte" }
            return payload[0].toInt() and 0xff
        }

        private fun u16le(b: ByteArray, i: Int) = (b[i].toInt() and 0xff) or ((b[i + 1].toInt() and 0xff) shl 8)
        private fun u32le(b: ByteArray, i: Int): Long = (b[i].toLong() and 0xff) or
            ((b[i + 1].toLong() and 0xff) shl 8) or ((b[i + 2].toLong() and 0xff) shl 16) or
            ((b[i + 3].toLong() and 0xff) shl 24)
    }
}
