package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import com.nordbuds.studio.protocol.Protocol
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import java.util.ArrayDeque
import java.util.UUID

/** HeyMelody 0x079A BLE transport. Complete protocol frames are written without response;
 * notifications carry replies. Unknown ATT fragmentation is deliberately not guessed. */
@SuppressLint("MissingPermission")
class GattLink(
    private val context: Context,
    private val onState: (State, String?) -> Unit,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit = {}
) : BluetoothGattCallback() {
    enum class State { DISCONNECTED, CONNECTING, DISCOVERING, READY, FAILED }
    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var writeChar: BluetoothGattCharacteristic? = null
    @Volatile private var ready = false
    @Volatile private var mtu = 23
    @Volatile private var mtuPending = false
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val parser = Protocol.Parser()
    private val queue = ArrayDeque<ByteArray>()
    private val lock = Any()
    private var writing = false
    private var seq = 0x20
    private var readySignal = CompletableDeferred<Boolean>()

    suspend fun connect(device: BluetoothDevice): Boolean {
        close(false); readySignal = CompletableDeferred(); onState(State.CONNECTING, null)
        gatt = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(context, false, this, BluetoothDevice.TRANSPORT_LE)
               else device.connectGatt(context, false, this)
        return try { withTimeout(7_000) { readySignal.await() } } catch (_: Exception) {
            fail("GATT setup timed out"); false
        }
    }
    override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
        if (status != BluetoothGatt.GATT_SUCCESS) { fail("GATT connection status=$status"); closeGatt(g); return }
        when (newState) {
            BluetoothProfile.STATE_CONNECTED -> {
                onState(State.DISCOVERING, null)
                // Ask for a larger ATT MTU first; discovery starts from onMtuChanged (or a short timeout).
                mtuPending = true
                val asked = Build.VERSION.SDK_INT >= 21 && try { g.requestMtu(REQUESTED_MTU) } catch (_: Exception) { false }
                if (!asked) { mtuPending = false; startDiscovery(g) }
                else handler.postDelayed({ if (mtuPending) { mtuPending = false; startDiscovery(g) } }, 1500)
            }
            BluetoothProfile.STATE_DISCONNECTED -> { ready = false; writeChar = null; if (!readySignal.isCompleted) readySignal.complete(false); onState(State.DISCONNECTED, null); onDropped("GATT disconnected") }
        }
    }
    override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
        if (status != BluetoothGatt.GATT_SUCCESS) { fail("GATT discovery status=$status"); return }
        val service = g.getService(SERVICE_UUID)
        val w = service?.getCharacteristic(WRITE_UUID); val n = service?.getCharacteristic(NOTIFY_UUID)
        if (w == null || n == null) { fail("HeyMelody GATT service/write/notify missing"); return }
        if ((w.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) { fail("GATT write characteristic is not writable"); return }
        if ((n.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) == 0) { fail("GATT notify characteristic is unsupported"); return }
        writeChar = w
        if (!g.setCharacteristicNotification(n, true)) { fail("Cannot enable GATT notifications"); return }
        val d = n.getDescriptor(CCCD_UUID) ?: run { fail("CCCD descriptor missing"); return }
        val v = if ((n.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        val ok = if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(d, v) == BluetoothGatt.GATT_SUCCESS else {
            @Suppress("DEPRECATION") d.value = v
            @Suppress("DEPRECATION") g.writeDescriptor(d)
        }
        if (!ok) fail("Could not subscribe to notifications")
    }
    override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
        if (d.uuid == CCCD_UUID) if (status == BluetoothGatt.GATT_SUCCESS) {
            ready = true; onState(State.READY, null); if (!readySignal.isCompleted) readySignal.complete(true)
        } else fail("Notification subscription failed: $status")
    }
    override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) { if (c.uuid == NOTIFY_UUID) c.value?.let(::accept) }
    override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) { if (c.uuid == NOTIFY_UUID) accept(value) }
    override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
        synchronized(lock) { writing = false; if (status != BluetoothGatt.GATT_SUCCESS) { queue.clear(); fail("GATT write failed: $status") } else dispatchLocked() }
    }
    override fun onMtuChanged(g: BluetoothGatt, mtuValue: Int, status: Int) {
        if (status == BluetoothGatt.GATT_SUCCESS) mtu = mtuValue
        if (mtuPending) { mtuPending = false; startDiscovery(g) }
    }
    private fun startDiscovery(g: BluetoothGatt) { if (!g.discoverServices()) fail("Service discovery could not start") }
    /** Largest complete protocol frame that fits one ATT write right now. */
    val maxFrameBytes: Int get() = mtu - 3
    private fun accept(b: ByteArray) { synchronized(parser) { parser.feed(b).forEach(onFrame) } }
    fun write(cmd: Int, group: Int, payload: IntArray) { synchronized(lock) { seq = Protocol.nextSeq(seq); enqueueLocked(Protocol.buildFrame(cmd, group, seq, payload)) } }
    fun reply(req: Protocol.Frame, payload: IntArray) { synchronized(lock) { enqueueLocked(Protocol.buildFrame(req.lo, req.hi or 0x80, req.seq, payload)) } }
    private fun enqueueLocked(bytes: ByteArray) {
        if (!ready) { fail("GATT is not ready"); return }
        if (bytes.size > mtu - 3) { fail("Frame ${bytes.size}B exceeds ATT payload ${mtu - 3}B; RFCOMM fallback required"); return }
        queue.addLast(bytes); dispatchLocked()
    }
    private fun dispatchLocked() {
        if (writing || queue.isEmpty() || !ready) return
        val g = gatt ?: return; val c = writeChar ?: return; val b = queue.removeFirst(); writing = true
        val result = if (Build.VERSION.SDK_INT >= 33) g.writeCharacteristic(c, b, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) else {
            @Suppress("DEPRECATION") c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            @Suppress("DEPRECATION") c.value = b
            @Suppress("DEPRECATION") if (g.writeCharacteristic(c)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
        }
        if (result != BluetoothGatt.GATT_SUCCESS) { writing = false; fail("GATT write enqueue failed: $result") }
    }
    private fun fail(msg: String) { ready = false; if (!readySignal.isCompleted) readySignal.complete(false); onState(State.FAILED, msg); onDropped(msg) }
    fun close(notify: Boolean = true) { ready = false; synchronized(lock) { queue.clear(); writing = false }; val old = gatt; gatt = null; writeChar = null; if (old != null) closeGatt(old); if (notify) onState(State.DISCONNECTED, null) }
    private fun closeGatt(g: BluetoothGatt) { try { g.disconnect() } catch (_: Exception) {}; try { g.close() } catch (_: Exception) {}; if (gatt === g) gatt = null }
    companion object {
        val SERVICE_UUID = UUID.fromString("0000079A-D102-11E1-9B23-00025B00A5A5")
        val WRITE_UUID = UUID.fromString("0100079A-D102-11E1-9B23-00025B00A5A5")
        val NOTIFY_UUID = UUID.fromString("0200079A-D102-11E1-9B23-00025B00A5A5")
        val CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
        const val REQUESTED_MTU = 247
    }
}
