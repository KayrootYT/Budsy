package com.nordbuds.studio

/**
 * Budsy theme spec. The only specs in the app are the four built-in worlds in WorldThemes.kt
 * (Forest, Snow, Registaan, Samundar); Stock Budsy is the absence of a spec.
 */

/** Per-appearance colour overrides. Every field is optional; null keeps the Stock value. */
data class ColorSet(
    val bg: Long? = null, val card: Long? = null, val thumb: Long? = null,
    val text: Long? = null, val sub: Long? = null, val line: Long? = null, val track: Long? = null,
    val accent: Long? = null, val accent2: Long? = null,
    val green: Long? = null, val amber: Long? = null, val red: Long? = null, val sheet: Long? = null
) {
    val isEmpty get() = listOf(bg, card, thumb, text, sub, line, track, accent, accent2, green, amber, red, sheet).all { it == null }
}

/** Corner radii in dp. */
data class ShapeSpec(val panel: Float = 26f, val card: Float = 20f, val tile: Float = 22f, val button: Float = 16f, val pill: Float = 50f)

enum class CardStyle { SOLID, GLASS, GRADIENT, OUTLINE, FLAT }

data class CardSpec(
    val style: CardStyle = CardStyle.SOLID,
    val borderWidth: Float = 1f,
    val borderAlpha: Float = 0.8f,
    val fillAlpha: Float = 1f,
    val glow: Boolean = true,
    val gradientFrom: Long? = null,
    val gradientTo: Long? = null
)

data class FontSpec(val file: String? = null, val boldFile: String? = null, val family: String = "sans", val scale: Float = 1f, val tracking: Float = 0f)

data class MotionSpec(
    val enabled: Boolean = true,
    val speed: Float = 1f,          // 0.25 .. 3.0, higher = faster
    val enter: Boolean = true,      // staggered card entrance
    val bounce: Boolean = true,     // springy tap feedback
    val glowPulse: Boolean = true,
    val tabTransition: String = "slide" // slide | fade | none
)

data class BackgroundSpec(
    val image: String? = null, val imageAlpha: Float = 0.92f, val overlayAlpha: Float = 0f,
    val blobs: Boolean = false, val dotMatrix: Boolean = false
)

/** Icon pack: logical icon key -> relative file inside the package (PNG/WebP/SVG-free). */
data class IconSpec(val tintAccent: Boolean = true, val map: Map<String, String> = emptyMap())

data class ThemeSpec(
    val schema: Int = 1,
    val name: String = "Imported Budsy Theme",
    val author: String = "Unknown",
    val description: String = "",
    val version: String = "1.0",
    val source: String = "budsytheme",
    val light: ColorSet = ColorSet(),
    val dark: ColorSet = ColorSet(),
    val amoled: ColorSet = ColorSet(),
    val shapes: ShapeSpec = ShapeSpec(),
    val card: CardSpec = CardSpec(),
    val font: FontSpec = FontSpec(),
    val motion: MotionSpec = MotionSpec(),
    val background: BackgroundSpec = BackgroundSpec(),
    val icons: IconSpec = IconSpec(),
    /** Which pieces this package actually customised; shown as badges in Theme Manager. */
    val features: Set<String> = emptySet(),
    /** Which animated world this spec draws (see [World]); [World.NONE] = plain. */
    val world: Int = World.NONE
) {
    val hasWorld: Boolean get() = world != World.NONE
    companion object { val STOCK = ThemeSpec(name = "Stock Budsy", author = "Budsy", description = "Built-in theme", source = "stock") }

    fun colorsFor(appearance: Int): ColorSet = when (appearance) {
        AppearanceMode.AMOLED -> amoled.takeUnless { it.isEmpty } ?: dark
        AppearanceMode.DARK -> dark
        else -> light
    }
}
