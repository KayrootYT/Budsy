package com.nordbuds.studio

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * "Ocean Reef" living world.
 *
 * The screen is one big glass bottle of water:
 *  - BOTTOM HALF: water. It really sloshes when the phone is tilted / shaken (accelerometer -> damped spring + wave
 *    height-field), curves up at the glass walls (meniscus), reflects the sky, has caustic light and a bright surface
 *    line. Touching the water sends real ripples that disturb the surface. Fish, jellyfish, turtle and seahorses
 *    swim in it and bolt away from a finger; they drift back afterwards.
 *  - TOP HALF: the surface carries lotus flowers, lily pads, reeds and small flowering plants with butterflies.
 *    Above that the far bank: meadow, trees, grass, a hopping rabbit and a grazing deer (both run from a finger),
 *    then hills and sky.
 *  - Light = day (sun, clouds, birds). Dark = evening (low sun, sunset sky, first stars, fireflies).
 *    AMOLED = night (moon, stars, shooting star, many fireflies).
 */

// ====================================================================================== input + sensors

/** Latest finger position, fed by [waterTouchSource] from the root of the app (observe-only, never consumes). */
internal object WaterInput {
    @Volatile var x = -1f
    @Volatile var y = -1f
    @Volatile var down = false
}

fun Modifier.waterTouchSource(enabled: Boolean): Modifier =
    if (!enabled) this else this.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val e = awaitPointerEvent(PointerEventPass.Initial)
                val c = e.changes.firstOrNull { it.pressed }
                if (c != null) { WaterInput.x = c.position.x; WaterInput.y = c.position.y; WaterInput.down = true }
                else WaterInput.down = false
            }
        }
    }

private class WaterMotion {
    @Volatile var ax = 0f
    @Volatile var ay = 9.8f
    @Volatile var lx = 0f
    @Volatile var ly = 0f
}

@Composable
private fun rememberWaterMotion(enabled: Boolean): WaterMotion {
    val ctx = LocalContext.current
    val m = remember { WaterMotion() }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var active by remember { mutableStateOf(true) }
    DisposableEffect(owner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) active = false
            else if (e == androidx.lifecycle.Lifecycle.Event.ON_START) active = true
        }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    DisposableEffect(ctx, active, enabled) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]; val y = e.values[1]
                m.ax += (x - m.ax) * 0.10f           // low-pass = gravity direction
                m.ay += (y - m.ay) * 0.10f
                m.lx = x - m.ax                      // what is left = shake
                m.ly = y - m.ay
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (active && enabled && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm?.unregisterListener(l) }
    }
    return m
}

// ====================================================================================== palette

private class WPal(
    val skyTop: Color, val skyMid: Color, val skyBot: Color,
    val hillFar: Color, val hillNear: Color, val meadowA: Color, val meadowB: Color,
    val trunk: Color, val leafA: Color, val leafB: Color, val grass: Color,
    val waterTop: Color, val waterMid: Color, val waterDeep: Color,
    val sandA: Color, val sandB: Color, val pad: Color, val padDark: Color,
    val petalTip: Color, val petalBase: Color, val reed: Color, val cloud: Color,
    val glitter: Color
)

private fun wpal(mode: Int): WPal = when (mode) {
    0 -> WPal(
        Color(0xFF4FB8FF), Color(0xFF9AD9FF), Color(0xFFDFF6FF),
        Color(0xFF86CDB8), Color(0xFF55B07F), Color(0xFF7ED65C), Color(0xFF3F9E45),
        Color(0xFF7A5230), Color(0xFF4CC26B), Color(0xFF248A4B), Color(0xFF2F9E44),
        Color(0xFF8FE6F2), Color(0xFF3DB8DA), Color(0xFF137BAE),
        Color(0xFFF1DBA6), Color(0xFFD2B075), Color(0xFF3DBB6A), Color(0xFF1F8A4C),
        Color(0xFFFF7FAE), Color(0xFFFFEAF2), Color(0xFF3A9A4C), Color(0xFFFFFFFF),
        Color(0xFFFFF6C0)
    )
    1 -> WPal(
        Color(0xFF2A1A5E), Color(0xFFB34A78), Color(0xFFFFAA5E),
        Color(0xFF6B3F7C), Color(0xFF3D2A58), Color(0xFF5C6B3A), Color(0xFF263520),
        Color(0xFF3A2418), Color(0xFF3E6B4A), Color(0xFF1F3A2E), Color(0xFF3C5E30),
        Color(0xFF1C86B0), Color(0xFF0A4B7A), Color(0xFF031D36),
        Color(0xFF3F6075), Color(0xFF1B3346), Color(0xFF2E7A55), Color(0xFF174A36),
        Color(0xFFFF6B8F), Color(0xFFFFD0C0), Color(0xFF2D5A3A), Color(0xFFFFB18A),
        Color(0xFFFFC27A)
    )
    else -> WPal(
        Color(0xFF000000), Color(0xFF020A18), Color(0xFF08233D),
        Color(0xFF06121C), Color(0xFF040C14), Color(0xFF0A2018), Color(0xFF020807),
        Color(0xFF0E0A08), Color(0xFF0C3A2E), Color(0xFF04140F), Color(0xFF0C3A2A),
        Color(0xFF0B4F73), Color(0xFF041F37), Color(0xFF00060C),
        Color(0xFF14303F), Color(0xFF050E15), Color(0xFF0F5A44), Color(0xFF06281F),
        Color(0xFFB894FF), Color(0xFFE8F4FF), Color(0xFF0F4A34), Color(0xFF2A3E60),
        Color(0xFFEAF2FF)
    )
}

// ====================================================================================== creature specs

internal class FishSpec(
    val f: Float, val len: Float, val spd: Float, val off: Float, val dir: Int,
    val c1: Color, val c2: Color, val stripe: Boolean, val alpha: Float
)

/** f = depth inside the water (0 = surface, 1 = sea floor). */
private val FISH: List<FishSpec> = listOf(
    FishSpec(0.14f, 46f, 0.030f, 0.10f, 1, Color(0xFFFF8A2B), Color(0xFFFF5A1F), true, 1f),
    FishSpec(0.27f, 38f, 0.042f, 0.55f, -1, Color(0xFF2D7BFF), Color(0xFF1CD0FF), false, 1f),
    FishSpec(0.40f, 52f, 0.024f, 0.80f, 1, Color(0xFFFFE14D), Color(0xFFFFA800), true, 1f),
    FishSpec(0.52f, 34f, 0.050f, 0.30f, -1, Color(0xFFFF7EB6), Color(0xFFFF4F9A), false, 1f),
    FishSpec(0.63f, 44f, 0.034f, 0.65f, 1, Color(0xFF4DF0A0), Color(0xFF1FBF7A), false, 1f),
    FishSpec(0.21f, 26f, 0.060f, 0.90f, -1, Color(0xFFB388FF), Color(0xFF7C4DFF), true, 0.85f),
    FishSpec(0.72f, 30f, 0.045f, 0.45f, 1, Color(0xFFFF5252), Color(0xFFD32F2F), false, 0.9f),
    FishSpec(0.46f, 22f, 0.070f, 0.15f, -1, Color(0xFF7DF9FF), Color(0xFF18C8E0), false, 0.75f)
) + List(6) { k ->
    FishSpec(0.33f + (k % 3) * 0.028f, 15f, 0.038f, 0.50f - k * 0.016f, 1, Color(0xFFD6F4FF), Color(0xFF6CC3F0), false, 0.9f)
}

private class JellySpec(val x: Float, val f: Float, val r: Float, val color: Color, val ph: Float)

private val JELLIES = listOf(
    JellySpec(0.18f, 0.26f, 30f, Color(0xFFFF8FD6), 0.0f),
    JellySpec(0.80f, 0.38f, 24f, Color(0xFF7DF9FF), 2.1f),
    JellySpec(0.55f, 0.58f, 34f, Color(0xFFB08CFF), 4.2f)
)

private class SeahorseSpec(val x: Float, val f: Float, val size: Float, val color: Color, val ph: Float)

private val SEAHORSES = listOf(
    SeahorseSpec(0.10f, 0.80f, 70f, Color(0xFFFFB347), 0.5f),
    SeahorseSpec(0.88f, 0.76f, 58f, Color(0xFFFF7EB6), 2.5f)
)

internal class CoralSpec(val x: Float, val kind: Int, val size: Float, val color: Color, val ph: Float)

private val CORALS = listOf(
    CoralSpec(0.05f, 0, 64f, Color(0xFFFF6F91), 0.2f),
    CoralSpec(0.19f, 2, 40f, Color(0xFFFFB84D), 1.0f),
    CoralSpec(0.30f, 3, 74f, Color(0xFF2BD48A), 2.0f),
    CoralSpec(0.43f, 1, 60f, Color(0xFFB07CFF), 3.0f),
    CoralSpec(0.57f, 0, 82f, Color(0xFFFF9A3C), 4.0f),
    CoralSpec(0.69f, 3, 58f, Color(0xFF39E6C2), 5.0f),
    CoralSpec(0.79f, 2, 48f, Color(0xFFFF7EB6), 6.0f),
    CoralSpec(0.90f, 1, 68f, Color(0xFFFF6F91), 7.0f),
    CoralSpec(0.97f, 0, 56f, Color(0xFFFFD166), 8.0f)
)

private class LotusSpec(val x: Float, val s: Float, val ph: Float)
private val LOTUS = listOf(LotusSpec(0.20f, 22f, 0.3f), LotusSpec(0.54f, 28f, 1.9f), LotusSpec(0.83f, 20f, 4.0f))

private class PadSpec(val x: Float, val s: Float, val ph: Float)
private val PADS = listOf(
    PadSpec(0.07f, 17f, 0.4f), PadSpec(0.36f, 21f, 1.2f), PadSpec(0.67f, 18f, 2.6f),
    PadSpec(0.93f, 20f, 3.3f), PadSpec(0.45f, 14f, 5.0f), PadSpec(0.73f, 13f, 0.9f)
)

/** kind 0 = reed + cattail, 1 = small flowering plant */
private class PlantSpec(val x: Float, val hgt: Float, val kind: Int, val ph: Float, val c: Color)
private val PLANTS = listOf(
    PlantSpec(0.02f, 70f, 0, 0.2f, Color(0xFF7A4A24)), PlantSpec(0.06f, 54f, 1, 1.1f, Color(0xFFB388FF)),
    PlantSpec(0.10f, 62f, 0, 2.0f, Color(0xFF7A4A24)), PlantSpec(0.29f, 34f, 1, 0.7f, Color(0xFFFFE14D)),
    PlantSpec(0.63f, 36f, 1, 3.1f, Color(0xFFFF7EB6)), PlantSpec(0.88f, 52f, 1, 4.2f, Color(0xFFB388FF)),
    PlantSpec(0.92f, 66f, 0, 1.4f, Color(0xFF7A4A24)), PlantSpec(0.97f, 74f, 0, 2.6f, Color(0xFF7A4A24))
)

private class ButterflySpec(val home: Float, val ph: Float, val c1: Color, val c2: Color)
private val BUTTERFLIES = listOf(
    ButterflySpec(0.20f, 0.0f, Color(0xFFFF9F43), Color(0xFFFFD166)),
    ButterflySpec(0.54f, 1.7f, Color(0xFF74B9FF), Color(0xFF9AD0FF)),
    ButterflySpec(0.83f, 3.1f, Color(0xFFFF7EB6), Color(0xFFFFB3D1)),
    ButterflySpec(0.36f, 4.6f, Color(0xFFB388FF), Color(0xFFD9C5FF)),
    ButterflySpec(0.68f, 5.9f, Color(0xFFFFE14D), Color(0xFFFFF29A))
)

private class TreeSpec(val x: Float, val base: Float, val s: Float, val kind: Int, val ph: Float)
private val TREES = listOf(
    TreeSpec(0.04f, 0.392f, 58f, 0, 0.1f), TreeSpec(0.15f, 0.405f, 44f, 1, 1.4f), TreeSpec(0.26f, 0.378f, 32f, 0, 2.2f),
    TreeSpec(0.62f, 0.372f, 28f, 1, 0.8f), TreeSpec(0.80f, 0.380f, 36f, 0, 3.0f),
    TreeSpec(0.90f, 0.392f, 62f, 0, 1.9f), TreeSpec(0.98f, 0.406f, 46f, 1, 2.7f)
)

private class CloudSpec(val y: Float, val s: Float, val spd: Float, val off: Float)
private val CLOUDS = listOf(
    CloudSpec(0.055f, 34f, 0.006f, 0.10f), CloudSpec(0.115f, 26f, 0.009f, 0.55f),
    CloudSpec(0.170f, 40f, 0.005f, 0.80f), CloudSpec(0.085f, 22f, 0.011f, 0.32f)
)

// ====================================================================================== simulation state

private const val N_COL = 48
private const val RIPPLE_SECONDS = 2.4f

private class Critter {
    var ox = 0f; var oy = 0f; var vx = 0f; var vy = 0f; var panic = 0f
}

private class RippleFx(val x: Float, val y: Float, val t0: Float)

private fun rnd(i: Int, k: Int): Float {
    val s = sin(i * 12.9898f + k * 78.233f) * 43758.5453f
    return s - floor(s)
}

private class WorldSim {
    var cw = -1f; var ch = -1f
    var lastT = -1f; var dt = 0f
    // touch
    var tx = -1f; var ty = -1f; var down = false; var fresh = false; var prevDown = false
    var lastRx = -9999f; var lastRy = -9999f
    // water body
    var ang = 0f; var angV = 0f
    val hf = FloatArray(N_COL + 1); val hv = FloatArray(N_COL + 1)
    val surfY = FloatArray(N_COL + 1)
    val ripples = ArrayList<RippleFx>()
    // creatures
    val fish = Array(FISH.size) { Critter() }
    val jelly = Array(JELLIES.size) { Critter() }
    val sea = Array(SEAHORSES.size) { Critter() }
    val turtle = Critter()
    val bf = Array(BUTTERFLIES.size) { Critter() }
    val rabbit = Critter()
    val deer = Critter()
    // cached statics
    var hillFar = Path(); var hillNear = Path(); var meadow = Path()
    var starX = FloatArray(0); var starY = FloatArray(0); var starS = FloatArray(0)
    var dotX = FloatArray(0); var dotY = FloatArray(0); var dotC = IntArray(0)

    fun build(w: Float, h: Float) {
        cw = w; ch = h
        val step = w / 26f
        hillFar = Path().apply {
            moveTo(-20f, h * 0.40f)
            var x = -20f
            while (x <= w + 20f) {
                lineTo(x, h * (0.255f + 0.035f * sin(x / w * 5.2f + 0.7f) + 0.018f * sin(x / w * 12.1f + 2.0f)))
                x += step
            }
            lineTo(w + 20f, h * 0.40f); close()
        }
        hillNear = Path().apply {
            moveTo(-20f, h * 0.42f)
            var x = -20f
            while (x <= w + 20f) {
                lineTo(x, h * (0.305f + 0.025f * sin(x / w * 4.0f + 2.5f) + 0.012f * sin(x / w * 9.0f + 0.4f)))
                x += step
            }
            lineTo(w + 20f, h * 0.42f); close()
        }
        meadow = Path().apply {
            moveTo(-20f, h * 0.60f)
            var x = -20f
            while (x <= w + 20f) {
                lineTo(x, h * (0.345f + 0.012f * sin(x / w * 6.0f + 1.0f) + 0.006f * sin(x / w * 17.0f)))
                x += step
            }
            lineTo(w + 20f, h * 0.60f); close()
        }
        val ns = 70
        starX = FloatArray(ns) { rnd(it, 1) * w }
        starY = FloatArray(ns) { rnd(it, 2) * h * 0.26f }
        starS = FloatArray(ns) { 0.6f + rnd(it, 3) * 1.4f }
        val nd = 46
        dotX = FloatArray(nd) { rnd(it, 4) * w }
        dotY = FloatArray(nd) { h * (0.385f + rnd(it, 5) * 0.075f) }
        dotC = IntArray(nd) { (rnd(it, 6) * 4f).toInt().coerceIn(0, 3) }
    }

    fun computeSurface(w: Float, h: Float, u: Float, sY: Float, t: Float) {
        val slopeMax = 0.09f * h / w
        val slope = slopeMax * tanh(ang * 2.4f)
        for (i in 0..N_COL) {
            val x = w * i / N_COL
            val men = (exp(-x / (13f * u)) + exp(-(w - x) / (13f * u))) * 8f * u      // water climbs the glass walls
            val amb = sin(x / w * 12.566f + t * 1.1f) * 3.2f * u + sin(x / w * 31.4f - t * 1.7f) * 1.4f * u
            surfY[i] = sY + slope * (x - w / 2f) + hf[i] + amb - men
        }
    }

    fun surfAt(x: Float): Float {
        if (cw <= 0f) return 0f
        val f = (x / cw * N_COL).coerceIn(0f, N_COL.toFloat())
        val i = f.toInt().coerceAtMost(N_COL - 1)
        return surfY[i] + (surfY[i + 1] - surfY[i]) * (f - i)
    }

    fun surfAngle(x: Float): Float {
        val d = cw / N_COL
        return atan2(surfAt(x + d) - surfAt(x - d), 2f * d)
    }

    /** Tilt spring, shake, wave equation and touch ripples. */
    fun step(t: Float, m: WaterMotion, w: Float, u: Float) {
        val k = dt * 60f
        // water level follows gravity with a slosh (under-damped spring)
        val up = (m.ay / 9.8f).coerceIn(0f, 1f)
        val gate = ((up - 0.35f) / 0.35f).coerceIn(0f, 1f)
        val roll = atan2(m.ax, m.ay.coerceAtLeast(0.6f)).coerceIn(-0.7f, 0.7f)
        angV += ((roll * gate - ang) * 55f - angV * 4.2f) * dt
        ang += angV * dt
        // shaking pushes the surface
        val lx = m.lx.coerceIn(-12f, 12f)
        val half = N_COL / 2f
        for (i in 0..N_COL) hv[i] += -lx * 5f * u * ((i - half) / half) * k * 0.2f
        if (hypot(m.lx, m.ly) > 7f) {
            val c = (rnd((t * 40f).toInt(), 9) * N_COL).toInt().coerceIn(0, N_COL)
            hv[c] += 90f * u * k * 0.3f
        }
        // wave equation
        for (i in 0..N_COL) {
            val l = hf[if (i == 0) 1 else i - 1]; val r = hf[if (i == N_COL) N_COL - 1 else i + 1]
            hv[i] += ((l + r - 2f * hf[i]) * 100f - hf[i] * 1.2f) * dt
        }
        val damp = (1f - 1.4f * dt).coerceAtLeast(0f)
        val lim = 18f * u
        for (i in 0..N_COL) { hv[i] *= damp; hf[i] = (hf[i] + hv[i] * dt).coerceIn(-lim, lim) }
        // touch in the water
        if (down) {
            val sy = surfAt(tx)
            if (ty > sy - 24f * u) {
                val moved = hypot(tx - lastRx, ty - lastRy)
                if (fresh || moved > 42f * u) {
                    if (ripples.size >= 7) ripples.removeAt(0)
                    ripples.add(RippleFx(tx, ty, t)); lastRx = tx; lastRy = ty
                }
                if (ty - sy < 140f * u) {
                    val c = (tx / w * N_COL).toInt().coerceIn(0, N_COL)
                    val amp = if (fresh) 120f * u else 18f * u * k
                    for (d in -3..3) {
                        val idx = c + d
                        if (idx in 0..N_COL) hv[idx] += amp * (1f - abs(d) / 4f)
                    }
                }
            }
        }
        ripples.removeAll { t - it.t0 > RIPPLE_SECONDS || it.t0 > t }
    }
}

private fun Critter.scare(px: Float, py: Float, s: WorldSim, radius: Float, burst: Float) {
    if (!s.down) return
    val dx = px - s.tx; val dy = py - s.ty
    val d = hypot(dx, dy)
    if (d >= radius) return
    val nx = if (d > 0.5f) dx / d else 1f
    val ny = if (d > 0.5f) dy / d else 0f
    val kk = 1f - d / radius
    vx += nx * 2600f * kk * s.dt; vy += ny * 2600f * kk * s.dt
    if (s.fresh) { vx += nx * burst; vy += ny * burst }
    panic = 1f
}

private fun Critter.advance(dt: Float, maxOff: Float) {
    ox += vx * dt; oy += vy * dt
    val dec = exp(-2.6f * dt)
    vx *= dec; vy *= dec
    val ret = 0.55f * dt
    ox -= ox * ret; oy -= oy * ret
    ox = ox.coerceIn(-maxOff, maxOff); oy = oy.coerceIn(-maxOff, maxOff)
    panic = (panic - 0.9f * dt).coerceAtLeast(0f)
}

// ====================================================================================== composable

@Composable
fun OceanBackground(modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val mode = if (P.amoled) 2 else if (P.dark) 1 else 0
    val pal = remember(mode) { wpal(mode) }
    val sim = remember { WorldSim() }
    val motion = rememberWaterMotion(!reduce)
    val accent = P.accent2
    var t by remember { mutableFloatStateOf(if (reduce) 9f else 0f) }
    if (!reduce) LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t = (t + (n - last) / 1_000_000_000f) % 7200f
                last = n
            }
        }
    }
    Canvas(modifier.fillMaxSize()) { drawWorld(t, mode, sim, motion, pal, !reduce, accent) }
}

// ====================================================================================== world

private fun DrawScope.drawWorld(t: Float, mode: Int, sim: WorldSim, m: WaterMotion, pal: WPal, live: Boolean, accent: Color) {
    val w = size.width; val h = size.height
    if (w <= 0f || h <= 0f) return
    val u = w / 400f
    if (sim.cw != w || sim.ch != h) sim.build(w, h)
    val sY = h * 0.5f

    sim.dt = if (sim.lastT < 0f) 0f else (t - sim.lastT).coerceIn(0f, 0.05f)
    sim.lastT = t
    sim.down = live && WaterInput.down
    sim.tx = WaterInput.x; sim.ty = WaterInput.y
    sim.fresh = sim.down && !sim.prevDown
    sim.prevDown = sim.down
    if (live && sim.dt > 0f) sim.step(t, m, w, u)
    sim.computeSurface(w, h, u, sY, t)

    val shift = -sim.ang * 10f * u      // gentle gyro parallax for sky and hills

    drawSky(t, mode, sim, pal, u, shift)
    drawLand(t, mode, sim, pal, u, shift)
    drawWater(t, mode, sim, pal, u, accent)
    drawPond(t, mode, sim, pal, u)
}

// ------------------------------------------------------------------------------------------ sky

private fun DrawScope.drawCloud(x: Float, y: Float, s: Float, c: Color) {
    drawOval(c, Offset(x - s, y - s * 0.18f), Size(s * 2f, s * 0.36f))
    drawCircle(c, s * 0.34f, Offset(x - s * 0.35f, y - s * 0.25f))
    drawCircle(c, s * 0.44f, Offset(x + s * 0.05f, y - s * 0.35f))
    drawCircle(c, s * 0.30f, Offset(x + s * 0.50f, y - s * 0.20f))
}

private fun DrawScope.drawBird(x: Float, y: Float, s: Float, flap: Float, c: Color, sw: Float) {
    val p = Path().apply {
        moveTo(x - s, y); quadTo(x - s * 0.5f, y - s * flap, x, y); quadTo(x + s * 0.5f, y - s * flap, x + s, y)
    }
    drawPath(p, c, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawSky(t: Float, mode: Int, sim: WorldSim, pal: WPal, u: Float, shift: Float) {
    val w = size.width; val h = size.height
    drawRect(Brush.verticalGradient(listOf(pal.skyTop, pal.skyMid, pal.skyBot), startY = 0f, endY = h * 0.40f), size = Size(w, h * 0.58f))

    // stars (night full, evening: only a few, faint, high up)
    if (mode >= 1) {
        val n = if (mode == 2) sim.starX.size else 22
        for (i in 0 until n) {
            val tw = 0.55f + 0.45f * sin(t * (1.2f + (i % 5) * 0.4f) + i)
            val a = (if (mode == 2) 0.9f else 0.45f) * tw
            val sx = sim.starX[i] + shift * 0.3f; val sy = sim.starY[i] * (if (mode == 2) 1f else 0.6f)
            drawCircle(Color.White.copy(alpha = a), sim.starS[i] * u * 0.6f, Offset(sx, sy))
            if (i % 9 == 0 && mode == 2) {
                val r = sim.starS[i] * u * 2.4f
                drawLine(Color.White.copy(alpha = a * 0.6f), Offset(sx - r, sy), Offset(sx + r, sy), 0.8f * u)
                drawLine(Color.White.copy(alpha = a * 0.6f), Offset(sx, sy - r), Offset(sx, sy + r), 0.8f * u)
            }
        }
    }
    // shooting star (night)
    if (mode == 2) {
        val ph = t % 9f
        if (ph < 0.9f) {
            val q = ph / 0.9f
            val x0 = w * 0.15f + q * w * 0.35f; val y0 = h * 0.03f + q * h * 0.07f
            drawLine(Brush.linearGradient(listOf(Color.Transparent, Color.White), start = Offset(x0 - 60f * u, y0 - 22f * u), end = Offset(x0, y0)),
                Offset(x0 - 60f * u, y0 - 22f * u), Offset(x0, y0), 2f * u, StrokeCap.Round)
        }
    }

    // sun / low sun / moon
    when (mode) {
        0 -> {
            val sx = w * 0.80f + shift; val sy = h * 0.095f; val r = 26f * u
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF2A8).copy(alpha = 0.9f), Color(0xFFFFE066).copy(alpha = 0.25f), Color.Transparent), center = Offset(sx, sy), radius = 74f * u), 74f * u, Offset(sx, sy))
            for (i in 0 until 14) {
                val a = i * 2f * PI.toFloat() / 14f + t * 0.1f
                val r2 = r * (1.8f + 0.25f * sin(t * 1.5f + i))
                drawLine(Color(0xFFFFE680).copy(alpha = 0.5f), Offset(sx + cos(a) * r * 1.35f, sy + sin(a) * r * 1.35f), Offset(sx + cos(a) * r2, sy + sin(a) * r2), 2.2f * u, StrokeCap.Round)
            }
            drawCircle(Color(0xFFFFE04A), r, Offset(sx, sy))
            drawCircle(Color(0xFFFFF6C2), r * 0.62f, Offset(sx, sy))
        }
        1 -> {
            val sx = w * 0.30f + shift; val sy = h * 0.285f; val r = 36f * u
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFF8A3D).copy(alpha = 0.75f), Color(0xFFFF5A3D).copy(alpha = 0.25f), Color.Transparent), center = Offset(sx, sy), radius = 150f * u), 150f * u, Offset(sx, sy))
            drawCircle(Color(0xFFFFB347), r, Offset(sx, sy))
            drawCircle(Color(0xFFFFD58A), r * 0.7f, Offset(sx, sy))
        }
        else -> {
            val mx = w * 0.78f + shift; val my = h * 0.10f; val r = 24f * u
            drawCircle(Brush.radialGradient(listOf(Color(0xFFBFD8FF).copy(alpha = 0.45f), Color(0xFF7FA8E8).copy(alpha = 0.12f), Color.Transparent), center = Offset(mx, my), radius = 90f * u), 90f * u, Offset(mx, my))
            drawCircle(Color(0xFFF4F1DE), r, Offset(mx, my))
            val cr = Color(0xFFC9C6B0).copy(alpha = 0.55f)
            drawCircle(cr, r * 0.22f, Offset(mx - r * 0.30f, my - r * 0.25f))
            drawCircle(cr, r * 0.15f, Offset(mx + r * 0.32f, my + r * 0.05f))
            drawCircle(cr, r * 0.12f, Offset(mx - r * 0.05f, my + r * 0.42f))
            drawCircle(cr, r * 0.09f, Offset(mx + r * 0.10f, my - r * 0.50f))
            drawCircle(Color.White.copy(alpha = 0.35f), r, Offset(mx, my), style = Stroke(1.2f * u))
        }
    }

    // clouds
    val cc = when (mode) { 0 -> pal.cloud.copy(alpha = 0.92f); 1 -> pal.cloud.copy(alpha = 0.60f); else -> pal.cloud.copy(alpha = 0.40f) }
    for (c in CLOUDS) {
        val x = (((t * c.spd + c.off) % 1.5f) - 0.25f) * w + shift * 1.5f
        drawCloud(x, c.y * h, c.s * u, cc)
    }
    // birds
    if (mode <= 1) {
        val n = if (mode == 0) 3 else 2
        val col = if (mode == 0) Color(0xFF2B3A55).copy(alpha = 0.75f) else Color(0xFF1A1030).copy(alpha = 0.85f)
        for (i in 0 until n) {
            val x = (((t * (0.018f + i * 0.004f) + i * 0.31f) % 1.3f) - 0.15f) * w
            val y = h * (0.07f + i * 0.045f) + sin(t * 0.9f + i) * 5f * u
            drawBird(x, y, (7f + i * 1.5f) * u, 0.55f + 0.45f * sin(t * 7f + i * 2f), col, 1.6f * u)
        }
    }
}

// ------------------------------------------------------------------------------------------ land

private fun DrawScope.drawTree(x: Float, y: Float, s: Float, kind: Int, pal: WPal, t: Float, ph: Float, u: Float) {
    val sway = sin(t * 0.8f + ph) * s * 0.03f
    drawOval(Color.Black.copy(alpha = 0.16f), Offset(x - s * 0.34f, y - s * 0.04f), Size(s * 0.68f, s * 0.10f))
    drawRect(pal.trunk, Offset(x - s * 0.07f, y - s * 0.55f), Size(s * 0.14f, s * 0.55f))
    if (kind == 0) {
        drawCircle(pal.leafB, s * 0.38f, Offset(x + sway, y - s * 0.82f))
        drawCircle(pal.leafA, s * 0.30f, Offset(x - s * 0.20f + sway, y - s * 0.70f))
        drawCircle(pal.leafA, s * 0.30f, Offset(x + s * 0.22f + sway, y - s * 0.72f))
        drawCircle(lerp(pal.leafA, Color.White, 0.25f).copy(alpha = 0.5f), s * 0.17f, Offset(x - s * 0.08f + sway, y - s * 0.96f))
    } else {
        for (i in 0..2) {
            val ty = y - s * 0.22f - i * s * 0.30f
            val tw = s * (0.38f - i * 0.08f)
            val tip = x + sway * (i + 1) / 2f
            val p = Path().apply { moveTo(tip, ty - s * 0.42f); lineTo(x - tw, ty); lineTo(x + tw, ty); close() }
            drawPath(p, if (i % 2 == 0) pal.leafB else pal.leafA)
        }
    }
}

private fun DrawScope.drawRabbit(x: Float, y: Float, S: Float, face: Float, air: Float, t: Float, mode: Int) {
    val fur = when (mode) { 0 -> Color(0xFFD9C3A5); 1 -> Color(0xFF9A8470); else -> Color(0xFF2E2A2A) }
    val dark = lerp(fur, Color.Black, 0.25f)
    val light = lerp(fur, Color.White, 0.6f)
    val ear = sin(t * 2.3f) * 5f
    withTransform({ translate(x, y - air * S * 0.9f); scale(face, 1f, Offset.Zero) }) {
        drawCircle(light, S * 0.09f, Offset(-S * 0.44f, -S * 0.30f))
        drawOval(dark, Offset(-S * 0.38f, -S * 0.34f), Size(S * 0.40f, S * 0.34f))
        drawOval(fur, Offset(-S * 0.42f, -S * 0.55f), Size(S * 0.85f, S * 0.50f))
        drawOval(fur, Offset(-S * 0.20f, -S * 0.08f), Size(S * 0.34f, S * 0.10f))
        drawLine(fur, Offset(S * 0.28f, -S * 0.18f), Offset(S * 0.34f - air * S * 0.12f, 0f), S * 0.07f, StrokeCap.Round)
        drawCircle(fur, S * 0.20f, Offset(S * 0.46f, -S * 0.52f))
        withTransform({ rotate(-18f + ear, Offset(S * 0.42f, -S * 0.66f)) }) {
            drawOval(fur, Offset(S * 0.36f, -S * 1.10f), Size(S * 0.13f, S * 0.46f))
            drawOval(Color(0xFFFFB3C1).copy(alpha = 0.8f), Offset(S * 0.385f, -S * 1.04f), Size(S * 0.07f, S * 0.32f))
        }
        withTransform({ rotate(6f - ear * 0.5f, Offset(S * 0.50f, -S * 0.66f)) }) {
            drawOval(dark, Offset(S * 0.45f, -S * 1.06f), Size(S * 0.12f, S * 0.42f))
        }
        drawCircle(Color.Black, S * 0.027f, Offset(S * 0.53f, -S * 0.56f))
        drawCircle(Color.White, S * 0.009f, Offset(S * 0.54f, -S * 0.575f))
        drawCircle(Color(0xFFFF8FA3), S * 0.03f, Offset(S * 0.655f, -S * 0.50f))
    }
}

private fun DrawScope.drawDeer(x: Float, y: Float, S: Float, face: Float, graze: Float, gait: Float, t: Float, mode: Int) {
    val coat = when (mode) { 0 -> Color(0xFFB9824B); 1 -> Color(0xFF8A5A3A); else -> Color(0xFF2A1C12) }
    val coatDark = lerp(coat, Color.Black, 0.3f)
    val belly = lerp(coat, Color.White, 0.55f)
    val hoof = Color(0xFF2A1C12)
    val legH = S * 0.50f
    withTransform({ translate(x, y); scale(face, 1f, Offset.Zero) }) {
        for (k in 0..3) {
            val lx = when (k) { 0 -> -S * 0.34f; 1 -> -S * 0.22f; 2 -> S * 0.24f; else -> S * 0.36f }
            val sw = sin(t * 14f + k * 1.6f) * gait * S * 0.16f
            drawLine(if (k % 2 == 0) coatDark else coat, Offset(lx, -legH), Offset(lx + sw, 0f), S * 0.055f, StrokeCap.Round)
            drawCircle(hoof, S * 0.03f, Offset(lx + sw, 0f))
        }
        drawOval(Color.White, Offset(-S * 0.56f, -legH - S * 0.30f), Size(S * 0.10f, S * 0.16f))
        drawOval(coat, Offset(-S * 0.52f, -legH - S * 0.30f), Size(S * 1.04f, S * 0.46f))
        drawOval(belly, Offset(-S * 0.35f, -legH - S * 0.06f), Size(S * 0.70f, S * 0.16f))
        for (k in 0..4) drawCircle(Color.White.copy(alpha = 0.55f), S * 0.02f, Offset(-S * 0.3f + k * S * 0.14f, -legH - S * (0.22f - (k % 2) * 0.06f)))
        val bx = S * 0.36f; val by = -legH - S * 0.18f
        val a = 0.45f + graze * 1.85f
        val nl = S * 0.46f
        val hx = bx + sin(a) * nl; val hy = by - cos(a) * nl
        drawLine(coat, Offset(bx - S * 0.02f, by), Offset(hx, hy), S * 0.17f, StrokeCap.Round)
        val rot = -90f + a * 57.29578f + 50f
        withTransform({ translate(hx, hy); rotate(rot, Offset.Zero) }) {
            val antler = Color(0xFF6B4A2B)
            val aw = S * 0.022f
            drawLine(antler, Offset(-S * 0.02f, -S * 0.07f), Offset(-S * 0.08f, -S * 0.30f), aw, StrokeCap.Round)
            drawLine(antler, Offset(-S * 0.08f, -S * 0.30f), Offset(-S * 0.03f, -S * 0.46f), aw, StrokeCap.Round)
            drawLine(antler, Offset(-S * 0.06f, -S * 0.22f), Offset(S * 0.05f, -S * 0.30f), aw, StrokeCap.Round)
            drawOval(coat, Offset(-S * 0.06f, -S * 0.07f), Size(S * 0.28f, S * 0.14f))
            withTransform({ rotate(-30f + sin(t * 1.7f) * 8f, Offset(-S * 0.01f, -S * 0.05f)) }) {
                drawOval(coatDark, Offset(-S * 0.05f, -S * 0.17f), Size(S * 0.07f, S * 0.14f))
            }
            drawCircle(Color.Black, S * 0.013f, Offset(S * 0.07f, -S * 0.02f))
            drawCircle(hoof, S * 0.025f, Offset(S * 0.215f, 0f))
        }
    }
}

private fun DrawScope.drawLand(t: Float, mode: Int, sim: WorldSim, pal: WPal, u: Float, shift: Float) {
    val w = size.width; val h = size.height

    withTransform({ translate(shift * 0.8f, 0f) }) { drawPath(sim.hillFar, pal.hillFar) }
    // tiny far trees on the near hill line
    withTransform({ translate(shift * 0.5f, 0f) }) {
        drawPath(sim.hillNear, pal.hillNear)
        for (i in 0 until 14) {
            val x = w * (i + 0.5f) / 14f
            val y = h * (0.305f + 0.025f * sin(x / w * 4.0f + 2.5f) + 0.012f * sin(x / w * 9.0f + 0.4f))
            val s = (8f + (i % 3) * 3f) * u
            drawCircle(pal.leafB, s, Offset(x, y - s * 0.3f))
        }
    }
    // meadow
    drawPath(sim.meadow, Brush.verticalGradient(listOf(pal.meadowA, pal.meadowB), startY = h * 0.34f, endY = h * 0.58f))
    // meadow flowers
    for (i in sim.dotX.indices) {
        val c = when (sim.dotC[i]) { 0 -> Color(0xFFFFFFFF); 1 -> Color(0xFFFFE14D); 2 -> Color(0xFFFF8FB8); else -> Color(0xFFB794FF) }
        drawCircle(c.copy(alpha = if (mode == 2) 0.45f else 0.9f), 1.7f * u, Offset(sim.dotX[i], sim.dotY[i]))
    }
    // trees + bushes
    for (tr in TREES) drawTree(tr.x * w, tr.base * h, tr.s * u, tr.kind, pal, t, tr.ph, u)
    for (i in 0 until 6) {
        val bx = w * (0.10f + i * 0.17f); val by = h * (0.418f + (i % 2) * 0.012f); val s = (13f + (i % 3) * 4f) * u
        drawCircle(pal.leafB, s, Offset(bx, by - s * 0.5f))
        drawCircle(pal.leafA, s * 0.75f, Offset(bx + s * 0.7f, by - s * 0.4f))
    }

    // rabbit: hops between random spots, nibbles in between
    run {
        val period = 4.2f
        val n = floor(t / period).toInt()
        val local = (t % period) / period
        val lo = w * 0.12f; val hi = w * 0.55f
        val xa = lo + (hi - lo) * (0.5f + 0.5f * sin(n * 2.3f + 1.1f))
        val xb = lo + (hi - lo) * (0.5f + 0.5f * sin((n + 1) * 2.3f + 1.1f))
        val mv = (local / 0.45f).coerceIn(0f, 1f)
        val ease = mv * mv * (3f - 2f * mv)
        val cr = sim.rabbit
        val rx = xa + (xb - xa) * ease + cr.ox
        val moving = local < 0.45f
        val air = (if (moving) abs(sin(mv * 2f * PI.toFloat())) * 0.6f else 0f) + (if (cr.panic > 0.2f) abs(sin(t * 16f)) * 0.7f else 0f)
        val ry = h * 0.435f
        cr.scare(rx, ry, sim, 120f * u, 560f * u)
        cr.advance(sim.dt, 200f * u); cr.vy = 0f; cr.oy = 0f
        val face = if (cr.panic > 0.2f && abs(cr.vx) > 20f * u) (if (cr.vx > 0f) 1f else -1f) else (if (xb >= xa) 1f else -1f)
        drawOval(Color.Black.copy(alpha = 0.18f), Offset(rx - 14f * u, ry - 2f * u), Size(28f * u, 5f * u))
        drawRabbit(rx, ry, 34f * u, face, air, t, mode)
    }
    // deer: grazes, lifts its head, runs when scared
    run {
        val cr = sim.deer
        val dx = w * 0.72f + sin(t * 0.05f) * 26f * u + cr.ox
        val dy = h * 0.418f
        cr.scare(dx, dy - 30f * u, sim, 150f * u, 420f * u)
        cr.advance(sim.dt, 230f * u); cr.vy = 0f; cr.oy = 0f
        val cyc = 0.5f + 0.5f * sin(t * 0.45f)
        val graze = if (cr.panic > 0.2f) 0f else (cyc * cyc * (3f - 2f * cyc)).coerceIn(0f, 1f)
        val gait = if (cr.panic > 0.2f) 1f else 0f
        val face = if (cr.panic > 0.2f && abs(cr.vx) > 20f * u) (if (cr.vx > 0f) 1f else -1f) else -1f
        drawOval(Color.Black.copy(alpha = 0.2f), Offset(dx - 34f * u, dy - 3f * u), Size(68f * u, 6f * u))
        drawDeer(dx, dy, 64f * u, face, graze, gait, t, mode)
    }

    // bank shade + front grass
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f)), startY = h * 0.43f, endY = h * 0.52f),
        Offset(0f, h * 0.43f), Size(w, h * 0.09f))
    run {
        val n = (w / (16f * u)).toInt()
        for (i in 0..n) {
            val x = i * 16f * u + (i % 3) * 3f * u
            val by = h * (0.462f + 0.004f * (i % 4))
            for (b in 0..2) {
                val sw = sin(t * 1.4f + i * 0.7f + b) * 4f * u
                drawLine(if (b == 1) lerp(pal.grass, Color.White, 0.12f) else pal.grass,
                    Offset(x + b * 4f * u, by + 10f * u), Offset(x + b * 4f * u + sw + (b - 1) * 3f * u, by - (12f + (i * 7 + b * 5) % 9) * u), 1.8f * u, StrokeCap.Round)
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ water

private fun DrawScope.drawRipple(r: RippleFx, t: Float, u: Float, sim: WorldSim, accent: Color) {
    val p = ((t - r.t0) / RIPPLE_SECONDS).coerceIn(0f, 1f)
    val sy = sim.surfAt(r.x)
    val near = ((100f * u - (r.y - sy)) / (100f * u)).coerceIn(0f, 1f)      // 1 = on the surface -> flat rings
    val cy = r.y + (sy - r.y) * near
    val flat = 1f - 0.78f * near
    for (k in 0..2) {
        val pk = p - k * 0.10f
        if (pk <= 0f) continue
        val rad = 170f * u * (1f - (1f - pk) * (1f - pk))
        val al = (1f - pk).pow(1.5f) * (0.55f - k * 0.14f)
        val tl = Offset(r.x - rad, cy - rad * flat)
        val sz = Size(rad * 2f, rad * 2f * flat)
        drawOval(Color.White.copy(alpha = al), tl, sz, style = Stroke((2.6f - k * 0.6f) * u * 0.5f))
        val rad2 = (rad - 3f * u).coerceAtLeast(0f)
        drawOval(accent.copy(alpha = al * 0.6f), Offset(r.x - rad2, cy - rad2 * flat), Size(rad2 * 2f, rad2 * 2f * flat), style = Stroke(1.4f * u * 0.5f))
    }
    val lens = 170f * u * p + 1f
    drawOval(Brush.radialGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.10f * (1f - p)), Color.Transparent), center = Offset(r.x, cy), radius = lens),
        Offset(r.x - lens, cy - lens * flat), Size(lens * 2f, lens * 2f * flat))
}

private fun DrawScope.drawWater(t: Float, mode: Int, sim: WorldSim, pal: WPal, u: Float, accent: Color) {
    val w = size.width; val h = size.height
    val sY = h * 0.5f
    val floorY = h * 0.93f
    val H = floorY - sY
    val light = mode == 0

    val water = Path().apply {
        moveTo(0f, sim.surfY[0])
        for (i in 1..N_COL) lineTo(w * i / N_COL, sim.surfY[i])
        lineTo(w, h); lineTo(0f, h); close()
    }
    drawPath(water, Brush.verticalGradient(listOf(pal.waterTop, pal.waterMid, pal.waterDeep), startY = sY - 20f * u, endY = h))

    val flow = -sim.ang * 90f * u      // the whole water body drifts with the slosh

    clipPath(water) {
        // sky reflected in the top of the water
        drawRect(Brush.verticalGradient(listOf(pal.skyBot.copy(alpha = if (mode == 2) 0.30f else 0.42f), Color.Transparent), startY = sY - 30f * u, endY = sY + H * 0.26f),
            Offset(0f, sY - 30f * u), Size(w, H * 0.26f + 30f * u))

        // god rays
        val rayBottom = h * 0.84f
        for (i in 0..4) {
            val x0 = w * (0.08f + 0.21f * i) + sin(t * 0.25f + i * 1.7f) * 22f * u + flow * 0.2f
            val a = (if (light) 0.16f else 0.12f) + 0.05f * sin(t * 0.8f + i)
            val xb = x0 - 110f * u + sin(t * 0.3f + i) * 14f * u
            val ray = Path().apply { moveTo(x0, sY - 10f * u); lineTo(x0 + 22f * u, sY - 10f * u); lineTo(xb + 84f * u, rayBottom); lineTo(xb, rayBottom); close() }
            drawPath(ray, Brush.verticalGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), startY = sY, endY = rayBottom))
        }
        // swell bands
        for (k in 0..2) {
            val yb = sY + H * (0.22f + 0.24f * k)
            val p = Path()
            var x = -10f
            p.moveTo(x, yb)
            while (x <= w + 10f) { p.lineTo(x, yb + sin(x / w * 8.2f + t * (0.5f + 0.12f * k) + k * 2f) * 11f * u); x += w / 24f }
            drawPath(p, Color.White.copy(alpha = if (light) 0.07f else 0.04f), style = Stroke(26f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        // caustic light net
        for (k in 0..5) {
            val yb = sY + H * (0.05f + 0.045f * k)
            val p = Path()
            var x = -10f
            p.moveTo(x, yb)
            while (x <= w + 10f) { p.lineTo(x, yb + sin(x / w * (14f + k * 3f) + t * (0.9f + 0.2f * k) + k) * 5f * u); x += w / 22f }
            drawPath(p, Color.White.copy(alpha = (if (light) 0.16f else 0.10f) * (1f - k / 7f)), style = Stroke(2.2f * u, cap = StrokeCap.Round))
        }
        // sun / moon glitter path
        run {
            val gx = (if (mode == 1) w * 0.30f else if (mode == 2) w * 0.78f else w * 0.80f)
            val sy = sim.surfAt(gx)
            for (i in 0..9) {
                val y = sy + (i + 0.6f) * 0.018f * H
                val hw = (12f - i) * 3.4f * u
                val a = 0.65f * (1f - i / 10f) * (0.45f + 0.55f * sin(t * 2.3f + i * 1.9f))
                if (a > 0.02f) drawLine(pal.glitter.copy(alpha = a), Offset(gx + sin(t * 1.1f + i) * 6f * u - hw, y), Offset(gx + sin(t * 1.1f + i) * 6f * u + hw, y), 2.2f * u, StrokeCap.Round)
            }
        }

        // ---- creatures, far to near
        val sTopPad = 12f * u
        for ((i, j) in JELLIES.withIndex()) {
            val cr = sim.jelly[i]
            val cx = j.x * w + sin(t * 0.35f + j.ph) * 28f * u + flow * 0.5f + cr.ox
            var cy = sY + j.f * H + sin(t * 0.55f + j.ph * 1.3f) * 30f * u + cr.oy
            cy = cy.coerceIn(sim.surfAt(cx) + 34f * u, floorY - 70f * u)
            cr.scare(cx, cy, sim, 130f * u, 300f * u)
            cr.advance(sim.dt, 200f * u)
            drawJelly(cx, cy, j.r * u, j.color, t * (1f + cr.panic * 1.6f), j.ph, u)
        }
        run {
            val L = 96f * u
            val cr = sim.turtle
            val cyc = (t * 0.011f + 0.25f) % 1f
            val tx = -L + cyc * (w + 2f * L) + flow * 0.6f + cr.ox
            var ty = sY + 0.46f * H + sin(t * 0.6f) * 14f * u + cr.oy
            ty = ty.coerceIn(sim.surfAt(tx) + 40f * u, floorY - 50f * u)
            cr.scare(tx, ty, sim, 150f * u, 260f * u)
            cr.advance(sim.dt, 200f * u)
            drawTurtle(tx, ty, L, t * (1f + cr.panic * 1.8f), u)
        }
        for ((i, f) in FISH.withIndex()) {
            val cr = sim.fish[i]
            val L = f.len * u
            val cyc = (t * f.spd + f.off) % 1f
            val xr = -L + cyc * (w + 2f * L)
            val bx = (if (f.dir > 0) xr else w - xr) + flow * (0.5f + f.f) + cr.ox
            var by = sY + f.f * H + sin(t * 1.4f + f.off * 20f) * 7f * u + cr.oy
            by = by.coerceIn(sim.surfAt(bx) + sTopPad + L * 0.2f, floorY - 16f * u)
            cr.scare(bx, by, sim, 120f * u, 340f * u)
            cr.advance(sim.dt, 240f * u)
            val dirNow = if (cr.panic > 0.3f && abs(cr.vx) > 30f * u) (if (cr.vx > 0f) 1 else -1) else f.dir
            val wig = sin(t * (7f + 20f * cr.panic) + f.off * 10f) * 0.09f * L * (1f + 2.5f * cr.panic)
            drawFish(bx, by, L, dirNow, f.c1, f.c2, f.stripe, wig, f.alpha)
        }
        for ((i, s) in SEAHORSES.withIndex()) {
            val cr = sim.sea[i]
            val sx = s.x * w + sin(t * 0.5f + s.ph) * 8f * u + flow * 0.4f + cr.ox
            val sy = sY + s.f * H + sin(t * 0.8f + s.ph) * 10f * u + cr.oy
            cr.scare(sx, sy, sim, 120f * u, 300f * u)
            cr.advance(sim.dt, 180f * u)
            drawSeahorse(sx, sy.coerceIn(sim.surfAt(sx) + 40f * u, floorY - 20f * u), s.size * u, s.color, t * (1f + cr.panic * 1.5f), s.ph)
        }

        // sea floor + coral + weed
        val sand = Path().apply {
            moveTo(0f, h); lineTo(0f, floorY)
            var x = 0f
            while (x <= w + 8f) { lineTo(x, floorY + sin(x / w * 9f) * 5f * u + 4f * u); x += w / 30f }
            lineTo(w, h); close()
        }
        drawPath(sand, Brush.verticalGradient(listOf(pal.sandA, pal.sandB), startY = floorY, endY = h))
        for (c in CORALS) drawCoral(c, w * c.x, floorY + 5f * u, t, u)

        // bubbles
        for (i in 0 until 18) {
            val prog = (t * (0.03f + 0.012f * (i % 4)) + i * 0.173f) % 1f
            val bx = w * ((i * 0.618034f) % 1f) + sin(t * 0.8f + i) * 6f * u + flow * 0.3f
            val by = floorY - prog * (floorY - sY - 10f * u)
            val r = (2f + (i % 4) * 1.6f) * u
            val al = (1f - prog).coerceIn(0f, 1f) * 0.9f + 0.1f
            drawCircle(Color.White.copy(alpha = 0.10f * al), r, Offset(bx, by))
            drawCircle(Color.White.copy(alpha = 0.55f * al), r, Offset(bx, by), style = Stroke(1f * u))
            drawCircle(Color.White.copy(alpha = 0.85f * al), r * 0.25f, Offset(bx - r * 0.35f, by - r * 0.35f))
        }

        // touch ripples
        for (r in sim.ripples) drawRipple(r, t, u, sim, accent)

        // glass walls: bright refraction strips on both sides, a tall specular streak and a thick glass base
        drawRect(Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.26f), Color.Transparent), startX = 0f, endX = 16f * u), Offset(0f, 0f), Size(16f * u, h))
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.22f)), startX = w - 16f * u, endX = w), Offset(w - 16f * u, 0f), Size(16f * u, h))
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.08f), Color.Transparent), startX = w * 0.07f, endX = w * 0.07f + 26f * u),
            Offset(w * 0.07f, sY), Size(26f * u, h - sY))
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.16f)), startY = h - 14f * u, endY = h), Offset(0f, h - 14f * u), Size(w, 14f * u))
    }
}

// ------------------------------------------------------------------------------------------ surface life

private fun DrawScope.drawPetal(len: Float, wid: Float, tip: Color, base: Color) {
    val p = Path().apply {
        moveTo(0f, 0f)
        cubicTo(-wid, -len * 0.25f, -wid * 0.8f, -len * 0.8f, 0f, -len)
        cubicTo(wid * 0.8f, -len * 0.8f, wid, -len * 0.25f, 0f, 0f)
    }
    drawPath(p, Brush.verticalGradient(listOf(tip, base), startY = -len, endY = 0f))
    drawPath(p, Color.White.copy(alpha = 0.35f), style = Stroke(len * 0.02f))
}

private fun DrawScope.drawPad(x: Float, y: Float, s: Float, ang: Float, pal: WPal, flower: Boolean, petal: Color) {
    withTransform({ translate(x, y); rotate(ang * 57.29578f, Offset.Zero) }) {
        drawOval(Color.Black.copy(alpha = 0.18f), Offset(-s * 1.05f, -s * 0.06f), Size(s * 2.1f, s * 0.30f))
        drawOval(pal.padDark, Offset(-s, -s * 0.17f), Size(s * 2f, s * 0.36f))
        drawOval(pal.pad, Offset(-s * 0.94f, -s * 0.19f), Size(s * 1.88f, s * 0.30f))
        for (k in -1..1) drawLine(pal.padDark.copy(alpha = 0.35f), Offset(0f, -s * 0.04f), Offset(k * s * 0.7f, -s * 0.05f + (if (k == 0) s * 0.08f else 0f)), s * 0.03f, StrokeCap.Round)
        if (flower) {
            drawCircle(petal, s * 0.17f, Offset(-s * 0.1f, -s * 0.26f))
            drawCircle(Color.White.copy(alpha = 0.7f), s * 0.08f, Offset(-s * 0.1f, -s * 0.26f))
            drawCircle(petal.copy(alpha = 0.85f), s * 0.12f, Offset(s * 0.18f, -s * 0.24f))
        }
    }
}

private fun DrawScope.drawLotus(x: Float, y: Float, s: Float, ang: Float, t: Float, ph: Float, pal: WPal, mode: Int) {
    drawPad(x, y, s * 1.15f, ang, pal, false, pal.petalTip)
    withTransform({ translate(x, y - s * 0.06f); rotate(ang * 57.29578f + sin(t * 0.9f + ph) * 1.5f, Offset.Zero) }) {
        if (mode == 2) drawCircle(Brush.radialGradient(listOf(pal.petalTip.copy(alpha = 0.45f), Color.Transparent), center = Offset(0f, -s * 0.5f), radius = s * 1.7f), s * 1.7f, Offset(0f, -s * 0.5f))
        val back = lerp(pal.petalTip, pal.petalBase, 0.25f)
        for (i in 0..4) withTransform({ rotate(-64f + i * 32f, Offset.Zero) }) { drawPetal(s * 1.05f, s * 0.34f, back, pal.petalBase) }
        for (i in 0..2) withTransform({ rotate(-36f + i * 36f, Offset.Zero) }) { drawPetal(s * 0.92f, s * 0.36f, pal.petalTip, pal.petalBase) }
        drawOval(Color(0xFFFFD43B), Offset(-s * 0.16f, -s * 0.22f), Size(s * 0.32f, s * 0.22f))
        for (k in -2..2) drawCircle(Color(0xFFFFA000), s * 0.03f, Offset(k * s * 0.06f, -s * 0.22f))
    }
}

private fun DrawScope.drawPlant(x: Float, base: Float, hgt: Float, kind: Int, t: Float, ph: Float, c: Color, pal: WPal, u: Float) {
    val sw = sin(t * 0.9f + ph) * 5f * u
    val stem = Path().apply { moveTo(x, base + 16f * u); quadTo(x + sw * 0.3f, base - hgt * 0.5f, x + sw, base - hgt) }
    drawPath(stem, pal.reed, style = Stroke(2.6f * u, cap = StrokeCap.Round))
    for (k in 0..1) {
        val sd = if (k == 0) -1f else 1f
        val leaf = Path().apply { moveTo(x + sw * 0.2f, base - hgt * 0.1f); quadTo(x + sd * 14f * u, base - hgt * 0.45f, x + sd * 22f * u + sw * 0.4f, base - hgt * 0.62f) }
        drawPath(leaf, pal.reed.copy(alpha = 0.9f), style = Stroke(2f * u, cap = StrokeCap.Round))
    }
    if (kind == 0) {
        drawOval(c, Offset(x + sw - 2.8f * u, base - hgt - 9f * u), Size(5.6f * u, 17f * u))
        drawLine(pal.reed, Offset(x + sw, base - hgt - 9f * u), Offset(x + sw, base - hgt - 16f * u), 1.4f * u, StrokeCap.Round)
    } else {
        for (k in 0..4) {
            val a = k * 2f * PI.toFloat() / 5f + t * 0.3f
            drawCircle(c, 3.2f * u, Offset(x + sw + cos(a) * 4.2f * u, base - hgt + sin(a) * 4.2f * u))
        }
        drawCircle(Color(0xFFFFE14D), 2.2f * u, Offset(x + sw, base - hgt))
    }
}

private fun DrawScope.drawButterfly(x: Float, y: Float, s: Float, rot: Float, flap: Float, c1: Color, c2: Color) {
    withTransform({ translate(x, y); rotate(rot, Offset.Zero) }) {
        withTransform({ scale(flap, 1f, Offset.Zero) }) {
            for (k in 0..1) {
                val sd = if (k == 0) -1f else 1f
                val up = Path().apply {
                    moveTo(0f, 0f); cubicTo(sd * s * 0.4f, -s * 0.9f, sd * s * 1.2f, -s * 0.9f, sd * s * 1.0f, -s * 0.2f)
                    quadTo(sd * s * 0.5f, s * 0.1f, 0f, 0f)
                }
                drawPath(up, c1)
                val lo = Path().apply {
                    moveTo(0f, 0f); cubicTo(sd * s * 0.9f, s * 0.1f, sd * s * 0.9f, s * 0.8f, sd * s * 0.3f, s * 0.7f)
                    quadTo(0f, s * 0.4f, 0f, 0f)
                }
                drawPath(lo, c2)
                drawCircle(Color.White.copy(alpha = 0.8f), s * 0.11f, Offset(sd * s * 0.62f, -s * 0.42f))
                drawCircle(Color.Black.copy(alpha = 0.25f), s * 0.07f, Offset(sd * s * 0.45f, s * 0.38f))
            }
        }
        drawLine(Color(0xFF2B1B14), Offset(0f, -s * 0.42f), Offset(0f, s * 0.55f), s * 0.13f, StrokeCap.Round)
        drawLine(Color(0xFF2B1B14), Offset(0f, -s * 0.40f), Offset(-s * 0.25f, -s * 0.78f), s * 0.04f, StrokeCap.Round)
        drawLine(Color(0xFF2B1B14), Offset(0f, -s * 0.40f), Offset(s * 0.25f, -s * 0.78f), s * 0.04f, StrokeCap.Round)
    }
}

private fun DrawScope.drawPond(t: Float, mode: Int, sim: WorldSim, pal: WPal, u: Float) {
    val w = size.width; val h = size.height
    val sY = h * 0.5f

    // bright surface line + soft foam bands that follow every wave
    val line = Path().apply {
        moveTo(0f, sim.surfY[0]); for (i in 1..N_COL) lineTo(w * i / N_COL, sim.surfY[i])
    }
    val band = Path().apply {
        moveTo(0f, sim.surfY[0]); for (i in 1..N_COL) lineTo(w * i / N_COL, sim.surfY[i])
        for (i in N_COL downTo 0) lineTo(w * i / N_COL, sim.surfY[i] + 16f * u + sin(i * 0.9f + t * 1.5f) * 2f * u)
        close()
    }
    drawPath(band, Color.White.copy(alpha = if (mode == 0) 0.20f else 0.12f))
    val band2 = Path().apply {
        moveTo(0f, sim.surfY[0]); for (i in 1..N_COL) lineTo(w * i / N_COL, sim.surfY[i])
        for (i in N_COL downTo 0) lineTo(w * i / N_COL, sim.surfY[i] + 5f * u)
        close()
    }
    drawPath(band2, Color.White.copy(alpha = 0.22f))
    drawPath(line, Color.White.copy(alpha = 0.85f), style = Stroke(2.2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))

    // reeds and small flowering plants rooted in the pond
    for (p in PLANTS) {
        val x = p.x * w
        drawPlant(x, sim.surfAt(x), p.hgt * u, p.kind, t, p.ph, p.c, pal, u)
    }
    // lily pads (some with a tiny flower)
    for ((i, p) in PADS.withIndex()) {
        val x = p.x * w + sin(t * 0.25f + p.ph) * 6f * u
        drawPad(x, sim.surfAt(x) + sin(t * 1.3f + p.ph) * 1.2f * u, p.s * u, sim.surfAngle(x), pal, i % 2 == 0, if (i % 4 == 0) Color(0xFFFFFFFF) else Color(0xFFFFB3D1))
    }
    // lotus flowers
    for (l in LOTUS) {
        val x = l.x * w + sin(t * 0.22f + l.ph) * 5f * u
        drawLotus(x, sim.surfAt(x) + sin(t * 1.3f + l.ph) * 1.5f * u, l.s * u, sim.surfAngle(x), t, l.ph, pal, mode)
    }

    // butterflies above the lotus (day: all, evening: three, night: none -> fireflies take over)
    if (mode <= 1) {
        val count = if (mode == 0) BUTTERFLIES.size else 3
        for (i in 0 until count) {
            val b = BUTTERFLIES[i]
            val cr = sim.bf[i]
            val hx = b.home * w
            val bx = hx + sin(t * 0.7f + b.ph) * 70f * u + sin(t * 1.9f + b.ph * 2f) * 14f * u + cr.ox
            val by = sim.surfAt(hx) - 48f * u - (0.5f + 0.5f * sin(t * 1.1f + b.ph)) * 62f * u + sin(t * 5f + b.ph) * 5f * u + cr.oy
            cr.scare(bx, by, sim, 110f * u, 320f * u)
            cr.advance(sim.dt, 200f * u)
            val flap = 0.25f + 0.75f * abs(sin(t * (12f + 10f * cr.panic) + b.ph))
            val rot = (cos(t * 0.7f + b.ph) * 18f).coerceIn(-30f, 30f) + cr.vx * 0.02f
            val a = if (mode == 1) 0.85f else 1f
            drawButterfly(bx, by, 9f * u, rot, flap, b.c1.copy(alpha = a), b.c2.copy(alpha = a))
        }
    }

    // fireflies (jugnu)
    if (mode >= 1) {
        val n = if (mode == 2) 28 else 12
        for (i in 0 until n) {
            val fx = w * ((i * 0.618034f + 0.11f) % 1f) + sin(t * 0.4f + i) * 30f * u
            val fy = h * (0.22f + 0.30f * ((i * 0.381966f) % 1f)) + sin(t * 0.6f + i * 1.7f) * 20f * u
            val g = sin(t * 1.3f + i * 2.1f).coerceAtLeast(0f).let { it * it } * (if (mode == 2) 1f else 0.8f)
            if (g < 0.03f) continue
            drawCircle(Brush.radialGradient(listOf(Color(0xFFE8FF6A).copy(alpha = 0.55f * g), Color.Transparent), center = Offset(fx, fy), radius = 14f * u), 14f * u, Offset(fx, fy))
            drawCircle(Color(0xFFF4FF9A).copy(alpha = g), 1.8f * u, Offset(fx, fy))
        }
    }
}
