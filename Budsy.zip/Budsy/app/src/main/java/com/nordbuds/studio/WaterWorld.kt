package com.nordbuds.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.repeatOnLifecycle
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin

/**
 * "Ganga from the Himalaya" living world.
 *
 *  - TOP: snow-capped Himalaya (far + mid range, haze, forested foothills). The sun (day), low sun (evening) or moon + stars (night).
 *  - MIDDLE: the Ganga is born in a gap in the glaciers, winds down through the valley, sweeps past the left screen corner,
 *    swings back across the middle, widens and ends in a calm pool in the centre of the screen.
 *  - BOTTOM: land again: sandy ghat, meadow, marigolds. Pines, a small temple and a boat sit along the banks.
 *  - Live layer (cheap): drifting clouds, birds, flowing glints on the water, floating diyas (evening / night),
 *    a drifting boat, touch ripples on the river and a shooting star at night.
 *
 *  Everything that never moves (sky, mountains, land, river body) is painted ONCE into a bitmap and only blitted each frame.
 */

// ====================================================================================== input

/** Latest finger position, fed by [waterTouchSource] from the root of the app (observe-only, never consumes). */
internal object WaterInput {
    @Volatile var x = -1f
    @Volatile var y = -1f
    @Volatile var down = false
}

fun Modifier.waterTouchSource(enabled: Boolean): Modifier =
    if (!enabled) this else this.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val e = awaitPointerEvent(PointerEventPass.Initial)
                val c = e.changes.firstOrNull { it.pressed }
                if (c != null) { WaterInput.x = c.position.x; WaterInput.y = c.position.y; WaterInput.down = true }
                else WaterInput.down = false
            }
        }
    }

// ====================================================================================== palette

private class GPal(
    val skyTop: Color, val skyMid: Color, val skyBot: Color, val sun: Color, val sunGlow: Color,
    val farMtn: Color, val farShade: Color, val snow: Color, val snowShade: Color,
    val midMtn: Color, val hill: Color, val forest: Color,
    val landA: Color, val landB: Color, val sand: Color,
    val riverTop: Color, val riverBot: Color, val glint: Color, val cloud: Color, val haze: Color,
    val cloudA: Float, val stars: Boolean, val lamps: Boolean, val birdC: Color
)

private fun gpal(mode: Int): GPal = when (mode) {
    0 -> GPal(
        Color(0xFF4FB3FF), Color(0xFFA5DBFF), Color(0xFFFFF1D0), Color(0xFFFFE27A), Color(0xFFFFF6C8),
        Color(0xFF8FA8C8), Color(0xFF6F8AB0), Color(0xFFFFFFFF), Color(0xFFCFE0F3),
        Color(0xFF5F8E86), Color(0xFF3F7D4F), Color(0xFF2C5E3A),
        Color(0xFF7BC26A), Color(0xFF4C9A4A), Color(0xFFE3CF9B),
        Color(0xFF5CD0D6), Color(0xFF1F95B8), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFFFFFFF),
        0.85f, false, false, Color(0xFF2B3A4F)
    )
    1 -> GPal(
        Color(0xFF22306B), Color(0xFF9A5A86), Color(0xFFFFA974), Color(0xFFFF8A4C), Color(0xFFFFC08A),
        Color(0xFF6D6A9A), Color(0xFF4B4A7A), Color(0xFFFFD9E0), Color(0xFFC79BB8),
        Color(0xFF3F4C6B), Color(0xFF2E5A4A), Color(0xFF1F4237),
        Color(0xFF3F7A4F), Color(0xFF2A5C3F), Color(0xFFB79A6E),
        Color(0xFFF0A27E), Color(0xFF2A6A9C), Color(0xFFFFE2B8), Color(0xFFFFC9A8), Color(0xFFFFB88A),
        0.55f, true, true, Color(0xFF2B1F3D)
    )
    else -> GPal(
        Color(0xFF000000), Color(0xFF050B1E), Color(0xFF0E1F45), Color(0xFFE9F1FF), Color(0xFF6C88C8),
        Color(0xFF1A2447), Color(0xFF0F1730), Color(0xFFB9CBEE), Color(0xFF6F84B5),
        Color(0xFF0E1830), Color(0xFF0B2A25), Color(0xFF07201C),
        Color(0xFF0F3A2E), Color(0xFF0A2A22), Color(0xFF3A3A33),
        Color(0xFF1F4C85), Color(0xFF06203F), Color(0xFFBFD6FF), Color(0xFF8FA6D8), Color(0xFF3A5AA0),
        0.28f, true, true, Color(0xFF000000)
    )
}

// ====================================================================================== sim / caches

private const val RIVER_SEG = 16

private class WorldSim {
    var bmp: ImageBitmap? = null
    var key = -1
    // river centre line (px): position, unit normal, full width
    var n = 0
    var cx = FloatArray(0); var cy = FloatArray(0); var nx = FloatArray(0); var ny = FloatArray(0); var wd = FloatArray(0)
    // touch ripples
    val rx = FloatArray(5); val ry = FloatArray(5); val rb = FloatArray(5) { -99f }
    var ripIdx = 0
    var lastRip = -9f

    fun buildRiver(w: Float, h: Float) {
        // control points (fraction of screen) and full width (fraction of screen width). Source in the glacier gap, ends centre-bottom.
        val px = floatArrayOf(0.52f, 0.60f, 0.70f, 0.50f, 0.22f, 0.00f, 0.12f, 0.40f, 0.70f, 0.80f, 0.62f, 0.50f)
        val py = floatArrayOf(0.318f, 0.355f, 0.400f, 0.450f, 0.490f, 0.560f, 0.625f, 0.675f, 0.720f, 0.770f, 0.820f, 0.850f)
        val pw = floatArrayOf(0.010f, 0.016f, 0.024f, 0.034f, 0.048f, 0.064f, 0.082f, 0.102f, 0.124f, 0.146f, 0.172f, 0.200f)
        val segs = px.size - 1
        n = segs * RIVER_SEG + 1
        cx = FloatArray(n); cy = FloatArray(n); nx = FloatArray(n); ny = FloatArray(n); wd = FloatArray(n)
        fun cr(a: Float, b: Float, c: Float, d: Float, t: Float): Float =
            0.5f * ((2f * b) + (-a + c) * t + (2f * a - 5f * b + 4f * c - d) * t * t + (-a + 3f * b - 3f * c + d) * t * t * t)
        for (s in 0 until segs) {
            val i0 = maxOf(s - 1, 0); val i1 = s; val i2 = s + 1; val i3 = minOf(s + 2, px.size - 1)
            for (k in 0 until RIVER_SEG) {
                val t = k / RIVER_SEG.toFloat(); val idx = s * RIVER_SEG + k
                cx[idx] = cr(px[i0], px[i1], px[i2], px[i3], t) * w
                cy[idx] = cr(py[i0], py[i1], py[i2], py[i3], t) * h
                wd[idx] = maxOf(cr(pw[i0], pw[i1], pw[i2], pw[i3], t), 0.006f) * w
            }
        }
        cx[n - 1] = px.last() * w; cy[n - 1] = py.last() * h; wd[n - 1] = pw.last() * w
        for (i in 0 until n) {
            val a = maxOf(i - 1, 0); val b = minOf(i + 1, n - 1)
            var tx = cx[b] - cx[a]; var ty = cy[b] - cy[a]
            val l = hypot(tx, ty).coerceAtLeast(0.001f); tx /= l; ty /= l
            nx[i] = -ty; ny[i] = tx
        }
    }

    /** true when (x, y) is farther than [margin] px from the water edge, i.e. safe land for trees / animals / flowers */
    fun onLand(x: Float, y: Float, margin: Float): Boolean {
        for (i in 0 until n) { if (hypot(x - cx[i], y - cy[i]) < wd[i] * 0.5f + margin) return false }
        val ex = cx[n - 1]; val ey = cy[n - 1]
        if (hypot((x - ex) / (wd[n - 1] * 1.05f), (y - ey) / (wd[n - 1] * 0.38f)) < 1f) return false
        return true
    }

    fun insideRiver(x: Float, y: Float): Boolean {
        for (i in 0 until n step 2) {
            val d = hypot(x - cx[i], y - cy[i])
            if (d < wd[i] * 0.5f) return true
        }
        return false
    }
}

private fun hash(n: Int): Float { val x = sin(n * 127.1f + 311.7f) * 43758.547f; return x - floor(x) }

// ====================================================================================== composable

@Composable
fun OceanBackground(modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val mode = if (P.amoled) 2 else if (P.dark) 1 else 0
    val pal = remember(mode) { gpal(mode) }
    val sim = remember { WorldSim() }
    var t by remember { mutableFloatStateOf(if (reduce) 9f else 0f) }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    // ~30 fps for the ambient world (full rate only while a finger is on the river); stops completely in the background.
    if (!reduce) LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            var last = 0L
            while (true) {
                withFrameNanos { nanos ->
                    if (last == 0L) { last = nanos; return@withFrameNanos }
                    val minGap = if (WaterInput.down) 16_000_000L else 33_000_000L
                    val gap = nanos - last
                    if (gap >= minGap - 4_000_000L) {
                        t = (t + gap / 1_000_000_000f) % 7200f
                        last = nanos
                    }
                }
            }
        }
    }
    Canvas(modifier.fillMaxSize()) { drawWorld(t, mode, sim, pal, !reduce) }
}

// ====================================================================================== draw

private fun DrawScope.drawWorld(t: Float, mode: Int, sim: WorldSim, pal: GPal, live: Boolean) {
    val w = size.width; val h = size.height
    val u = w / 1080f
    val key = mode * 100000 + w.toInt() * 7 + h.toInt()
    if (sim.bmp == null || sim.key != key) {
        sim.buildRiver(w, h)
        val bmp = ImageBitmap(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1))
        CanvasDrawScope().draw(this, LayoutDirection.Ltr, GfxCanvas(bmp), Size(w, h)) { drawStatic(mode, sim, pal) }
        sim.bmp = bmp; sim.key = key
    }
    drawImage(sim.bmp!!)

    // ---- animals on the land
    drawCow(w * 0.74f, h * 0.595f, 22f * u, t, mode)
    drawDeer(w * 0.20f, h * 0.80f, 26f * u, t, mode)
    drawRabbit(w * (0.86f + 0.04f * sin(t * 0.25f)), h * 0.865f, 9f * u, t, mode)

    // ---- swaying grass blades + flowers in the bottom meadow
    for (i in 0 until 36) {
        val x = hash(i + 2500) * w; val y = h * (0.945f + 0.05f * hash(i + 2600)); val len = (16f + 18f * hash(i + 2700)) * u
        val sw = sin(t * 1.6f + x * 0.01f + i) * 3.5f * u
        drawLine(pal.landA, Offset(x, y), Offset(x + sw, y - len), 1.9f * u, StrokeCap.Round)
    }
    val petals = intArrayOf(0xFFFF8FB8.toInt(), 0xFFFFE14D.toInt(), 0xFFFFFFFF.toInt(), 0xFFB388FF.toInt(), 0xFFFF7A59.toInt(), 0xFFFFA43D.toInt())
    for (i in 0 until 14) {
        val x = hash(i + 2300) * w; val y = h * (0.948f + 0.045f * hash(i + 2400)); val sh = (16f + 14f * hash(i + 2450)) * u
        val hx = x + sin(t * 1.4f + i) * 3f * u; val hy = y - sh
        drawLine(pal.landB, Offset(x, y), Offset(hx, hy), 1.5f * u, StrokeCap.Round)
        val pc = tintMode(Color(petals[i % petals.size]), mode)
        for (k in 0 until 5) { val a = k * 1.2566f + t * 0.1f; drawCircle(pc, 2.4f * u, Offset(hx + kotlin.math.cos(a) * 3.1f * u, hy + sin(a) * 3.1f * u)) }
        drawCircle(Color(0xFFFFD84D), 1.8f * u, Offset(hx, hy))
    }

    // ---- clouds
    val nCl = 4
    for (i in 0 until nCl) {
        val x = (((i * 0.31f + t * 0.006f * (0.6f + 0.3f * i)) % 1.4f) - 0.2f) * w
        val y = h * (0.04f + 0.035f * ((i * 3) % 4))
        val c = pal.cloud.copy(alpha = pal.cloudA * (0.8f - 0.12f * i))
        val r = (26f + 7f * (i % 3)) * u
        drawCircle(c, r, Offset(x, y)); drawCircle(c, r * 1.2f, Offset(x + r * 1.1f, y - r * 0.2f))
        drawCircle(c, r * 0.9f, Offset(x + r * 2.2f, y)); drawCircle(c, r * 0.8f, Offset(x + r * 0.2f, y + r * 0.3f))
        drawCircle(c, r * 0.7f, Offset(x + r * 1.5f, y + r * 0.4f))
    }
    // ---- birds (day / evening)
    if (pal.cloudA > 0.5f) for (i in 0 until 4) {
        val x = (((i * 0.27f + t * 0.010f * (0.7f + 0.2f * i)) % 1.2f) - 0.1f) * w
        val y = h * (0.10f + 0.03f * i) + sin(t * 0.9f + i) * 6f * u
        val s = (7f + 2f * i) * u; val f = sin(t * 7f + i * 2f) * s * 0.6f
        drawLine(pal.birdC.copy(alpha = 0.75f), Offset(x - s, y - f), Offset(x, y), 1.6f * u, StrokeCap.Round)
        drawLine(pal.birdC.copy(alpha = 0.75f), Offset(x, y), Offset(x + s, y - f), 1.6f * u, StrokeCap.Round)
    }
    // ---- twinkling stars + shooting star (evening / night)
    if (pal.stars) {
        for (i in 0 until 14) {
            val x = hash(i + 300) * w; val y = hash(i + 400) * h * 0.22f
            val a = 0.25f + 0.6f * (0.5f + 0.5f * sin(t * (1.2f + hash(i) * 2f) + i))
            drawCircle(Color.White.copy(alpha = a), (1.1f + hash(i + 9)) * u, Offset(x, y))
        }
        if (mode == 2) {
            val ph = (t % 11f) / 1.1f
            if (ph < 1f) {
                val sx = w * 0.9f - ph * w * 0.35f; val sy = h * 0.03f + ph * h * 0.10f
                drawLine(Brush.linearGradient(listOf(Color.White.copy(alpha = (1f - ph) * 0.9f), Color.Transparent), Offset(sx, sy), Offset(sx + 70f * u, sy - 26f * u)),
                    Offset(sx, sy), Offset(sx + 70f * u, sy - 26f * u), 2f * u, StrokeCap.Round)
            }
        }
    }

    // ---- flowing glints on the river
    val n = sim.n
    for (i in 0 until 46) {
        val s = (i * 0.6180339f + t * 0.012f * (0.6f + hash(i) * 0.8f)) % 1f
        val idx = (s * (n - 1)).toInt().coerceIn(1, n - 2)
        val o = (hash(i + 50) - 0.5f) * 0.8f * sim.wd[idx]
        val gx = sim.cx[idx] + sim.nx[idx] * o; val gy = sim.cy[idx] + sim.ny[idx] * o
        val dx = sim.cx[idx + 1] - sim.cx[idx - 1]; val dy = sim.cy[idx + 1] - sim.cy[idx - 1]
        val l = hypot(dx, dy).coerceAtLeast(0.001f)
        val len = (3f + 11f * s) * u
        val a = 0.20f + 0.55f * (0.5f + 0.5f * sin(t * 2.2f + i * 1.7f))
        drawLine(pal.glint.copy(alpha = a), Offset(gx, gy), Offset(gx + dx / l * len, gy + dy / l * len), (1.2f + 1.8f * s) * u, StrokeCap.Round)
    }

    // ---- floating diyas (evening / night)
    if (pal.lamps) for (i in 0 until 6) {
        val s = 0.14f + ((i / 6f + t * 0.005f) % 1f) * 0.80f
        val idx = (s * (n - 1)).toInt().coerceIn(1, n - 2)
        val o = sin(t * 0.4f + i * 1.3f) * 0.25f * sim.wd[idx]
        val x = sim.cx[idx] + sim.nx[idx] * o; val y = sim.cy[idx] + sim.ny[idx] * o + sin(t * 1.6f + i) * 0.8f * u
        val r = (2.4f + 6.5f * s) * u
        val fl = 1f + 0.12f * sin(t * 9f + i * 3f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFB347).copy(alpha = 0.55f), Color.Transparent), Offset(x, y - r * 0.6f), r * 3.4f), r * 3.4f, Offset(x, y - r * 0.6f))
        drawOval(Color(0xFFB5541F), Offset(x - r, y - r * 0.2f), Size(r * 2f, r * 0.9f))
        drawOval(Color(0xFFFFD27A), Offset(x - r * 0.28f * fl, y - r * 1.25f * fl), Size(r * 0.56f * fl, r * 1.15f * fl))
    }

    // ---- boat drifting down the river
    run {
        val s = 0.28f + ((t * 0.0035f) % 1f) * 0.55f
        val idx = (s * (n - 1)).toInt().coerceIn(1, n - 2)
        val bx = sim.cx[idx]; val by = sim.cy[idx] + sin(t * 1.3f) * 0.9f * u
        val bs = (5f + 18f * s) * u
        val hull = Path().apply {
            moveTo(bx - bs * 1.5f, by - bs * 0.15f); lineTo(bx + bs * 1.5f, by - bs * 0.15f)
            lineTo(bx + bs * 1.0f, by + bs * 0.45f); lineTo(bx - bs * 1.0f, by + bs * 0.45f); close()
        }
        drawPath(hull, Color(0xFF5A3A22))
        val sail = Path().apply { moveTo(bx, by - bs * 2.6f); lineTo(bx + bs * 1.1f, by - bs * 0.25f); lineTo(bx, by - bs * 0.25f); close() }
        drawPath(sail, if (mode == 2) Color(0xFF8FA6D8) else Color(0xFFFFF4E0))
        drawLine(Color(0xFF3B2814), Offset(bx, by - bs * 2.7f), Offset(bx, by - bs * 0.15f), 1.2f * u)
        if (pal.lamps) drawCircle(Color(0xFFFFC46B).copy(alpha = 0.9f), bs * 0.22f, Offset(bx - bs * 1.2f, by - bs * 0.45f))
    }

    // ---- touch ripples on the river
    if (live) {
        if (WaterInput.down && t - sim.lastRip > 0.16f && sim.insideRiver(WaterInput.x, WaterInput.y)) {
            val k = sim.ripIdx; sim.rx[k] = WaterInput.x; sim.ry[k] = WaterInput.y; sim.rb[k] = t
            sim.ripIdx = (k + 1) % sim.rx.size; sim.lastRip = t
        }
        for (k in sim.rx.indices) {
            val a = t - sim.rb[k]
            if (a < 0f || a > 1.4f) continue
            val r = (8f + 60f * a) * u
            drawOval(pal.glint.copy(alpha = (1f - a / 1.4f) * 0.55f), Offset(sim.rx[k] - r, sim.ry[k] - r * 0.45f), Size(r * 2f, r * 0.9f), style = Stroke(1.6f * u))
        }
    }

    // ---- butterflies over the flowers (day: 5, evening: 3) / fireflies (evening + night)
    if (mode <= 1) {
        val hxs = floatArrayOf(0.18f, 0.76f, 0.42f, 0.10f, 0.90f); val hys = floatArrayOf(0.93f, 0.91f, 0.955f, 0.70f, 0.64f)
        val c1 = intArrayOf(0xFFFF9F43.toInt(), 0xFF74B9FF.toInt(), 0xFFFF7EB6.toInt(), 0xFFB388FF.toInt(), 0xFFFFE14D.toInt())
        val c2 = intArrayOf(0xFFFFD166.toInt(), 0xFF9AD0FF.toInt(), 0xFFFFB3D1.toInt(), 0xFFD9C5FF.toInt(), 0xFFFFF29A.toInt())
        val count = if (mode == 0) 5 else 3
        for (i in 0 until count) {
            val ph = i * 1.9f
            val bx = hxs[i] * w + sin(t * 0.7f + ph) * 64f * u + sin(t * 1.9f + ph * 2f) * 14f * u
            val by = hys[i] * h - 30f * u + sin(t * 0.9f + ph * 1.3f) * 26f * u + sin(t * 2.3f + ph) * 5f * u
            butterfly(bx, by, (7f + 2f * (i % 3)) * u, tintMode(Color(c1[i]), mode), tintMode(Color(c2[i]), mode), kotlin.math.abs(sin(t * 9f + ph)))
        }
    }
    if (mode >= 1) for (i in 0 until if (mode == 2) 14 else 8) {
        val bx = (hash(i + 2100) + sin(t * 0.3f + i) * 0.04f) * w
        val by = h * (0.46f + 0.46f * hash(i + 2200)) + sin(t * 0.6f + i * 2f) * 14f * u
        val a = 0.25f + 0.75f * (0.5f + 0.5f * sin(t * 2.4f + i * 1.9f))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFD8FF6A).copy(alpha = 0.55f * a), Color.Transparent), Offset(bx, by), 9f * u), 9f * u, Offset(bx, by))
        drawCircle(Color(0xFFF3FFB0).copy(alpha = a), 1.6f * u, Offset(bx, by))
    }
}

// ====================================================================================== life: plants, animals, butterflies

private fun tintMode(c: Color, mode: Int): Color = when (mode) { 1 -> lerp(c, Color(0xFF3A2A5A), 0.35f); 2 -> lerp(c, Color(0xFF050A1A), 0.78f); else -> c }

private fun DrawScope.broadleaf(x: Float, baseY: Float, s: Float, leaf: Color, light: Color, trunk: Color) {
    drawLine(trunk, Offset(x, baseY), Offset(x, baseY - s * 0.55f), s * 0.14f, StrokeCap.Round)
    drawCircle(leaf, s * 0.42f, Offset(x, baseY - s * 0.82f))
    drawCircle(leaf, s * 0.34f, Offset(x - s * 0.30f, baseY - s * 0.62f))
    drawCircle(leaf, s * 0.34f, Offset(x + s * 0.30f, baseY - s * 0.64f))
    drawCircle(light.copy(alpha = 0.55f), s * 0.22f, Offset(x - s * 0.10f, baseY - s * 0.95f))
}

private fun DrawScope.butterfly(x: Float, y: Float, s: Float, c1: Color, c2: Color, flap: Float) {
    val wv = (0.25f + 0.75f * flap) * s
    drawOval(c1, Offset(x - wv, y - s * 0.75f), Size(wv, s * 0.85f)); drawOval(c1, Offset(x, y - s * 0.75f), Size(wv, s * 0.85f))
    drawOval(c2, Offset(x - wv * 0.8f, y - s * 0.05f), Size(wv * 0.8f, s * 0.65f)); drawOval(c2, Offset(x, y - s * 0.05f), Size(wv * 0.8f, s * 0.65f))
    drawLine(Color(0xFF2B2230), Offset(x, y - s * 0.55f), Offset(x, y + s * 0.55f), s * 0.17f, StrokeCap.Round)
    drawLine(Color(0xFF2B2230), Offset(x, y - s * 0.55f), Offset(x - s * 0.3f, y - s * 0.95f), s * 0.07f, StrokeCap.Round)
    drawLine(Color(0xFF2B2230), Offset(x, y - s * 0.55f), Offset(x + s * 0.3f, y - s * 0.95f), s * 0.07f, StrokeCap.Round)
}

/** Doe grazing: the head dips to the grass and lifts again. */
private fun DrawScope.drawDeer(x: Float, g: Float, s: Float, t: Float, mode: Int) {
    val body = tintMode(Color(0xFFB9824A), mode); val dark = tintMode(Color(0xFF7A4E27), mode); val belly = tintMode(Color(0xFFF1DDB8), mode)
    val by = g - s * 1.55f
    val dip = 0.5f + 0.5f * sin(t * 0.5f)
    val legW = s * 0.13f
    for (lx in floatArrayOf(-0.85f, -0.55f, 0.6f, 0.9f)) drawLine(dark, Offset(x + lx * s, by + s * 0.2f), Offset(x + lx * s, g), legW, StrokeCap.Round)
    drawOval(body, Offset(x - s * 1.15f, by - s * 0.45f), Size(s * 2.3f, s * 0.95f))
    drawOval(belly, Offset(x - s * 0.8f, by + s * 0.12f), Size(s * 1.6f, s * 0.3f))
    for (k in 0 until 5) drawCircle(Color.White.copy(alpha = 0.65f), s * 0.05f, Offset(x - s * 0.7f + k * s * 0.34f, by - s * 0.22f + (k % 2) * s * 0.12f))
    drawLine(Color.White.copy(alpha = 0.9f), Offset(x - s * 1.12f, by - s * 0.15f), Offset(x - s * 1.28f, by - s * 0.32f), s * 0.12f, StrokeCap.Round)   // tail
    val hx = x + s * (1.55f + 0.25f * dip); val hy = by - s * (0.95f - 1.25f * dip)
    drawLine(body, Offset(x + s * 0.95f, by - s * 0.25f), Offset(hx, hy), s * 0.36f, StrokeCap.Round)
    drawOval(body, Offset(hx - s * 0.2f, hy - s * 0.2f), Size(s * 0.65f, s * 0.38f))
    drawCircle(Color(0xFF241812), s * 0.05f, Offset(hx + s * 0.12f, hy - s * 0.04f))
    drawOval(body, Offset(hx - s * 0.12f, hy - s * 0.55f), Size(s * 0.2f, s * 0.38f)); drawOval(dark, Offset(hx + s * 0.06f, hy - s * 0.5f), Size(s * 0.16f, s * 0.32f))
}

/** Rabbit that hops in small arcs. */
private fun DrawScope.drawRabbit(x: Float, g: Float, s: Float, t: Float, mode: Int) {
    val fur = tintMode(Color(0xFFE9E1D6), mode); val ear = tintMode(Color(0xFFFFB3C1), mode)
    val hop = maxOf(0f, sin(t * 2.4f)); val y = g - hop * s * 1.1f
    drawOval(fur, Offset(x - s * 1.0f, y - s * 1.1f), Size(s * 2.0f, s * 1.2f))
    drawCircle(fur, s * 0.58f, Offset(x + s * 0.95f, y - s * 1.2f))
    drawOval(fur, Offset(x + s * 0.7f, y - s * 2.35f), Size(s * 0.38f, s * 1.3f)); drawOval(ear, Offset(x + s * 0.78f, y - s * 2.2f), Size(s * 0.2f, s * 0.95f))
    drawOval(fur, Offset(x + s * 1.05f, y - s * 2.3f), Size(s * 0.38f, s * 1.25f))
    drawCircle(Color.White, s * 0.28f, Offset(x - s * 1.05f, y - s * 0.65f))
    drawCircle(Color(0xFF241812), s * 0.07f, Offset(x + s * 1.2f, y - s * 1.3f))
}

/** Zebu cow standing on the bank; the tail swishes. */
private fun DrawScope.drawCow(x: Float, g: Float, s: Float, t: Float, mode: Int) {
    val hide = tintMode(Color(0xFFF4ECE0), mode); val patch = tintMode(Color(0xFFB07A4A), mode); val dark = tintMode(Color(0xFF6B4A2A), mode)
    val by = g - s * 1.7f
    for (lx in floatArrayOf(-1.2f, -0.8f, 0.8f, 1.2f)) drawLine(dark, Offset(x + lx * s, by + s * 0.3f), Offset(x + lx * s, g), s * 0.2f, StrokeCap.Round)
    drawOval(hide, Offset(x - s * 1.55f, by - s * 0.65f), Size(s * 3.1f, s * 1.35f))
    drawCircle(patch, s * 0.42f, Offset(x - s * 0.5f, by - s * 0.1f)); drawCircle(patch, s * 0.3f, Offset(x + s * 0.4f, by + s * 0.15f))
    drawCircle(hide, s * 0.42f, Offset(x + s * 1.0f, by - s * 0.65f))                         // hump
    val sw = sin(t * 1.6f) * s * 0.35f
    drawLine(dark, Offset(x - s * 1.5f, by - s * 0.3f), Offset(x - s * 1.8f + sw, by + s * 0.7f), s * 0.1f, StrokeCap.Round)   // tail
    val hx = x + s * 1.75f; val hy = by - s * 0.05f
    drawLine(hide, Offset(x + s * 1.3f, by - s * 0.2f), Offset(hx, hy), s * 0.55f, StrokeCap.Round)
    drawOval(hide, Offset(hx - s * 0.2f, hy - s * 0.3f), Size(s * 0.85f, s * 0.7f)); drawOval(patch, Offset(hx + s * 0.35f, hy + s * 0.02f), Size(s * 0.3f, s * 0.26f))
    drawLine(dark, Offset(hx + s * 0.05f, hy - s * 0.28f), Offset(hx - s * 0.05f, hy - s * 0.6f), s * 0.09f, StrokeCap.Round)
    drawLine(dark, Offset(hx + s * 0.3f, hy - s * 0.28f), Offset(hx + s * 0.4f, hy - s * 0.58f), s * 0.09f, StrokeCap.Round)
    drawCircle(Color(0xFF241812), s * 0.06f, Offset(hx + s * 0.28f, hy - s * 0.08f))
}

// ====================================================================================== static layer

private fun DrawScope.drawStatic(mode: Int, sim: WorldSim, pal: GPal) {
    val w = size.width; val h = size.height; val u = w / 1080f
    val baseY = h * 0.31f

    // sky
    drawRect(Brush.verticalGradient(listOf(pal.skyTop, pal.skyMid, pal.skyBot), 0f, h * 0.36f), size = Size(w, h * 0.36f))
    // sun / moon
    val sunX = if (mode == 2) w * 0.20f else w * 0.80f
    val sunY = if (mode == 1) h * 0.24f else h * 0.095f
    drawCircle(Brush.radialGradient(listOf(pal.sunGlow.copy(alpha = if (mode == 2) 0.35f else 0.6f), Color.Transparent), Offset(sunX, sunY), 190f * u), 190f * u, Offset(sunX, sunY))
    drawCircle(pal.sun, (if (mode == 2) 34f else 46f) * u, Offset(sunX, sunY))
    if (mode == 2) drawCircle(pal.skyMid.copy(alpha = 0.55f), 30f * u, Offset(sunX + 14f * u, sunY - 4f * u))   // crescent bite
    // stars
    if (pal.stars) for (i in 0 until 70) {
        val a = if (mode == 2) 0.35f + 0.55f * hash(i + 20) else 0.15f + 0.4f * hash(i + 20)
        drawCircle(Color.White.copy(alpha = a), (0.8f + 1.3f * hash(i + 90)) * u, Offset(hash(i) * w, hash(i + 55) * h * 0.26f))
    }

    // far Himalaya: alternating peak / valley vertices (x fraction, y fraction)
    val fx = floatArrayOf(0.00f, 0.06f, 0.12f, 0.19f, 0.27f, 0.34f, 0.42f, 0.50f, 0.57f, 0.65f, 0.72f, 0.79f, 0.87f, 0.94f, 1.00f)
    val fy = floatArrayOf(0.22f, 0.15f, 0.21f, 0.10f, 0.19f, 0.14f, 0.20f, 0.06f, 0.18f, 0.12f, 0.20f, 0.09f, 0.19f, 0.13f, 0.22f)
    val far = Path().apply {
        moveTo(0f, baseY)
        for (i in fx.indices) lineTo(fx[i] * w, fy[i] * h)
        lineTo(w, baseY); close()
    }
    drawPath(far, Brush.verticalGradient(listOf(pal.farMtn, pal.farMtn.copy(alpha = 0.92f)), h * 0.06f, baseY))
    // shaded east faces + snow caps on every peak (odd indices)
    for (i in 1 until fx.size - 1 step 2) {
        val pxv = fx[i] * w; val pyv = fy[i] * h
        val lx = fx[i - 1] * w; val ly = fy[i - 1] * h; val rx = fx[i + 1] * w; val ry = fy[i + 1] * h
        drawPath(Path().apply { moveTo(pxv, pyv); lineTo(rx, ry); lineTo(pxv + (rx - pxv) * 0.35f, baseY); lineTo(pxv - 4f * u, baseY * 0.99f); close() }, pal.farShade.copy(alpha = 0.55f))
        val cap = 0.40f
        val l1x = pxv + (lx - pxv) * cap; val l1y = pyv + (ly - pyv) * cap
        val r1x = pxv + (rx - pxv) * cap; val r1y = pyv + (ry - pyv) * cap
        val snow = Path().apply {
            moveTo(pxv, pyv); lineTo(r1x, r1y)
            lineTo(r1x - (r1x - pxv) * 0.25f, r1y + 9f * u); lineTo(pxv + (r1x - pxv) * 0.35f, r1y - 3f * u)
            lineTo(pxv, r1y + 22f * u); lineTo(pxv + (l1x - pxv) * 0.45f, l1y - 2f * u)
            lineTo(l1x + (pxv - l1x) * 0.25f, l1y + 10f * u); lineTo(l1x, l1y); close()
        }
        drawPath(snow, pal.snow)
        drawPath(Path().apply { moveTo(pxv, pyv); lineTo(r1x, r1y); lineTo(pxv + (r1x - pxv) * 0.35f, r1y - 3f * u); lineTo(pxv, r1y + 22f * u); close() }, pal.snowShade.copy(alpha = 0.8f))
    }
    // haze between the ranges
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, pal.haze.copy(alpha = if (mode == 0) 0.45f else 0.28f), Color.Transparent), h * 0.17f, baseY + 8f * u), Offset(0f, h * 0.17f), Size(w, baseY + 8f * u - h * 0.17f))

    // mid range (forested ridge)
    val mid = Path().apply {
        moveTo(0f, h * 0.34f)
        var x = 0f
        while (x <= w + 30f * u) {
            val k = x / w
            lineTo(x, h * (0.285f + 0.025f * sin(k * 9.2f + 0.6f) + 0.015f * sin(k * 21f) + 0.012f * hash((x / (30f * u)).toInt() + 700)))
            x += 30f * u
        }
        lineTo(w, h * 0.34f); close()
    }
    drawPath(mid, pal.midMtn)
    // foothills + land
    val hills = Path().apply {
        moveTo(0f, h * 0.36f)
        var x = 0f
        while (x <= w + 20f * u) { lineTo(x, h * (0.322f + 0.014f * sin(x / w * 7f + 2f) + 0.008f * sin(x / w * 17f))); x += 20f * u }
        lineTo(w, h * 0.36f); close()
    }
    drawPath(hills, pal.hill)
    drawRect(Brush.verticalGradient(listOf(pal.forest, pal.landA, pal.landB), h * 0.33f, h), Offset(0f, h * 0.33f), Size(w, h * 0.67f))
    // pines on the foothills (small, far)
    for (i in 0 until 34) {
        val x = hash(i + 800) * w; val y = h * (0.325f + 0.035f * hash(i + 850))
        pine(x, y, (9f + 7f * hash(i + 870)) * u, pal.forest, pal.landB)
    }

    // ---------------- river ----------------
    val n = sim.n
    fun edgeLine(sign: Float, extra: Float): Path = Path().apply {
        for (i in 0 until n) {
            val half = (sim.wd[i] + extra * (0.5f + i / n.toFloat())) * 0.5f
            val x = sim.cx[i] + sim.nx[i] * half * sign; val y = sim.cy[i] + sim.ny[i] * half * sign
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
    }
    fun ribbon(extra: Float): Path = Path().apply {
        for (i in 0 until n) {
            val half = (sim.wd[i] + extra * (0.5f + i / n.toFloat())) * 0.5f
            val x = sim.cx[i] - sim.nx[i] * half; val y = sim.cy[i] - sim.ny[i] * half
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        for (i in n - 1 downTo 0) {
            val half = (sim.wd[i] + extra * (0.5f + i / n.toFloat())) * 0.5f
            lineTo(sim.cx[i] + sim.nx[i] * half, sim.cy[i] + sim.ny[i] * half)
        }
        close()
    }
    val ex = sim.cx[n - 1]; val ey = sim.cy[n - 1]; val er = sim.wd[n - 1] * 0.95f
    // sandy banks + pool bank
    drawPath(ribbon(16f * u), pal.sand)
    drawOval(pal.sand, Offset(ex - er - 8f * u, ey - er * 0.30f - 6f * u), Size(2f * er + 16f * u, er * 0.60f + 12f * u))
    // water
    val water = Brush.verticalGradient(listOf(pal.riverTop, pal.riverBot), h * 0.31f, h * 0.88f)
    drawPath(ribbon(0f), water)
    drawOval(water, Offset(ex - er, ey - er * 0.30f), Size(2f * er, er * 0.60f))
    // soft darker middle + bright foam on both banks
    drawPath(edgeLine(-1f, 0f), pal.glint.copy(alpha = 0.30f), style = Stroke(1.4f * u))
    drawPath(edgeLine(1f, 0f), pal.glint.copy(alpha = 0.22f), style = Stroke(1.2f * u))
    // sky reflection sheen on the pool
    drawOval(Brush.verticalGradient(listOf(pal.skyBot.copy(alpha = if (mode == 0) 0.35f else 0.22f), Color.Transparent), ey - er * 0.30f, ey + er * 0.30f),
        Offset(ex - er * 0.9f, ey - er * 0.26f), Size(er * 1.8f, er * 0.5f))
    // glacier mouth at the source
    drawOval(pal.snow, Offset(sim.cx[0] - 26f * u, sim.cy[0] - 12f * u), Size(52f * u, 18f * u))
    drawOval(pal.snowShade.copy(alpha = 0.7f), Offset(sim.cx[0] - 14f * u, sim.cy[0] - 6f * u), Size(28f * u, 10f * u))

    // trees along the banks (scaled by depth)
    for (i in 0 until 26) {
        val idx = ((i + 0.5f) / 26f * (n - 1)).toInt().coerceIn(0, n - 1)
        val s = idx / (n - 1).toFloat()
        val side = if (i % 2 == 0) 1f else -1f
        val off = sim.wd[idx] * 0.5f + (22f + 40f * hash(i + 910)) * u * (0.4f + s)
        val x = sim.cx[idx] + sim.nx[idx] * off * side; val y = sim.cy[idx] + sim.ny[idx] * off * side
        if (x < -20f * u || x > w + 20f * u) continue
        if (i % 3 == 0) pine(x, y, (14f + 34f * s) * u, pal.forest, pal.landB)
        else broadleaf(x, y, (14f + 34f * s) * u, pal.forest, pal.landA, pal.landB)
    }
    // small temple on the right bank mid-way
    run {
        val idx = (0.52f * (n - 1)).toInt()
        val tx = (sim.cx[idx] + sim.wd[idx] * 0.5f + 60f * u).coerceAtMost(w * 0.93f); val ty = sim.cy[idx] + 6f * u
        val tw = 34f * u
        val body = if (mode == 2) Color(0xFF1B2540) else Color(0xFFF2E3C8)
        drawRect(body, Offset(tx - tw / 2f, ty - tw * 0.8f), Size(tw, tw * 0.8f))
        drawPath(Path().apply { moveTo(tx - tw * 0.62f, ty - tw * 0.8f); lineTo(tx, ty - tw * 1.75f); lineTo(tx + tw * 0.62f, ty - tw * 0.8f); close() }, if (mode == 2) Color(0xFF2A3560) else Color(0xFFE2773A))
        drawLine(Color(0xFFE2773A), Offset(tx, ty - tw * 1.75f), Offset(tx, ty - tw * 2.2f), 1.6f * u)
        drawPath(Path().apply { moveTo(tx, ty - tw * 2.2f); lineTo(tx + tw * 0.38f, ty - tw * 2.05f); lineTo(tx, ty - tw * 1.92f); close() }, Color(0xFFFF6A3D))
        drawRect(if (mode == 0) Color(0xFF6B4A2A) else Color(0xFF0B0F1E), Offset(tx - tw * 0.12f, ty - tw * 0.45f), Size(tw * 0.24f, tw * 0.45f))
        if (pal.lamps) drawCircle(Color(0xFFFFC46B).copy(alpha = 0.85f), 2.2f * u, Offset(tx, ty - tw * 0.55f))
    }

    // ---------------- land life: trees, bushes, plants, flowers (static, painted once) ----------------
    run {
        val trees = ArrayList<FloatArray>()
        for (i in 0 until 90) {
            val x = hash(i + 3000) * w; val y = h * (0.42f + 0.42f * hash(i + 3100))
            if (trees.size < 30 && sim.onLand(x, y, 34f * u)) trees.add(floatArrayOf(x, y, i.toFloat()))
        }
        trees.sortBy { it[1] }
        for (tr in trees) {
            val sc = (16f + 40f * ((tr[1] / h - 0.40f) / 0.46f)) * u
            if (tr[2].toInt() % 3 == 0) pine(tr[0], tr[1], sc, pal.forest, pal.landB) else broadleaf(tr[0], tr[1], sc, pal.forest, pal.landA, pal.landB)
        }
        // bushes / shrubs
        var bushes = 0
        for (i in 0 until 90) {
            if (bushes >= 26) break
            val x = hash(i + 3200) * w; val y = h * (0.44f + 0.44f * hash(i + 3300))
            if (!sim.onLand(x, y, 18f * u)) continue
            bushes++
            val r = (6f + 11f * (y / h - 0.4f)) * u
            drawCircle(pal.forest, r, Offset(x, y - r * 0.5f)); drawCircle(pal.landB, r * 0.8f, Offset(x + r * 0.7f, y - r * 0.35f))
            drawCircle(pal.landA.copy(alpha = 0.8f), r * 0.55f, Offset(x - r * 0.3f, y - r * 0.8f))
        }
        // leafy plants + wild flowers
        val fc = intArrayOf(0xFFFF8FB8.toInt(), 0xFFFFE14D.toInt(), 0xFFFFFFFF.toInt(), 0xFFB388FF.toInt(), 0xFFFF7A59.toInt())
        var fl = 0
        for (i in 0 until 400) {
            if (fl >= 150) break
            val x = hash(i + 3400) * w; val y = h * (0.42f + 0.44f * hash(i + 3500))
            if (!sim.onLand(x, y, 10f * u)) continue
            fl++
            val sz = (1.6f + 1.8f * (y / h - 0.4f)) * u
            drawLine(pal.landB, Offset(x, y), Offset(x, y - sz * 3.2f), 1.1f * u)
            drawCircle(Color(fc[i % fc.size]), sz, Offset(x, y - sz * 3.4f))
            if (i % 4 == 0) { drawCircle(pal.landA, sz * 1.5f, Offset(x - sz * 1.6f, y - sz * 0.6f)); drawCircle(pal.landA, sz * 1.3f, Offset(x + sz * 1.7f, y - sz * 0.5f)) }
        }
    }

    // ---------------- bottom land ----------------
    val sandTop = h * 0.865f
    val sandPath = Path().apply {
        moveTo(0f, h); lineTo(0f, sandTop)
        var x = 0f
        while (x <= w + 20f * u) { lineTo(x, sandTop + 7f * u * sin(x / w * 9f + 1f) - 14f * u * (1f - kotlin.math.abs(x / w - 0.5f) * 2f).coerceAtLeast(0f)); x += 20f * u }
        lineTo(w, h); close()
    }
    drawPath(sandPath, pal.sand)
    // ghat steps in front of the pool
    for (k in 0 until 4) {
        val sy = sandTop + (2f + k * 11f) * u; val sw = (0.50f + 0.06f * k) * w
        drawRect(if (mode == 2) Color(0xFF2A2C34) else Color(0xFFCFB98A).copy(alpha = 0.55f - 0.06f * k), Offset(w / 2f - sw / 2f, sy), Size(sw, 3.2f * u))
    }
    // meadow strip at the very bottom
    val grass = Path().apply {
        moveTo(0f, h); lineTo(0f, h * 0.935f)
        var x = 0f
        while (x <= w + 20f * u) { lineTo(x, h * 0.935f + 6f * u * sin(x / w * 11f)); x += 20f * u }
        lineTo(w, h); close()
    }
    drawPath(grass, Brush.verticalGradient(listOf(pal.landA, pal.landB), h * 0.93f, h))
    for (i in 0 until 90) {
        val x = hash(i + 1000) * w; val y = h * (0.94f + 0.06f * hash(i + 1100))
        val gh = (10f + 16f * hash(i + 1200)) * u
        drawLine(pal.landA.copy(alpha = 0.9f), Offset(x, y), Offset(x + (hash(i + 1300) - 0.5f) * 8f * u, y - gh), 1.6f * u, StrokeCap.Round)
    }
    // marigolds
    for (i in 0 until 16) {
        val x = hash(i + 1400) * w; val y = h * (0.955f + 0.04f * hash(i + 1500))
        drawCircle(if (i % 3 == 0) Color(0xFFFF8A1E) else Color(0xFFFFC21E), (2.6f + 1.6f * hash(i + 1600)) * u, Offset(x, y))
    }
    // grass on the left / right banks of the middle land
    for (i in 0 until 60) {
        val side = if (i % 2 == 0) 0f else 1f
        val x = if (side == 0f) hash(i + 1700) * w * 0.14f else w - hash(i + 1700) * w * 0.14f
        val y = h * (0.48f + 0.36f * hash(i + 1800))
        drawLine(pal.landA.copy(alpha = 0.55f), Offset(x, y), Offset(x + (hash(i + 1900) - 0.5f) * 6f * u, y - (7f + 9f * hash(i + 2000)) * u), 1.4f * u, StrokeCap.Round)
    }
}

/** A small pine: stacked triangles over a trunk. */
private fun DrawScope.pine(x: Float, baseY: Float, s: Float, leaf: Color, trunk: Color) {
    drawLine(trunk, Offset(x, baseY), Offset(x, baseY - s * 0.35f), s * 0.12f)
    for (k in 0 until 3) {
        val y0 = baseY - s * (0.20f + 0.34f * k); val ww = s * (0.50f - 0.11f * k)
        drawPath(Path().apply { moveTo(x - ww, y0); lineTo(x, y0 - s * 0.55f); lineTo(x + ww, y0); close() }, leaf)
    }
}

internal fun Path.quadTo(x1: Float, y1: Float, x2: Float, y2: Float) = quadraticBezierTo(x1, y1, x2, y2)
