package com.nordbuds.studio

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Brightness4
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val FEATURE_LABELS = linkedMapOf(
    "colors" to "Colors", "font" to "Font", "shapes" to "Shapes", "cards" to "Cards",
    "animation" to "Animation", "background" to "Wallpaper", "icons" to "Icons"
)

/**
 * Full-page Theme Manager (HyperOS-style): Stock Budsy + appearance, import .mtz/.budsytheme, and a library of
 * installed themes with Apply / Preview / Duplicate / Export / Delete. Preview renders a live mini-UI using the
 * theme's own colours, font, shapes, card style and icons before it is applied.
 */
@Composable
fun ThemeManagerScreen(
    activeId: String?, appearance: Int,
    onApply: (String?) -> Unit, onAppearance: (Int) -> Unit, onChanged: () -> Unit,
    toast: (String) -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var themes by remember { mutableStateOf(ThemeStore.list(ctx)) }
    var preview by remember { mutableStateOf<ImportedTheme?>(null) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var exportId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    fun reload() { themes = ThemeStore.list(ctx); onChanged() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                try {
                    val added = withContext(Dispatchers.IO) { ThemeStore.importPackage(ctx, uri) }
                    reload()
                    toast("Imported ${added.name}. Tap Apply to use it.")
                } catch (e: Exception) { toast("Import failed: ${e.message ?: "Invalid package"}") }
                finally { busy = false }
            }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val id = exportId
        if (uri != null && id != null) scope.launch {
            try { withContext(Dispatchers.IO) { ThemeStore.export(ctx, id, uri) }; toast("Theme saved as .budsytheme") }
            catch (e: Exception) { toast("Export failed: ${e.message ?: "Storage error"}") }
        }
        exportId = null
    }

    val ap = if (P.amoled) AppearanceMode.AMOLED else if (P.dark) AppearanceMode.DARK else AppearanceMode.LIGHT
    val activeName = themes.firstOrNull { it.id == activeId }?.name ?: "Stock Budsy"

    Box(Modifier.fillMaxSize().background(P.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }) {
        ImportedThemeImage(activeId, "background", Modifier.fillMaxSize(), alpha = LocalThemeSpec.current.background.imageAlpha)
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().background(P.bg.copy(alpha = 0.96f)).statusBarsPadding().padding(start = 6.dp, end = 16.dp, top = 6.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onBack() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = P.text)
                }
                Column(Modifier.weight(1f)) {
                    Txt("Theme Manager", 19, FontWeight.Bold, P.text, maxLines = 1)
                    Txt("Applied: $activeName", 11, color = P.sub, maxLines = 1)
                }
            }
            HorizontalDivider(color = P.line.copy(alpha = 0.72f), thickness = 0.6.dp)

            Page {
                SectionLabel("Stock Budsy", Icons.Rounded.Headphones, "Built-in default · always available, cannot be deleted")
                Segmented(
                    listOf(Icons.Rounded.WbSunny to "Light", Icons.Rounded.NightsStay to "Dark", Icons.Rounded.Brightness4 to "AMOLED", Icons.Rounded.Settings to "System"),
                    sel = when (appearance) { AppearanceMode.LIGHT -> 0; AppearanceMode.DARK -> 1; AppearanceMode.AMOLED -> 2; else -> 3 }
                ) { onAppearance(when (it) { 0 -> AppearanceMode.LIGHT; 1 -> AppearanceMode.DARK; 2 -> AppearanceMode.AMOLED; else -> AppearanceMode.SYSTEM }) }
                ValueRow(
                    "Use Stock Budsy", if (activeId == null) "Applied" else "Tap to switch back",
                    chevron = activeId != null, icon = Icons.Rounded.Headphones, glow = activeId == null
                ) { if (activeId != null) { onApply(null); toast("Stock Budsy applied.") } }
                SectionNote("Light, Dark and AMOLED work with Stock and with every imported theme (a theme can supply its own colours for each).")

                SectionLabel("Your themes", Icons.Rounded.Palette, "Import a .mtz or .budsytheme file, then Apply, Preview, Duplicate, Export or Delete")
                WideButton(if (busy) "Importing…" else "Import theme (.mtz / .budsytheme)", enabled = !busy, icon = Icons.Rounded.FileOpen) {
                    importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                }
                if (themes.isEmpty()) {
                    SectionNote("No themes imported yet. Stock Budsy is active.")
                }
                themes.forEach { item ->
                    ThemeCard(
                        item = item, applied = item.id == activeId, appearance = ap,
                        onApply = { onApply(item.id); toast("Applied ${item.name}.") },
                        onPreview = { preview = item },
                        onDuplicate = {
                            scope.launch {
                                try { val c = withContext(Dispatchers.IO) { ThemeStore.duplicate(ctx, item.id) }; reload(); toast("Created ${c.name}.") }
                                catch (e: Exception) { toast("Duplicate failed: ${e.message ?: "Storage error"}") }
                            }
                        },
                        onExport = { exportId = item.id; exportLauncher.launch("${item.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.budsytheme") },
                        onDelete = { deleteId = item.id }
                    )
                }

                SectionLabel("What a theme can change", Icons.Rounded.Settings)
                SectionNote("Colours (Light / Dark / AMOLED) · Font · Corner shapes · Card style (solid, glass, gradient, outline) · Animation speed, bounce, glow and tab transition · Wallpaper and dot-matrix · Navigation, header and battery icons · Earbud / case artwork.\nMTZ files: name, author, font and wallpaper are read. System-level MTZ parts (lock screen, launcher, status bar) cannot apply to a single app. Add a budsy/theme.json to an MTZ for full Budsy styling.")
                Spacer(Modifier.navigationBarsPadding())
            }
        }
    }

    val pv = preview
    if (pv != null) {
        val spec = remember(pv.id) { ThemeStore.spec(ctx, pv.id) }
        SheetDialog(
            onDismiss = { preview = null },
            footer = {
                WideButton(if (pv.id == activeId) "Currently applied" else "Apply ${pv.name}", enabled = pv.id != activeId, icon = Icons.Rounded.CheckCircle) {
                    onApply(pv.id); toast("Applied ${pv.name}."); preview = null
                }
            }
        ) {
            SheetTitle(pv.name)
            Txt("By ${pv.author} · ${pv.source.uppercase()} · v${pv.version}", 12, color = P.sub, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            // The preview is rendered with the candidate theme itself, so font, shapes, cards, icons and motion are real.
            BudsyTheme(ThemeMode.STOCK, ap, spec, pv.id) { ThemePreviewMock(pv.id) }
            if (pv.description.isNotBlank()) Txt(pv.description, 12, color = P.sub, modifier = Modifier.padding(top = 8.dp), lineHeight = 16)
        }
    }

    if (deleteId != null) {
        val id = deleteId!!
        GlassDialog(
            "Delete theme?", { deleteId = null }, "Delete",
            {
                try {
                    ThemeStore.delete(ctx, id)
                    if (activeId == id) onApply(null)
                    reload()
                    toast("Theme deleted.")
                } catch (e: Exception) { toast("Delete failed: ${e.message ?: "Unknown error"}") }
                deleteId = null
            },
            "Cancel", { deleteId = null }
        ) { Txt("This removes the theme and its files from Budsy. Stock Budsy is never affected.", 14, color = P.text, lineHeight = 20) }
    }
}

@Composable
private fun ThemeCard(
    item: ImportedTheme, applied: Boolean, appearance: Int,
    onApply: () -> Unit, onPreview: () -> Unit, onDuplicate: () -> Unit, onExport: () -> Unit, onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val spec = remember(item.id) { ThemeStore.spec(ctx, item.id) }
    val cs = spec?.colorsFor(appearance)
    val swatches = listOf(cs?.bg ?: 0xFF888888, cs?.card ?: 0xFFAAAAAA, cs?.accent ?: 0xFF3478F6, cs?.text ?: 0xFF222222).map { androidx.compose.ui.graphics.Color(it) }
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy((-8).dp)) {
                swatches.forEach { Box(Modifier.size(26.dp).clip(CircleShape).background(it).border(1.dp, P.line, CircleShape)) }
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Txt(item.name, 15, FontWeight.SemiBold, P.text, maxLines = 1)
                Txt("By ${item.author} · ${item.source.uppercase()}" + if (applied) " · Applied" else "", 11, color = if (applied) P.green else P.sub, maxLines = 1)
            }
        }
        if (item.features.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                FEATURE_LABELS.filterKeys { it in item.features }.values.take(5).forEach { label ->
                    Txt(label.uppercase(), 9, FontWeight.Bold, P.accent, Modifier.clip(CircleShape).background(P.accent.copy(alpha = 0.14f)).padding(horizontal = 7.dp, vertical = 2.dp), maxLines = 1, spacing = 0.6f)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton(if (applied) "Applied" else "Apply", !applied, icon = Icons.Rounded.CheckCircle) { if (!applied) onApply() }
            SmallButton("Preview", false, icon = Icons.Rounded.Visibility, onClick = onPreview)
            SmallButton("Copy", false, icon = Icons.Rounded.ContentCopy, onClick = onDuplicate)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("Save / Export", false, icon = Icons.Rounded.Share, onClick = onExport)
            SmallButton("Delete", false, icon = Icons.Rounded.Delete, onClick = onDelete)
        }
    }
}

/** A miniature Budsy screen drawn with whatever theme is in scope. */
@Composable
private fun ThemePreviewMock(themeId: String) {
    val shape = RoundedCornerShape(LocalThemeSpec.current.shapes.panel.dp.coerceAtMost(28.dp))
    Box(Modifier.fillMaxWidth().clip(shape).background(P.bg).border(1.dp, P.line, shape)) {
        ImportedThemeImage(themeId, "background", Modifier.matchParentSize(), alpha = LocalThemeSpec.current.background.imageAlpha)
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ThemedIcon(IconKeys.APP, Icons.Rounded.Headphones, P.accent, Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Txt("Budsy Buds", 17, FontWeight.Bold, P.text)
            }
            Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                ImportedThemeImage(themeId, "hero_both_out", Modifier.fillMaxSize(), ContentScale.Fit)
            }
            GlassPanel {
                Txt("Noise control", 14, FontWeight.SemiBold, P.text)
                Txt("Fonts, cards, shapes and icons follow this theme.", 12, color = P.sub, lineHeight = 16)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SmallButton("Primary", true) { }
                    SmallButton("Secondary", false) { }
                    IosSwitch(on = true, onChange = { })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("ANC", "On", Icons.Rounded.Headphones, true, Modifier.weight(1f)) { }
                FeatureTile("Off", "", Icons.Rounded.Headphones, false, Modifier.weight(1f)) { }
                BatteryStat(82, false, "Left", Modifier.weight(1f))
            }
        }
    }
}

