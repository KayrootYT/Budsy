package com.nordbuds.studio

import android.content.Context
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.concurrent.ConcurrentHashMap

/**
 * Phosphor Icons (MIT, https://phosphoricons.com) replace the Material glyphs everywhere in the app.
 * The SVGs are downloaded at build time into assets/icons (see app/build.gradle.kts). If one is missing the
 * original Material icon is drawn, so the app never breaks.
 *
 * This Icon() lives in the app package and wins over material3's Icon for every call that passes an ImageVector.
 */
private val PHOSPHOR_SLUGS: Map<String, String> = mapOf(
    "Rounded.Bluetooth" to "bluetooth",
    "Rounded.BluetoothDisabled" to "bluetooth-slash",
    "Rounded.Headphones" to "headphones",
    "Rounded.CheckCircle" to "check-circle",
    "Rounded.Waves" to "waves",
    "Rounded.Devices" to "devices",
    "Rounded.Close" to "x",
    "Rounded.TouchApp" to "hand-tap",
    "Rounded.ChevronRight" to "caret-right",
    "Rounded.ChevronLeft" to "caret-left",
    "Rounded.Tune" to "sliders-horizontal",
    "Rounded.SportsEsports" to "game-controller",
    "Rounded.Settings" to "gear-six",
    "Rounded.Info" to "info",
    "Rounded.Hearing" to "ear",
    "Rounded.Equalizer" to "equalizer",
    "Rounded.Block" to "prohibit",
    "Rounded.VolumeUp" to "speaker-high",
    "Rounded.VolumeDown" to "speaker-low",
    "Rounded.Vibration" to "vibrate",
    "Rounded.SystemUpdate" to "download-simple",
    "Rounded.Speaker" to "speaker-hifi",
    "Rounded.PanTool" to "hand",
    "Rounded.Palette" to "palette",
    "Rounded.LocationSearching" to "crosshair",
    "Rounded.LinkOff" to "link-break",
    "Rounded.Link" to "link",
    "Rounded.Language" to "globe",
    "Rounded.GraphicEq" to "waveform",
    "Rounded.Check" to "check",
    "Rounded.Call" to "phone",
    "Rounded.CallEnd" to "phone-disconnect",
    "Rounded.BugReport" to "bug",
    "Rounded.WbSunny" to "sun",
    "Rounded.Timer" to "timer",
    "Rounded.Stop" to "stop",
    "Rounded.Share" to "share-network",
    "Rounded.Sensors" to "broadcast",
    "Rounded.School" to "graduation-cap",
    "Rounded.Refresh" to "arrows-clockwise",
    "Rounded.NotificationsActive" to "bell-ringing",
    "Rounded.Notifications" to "bell",
    "Rounded.NightsStay" to "moon-stars",
    "Rounded.MoreHoriz" to "dots-three",
    "Rounded.Memory" to "cpu",
    "Rounded.Flag" to "flag",
    "Rounded.Fingerprint" to "fingerprint",
    "Rounded.Edit" to "pencil-simple",
    "Rounded.Delete" to "trash",
    "Rounded.ContentCopy" to "copy",
    "Rounded.Brightness4" to "circle-half",
    "Rounded.Bolt" to "lightning",
    "Rounded.AutoAwesome" to "sparkle",
    "Rounded.Warning" to "warning",
    "Rounded.Visibility" to "eye",
    "Rounded.SkipPrevious" to "skip-back",
    "Rounded.SkipNext" to "skip-forward",
    "Rounded.Search" to "magnifying-glass",
    "Rounded.Save" to "floppy-disk",
    "Rounded.RestartAlt" to "arrow-counter-clockwise",
    "Rounded.Replay" to "arrow-counter-clockwise",
    "Rounded.RecordVoiceOver" to "microphone-stage",
    "Rounded.PlayArrow" to "play",
    "Rounded.MusicNote" to "music-note",
    "Rounded.Mic" to "microphone",
    "Rounded.LooksOne" to "number-circle-one",
    "Rounded.LooksTwo" to "number-circle-two",
    "Rounded.Looks3" to "number-circle-three",
    "Rounded.FileOpen" to "folder-open",
    "Rounded.Contrast" to "circle-half",
    "Rounded.Circle" to "circle",
    "Rounded.BatteryFull" to "battery-full",
    "Rounded.BatteryChargingFull" to "battery-charging",
    "Rounded.Badge" to "identification-badge")

private val phCache = ConcurrentHashMap<String, ImageVector>()
private val phMissing: MutableSet<String> = ConcurrentHashMap.newKeySet()

private fun phosphorFor(ctx: Context, materialName: String?): ImageVector? {
    if (materialName == null) return null
    phCache[materialName]?.let { return it }
    if (materialName in phMissing) return null
    val slug = PHOSPHOR_SLUGS[materialName]
    if (slug == null) { phMissing.add(materialName); return null }
    return try {
        val svg = ctx.applicationContext.assets.open("icons/$slug.svg").bufferedReader().use { it.readText() }
        val paths = Regex("\\sd=\"([^\"]+)\"").findAll(svg).map { it.groupValues[1] }.toList()
        if (paths.isEmpty()) throw IllegalStateException("no path in $slug")
        val b = ImageVector.Builder(slug, 24.dp, 24.dp, 256f, 256f)
        paths.forEach { d -> b.addPath(PathParser().parsePathString(d).toNodes(), fill = SolidColor(Color.Black)) }
        val v = b.build()
        phCache[materialName] = v
        v
    } catch (_: Throwable) { phMissing.add(materialName); null }
}

@Composable
fun Icon(imageVector: ImageVector, contentDescription: String?, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current) {
    val ctx = LocalContext.current
    val v = remember(imageVector, ctx) { phosphorFor(ctx, imageVector.name) ?: imageVector }
    androidx.compose.material3.Icon(v, contentDescription, modifier, tint)
}
