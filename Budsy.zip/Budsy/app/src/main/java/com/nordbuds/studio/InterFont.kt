package com.nordbuds.studio

import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import java.io.File

/**
 * Inter (SIL OFL, https://rsms.me/inter) - the open-source typeface closest to iOS's SF Pro.
 * The TTFs are downloaded at build time into assets/fonts (see app/build.gradle.kts), copied once to app storage and
 * loaded from there. Returns null when the files are absent so the caller falls back to the system sans font.
 */
object InterFont {
    @Volatile private var cached: FontFamily? = null
    @Volatile private var tried = false

    fun get(ctx: Context): FontFamily? {
        if (tried) return cached
        synchronized(this) {
            if (tried) return cached
            cached = try { build(ctx) } catch (_: Throwable) { null }
            tried = true
        }
        return cached
    }

    @OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
    private fun build(ctx: Context): FontFamily? {
        val app = ctx.applicationContext
        val dir = File(app.filesDir, "fonts_inter").apply { mkdirs() }
        fun file(name: String): File? {
            val out = File(dir, name)
            if (!out.exists() || out.length() == 0L) {
                try { app.assets.open("fonts/$name").use { i -> out.outputStream().use { o -> i.copyTo(o) } } }
                catch (_: Exception) { out.delete(); return null }
            }
            return out
        }
        val reg = file("inter_regular.ttf") ?: return null
        android.graphics.Typeface.createFromFile(reg)   // throws on a corrupt file
        val med = file("inter_medium.ttf") ?: reg
        val semi = file("inter_semibold.ttf") ?: med
        val bold = file("inter_bold.ttf") ?: semi
        return FontFamily(
            androidx.compose.ui.text.font.Font(reg, FontWeight.Normal),
            androidx.compose.ui.text.font.Font(med, FontWeight.Medium),
            androidx.compose.ui.text.font.Font(semi, FontWeight.SemiBold),
            androidx.compose.ui.text.font.Font(bold, FontWeight.Bold)
        )
    }
}
