package com.nordbuds.studio

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Auto-connect even when the app is not open: as soon as the earbuds connect to the phone
 * (taken out of the case) the control channel is opened too.
 */
@SuppressLint("MissingPermission")
class BtConnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != BluetoothDevice.ACTION_ACL_CONNECTED && action != BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED) return
        if (action == BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED &&
            intent.getIntExtra(BluetoothProfile.EXTRA_STATE, -1) != BluetoothProfile.STATE_CONNECTED) return
        if (Build.VERSION.SDK_INT >= 31 &&
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val dev: BluetoothDevice = (if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)) ?: return
        Buds.attach(context.applicationContext)
        if (Buds.autoPaused || Buds.connected) return
        val last = Buds.prefs.lastAddr
        val ours = dev.address == last || (last == null && (dev.name ?: "").contains("buds", true))
        if (!ours) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                delay(1200) // let the earbuds finish bringing up their control service
                // Runs in Buds' own scope: the receiver's ~10 s budget must not cancel the GATT -> RFCOMM fallback.
                Buds.connect(dev, auto = true, retries = 2)
                delay(7000)
            } finally { pending.finish() }
        }
    }
}
