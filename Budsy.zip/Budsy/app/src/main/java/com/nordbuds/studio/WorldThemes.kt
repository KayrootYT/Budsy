package com.nordbuds.studio

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.pow

/** Ids of the four built-in worlds. [NONE] = Stock Budsy. */
object World {
    const val NONE = 0
    const val FOREST = 1
    const val SNOW = 2
    const val DESERT = 3
    const val OCEAN = 4
    val all = listOf(FOREST, SNOW, DESERT, OCEAN)
}

/** Day / Night / AMOLED as used by the scene painter. */
object SceneMode { const val DAY = 0; const val NIGHT = 1; const val AMOLED = 2 }

/**
 * The four built-in Budsy worlds. Each has Day, Night and AMOLED palettes, an animated painted scene
 * (WorldScenes.kt) and 3D glass cards (below). Stock Budsy is never modified: it is what you get with no world applied.
 */
object WorldThemes {
    private fun spec(world: Int, name: String, description: String, light: ColorSet, dark: ColorSet, amoled: ColorSet) = ThemeSpec(
        name = name, author = "Budsy", version = "2.0", source = "builtin", description = description,
        light = light, dark = dark, amoled = amoled,
        shapes = ShapeSpec(panel = 28f, card = 22f, tile = 24f, button = 18f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1f, borderAlpha = 0.55f, fillAlpha = 1f, glow = true),
        world = world, features = setOf("colors", "shapes", "cards", "animation", "background")
    )

    private val FOREST = spec(World.FOREST, "Forest", "Misty pine valley: swaying trees, drifting leaves by day, fireflies by night.",
        light = ColorSet(bg = 0xFFD7EBCB, card = 0xFFFFFFFF, thumb = 0xFFCBE5BE, text = 0xFF14301C, sub = 0xFF46684D, line = 0xFFA3CC9A, track = 0xFFBFDDB2,
            accent = 0xFF2E8B3E, accent2 = 0xFF8BC34A, green = 0xFF2E9E4F, amber = 0xFFE0A100, red = 0xFFD94A3D, sheet = 0xFFE6F4DD),
        dark = ColorSet(bg = 0xFF0B1F14, card = 0xFF163626, thumb = 0xFF22513A, text = 0xFFE6F5E4, sub = 0xFF9DBFA4, line = 0xFF3C7A55, track = 0xFF1E4630,
            accent = 0xFF5ED17A, accent2 = 0xFFC6F04D, green = 0xFF5ED17A, amber = 0xFFFFC857, red = 0xFFFF6B5E, sheet = 0xFF11291C),
        amoled = ColorSet(bg = 0xFF000000, card = 0xFF0B1A11, thumb = 0xFF16301F, text = 0xFFE6F5E4, sub = 0xFF8FB398, line = 0xFF2C6040, track = 0xFF133021,
            accent = 0xFF4ADE80, accent2 = 0xFFB8E83C, green = 0xFF4ADE80, amber = 0xFFFFC857, red = 0xFFFF6B5E, sheet = 0xFF050D08))

    private val SNOW = spec(World.SNOW, "Snow", "Frozen peaks: falling snow by day, aurora skies by night.",
        light = ColorSet(bg = 0xFFE3EFFA, card = 0xFFFFFFFF, thumb = 0xFFD3E4F4, text = 0xFF16304A, sub = 0xFF4F6D8C, line = 0xFFB5CEE5, track = 0xFFCBDFF1,
            accent = 0xFF3B8FD9, accent2 = 0xFF7FD6F5, green = 0xFF2FB36D, amber = 0xFFE69A00, red = 0xFFE5484D, sheet = 0xFFEEF5FC),
        dark = ColorSet(bg = 0xFF0A1A2E, card = 0xFF152C47, thumb = 0xFF244A70, text = 0xFFEAF4FF, sub = 0xFFA5BFD8, line = 0xFF3F6A94, track = 0xFF1C3A5A,
            accent = 0xFF7CC4FF, accent2 = 0xFFB9A6FF, green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF0F2339),
        amoled = ColorSet(bg = 0xFF000000, card = 0xFF0A1626, thumb = 0xFF14304D, text = 0xFFEAF4FF, sub = 0xFF95B1CC, line = 0xFF2B5278, track = 0xFF11283F,
            accent = 0xFF6BB8FF, accent2 = 0xFFA78BFA, green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF050D18))

    private val DESERT = spec(World.DESERT, "Registaan", "Golden dunes: blazing sun and heat haze by day, a huge moon and starry sky by night.",
        light = ColorSet(bg = 0xFFF4DFB8, card = 0xFFFFFAF0, thumb = 0xFFEBD2A2, text = 0xFF3B2410, sub = 0xFF7A5933, line = 0xFFDFBE88, track = 0xFFEBD2A2,
            accent = 0xFFD2691E, accent2 = 0xFFF2A93B, green = 0xFF5A9E3A, amber = 0xFFE09A00, red = 0xFFC8402E, sheet = 0xFFFAECD0),
        dark = ColorSet(bg = 0xFF1A1230, card = 0xFF2D2140, thumb = 0xFF43305A, text = 0xFFFFEFD6, sub = 0xFFD0B89A, line = 0xFF6B4E6E, track = 0xFF35264A,
            accent = 0xFFFFA94D, accent2 = 0xFFFF6B6B, green = 0xFF7BD389, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF241A38),
        amoled = ColorSet(bg = 0xFF000000, card = 0xFF1A1020, thumb = 0xFF2E1D38, text = 0xFFFFEFD6, sub = 0xFFC4AA8C, line = 0xFF54396A, track = 0xFF22152D,
            accent = 0xFFFFA040, accent2 = 0xFFFF7A59, green = 0xFF7BD389, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF0C0710))

    private val OCEAN = spec(World.OCEAN, "Samundar", "Living sea: light rays, fish and bubbles by day, glowing plankton in the deep.",
        light = ColorSet(bg = 0xFFB4E8F4, card = 0xFFFFFFFF, thumb = 0xFFD7F3FA, text = 0xFF05304D, sub = 0xFF1E6A8A, line = 0xFF7CC8E0, track = 0xFFB5E6F2,
            accent = 0xFF0091C8, accent2 = 0xFF00C2B8, green = 0xFF1FB36B, amber = 0xFFE69A00, red = 0xFFE5484D, sheet = 0xFFDDF5FB),
        dark = ColorSet(bg = 0xFF04223F, card = 0xFF0E4A73, thumb = 0xFF1B6C96, text = 0xFFEAF9FF, sub = 0xFF9CC9E0, line = 0xFF5FB8D9, track = 0xFF1A4E73,
            accent = 0xFF2EE6D6, accent2 = 0xFF3AA0FF, green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF0A3558),
        amoled = ColorSet(bg = 0xFF000000, card = 0xFF062B45, thumb = 0xFF0B4468, text = 0xFFEAF9FF, sub = 0xFF8FBFD8, line = 0xFF3F9CC0, track = 0xFF0F3A57,
            accent = 0xFF18E0D0, accent2 = 0xFF2E8FFF, green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF03121F))

    private val byWorld = mapOf(World.FOREST to FOREST, World.SNOW to SNOW, World.DESERT to DESERT, World.OCEAN to OCEAN)
    private val ids = mapOf(World.FOREST to "world_forest", World.SNOW to "world_snow", World.DESERT to "world_registaan", World.OCEAN to "world_samundar")

    fun spec(world: Int): ThemeSpec? = byWorld[world]
    fun idOf(world: Int): String? = ids[world]
    /** Null for Stock or for any unknown / legacy id, which falls back to Stock Budsy. */
    fun byId(id: String?): ThemeSpec? = ids.entries.firstOrNull { it.value == id }?.key?.let { byWorld[it] }
    fun worldOf(id: String?): Int = ids.entries.firstOrNull { it.value == id }?.key ?: World.NONE
}

// ====================================================================================== small shared helpers

@Composable
fun isWorld(): Boolean = LocalThemeSpec.current.hasWorld

/** Scales an animation duration by the theme's motion speed (2.0 = twice as fast). */
@Composable
fun ms(base: Int): Int = (base / LocalThemeSpec.current.motion.speed).toInt().coerceAtLeast(1)

/** Card fill used by the generic card chrome when a world is applied (the glass modifiers draw the real face). */
@Composable
fun themedCardBrush(): Brush = SolidColor(P.tile.copy(alpha = LocalThemeSpec.current.card.fillAlpha))

/** Plain vector icon (theme icon packs no longer exist). */
@Composable
fun PlainIcon(icon: ImageVector, tint: Color, modifier: Modifier = Modifier) = Icon(icon, null, tint = tint, modifier = modifier)

private fun sceneModeOf(amoled: Boolean, dark: Boolean) = if (amoled) SceneMode.AMOLED else if (dark) SceneMode.NIGHT else SceneMode.DAY

// ====================================================================================== 3D glass

private const val RIPPLE_NS = 900_000_000L
private class Ripple(val c: Offset, val t0: Long)

/**
 * 3D glass for cards / tiles / panels, tinted from the active world palette: solid thickness edge + soft contact shadow,
 * translucent face (the scene shows through), top gloss, diagonal streak, bottom glow and a specular rim.
 * A touch sends a small soft ring from the finger. [pressed] sinks the face onto its edge. Reserves [depth] below the card.
 */
@Composable
fun Modifier.worldGlass(radius: Dp, active: Boolean = false, depth: Dp = 5.dp, pressed: Boolean = false, frost: Float = 0f): Modifier {
    val shape = RoundedCornerShape(radius)
    val mode = sceneModeOf(P.amoled, P.dark)
    val accent = P.accent; val accent2 = P.accent2
    val reduce = LocalReduceMotion.current
    val press by animateFloatAsState(if (pressed) 1f else 0f, spring(0.5f, 520f), label = "worldPress")
    val on by animateFloatAsState(if (active) 1f else 0f, tween(280), label = "worldOn")
    val ripples = remember { mutableStateListOf<Ripple>() }
    var now by remember { mutableLongStateOf(0L) }
    LaunchedEffect(ripples.size) {
        while (ripples.isNotEmpty()) {
            withFrameNanos { }
            val n = System.nanoTime()
            now = n
            ripples.removeAll { n - it.t0 > RIPPLE_NS }
        }
    }

    val faceA = when (mode) {
        SceneMode.DAY -> Color.White.copy(alpha = 0.62f)
        SceneMode.NIGHT -> lerp(P.thumb, Color.White, 0.22f).copy(alpha = 0.30f)
        else -> P.thumb.copy(alpha = 0.32f)
    }
    val faceB = when (mode) {
        SceneMode.DAY -> lerp(Color.White, accent2, 0.30f).copy(alpha = 0.32f)
        SceneMode.NIGHT -> P.tile.copy(alpha = 0.55f)
        else -> P.tile.copy(alpha = 0.64f)
    }
    val face = Brush.linearGradient(listOf(lerp(faceA, accent.copy(alpha = 0.46f), on), lerp(faceB, accent2.copy(alpha = 0.30f), on)))
    val edgeBase = when (mode) { SceneMode.DAY -> lerp(accent, Color.Black, 0.35f); SceneMode.NIGHT -> lerp(P.sheet, Color.Black, 0.35f); else -> lerp(P.tile, Color.Black, 0.35f) }
    val edge = lerp(edgeBase, accent2.copy(alpha = 0.85f), on * 0.7f)
    val shadowTint = if (mode == SceneMode.DAY) lerp(accent, Color.Black, 0.55f) else Color.Black
    val rim = Brush.linearGradient(listOf(
        lerp(Color.White.copy(alpha = 0.78f), accent, on), Color.White.copy(alpha = 0.14f),
        lerp(accent2.copy(alpha = 0.30f), accent2, on), Color.White.copy(alpha = 0.42f)
    ))
    val gl = if (mode == SceneMode.DAY) 1.2f else 1f
    val frostColor = P.sheet.copy(alpha = frost)
    val glowBottom = accent2.copy(alpha = 0.16f)

    return this
        .padding(bottom = depth)
        .graphicsLayer { translationY = press * depth.toPx() * 0.62f }
        .drawWithCache {
            val r = radius.toPx(); val d = depth.toPx()
            val faceRect = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
            onDrawBehind {
                val moved = d * 0.62f * press
                clipPath(faceRect, ClipOp.Difference) {
                    val topY = d - moved
                    for (i in 5 downTo 1) {
                        val g = d * 1.8f * i / 5f
                        drawRoundRect(
                            shadowTint.copy(alpha = 0.035f * (1f - press * 0.4f)),
                            Offset(-g * 0.6f, topY + 3.dp.toPx() - g * 0.5f), Size(size.width + 1.2f * g, size.height + 1.2f * g), CornerRadius(r + g * 0.6f)
                        )
                    }
                    drawRoundRect(shadowTint.copy(alpha = 0.22f), Offset(-1f, topY + 1.5.dp.toPx()), Size(size.width + 2f, size.height + 1f), CornerRadius(r + 1f))
                    drawRoundRect(edge, Offset(0f, topY), size, CornerRadius(r))
                }
            }
        }
        .clip(shape)
        .then(if (frost > 0f) Modifier.background(frostColor) else Modifier)
        .background(face)
        .pointerInput(reduce) {
            if (reduce) return@pointerInput
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)   // observe only; never consumes the touch
                    if (e.type == PointerEventType.Press) {
                        val p = e.changes.firstOrNull()?.position
                        if (p != null) {
                            if (ripples.size >= 4) ripples.removeAt(0)
                            ripples.add(Ripple(p, System.nanoTime()))
                        }
                    }
                }
            }
        }
        .drawBehind {
            val w = size.width; val h = size.height
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f * gl), Color.Transparent), startY = 0f, endY = h * 0.55f))
            drawRect(Brush.linearGradient(
                0f to Color.Transparent, 0.30f to Color.Transparent, 0.44f to Color.White.copy(alpha = 0.13f * gl),
                0.54f to Color.Transparent, 1f to Color.Transparent, start = Offset(0f, 0f), end = Offset(w, h * 0.9f)
            ))
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, glowBottom), startY = h * 0.6f, endY = h))
            val nn = now
            for (rp in ripples) {
                if (nn - rp.t0 < 0L) continue
                val p = ((nn - rp.t0).toFloat() / RIPPLE_NS).coerceIn(0f, 1f)
                val maxR = minOf(hypot(w, h) * 0.5f, 40f * density)
                for (k in 0..1) {
                    val pk = p - k * 0.18f
                    if (pk <= 0f) continue
                    val rad = maxR * (1f - (1f - pk) * (1f - pk))
                    val al = (1f - pk).pow(1.6f) * (0.50f - k * 0.18f)
                    drawCircle(Color.White.copy(alpha = al), rad, rp.c, style = Stroke((1.7f - k * 0.5f) * density))
                    drawCircle(accent2.copy(alpha = al * 0.5f), (rad - 2f * density).coerceAtLeast(0f), rp.c, style = Stroke(1f * density))
                }
            }
        }
        .border(1.dp, rim, shape)
}

/** Glass bubble used behind tile icons. */
@Composable
fun Modifier.worldBubble(active: Boolean): Modifier {
    val accent = P.accent; val accent2 = P.accent2
    return this
        .clip(CircleShape)
        .background(if (active) Brush.linearGradient(listOf(accent, accent2)) else Brush.radialGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.10f))))
        .drawBehind { drawCircle(Color.White.copy(alpha = 0.65f), size.minDimension * 0.09f, Offset(size.width * 0.32f, size.height * 0.28f)) }
        .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape)
}

/** Header glass: lightly see-through (the scene shows behind it) but more solid than the tile cards. */
@Composable
fun Modifier.worldHeaderGlass(): Modifier {
    val base = P.sheet
    val a0 = if (P.dark) 0.66f else 0.74f
    return this
        .background(Brush.verticalGradient(listOf(base.copy(alpha = a0), base.copy(alpha = a0 - 0.16f))))
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent), endY = size.height * 0.55f))
            drawLine(Color.White.copy(alpha = 0.38f), Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 1.5f)
        }
}

// ====================================================================================== theme picker

private fun worldTitle(world: Int) = WorldThemes.spec(world)?.name ?: "Stock Budsy"

/**
 * Full-screen picker: Stock Budsy plus the four worlds, each previewed live in the chosen Day / Night / AMOLED look.
 * [appearance] is the stored choice (LIGHT / DARK / AMOLED / SYSTEM); [resolved] is what is actually showing now.
 */
@Composable
fun WorldPickerScreen(
    activeWorld: Int, appearance: Int, resolved: Int,
    onApply: (Int) -> Unit, onAppearance: (Int) -> Unit, onBack: () -> Unit,
    onLiving: (Boolean) -> Unit
) {
    val previewMode = when (resolved) { AppearanceMode.AMOLED -> SceneMode.AMOLED; AppearanceMode.DARK -> SceneMode.NIGHT; else -> SceneMode.DAY }
    Column(Modifier.fillMaxSize().background(P.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.ArrowBack, null, tint = P.text)
            }
            Column(Modifier.padding(start = 6.dp)) {
                Txt("World Themes", 20, FontWeight.Bold, P.text, maxLines = 1)
                Txt("Four painted worlds · Day, Night and AMOLED", 11, color = P.sub, maxLines = 1)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // appearance
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    AppearanceMode.LIGHT to stringResource(R.string.light), AppearanceMode.DARK to stringResource(R.string.dark),
                    AppearanceMode.AMOLED to stringResource(R.string.amoled_black), AppearanceMode.SYSTEM to stringResource(R.string.follow_system)
                ).forEach { (m, label) ->
                    val sel = appearance == m
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (sel) P.accent else P.tile)
                            .border(1.dp, if (sel) P.accent else P.line, RoundedCornerShape(14.dp))
                            .semantics { role = Role.RadioButton; selected = sel }
                            .clickable(role = Role.RadioButton) { onAppearance(m) },
                        contentAlignment = Alignment.Center
                    ) { Txt(label, 12, FontWeight.SemiBold, if (sel) P.onAccent else P.text, maxLines = 1) }
                }
            }
            (listOf(World.NONE) + World.all).forEach { w ->
                WorldCard(w, previewMode, selected = activeWorld == w, animate = activeWorld == w) { onApply(w) }
            }
            // Battery / comfort switch: freezes every world, including the one behind the app.
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(P.tile.copy(alpha = 0.72f))
                    .border(1.dp, P.line.copy(alpha = 0.8f), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Txt("Living backgrounds", 14, FontWeight.SemiBold, P.text, maxLines = 1)
                    Txt("Animate the worlds. Off keeps a still frame and saves battery.", 11, color = P.sub, lineHeight = 15, maxLines = 2)
                }
                Spacer(Modifier.width(10.dp))
                IosSwitch(on = AmbientFx.enabled, onChange = onLiving)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun WorldCard(world: Int, previewMode: Int, selected: Boolean, animate: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        Modifier.fillMaxWidth().height(158.dp).clip(shape)
            .border(if (selected) 2.dp else 1.dp, if (selected) P.accent else P.line, shape)
            .semantics { role = Role.Button; this.selected = selected }
            .clickable(role = Role.Button) { onClick() }
    ) {
        if (world == World.NONE) {
            // Miniature of the real Stock Budsy wallpaper (silk gradient + soft light), not a flat colour.
            Box(
                Modifier.fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            when (previewMode) {
                                SceneMode.DAY -> listOf(Color(0xFFDCEBFF), Color(0xFFEAF2FD), Color(0xFFF6F9FE))
                                SceneMode.NIGHT -> listOf(Color(0xFF232327), Color(0xFF111113), Color(0xFF09090B))
                                else -> listOf(Color.Black, Color.Black, Color.Black)
                            }
                        )
                    )
                    .drawBehind {
                        if (previewMode == SceneMode.AMOLED) return@drawBehind
                        val w = size.width; val h = size.height
                        fun blob(c: Color, cx: Float, cy: Float, r: Float) =
                            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
                        if (previewMode == SceneMode.DAY) {
                            blob(Color(0xFF7DB8FF).copy(alpha = 0.55f), w * 0.18f, h * 0.10f, w * 0.80f)
                            blob(Color(0xFFB9A8FF).copy(alpha = 0.35f), w * 0.95f, h * 0.35f, w * 0.60f)
                            blob(Color(0xFF9ADBFF).copy(alpha = 0.35f), w * 0.80f, h * 0.95f, w * 0.75f)
                        } else {
                            blob(Color.White.copy(alpha = 0.10f), w * 0.5f, -h * 0.05f, w * 0.9f)
                        }
                    }
            )
        } else {
            WorldScene(world, previewMode, Modifier.fillMaxSize(), animate = animate)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.66f)))))
        Row(Modifier.align(Alignment.BottomStart).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier) {
                Txt(worldTitle(world), 18, FontWeight.Bold, Color.White, maxLines = 1)
                Txt(WorldThemes.spec(world)?.description ?: "The original Budsy look: clean, no animation.", 11, color = Color.White.copy(alpha = 0.85f), maxLines = 2)
            }
        }
        if (selected) Row(
            Modifier.align(Alignment.TopEnd).padding(10.dp).clip(CircleShape).background(P.accent)
                .padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Check, null, tint = P.onAccent, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Txt("APPLIED", 9, FontWeight.Bold, P.onAccent, spacing = 0.7f, maxLines = 1)
        }
    }
}
