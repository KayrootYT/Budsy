package com.nordbuds.studio

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

/** Developer links. Telegram handle is a placeholder: replace with the real one. */
object DevLinks {
    const val NAME = "Kayroot"
    const val GITHUB = "https://github.com/KayrootYT"
    const val INSTAGRAM = "https://www.instagram.com/kayrootx?exln=cms2b3F0ZHRscHZo"
    const val TELEGRAM = "https://t.me/Kayroot"
}

private const val PRIVACY_TEXT = """Budsy is a companion app for your Bluetooth earbuds and works entirely on your phone.

• No internet access: the app does not request the Internet permission, so it cannot send anything to a server.
• No accounts, ads, analytics or tracking.
• Bluetooth permissions are used only to find and connect to your earbuds and to read / change their settings.
• Notification permission is used only to show battery and connection status.
• Your settings, presets and themes are stored only on this device and are removed when you clear the app data or uninstall.
• Links on the About page (GitHub, Telegram, Instagram) open in your browser and are governed by those services' own policies."""

private const val TERMS_TEXT = """By using Budsy you agree to the following:

• The app is provided "as is", without warranty of any kind. Features can behave differently depending on your earbuds model and firmware.
• You use the app at your own risk. The developer is not liable for any loss or damage resulting from its use, including changes made to your earbuds' settings.
• Product names and trademarks belong to their respective owners and are used only to describe compatibility.
• You may not copy, resell or redistribute the app or its artwork without permission from the developer.
• These terms may be updated with new versions of the app."""

private const val LICENSE_TEXT = """Budsy
Copyright © 2026 Kayroot. All rights reserved.

Open-source components used in this app:
• Kotlin and AndroidX / Jetpack Compose: Apache License 2.0
• Material icons: Apache License 2.0
• Inter typeface: SIL Open Font License 1.1

Full license texts are available from the respective projects."""

@Composable
fun AboutSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var doc by remember { mutableStateOf<Int?>(null) }
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0" } catch (_: Exception) { "1.0" } }
    fun open(url: String) { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    SheetDialog(onDismiss) {
        SheetTitle("About")
        ValueRow("Budsy", "Version $version", chevron = false, icon = Icons.Rounded.Info)
        ValueRow("Developer", DevLinks.NAME, chevron = false, icon = Icons.Rounded.Person)
        SectionLabel("Social", Icons.Rounded.Language)
        ValueRow("GitHub", "KayrootYT", icon = Icons.Rounded.Code) { open(DevLinks.GITHUB) }
        ValueRow("Telegram", DevLinks.NAME, icon = Icons.Rounded.Send) { open(DevLinks.TELEGRAM) }
        ValueRow("Instagram", "kayrootx", icon = Icons.Rounded.PhotoCamera) { open(DevLinks.INSTAGRAM) }
        SectionLabel("Legal", Icons.Rounded.Gavel)
        ValueRow("Privacy Policy", "How your data is handled", icon = Icons.Rounded.PrivacyTip) { doc = 0 }
        ValueRow("Terms of Service", "Rules for using the app", icon = Icons.Rounded.Description) { doc = 1 }
        ValueRow("Licence", "Copyright and open-source notices", icon = Icons.Rounded.Gavel) { doc = 2 }
    }
    doc?.let { d ->
        SheetDialog({ doc = null }) {
            SheetTitle(when (d) { 0 -> "Privacy Policy"; 1 -> "Terms of Service"; else -> "Licence" })
            Txt(when (d) { 0 -> PRIVACY_TEXT; 1 -> TERMS_TEXT; else -> LICENSE_TEXT }, 14, FontWeight.Normal, P.text, lineHeight = 21)
            Spacer(Modifier.height(4.dp))
        }
    }
}

