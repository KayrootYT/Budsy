package com.nordbuds.studio.buds

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("budsy", Context.MODE_PRIVATE)
    var autoPaused: Boolean get() = p.getBoolean("auto_paused", false); set(v) { p.edit().putBoolean("auto_paused", v).apply() }
    var customName: String? get() = p.getString("custom_name", null); set(v) { p.edit().putString("custom_name", v).apply() }
    var lastAddr: String? get() = p.getString("last_addr", null); set(v) { p.edit().putString("last_addr", v).apply() }
    /** Selected visual identity: Aurora, Crystal, Nothing, Titanium, or permanent Stock. */
    var theme: Int
        get() = 0
        set(@Suppress("UNUSED_PARAMETER") v) { p.edit().putInt("design_theme", 0).putInt("theme_schema", 2).apply() }

    var activeImportedTheme: String?
        get() = p.getString("active_imported_theme", null)
        set(v) { p.edit().putString("active_imported_theme", v).apply() }

    /** Appearance is independent from visual identity; -1 follows Android system theme. */
    var appearanceMode: Int get() = p.getInt("appearance_mode", -1).let { if (it in -1..2) it else -1 }
        set(v) { p.edit().putInt("appearance_mode", v.coerceIn(-1, 2)).apply() }
    var welcomed: Boolean get() = p.getBoolean("welcomed", false); set(v) { p.edit().putBoolean("welcomed", v).apply() }
    var diag: Boolean get() = p.getBoolean("diag", false); set(v) { p.edit().putBoolean("diag", v).apply() }
    var batteryNotif: Boolean get() = p.getBoolean("battery_notif", false); set(v) { p.edit().putBoolean("battery_notif", v).apply() }
    /** The three custom EQ profiles, as JSON (see EqSlots). */
    var eqSlots: String? get() = p.getString("eq_slots", null); set(v) { p.edit().putString("eq_slots", v).apply() }
    /** Which custom slot is currently applied to the buds, -1 for none. */
    var eqActive: Int get() = p.getInt("eq_active", -1); set(v) { p.edit().putInt("eq_active", v).apply() }
    /** Tap sounds and haptic feedback on tiles and buttons. */
    var tapSound: Boolean get() = p.getBoolean("tap_sound", false); set(v) { p.edit().putBoolean("tap_sound", v).apply() }
    /** Foreground service that keeps the control link alive in the background. */
    var keepAlive: Boolean get() = p.getBoolean("keep_alive", false); set(v) { p.edit().putBoolean("keep_alive", v).apply() }
    /** Feature-flag id the user mapped to "Dual connection" (-1 = not mapped). */
    var dualFlagId: Int get() = p.getInt("dual_flag", -1); set(v) { p.edit().putInt("dual_flag", v).apply() }
    /** App language: "" follows the phone, otherwise a language tag such as "en" or "hi". */
    var language: String get() = p.getString("app_lang", "") ?: ""; set(v) { p.edit().putString("app_lang", v).apply() }
    /** Consecutive failed GATT-first attempts; 3+ makes automatic reconnects use RFCOMM directly. */
    var gattFails: Int get() = p.getInt("gatt_fails", 0); set(v) { p.edit().putInt("gatt_fails", v.coerceIn(0, 99)).apply() }
    var haptics: Boolean get() = p.getBoolean("haptics", true); set(v) { p.edit().putBoolean("haptics", v).apply() }
}
