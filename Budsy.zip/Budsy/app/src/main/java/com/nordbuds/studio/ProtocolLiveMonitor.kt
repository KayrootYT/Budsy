package com.nordbuds.studio

/** Pure helpers for the live monitor; it only analyzes events already captured by Budsy. */
object ProtocolLiveMonitor {
    enum class Filter { ALL, TX, RX, UNKNOWN }

    data class Summary(
        val visible: Int,
        val tx: Int,
        val rx: Int,
        val unknown: Int,
        val matched: Int,
        val latestCommand: Int?
    )

    fun filter(events: List<ProtocolLab.Event>, filter: Filter, query: String = ""): List<ProtocolLab.Event> {
        val needle = query.trim().lowercase()
        return events.filter { event ->
            val directionMatch = when (filter) {
                Filter.ALL -> true
                Filter.TX -> event.direction.equals("TX", true)
                Filter.RX -> event.direction.equals("RX", true)
                Filter.UNKNOWN -> event.decodedTitle.startsWith("Unknown", true)
            }
            val queryMatch = needle.isBlank() || sequenceOf(
                event.label,
                event.command.toString(16),
                event.command.toString(16).padStart(4, '0'),
                event.decodedTitle,
                event.decodedDetail,
                event.payload.joinToString(" ") { it.toString(16).padStart(2, '0') }
            ).any { it.lowercase().contains(needle) }
            directionMatch && queryMatch
        }
    }

    fun summarize(events: List<ProtocolLab.Event>): Summary = Summary(
        visible = events.size,
        tx = events.count { it.direction.equals("TX", true) },
        rx = events.count { it.direction.equals("RX", true) },
        unknown = events.count { it.decodedTitle.startsWith("Unknown", true) },
        matched = events.count { it.matched },
        latestCommand = events.lastOrNull()?.command
    )
}
