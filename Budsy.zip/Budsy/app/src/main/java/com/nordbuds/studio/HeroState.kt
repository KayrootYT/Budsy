package com.nordbuds.studio

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay

/** Physical case-lid state. UNKNOWN is the only value the current protocol can produce. */
enum class LidState { OPEN, CLOSED, UNKNOWN }

/** Physical earbud position relative to the case. Independent from Bluetooth connectivity. */
enum class BudPos { INSIDE, OUTSIDE, UNKNOWN }

/** The five home-screen visuals plus an explicit Unknown/Unverified visual. */
enum class HeroState(val number: Int, val title: String) {
    CASE_CLOSED(1, "Case closed"),
    BOTH_IN(2, "Case open, both buds inside"),
    LEFT_OUT(3, "Left bud outside"),
    RIGHT_OUT(4, "Right bud outside"),
    BOTH_OUT(5, "Both buds outside"),
    UNVERIFIED(0, "Unknown / unverified")
}

/** Where a displayed state came from. Only HARDWARE may be presented as detected. */
enum class HeroSource { HARDWARE, ESTIMATED, PRESENTATION, PREVIEW, UNVERIFIED }

/** Raw, independent inputs. Bluetooth [connected] never implies lid or bud position. */
data class HeroInput(val connected: Boolean, val lid: LidState, val left: BudPos, val right: BudPos)

data class ResolvedHero(val state: HeroState, val source: HeroSource, val note: String)

/**
 * Maps the reverse-engineered 0x0109 wear flags to a bud position.
 * Bit 0 = outside the case, bit 1 = in ear (same reading as the existing wear text).
 * That bit mapping is NOT verified on real firmware; negative = not reported.
 */
fun budPosFromWear(flags: Int): BudPos = when {
    flags < 0 -> BudPos.UNKNOWN
    (flags and 3) != 0 -> BudPos.OUTSIDE
    else -> BudPos.INSIDE
}

/** A case battery is shown only while connected, with valid case telemetry, and not when both buds are out. */
fun shouldShowCaseBattery(connected: Boolean, casePercent: Int, hero: HeroState): Boolean =
    connected && casePercent in 0..100 && hero != HeroState.BOTH_OUT

object HeroResolver {
    private fun posText(p: BudPos) = when (p) {
        BudPos.INSIDE -> "in case"; BudPos.OUTSIDE -> "out of case"; BudPos.UNKNOWN -> "unknown"
    }

    fun resolve(i: HeroInput): ResolvedHero {
        // Disconnected presentation: a UI choice, never a claim about the physical lid.
        if (!i.connected) return ResolvedHero(
            HeroState.CASE_CLOSED, HeroSource.PRESENTATION,
            "Disconnected. Closed case is shown as a presentation; lid state is not verified."
        )
        when (i.lid) {
            LidState.CLOSED ->
                return if (i.left == BudPos.OUTSIDE || i.right == BudPos.OUTSIDE)
                    ResolvedHero(HeroState.UNVERIFIED, HeroSource.UNVERIFIED, "Conflicting data: lid closed but a bud reported outside.")
                else ResolvedHero(HeroState.CASE_CLOSED, HeroSource.HARDWARE, "Lid closed (reported by the case).")
            LidState.UNKNOWN -> {
                if (i.left == BudPos.UNKNOWN || i.right == BudPos.UNKNOWN) return ResolvedHero(
                    HeroState.UNVERIFIED, HeroSource.UNVERIFIED,
                    "Lid and bud positions are not reported yet. Left: ${posText(i.left)} · Right: ${posText(i.right)}."
                )
                // Bud positions come from wear flags; the lid is NOT reported, so this is an estimate, never "verified".
                val s = stateFor(i.left, i.right)
                return ResolvedHero(s, HeroSource.ESTIMATED, "Estimated from earbud wear flags (Left: ${posText(i.left)} · Right: ${posText(i.right)}). Case lid is not reported by these earbuds.")
            }
            LidState.OPEN -> Unit
        }
        if (i.left == BudPos.UNKNOWN || i.right == BudPos.UNKNOWN) return ResolvedHero(
            HeroState.UNVERIFIED, HeroSource.UNVERIFIED, "Lid open, but a bud position is unknown."
        )
        val s = stateFor(i.left, i.right)
        return ResolvedHero(s, HeroSource.HARDWARE, "State ${s.number}: ${s.title} (reported by the device).")
    }

    private fun stateFor(l: BudPos, r: BudPos) = when {
        l == BudPos.INSIDE && r == BudPos.INSIDE -> HeroState.BOTH_IN
        l == BudPos.OUTSIDE && r == BudPos.INSIDE -> HeroState.LEFT_OUT
        l == BudPos.INSIDE && r == BudPos.OUTSIDE -> HeroState.RIGHT_OUT
        else -> HeroState.BOTH_OUT
    }

    fun preview(s: HeroState) = ResolvedHero(
        s, HeroSource.PREVIEW,
        if (s == HeroState.UNVERIFIED) "Preview: unknown / unverified. Not detected from hardware."
        else "Preview: state ${s.number}, ${s.title}. Not detected from hardware."
    )
}

/** Debug-only manual override; null = follow live data. Never persisted. */
object HeroPreview {
    var selected by mutableStateOf<HeroState?>(null)
}

/** Debounce: a new target must stay stable for [settleMs] before the UI switches; A→B→A never flickers. */
@Composable
fun rememberSettledHero(target: ResolvedHero, settleMs: Long = 450L): ResolvedHero {
    var settled by remember { mutableStateOf(target) }
    LaunchedEffect(target) {
        if (target != settled) { delay(settleMs); settled = target }
    }
    return settled
}
