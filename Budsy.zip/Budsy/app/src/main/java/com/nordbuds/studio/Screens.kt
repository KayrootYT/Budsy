package com.nordbuds.studio

import androidx.compose.foundation.border
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nordbuds.studio.protocol.Protocol
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

fun openHeyMelody(ctx: Context) {
    val pkg = "com.heytap.headset"
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { }
    }
}

fun openBluetooth(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { }
}

/** Card notice: glowing icon, two lines of text and a button. */
@Composable
private fun NoticeRow(icon: ImageVector, tint: Color, title: String, detail: String, action: String, onAction: () -> Unit) {
    GlassPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BounceIcon(icon, true, 44.dp, false, rememberGlow(true))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(title, 16, FontWeight.SemiBold, P.text)
                Txt(detail, 13, lineHeight = 18)
            }
            Spacer(Modifier.width(10.dp))
            SmallButton(action, false) { onAction() }
        }
    }
}

@Composable
fun NeedConnect(x: Ctx) {
    NoticeRow(
        Icons.Rounded.Bluetooth, P.accent,
        stringResource(R.string.earbuds_not_connected), stringResource(R.string.connect_on_the_overview_tab_first),
        stringResource(R.string.overview)
    ) { x.go(0) }
}

/** Audio counts as connected if the phone lists this address OR a device with the same name (BT identity addresses can differ). */
private fun audioUp(addr: String, name: String?, audio: Set<String>): Boolean =
    addr.uppercase() in audio || (!name.isNullOrEmpty() && ("name:" + name) in audio)

@Composable
private fun AudioWarning(name: String) {
    val ctx = LocalContext.current
    NoticeRow(
        Icons.Rounded.Warning, P.amber,
        stringResource(R.string.audio_is_not_connected), stringResource(R.string.audio_warning_detail, name),
        stringResource(R.string.open_2)
    ) { openBluetooth(ctx) }
}

/** Little "saved / saving / failed" line under a setting. */
@Composable
fun SaveLine(state: Buds.SaveState, message: String) {
    // Green "Earbuds confirmed / read back …" lines are intentionally never shown.
    if (state == Buds.SaveState.IDLE || state == Buds.SaveState.SAVED || message.isBlank()) return
    val c = when (state) { Buds.SaveState.SAVED -> P.green; Buds.SaveState.FAILED -> P.amber; Buds.SaveState.SAVING -> P.accent; else -> P.sub }
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (state == Buds.SaveState.SAVING) CircularProgressIndicator(Modifier.size(15.dp), color = c, strokeWidth = 2.dp)
        else Icon(if (state == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = c, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Txt(message, 13, color = c, lineHeight = 17)
    }
}

/** Expanding rings behind the hero image. */
@Composable
private fun PulseRings(active: Boolean, modifier: Modifier) {
    val reduce = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "heroRings")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "heroRingPhase"
    )
    val accent = P.accent; val accent2 = P.accent2
    Canvas(modifier) {
        val maxR = size.minDimension * 0.62f
        val k = if (active) 1f else 0.45f
        drawCircle(Brush.radialGradient(colors = listOf(accent.copy(alpha = 0.22f * k), Color.Transparent), center = center, radius = maxR), maxR, center)
        for (i in 0..2) {
            val q = ((if (reduce) 0.25f else phase) + i / 3f) % 1f
            drawCircle(accent2.copy(alpha = (1f - q) * 0.30f * k), maxR * (0.34f + 0.66f * q), center, style = Stroke(1.4.dp.toPx()))
        }
    }
}

private val NoiseIds = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)

// ================================================================= OVERVIEW

@Composable
fun OverviewScreen(x: Ctx) {
    val b = x.b
    val ctx = LocalContext.current
    var showList by rememberSaveable { mutableStateOf(false) }
    val connectFirstText = stringResource(R.string.err_connect_first)
    Page {
        if (b.connected && x.audioKnown && !audioUp(b.deviceAddr, b.deviceName, x.audio)) {
            AudioWarning(if (b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.your_earbuds))
        }

        // Hero: floating buds over pulsing rings, status and primary action grouped together.
        GlassPanel(index = 0) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt(stringResource(R.string.your_device_caps), 11, FontWeight.Bold, P.sub, spacing = 1.5f)
                    Spacer(Modifier.height(5.dp))
                    Txt(Buds.displayName.ifEmpty { "Nord Buds 3" }.removePrefix("OnePlus "), 22, FontWeight.Bold, P.text, maxLines = 1)
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulseDot(if (b.connected) P.green else P.sub, b.connected)
                        Spacer(Modifier.width(4.dp))
                        Txt(if (b.connected) stringResource(R.string.connected) else b.status, 13, color = if (b.connected) P.green else P.sub, maxLines = 1)
                    }
                }
                val orbSrc = remember { MutableInteractionSource() }
                val orbPressed by orbSrc.collectIsPressedAsState()
                val orbFb = rememberFeedback()
                val orbDesc = stringResource(R.string.choose_earbuds_desc)
                Box(
                    Modifier.pressClickable(orbSrc) { orbFb(0); showList = true }
                        .semantics { contentDescription = orbDesc; role = androidx.compose.ui.semantics.Role.Button }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    BluetoothOrb(b.connected, orbPressed)
                }
            }
            val liveHero = rememberSettledHero(HeroResolver.resolve(HeroInput(b.connected, b.lidState, b.leftPos, b.rightPos)))
            val previewSel = HeroPreview.selected
            val shown = if (previewSel != null) HeroResolver.preview(previewSel) else liveHero
            Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                PulseRings(b.connected, Modifier.fillMaxSize())
                val heroSlot = when (shown.state) {
                    HeroState.CASE_CLOSED -> "hero_case_closed"
                    HeroState.BOTH_IN -> "hero_case_open"
                    HeroState.LEFT_OUT -> "hero_left_out"
                    HeroState.RIGHT_OUT -> "hero_right_out"
                    HeroState.BOTH_OUT -> "hero_both_out"
                    HeroState.UNVERIFIED -> "hero_case_closed"
                }
                val customHero = remember(x.activeImportedTheme, heroSlot) {
                    ThemeStore.assetFile(ctx, x.activeImportedTheme, heroSlot)
                }
                if (customHero != null) {
                    ImportedThemeImage(x.activeImportedTheme, heroSlot, Modifier.fillMaxSize(), ContentScale.Fit)
                } else {
                    DeviceHeroArt(x.theme, shown.state, Modifier.fillMaxSize(), dashed = shown.source == HeroSource.ESTIMATED && x.prefs.diag, appearance = x.appearance, connecting = b.connecting)
                }
            }
            if (x.prefs.diag) HeroCaption(shown)
            // Connection is controlled from the compact status switch in the pinned header.
        }

        LaunchedEffect(showList, x.perm, x.scanPerm, b.bleScanning, b.bleScanResults.size) {
            if (showList && !b.connected && !b.bleScanning && b.bleScanResults.isEmpty()) {
                if (x.scanPerm) b.startBleScan() else x.askScanPerm()
            }
        }
        if (showList) {
            SheetDialog(
                onDismiss = {
                    showList = false
                    b.stopBleScan()
                    b.stopClassicScan()
                },
                footer = {
                    if (b.connected) {
                        WideButton(stringResource(R.string.disconnect_2), true, icon = Icons.Rounded.LinkOff) {
                            b.disconnect()
                            showList = false
                        }
                    } else {
                        WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) {
                            showList = false
                            b.stopBleScan()
                            b.stopClassicScan()
                        }
                    }
                }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Txt(if (b.connected) stringResource(R.string.device_connected_title) else stringResource(R.string.add_device_title), 20, FontWeight.Bold, P.text)
                        Txt(if (b.connected) b.deviceName else stringResource(R.string.find_nearby_earbuds), 12, color = P.sub)
                    }
                    if (b.bleScanning || b.connecting) CircularProgressIndicator(Modifier.size(20.dp), color = P.accent, strokeWidth = 2.dp)
                }
                if (b.connected) {
                    GlassPanel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BounceIcon(Icons.Rounded.Headphones, true, 42.dp, false, rememberGlow(true), P.accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Txt(Buds.displayName.ifBlank { b.deviceName }, 16, FontWeight.SemiBold, P.text)
                                Txt("Connected · ${b.deviceAddr}", 11, color = P.green)
                                Txt("Control transport: GATT primary · RFCOMM fallback", 11, color = P.sub)
                            }
                            Icon(Icons.Rounded.CheckCircle, null, tint = P.green)
                        }
                    }
                    WideButton(stringResource(R.string.refresh_2), false, enabled = !b.refreshing, icon = Icons.Rounded.Refresh, spin = b.refreshing) { b.refreshAll(); x.toast("Refreshing…") }
                } else {
                    ConnectBlock(x)
                }
            }
        }

        if (b.connected) {
            SectionLabel(stringResource(R.string.noise_control), Icons.Rounded.Waves, stringResource(R.string.noise_detail))
            GlassPanel(index = 2) {
                Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile("ANC", "", Icons.Rounded.Waves, b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { b.setAnc(Buds.ANC_ON) }
                    FeatureTile("Off", "", Icons.Rounded.Block, b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { b.setAnc(Buds.ANC_OFF) }
                    FeatureTile(stringResource(R.string.aware), "", Icons.Rounded.Hearing, b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { b.setAnc(Buds.ANC_TRANSP) }
                }
                SaveLine(b.ancSaveState, b.ancSaveMessage)
            }
        }

        SectionLabel(stringResource(R.string.battery_title), Icons.Rounded.BatteryChargingFull, stringResource(R.string.battery_detail))
        GlassPanel(index = 1) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BatteryStat(b.battery[0], b.charging[0], stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc))
                BatteryStat(b.battery[1], b.charging[1], stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc))
                BatteryStat(
                    if (b.connected) b.battery[2] else -1,
                    b.connected && b.charging[2],
                    stringResource(R.string.widget_case_label), Modifier.weight(1f),
                    desc = stringResource(R.string.battery_case_desc), icon = Icons.Rounded.BatteryFull
                )
            }
        }

        SectionLabel(stringResource(R.string.make_it_yours), Icons.Rounded.AutoAwesome, stringResource(R.string.make_it_yours_detail))
        SwitchRow(stringResource(R.string.game_mode), stringResource(R.string.lower_audio_latency), b.connected && b.gameMode == true, icon = Icons.Rounded.SportsEsports) {
            if (b.connected) b.setGame(b.gameMode != true) else x.toast(connectFirstText)
        }

        if (b.connected) {
            SectionLabel(stringResource(R.string.find_my_earbuds), Icons.Rounded.LocationSearching, stringResource(R.string.find_detail))
            GlassPanel(index = 4) {
                Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FindTile(stringResource(R.string.left_2), stringResource(R.string.left_bud), Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, 21, { b.findEarbuds(1) }, { b.stopFindEarbuds() })
                    FindTile(stringResource(R.string.right_2), stringResource(R.string.right_bud), Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, 22, { b.findEarbuds(2) }, { b.stopFindEarbuds() })
                    FindTile(stringResource(R.string.both_2), stringResource(R.string.both), Icons.Rounded.NotificationsActive, b.findAlertRequested && b.findAlertSide == 3, 23, { b.findEarbuds(3) }, { b.stopFindEarbuds() })
                }
                if (b.findAlertRequested || b.findAlertMessage.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Txt("${if (b.findAlertRequested) stringResource(R.string.find_alert_requested) else stringResource(R.string.find_stop_requested)} · ${when (b.findAlertSide) { 1 -> stringResource(R.string.left); 2 -> stringResource(R.string.right); else -> stringResource(R.string.both) }}", 13, color = P.sub)
                    if (b.findAlertMessage.isNotBlank() && !b.findAlertMessage.startsWith("Earbuds confirmed")) {
                        Spacer(Modifier.height(8.dp))
                        Txt(b.findAlertMessage, 12, color = P.sub, lineHeight = 16)
                    }
                }
                if (b.wear.any { it >= 0 }) {
                    Spacer(Modifier.height(12.dp))
                    Txt(stringResource(R.string.wear_sides, wearText(b.wear[0]), wearText(b.wear[1])), 13)
                }
            }
        }
    }
}

/** Find-my tile: tap plays the tone on that side; while it is playing the same tile turns into a Stop button. */
@Composable
private fun androidx.compose.foundation.layout.RowScope.FindTile(
    title: String, desc: String, icon: ImageVector, active: Boolean, seed: Int, onPlay: () -> Unit, onStop: () -> Unit
) = FeatureTile(
    title, if (active) stringResource(R.string.stop_alert) else desc, if (active) Icons.Rounded.Stop else icon,
    active, Modifier.weight(1f), seed
) { if (active) onStop() else onPlay() }

// ================================================================= SOUND

private fun presetIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Rounded.GraphicEq
    1 -> Icons.Rounded.RecordVoiceOver
    else -> Icons.Rounded.Speaker
}

@Composable
fun SoundScreen(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    Page {
        if (!b.connected) NeedConnect(x)

        Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            Txt("Sound Lab", 34, FontWeight.Bold, P.text)
            Txt("Personal audio for your earbuds", 14, FontWeight.Normal, P.sub, Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.height(6.dp))
        SectionLabel(stringResource(R.string.eq_presets), Icons.Rounded.GraphicEq)
        GlassPanel(index = 0) {
            val labels = Buds.PRESETS.mapIndexed { i, p -> presetIcon(i) to stringResource(p.second) }
            val idx = if (b.connected) Buds.PRESETS.indexOfFirst { it.first == b.eqPreset } else -1
            Segmented(labels, idx) { i ->
                if (b.connected) { b.setEq(Buds.PRESETS[i].first) } else x.toast(connectFirstText)
            }
        }
        if (b.connected) SaveLine(b.eqSaveState, b.eqSaveMessage)

        SwitchRow(stringResource(R.string.basswave), stringResource(R.string.bass_boost_sub), b.connected && b.bassOn == true, icon = Icons.Rounded.Speaker) {
            if (b.connected) b.setBassOn(b.bassOn != true) else x.toast(connectFirstText)
        }
        if (b.connected) {
            GlassPanel(index = 1) {
                val lv = b.bassLevel
                if (lv != null) {
                    var drag by remember { mutableStateOf<Int?>(null) }
                    var sent by remember { mutableStateOf<Int?>(null) }   // value just sent; shown until the earbuds read it back
                    LaunchedEffect(lv) { if (sent == lv) sent = null }
                    LaunchedEffect(sent) { if (sent != null) { delay(3000); sent = null } }
                    val shown = drag ?: (sent ?: lv)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt(stringResource(R.string.level), 14, FontWeight.Normal, P.sub, Modifier.weight(1f))
                        Txt(if (shown > 0) "+$shown" else "$shown", 16, FontWeight.Bold, P.accent)
                    }
                    Spacer(Modifier.height(6.dp))
                    Column(Modifier.fillMaxWidth().insetPanel(14.dp).padding(horizontal = 10.dp, vertical = 8.dp)) {
                        BassLevelBars(
                            value = shown, min = b.bassMin, max = b.bassMax, enabled = b.bassOn == true,
                            onChange = { v -> if (v != shown) Fx.tick(ctx); drag = v },
                            onFinished = { drag?.let { q -> sent = q; if (q != lv) b.setBassLevel(q) }; drag = null }
                        )
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Txt("${b.bassMin}", 11, FontWeight.Normal, P.sub)
                            Txt("0", 11, FontWeight.Normal, P.sub)
                            Txt("+${b.bassMax}", 11, FontWeight.Normal, P.sub)
                        }
                    }
                }
            }
            SaveLine(b.bassSaveState, b.bassSaveMessage)
        }

        CustomEqSection(x)
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt(stringResource(R.string.bluetooth_permission_is_needed_to_find_your_pair), 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton(stringResource(R.string.allow_bluetooth), icon = Icons.Rounded.Bluetooth) { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting) { bondedDevices(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (b.searching || b.connecting) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), color = P.accent, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Txt(if (b.connecting) stringResource(R.string.status_connecting) else stringResource(R.string.scanning_for_earbuds), 16, FontWeight.Medium, P.text)
            }
        }
        Txt(stringResource(R.string.select_a_device_to_connect), 17, FontWeight.SemiBold, P.text)
        Txt(stringResource(R.string.connect_the_earbuds_for_audio_in_bluetooth_setti), 14, lineHeight = 20)
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallButton(if (b.bleScanning) "Stop BLE scan" else "Scan nearby BLE", icon = Icons.Rounded.Bluetooth) {
                if (b.bleScanning) b.stopBleScan() else if (x.scanPerm) b.startBleScan() else x.askScanPerm()
            }
            Spacer(Modifier.width(8.dp))
            if (b.bleScanning) Txt("Searching nearby devices…", 12, color = P.sub)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SmallButton(if (b.classicScanning) "Stop classic scan" else "Scan classic devices", false, icon = Icons.Rounded.Devices) {
                if (b.classicScanning) b.stopClassicScan() else if (x.scanPerm) b.startClassicScan() else x.askScanPerm()
            }
            if (b.classicScanning) { Spacer(Modifier.width(8.dp)); Txt("Searching BR/EDR devices…", 12, color = P.sub) }
        }
        b.bleScanError?.let { Txt(it, 12, color = P.sub) }
        b.classicScanResults.take(12).forEach { device ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                BounceIcon(Icons.Rounded.Headphones, false, 34.dp, false, { 0f }, P.accent)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Txt(device.name ?: "Unnamed Bluetooth device", 14, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(device.address, 11, color = P.sub, maxLines = 1)
                }
                SmallButton("Connect", false, icon = Icons.Rounded.Link) { if (!b.connecting) b.connect(device) }
            }
            Divider()
        }
        b.bleScanResults.take(12).forEach { found ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                BounceIcon(Icons.Rounded.Bluetooth, false, 34.dp, false, { 0f }, P.accent)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Txt(found.name ?: "Unnamed BLE device", 14, FontWeight.Medium, P.text, maxLines = 1)
                    Txt("${found.device.address} · RSSI ${found.rssi} dBm", 11, color = P.sub, maxLines = 1)
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SmallButton("Connect", false, icon = Icons.Rounded.Link) { if (!b.connecting) b.connect(found.device) }
                    SmallButton("Probe GATT", false, icon = Icons.Rounded.Bluetooth) { b.probeGatt(found.device) }
                }
            }
            if (b.gattProbeState != "Not checked") Txt(b.gattProbeState, 11, color = P.sub, lineHeight = 15)
            Divider()
        }
        if (list.isEmpty()) Txt(stringResource(R.string.no_paired_devices_found), 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if ((d.name ?: "").contains("buds", ignoreCase = true))
                    Image(painterResource(R.drawable.hero_buds), null, Modifier.width(54.dp), contentScale = ContentScale.Fit)
                else BounceIcon(Icons.Rounded.Headphones, false, 40.dp, false, { 0f }, P.accent)
                Spacer(Modifier.width(12.dp))
                val up = audioUp(d.address, d.name, x.audio)
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(if (up) stringResource(R.string.connected_for_audio) else if (x.audioKnown) stringResource(R.string.not_connected_for_audio) else stringResource(R.string.paired), 13, color = if (up) P.green else P.sub)
                }
                if (x.audioKnown && !up) {
                    SmallButton(stringResource(R.string.bluetooth), icon = Icons.Rounded.Bluetooth) { openBluetooth(ctx) }
                    Spacer(Modifier.width(6.dp))
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.control), false) { if (!b.connecting) b.connect(d) }
                } else {
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.connect), icon = Icons.Rounded.Link) { if (!b.connecting) b.connect(d) }
                }
            }
            Divider()
        }
        Row(
            Modifier.clip(CircleShape).clickable { openBluetooth(ctx) }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt(stringResource(R.string.open_bluetooth_settings), 15, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val labelRes: Int)
private val NONE = Opt(Buds.F_NONE, R.string.fn_none)
private val PLAY = Opt(Buds.F_PLAY, R.string.fn_play)
private val PREV = Opt(Buds.F_PREV, R.string.fn_prev)
private val NEXT = Opt(Buds.F_NEXT, R.string.fn_next)
private val VOICE = Opt(Buds.F_VOICE, R.string.fn_voice)
private val GAME = Opt(Buds.F_GAME, R.string.fn_game)
private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, R.string.fn_vol_up), Opt(Buds.F_VOL_DN, R.string.fn_vol_down))
private fun optsFor(gid: Int) = when (gid) { Buds.G_SINGLE -> SINGLE_OPTS; Buds.G_DOUBLE -> DOUBLE_OPTS; Buds.G_TRIPLE -> TRIPLE_OPTS; else -> LONG_OPTS }

private fun fnIcon(fn: Int): ImageVector = when (fn) {
    Buds.F_NONE -> Icons.Rounded.Block
    Buds.F_PLAY -> Icons.Rounded.PlayArrow
    Buds.F_PREV -> Icons.Rounded.SkipPrevious
    Buds.F_NEXT -> Icons.Rounded.SkipNext
    Buds.F_VOICE -> Icons.Rounded.Mic
    Buds.F_GAME -> Icons.Rounded.SportsEsports
    Buds.F_VOL_UP -> Icons.Rounded.VolumeUp
    Buds.F_VOL_DN -> Icons.Rounded.VolumeDown
    Buds.F_ANC -> Icons.Rounded.Waves
    else -> Icons.Rounded.Tune
}

@Composable
private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return stringResource(it.labelRes) }
    return when (fn) {
        0x07 -> stringResource(R.string.fn_volume)
        0x0A -> stringResource(R.string.fn_switch_track)
        Buds.F_ANC -> stringResource(R.string.fn_anc)
        else -> stringResource(R.string.unknown_action, Protocol.hex(fn).uppercase())
    }
}

@Composable
private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add(stringResource(R.string.hold_anc))
        if ((mask and Buds.M_OFF) != 0) add(stringResource(R.string.hold_off))
        if ((mask and Buds.M_TRANSP) != 0) add(stringResource(R.string.hold_transparency))
    }
    return n.joinToString(", ")
}

@Composable
private fun wearText(f: Int): String = when {
    f < 0 -> "—"
    (f and 2) != 0 -> stringResource(R.string.wear_in_ear)
    (f and 1) == 0 -> stringResource(R.string.wear_in_case)
    else -> stringResource(R.string.wear_out_case)
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) stringResource(R.string.left) else stringResource(R.string.right)
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast(connectFirstText) }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null
    fun isSet(g: Int): Boolean = live && (cur(g) ?: Buds.F_NONE) != Buds.F_NONE

    Page {
        if (!live) NeedConnect(x)

        SectionLabel(stringResource(R.string.noise_control), Icons.Rounded.Waves)
        GlassPanel(index = 0) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("ANC", "", Icons.Rounded.Waves, live && b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { if (live) b.setAnc(Buds.ANC_ON) else x.toast(connectFirstText) }
                FeatureTile("Off", "", Icons.Rounded.Block, live && b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { if (live) b.setAnc(Buds.ANC_OFF) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.aware), "", Icons.Rounded.Hearing, live && b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { if (live) b.setAnc(Buds.ANC_TRANSP) else x.toast(connectFirstText) }
            }
            if (live) SaveLine(b.ancSaveState, b.ancSaveMessage)
        }

        SwitchRow(stringResource(R.string.game_mode), stringResource(R.string.lower_audio_latency), b.gameMode == true, live, Icons.Rounded.SportsEsports) { b.setGame(it) }

        SectionLabel(stringResource(R.string.find_my_earbuds), Icons.Rounded.LocationSearching)
        GlassPanel(index = 1) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FindTile(stringResource(R.string.left_2), stringResource(R.string.find_left_tone), Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, 21, { if (live) b.findEarbuds(1) else x.toast(connectFirstText) }, { b.stopFindEarbuds() })
                FindTile(stringResource(R.string.right_2), stringResource(R.string.find_right_tone), Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, 22, { if (live) b.findEarbuds(2) else x.toast(connectFirstText) }, { b.stopFindEarbuds() })
                FindTile(stringResource(R.string.both_2), stringResource(R.string.find_both_tone), Icons.Rounded.NotificationsActive, b.findAlertRequested && b.findAlertSide == 3, 23, { if (live) b.findEarbuds(3) else x.toast(connectFirstText) }, { b.stopFindEarbuds() })
            }
        }

        SectionLabel(stringResource(R.string.earbud_controls), Icons.Rounded.TouchApp, stringResource(R.string.pick_earbud))
        GlassPanel(index = 2) {
            // Compact stage: the earbud picture is smaller (was 190dp) with a soft accent halo, and crossfades L/R.
            Box(Modifier.fillMaxWidth().height(104.dp), contentAlignment = Alignment.Center) {
                val halo = P.accent.copy(alpha = if (P.dark) 0.20f else 0.14f)   // read P here: it is @Composable, not usable in the draw lambda
                Canvas(Modifier.size(110.dp)) {
                    drawCircle(Brush.radialGradient(listOf(halo, Color.Transparent)), radius = size.minDimension / 2f)
                }
                Crossfade(side, animationSpec = tween(220), label = "budSide") { sd -> BudPhoto(sd == 2, 88.dp, touchSpot = true) }
            }
            Spacer(Modifier.height(6.dp))
            Segmented(listOf(Icons.Rounded.ChevronLeft to stringResource(R.string.left_2), Icons.Rounded.ChevronRight to stringResource(R.string.right_2)), side - 1) { side = it + 1 }
        }

        SectionLabel(stringResource(R.string.when_not_on_a_call), Icons.Rounded.MusicNote)
        GlassPanel(index = 3) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.tile_single), fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE)), Icons.Rounded.TouchApp, isSet(Buds.G_SINGLE), Modifier.weight(1f), 41) { open(Buds.G_SINGLE) }
                FeatureTile(stringResource(R.string.tile_double), fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE)), Icons.Rounded.Fingerprint, isSet(Buds.G_DOUBLE), Modifier.weight(1f), 42) { open(Buds.G_DOUBLE) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.tile_triple), fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE)), Icons.Rounded.MoreHoriz, isSet(Buds.G_TRIPLE), Modifier.weight(1f), 43) { open(Buds.G_TRIPLE) }
                FeatureTile(stringResource(R.string.tile_hold), if (live) holdLabel(b.holdMask) else "—", Icons.Rounded.PanTool, live && b.holdMask > 0, Modifier.weight(1f), 44) { open(Buds.G_HOLD) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.tile_long), fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), Icons.Rounded.Timer, isSet(Buds.G_LONG), Modifier.weight(1f), 45) { open(Buds.G_LONG) }
                FeatureTile(stringResource(R.string.view_tutorial), stringResource(R.string.how_gestures), Icons.Rounded.School, false, Modifier.weight(1f), 46) { tutorial = true }
            }
            if (live) SaveLine(b.gestSaveState, b.gestSaveMessage)
        }

        SectionLabel(stringResource(R.string.when_on_a_call), Icons.Rounded.Call)
        ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), stringResource(R.string.answer_end_call), chevron = false, icon = Icons.Rounded.Call)
        ValueRow(stringResource(R.string.long_touch_and_hold), stringResource(R.string.decline_call), chevron = false, icon = Icons.Rounded.CallEnd)
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> stringResource(R.string.g_single); Buds.G_DOUBLE -> stringResource(R.string.g_double); else -> stringResource(R.string.g_triple) }) + " $sideName " + stringResource(R.string.earbud)
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(stringResource(o.labelRes), fnIcon(o.fn), now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }) {
            SheetTitle(stringResource(R.string.g_long))
            Txt(stringResource(R.string.long_touch_volume_help), 15, lineHeight = 22)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.long_touch_anc_help), 15, lineHeight = 22)
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEach { o ->
                RadioRow(stringResource(o.labelRes), fnIcon(o.fn), now == o.fn) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_HOLD) {
        LaunchedEffect(Unit) { b.queryHold() }
        var sel by rememberSaveable { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        var holdTouched by remember { mutableStateOf(false) }
        var submitted by remember { mutableStateOf(false) }
        // Close the sheet once the earbuds have confirmed (or accepted) the new Hold setting.
        LaunchedEffect(b.holdSaveState, submitted) {
            if (submitted && b.holdSaveState == Buds.SaveState.SAVED) { kotlinx.coroutines.delay(700); dlg = 0 }
        }
        LaunchedEffect(b.holdMask) { if (!holdTouched && b.holdMask > 0) sel = b.holdMask and 7 }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) { sel = v; holdTouched = true } }
        SheetDialog({ dlg = 0 }, footer = {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton(if (b.holdSaveState == Buds.SaveState.SAVING) stringResource(R.string.saving) else stringResource(R.string.confirm), true, icon = Icons.Rounded.Check) { if (b.holdSaveState != Buds.SaveState.SAVING) { submitted = true; b.updateHoldMask(sel) } } }
            }
        }) {
            SheetTitle(stringResource(R.string.g_hold))
            Txt(if (n == 1) stringResource(R.string.hold_one_option) else stringResource(R.string.hold_many_options, n), 15, lineHeight = 21)
            Spacer(Modifier.height(6.dp))
            CheckRow(stringResource(R.string.hold_anc), stringResource(R.string.hold_anc_sub), Icons.Rounded.Waves, (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow(stringResource(R.string.hold_off), stringResource(R.string.hold_off_sub), Icons.Rounded.Block, (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow(stringResource(R.string.hold_transparency), stringResource(R.string.hold_transparency_sub), Icons.Rounded.Hearing, (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            if (b.holdSaveState != Buds.SaveState.SAVED && (b.holdSaveState != Buds.SaveState.IDLE || b.holdSaveMessage.isNotBlank())) {
                Spacer(Modifier.height(12.dp))
                val saveColor = when (b.holdSaveState) {
                    Buds.SaveState.SAVED -> P.green
                    Buds.SaveState.FAILED -> P.amber
                    Buds.SaveState.SAVING -> P.accent
                    else -> P.sub
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (b.holdSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = saveColor)
                    else Icon(if (b.holdSaveState == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = saveColor, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Txt(b.holdSaveMessage, 12, color = saveColor, lineHeight = 17)
                }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle(stringResource(R.string.earbud_controls))
            TutorialLine(Icons.Rounded.TouchApp, stringResource(R.string.single_double_and_triple_tap_tap_the_touch_area_))
            TutorialLine(Icons.Rounded.PanTool, stringResource(R.string.touch_and_hold_hold_until_you_hear_a_beep_then_l))
            TutorialLine(Icons.Rounded.Timer, stringResource(R.string.long_touch_and_hold_keep_holding_until_you_hear_))
            TutorialLine(Icons.Rounded.Call, stringResource(R.string.during_a_call_double_tap_to_answer_or_end_it_lon))
            Spacer(Modifier.height(14.dp))
            WideButton(stringResource(R.string.got_it), true, icon = Icons.Rounded.Check) { tutorial = false }
        }
    }
}

@Composable
private fun TutorialLine(icon: ImageVector, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        BounceIcon(icon, false, 40.dp, false, { 0f }, P.accent)
        Spacer(Modifier.width(12.dp))
        Txt(text, 15, color = P.text, lineHeight = 21, modifier = Modifier.weight(1f))
    }
}

// ================================================================= SETTINGS

/** Languages the app ships strings for. The empty tag follows the phone. */
private val LANGS = listOf("" to "System", "en" to "English", "hi" to "\u0939\u093f\u0928\u094d\u0926\u0940")
private fun langName(tag: String): String = LANGS.firstOrNull { it.first == tag }?.second ?: "System"

@Composable
fun SettingsScreen(x: Ctx) {
    var diag by remember { mutableStateOf(x.prefs.diag) }
    var batteryNotif by remember { mutableStateOf(Buds.prefs.batteryNotif) }
    var tapSound by remember { mutableStateOf(x.prefs.tapSound) }
    var haptics by remember { mutableStateOf(x.prefs.haptics) }
    var rename by remember { mutableStateOf(false) }
    val connectFirstSettings = stringResource(R.string.err_connect_first)
    var langDlg by remember { mutableStateOf(false) }
    var protocolLabDlg by remember { mutableStateOf(false) }
    var protocolTesterDlg by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf(Buds.customName ?: Buds.deviceName) }
    var peerSel by remember { mutableStateOf<com.nordbuds.studio.protocol.VendorAdvancedHandlers.MultiDevice.Peer?>(null) }
    var addDlg by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    Page {
        SectionLabel(stringResource(R.string.section_device), Icons.Rounded.Headphones)
        ValueRow(stringResource(R.string.rename_device), Buds.displayName.ifEmpty { stringResource(R.string.app_name) }, icon = Icons.Rounded.Edit) { nameDraft = Buds.customName ?: Buds.deviceName; rename = true }
        SwitchRow(stringResource(R.string.battery_notification), stringResource(R.string.battery_notification_sub), batteryNotif, icon = Icons.Rounded.Notifications) { enabled ->
            batteryNotif = enabled
            Buds.prefs.batteryNotif = enabled
            if (!enabled) BatteryNotifier.cancel(ctx) else if (!x.notifGranted) x.askNotifPerm() else BatteryNotifier.update(ctx)
        }
        SwitchRow(stringResource(R.string.wear_detection), stringResource(R.string.wear_detection_sub), Buds.wearDetect == true, icon = Icons.Rounded.Hearing, badge = stringResource(R.string.experimental)) { Buds.setWearDetect(it) }
        SaveLine(Buds.wearSaveState, Buds.wearSaveMessage)

        SectionLabel(stringResource(R.string.section_connection), Icons.Rounded.Bluetooth)
        if (Buds.multiDevicePeers.isNotEmpty()) {
            Txt("Earbud multi-device status · ${Buds.multiDevicePeers.size} peer(s)", 13, FontWeight.SemiBold, P.text)
            Buds.multiDevicePeers.forEach { peer ->
                val state = when (peer.connectionState) { 0 -> "Disconnected"; 1 -> "Connected"; 2 -> "Connecting"; else -> "State ${peer.connectionState}" }
                val roles = listOfNotNull(
                    if (peer.isCurrentDevice) "This device" else null,
                    if (peer.isMainAudioDevice) "Main audio" else null,
                    if (peer.isAudioActive) "Audio active" else null
                ).joinToString(" · ")
                ValueRow(peer.name.ifBlank { peer.address }, listOf(state, roles).filter { it.isNotBlank() }.joinToString(" · "), icon = Icons.Rounded.Devices) { peerSel = peer }
            }
        } else if (Buds.connected) {
            ValueRow("Multi-device status", "No verified peer list received yet", icon = Icons.Rounded.Devices) { }
        }
        ValueRow(
            stringResource(R.string.dual_connection),
            if (Buds.multiDevicePeers.isNotEmpty()) "${Buds.multiDevicePeers.count { it.connectionState == 1 }} of ${Buds.multiDevicePeers.size} connected · tap a device to manage"
            else "No device list from the earbuds yet",
            icon = Icons.Rounded.Devices
        ) { if (Buds.connected) { Buds.refreshAll(); x.toast("Refreshing device list…") } else x.toast(connectFirstSettings) }
        ValueRow("Add new device", "Pair another phone or tablet with the earbuds", icon = Icons.Rounded.Add) {
            if (Buds.connected) addDlg = true else x.toast(connectFirstSettings)
        }
        SwitchRow(stringResource(R.string.keep_alive), stringResource(R.string.keep_alive_sub), Buds.keepAlive, icon = Icons.Rounded.Notifications) {
            Buds.updateKeepAlive(it)
            if (it && !x.notifGranted) x.askNotifPerm()
        }
        ValueRow(stringResource(R.string.firmware), if (Buds.connected) (com.nordbuds.studio.protocol.Protocol.formatFirmware(Buds.firmware) ?: "\u2014") else "\u2014", icon = Icons.Rounded.SystemUpdate) { openHeyMelody(ctx) }
        SectionNote(stringResource(R.string.fw_update_hint))
        if (Buds.connected && Buds.peers.isNotEmpty()) {
            SectionLabel(stringResource(R.string.connected_devices), Icons.Rounded.Devices)
            Buds.peers.forEach { ValueRow(it, "", chevron = false, icon = Icons.Rounded.Devices) }
        }

        SectionLabel(stringResource(R.string.language), Icons.Rounded.Language)
        ValueRow(stringResource(R.string.language), langName(x.prefs.language), icon = Icons.Rounded.Language) { langDlg = true }

        SectionLabel(stringResource(R.string.appearance), Icons.Rounded.Contrast, stringResource(R.string.appearance_detail))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.LIGHT, title = stringResource(R.string.light),
                subtitle = stringResource(R.string.ap_light_sub), icon = Icons.Rounded.WbSunny,
                mode = ThemeMode.STOCK, onClick = { x.setAppearance(AppearanceMode.LIGHT) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.DARK, title = stringResource(R.string.dark),
                subtitle = stringResource(R.string.ap_dark_sub), icon = Icons.Rounded.NightsStay,
                mode = ThemeMode.STOCK, onClick = { x.setAppearance(AppearanceMode.DARK) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.AMOLED, title = stringResource(R.string.amoled_black),
                subtitle = stringResource(R.string.ap_amoled_sub), icon = Icons.Rounded.Brightness4,
                mode = ThemeMode.STOCK, onClick = { x.setAppearance(AppearanceMode.AMOLED) })
            ThemeChoiceCard(selected = x.appearance == AppearanceMode.SYSTEM, title = stringResource(R.string.follow_system),
                subtitle = stringResource(R.string.ap_system_sub), icon = Icons.Rounded.Settings,
                mode = ThemeMode.STOCK, onClick = { x.setAppearance(AppearanceMode.SYSTEM) })
        }

        SectionLabel(stringResource(R.string.budsy_themes), Icons.Rounded.Palette, stringResource(R.string.themes_detail))
        ValueRow(
            "Theme Manager",
            if (x.activeImportedTheme == null) "Stock Budsy" else (ThemeStore.spec(ctx, x.activeImportedTheme)?.name ?: "Custom theme"),
            icon = Icons.Rounded.Palette
        ) { x.openThemeManager() }
        SectionNote("Import .mtz / .budsytheme files, preview, apply, duplicate, export or delete themes.")

        SectionLabel(stringResource(R.string.touch_feedback), Icons.Rounded.Vibration)
        SwitchRow(stringResource(R.string.tap_sounds), stringResource(R.string.tap_sounds_sub), tapSound, icon = Icons.Rounded.VolumeUp) { tapSound = it; x.prefs.tapSound = it; Fx.sound = it }
        SwitchRow(stringResource(R.string.haptics), stringResource(R.string.haptics_sub), haptics, icon = Icons.Rounded.Vibration) { haptics = it; x.prefs.haptics = it; Fx.haptics = it }
        ValueRow(stringResource(R.string.test_vibration), stringResource(R.string.test_vibration_sub), icon = Icons.Rounded.Vibration) { x.toast(Fx.test(ctx)) }

        if (langDlg) SheetDialog({ langDlg = false }) {
            SheetTitle(stringResource(R.string.language))
            LANGS.forEach { (tag, label) ->
                RadioRow(if (tag.isEmpty()) stringResource(R.string.language_system) else label, Icons.Rounded.Language, x.prefs.language == tag) {
                    langDlg = false
                    if (x.prefs.language != tag) { x.prefs.language = tag; (ctx as? android.app.Activity)?.recreate() }
                }
            }
        }
        SectionLabel(stringResource(R.string.diagnostics), Icons.Rounded.BugReport)
        SwitchRow(stringResource(R.string.diagnostics), stringResource(R.string.show_gesture_table_and_protocol_log), diag, icon = Icons.Rounded.BugReport) { diag = it; x.prefs.diag = it }
        if (diag) {
        SectionLabel("Protocol Verification", Icons.Rounded.Memory, "Find out which features have real device evidence")
        ValueRow("Automatic Protocol Tester", "Run safe read-only checks and see PASS / PARTIAL / FAIL / UNVERIFIED", icon = Icons.Rounded.Sensors) { protocolTesterDlg = true }
        SectionLabel("Protocol Laboratory", Icons.Rounded.Memory, "Capture and inspect Budsy Bluetooth control frames")
        ValueRow("Protocol capture", if (ProtocolLab.capturing) "Recording · ${ProtocolLab.totalCaptured} frames" else "Stopped · ${ProtocolLab.totalCaptured} saved", icon = Icons.Rounded.Sensors) { protocolLabDlg = true }
            HeroPreviewPicker(); Diagnostics(x)
        }
    }
    if (protocolLabDlg) ProtocolLabDialog(onDismiss = { protocolLabDlg = false })
    if (protocolTesterDlg) ProtocolAutoTesterDialog(onDismiss = { protocolTesterDlg = false })
    peerSel?.let { PeerSheet(it, x) { peerSel = null } }
    if (addDlg) AddDeviceSheet(x) { addDlg = false }
    if (rename) GlassDialog(
        stringResource(R.string.rename_device), { rename = false }, stringResource(R.string.save),
        { Buds.renameDevice(nameDraft); rename = false }, stringResource(R.string.cancel)
    ) {
        TextField(
            value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true,
            label = { Text(stringResource(R.string.rename_hint)) }, colors = budsyFieldColors(),
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
    }
}

private fun removeBondCompat(d: BluetoothDevice): Boolean =
    try { (d.javaClass.getMethod("removeBond").invoke(d) as? Boolean) ?: false } catch (_: Throwable) { false }

private fun openBluetoothSettings(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
}

@Composable
private fun PeerSheet(peer: com.nordbuds.studio.protocol.VendorAdvancedHandlers.MultiDevice.Peer, x: Ctx, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val local = remember(peer.address) { bondedDevices(ctx).firstOrNull { it.address.equals(peer.address, true) } }
    val state = when (peer.connectionState) { 0 -> "Disconnected"; 1 -> "Connected"; 2 -> "Connecting"; else -> "State ${peer.connectionState}" }
    SheetDialog(onDismiss) {
        SheetTitle(peer.name.ifBlank { peer.address })
        Txt("$state · ${peer.address}", 13, color = P.sub, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp), align = TextAlign.Center)
        if (local != null) {
            WideButton("Remove from this phone", false, destructive = true, icon = Icons.Rounded.Delete) {
                val ok = removeBondCompat(local)
                if (ok) x.toast("Removed ${peer.name.ifBlank { peer.address }}") else { x.toast("Android blocked it – opening Bluetooth settings"); openBluetoothSettings(ctx) }
                Buds.refreshAll(); onDismiss()
            }
        } else {
            SectionNote("This device is paired from another phone or tablet. Open Bluetooth settings on that device and forget the earbuds there – Budsy cannot send a remove command to the earbuds yet, because that command is not verified.")
        }
        Spacer(Modifier.height(10.dp))
        WideButton("Refresh status", false, icon = Icons.Rounded.Refresh) { Buds.refreshAll(); onDismiss() }
    }
}

@Composable
private fun AddDeviceSheet(x: Ctx, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val startCount = remember { Buds.multiDevicePeers.size }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(searching) {
        if (searching) { repeat(12) { Buds.refreshAll(); delay(3000) }; searching = false }
    }
    val found = Buds.multiDevicePeers.size - startCount
    SheetDialog(onDismiss) {
        SheetTitle("Add new device")
        Txt("1. Open the earbuds case and hold its button for about 3 seconds until the light flashes.\n2. On the new phone or tablet, open Bluetooth and select the earbuds.\n3. Come back here and tap Search – the new device appears in the list.", 13, color = P.sub, lineHeight = 19)
        Spacer(Modifier.height(14.dp))
        if (searching) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                CircularProgressIndicator(Modifier.size(18.dp), color = P.accent, strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Txt(if (found > 0) "$found new device found" else "Looking for a new device…", 14, FontWeight.Medium, P.text)
            }
        } else if (found > 0) {
            Txt("$found new device added to the list", 14, FontWeight.Medium, P.green, Modifier.padding(bottom = 10.dp))
        }
        WideButton(if (searching) "Searching…" else "Search for new device", enabled = !searching, icon = Icons.Rounded.Search) { searching = true }
        Spacer(Modifier.height(8.dp))
        WideButton("Open Bluetooth settings", false, icon = Icons.Rounded.Bluetooth) { openBluetoothSettings(ctx) }
    }
}

@Composable
private fun ProtocolLabDialog(onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val events = ProtocolLab.events
    var featureIdText by remember { mutableStateOf("01") }
    var liveFilter by remember { mutableStateOf(ProtocolLiveMonitor.Filter.ALL) }
    var liveSearch by remember { mutableStateOf("") }
    var featureLabelText by remember { mutableStateOf("") }
    val hciPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Could not open selected file")
            }.onSuccess { bytes ->
                ProtocolLab.importHci(uri.lastPathSegment ?: "bluetooth_hci_snoop.log", bytes)
            }.onFailure { ProtocolLab.importHci("selected file", byteArrayOf()) }
        }
    }
    AlertDialog(
        shape = RoundedCornerShape(28.dp), containerColor = P.sheet,
        onDismissRequest = onDismiss,
        title = { Text("Protocol Laboratory") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Captures Budsy RFCOMM traffic and imports Android btsnoop files. The importer attempts HCI ACL → L2CAP → RFCOMM reassembly and extracts vendor frames when the capture contains the required handshake and data.", fontSize = 12.sp, color = P.sub)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (ProtocolLab.capturing) "LIVE CAPTURE" else "CAPTURE STOPPED", color = if (ProtocolLab.capturing) Color(0xFF35C98A) else P.sub, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${ProtocolLab.totalCaptured} frames · ${ProtocolLab.matchedReplies} matched", color = P.sub, fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { if (ProtocolLab.capturing) ProtocolLab.stop() else ProtocolLab.start() }) { Text(if (ProtocolLab.capturing) "Stop" else "Start capture") }
                    TextButton(onClick = { clipboard.setText(AnnotatedString(ProtocolLab.exportText())) }) { Text("Copy TXT") }
                    TextButton(onClick = { clipboard.setText(AnnotatedString(ProtocolLab.exportJson())) }) { Text("Copy JSON") }
                    TextButton(onClick = { ProtocolLab.clear() }) { Text("Clear") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { hciPicker.launch(arrayOf("*/*")) }) { Text("Import HCI snoop") }
                    TextButton(onClick = { ProtocolLab.useImportedAsBaseline() }, enabled = ProtocolLab.importedHci != null) { Text("Set baseline") }
                }
                ProtocolLab.importError?.let { Text("Import error: $it", color = Color(0xFFFF7777), fontSize = 11.sp) }
                ProtocolLab.importedHci?.let { report ->
                    Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("HCI IMPORT · ${report.fileName}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = P.accent)
                        Text(report.summary(), fontSize = 10.sp, color = P.text)
                        if (report.vendorFrames.isNotEmpty()) {
                            Text("EXTRACTED VENDOR CONTROL FRAMES · ${report.vendorFrames.size}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF35C98A))
                            report.vendorFrames.take(20).forEach { frame ->
                                Text(frame.line(), fontSize = 9.sp, color = P.text)
                            }
                            if (report.vendorFrames.size > 20) Text("Showing first 20; full list included in TXT export.", fontSize = 9.sp, color = P.sub)
                        } else {
                            Text("No proprietary vendor frames extracted. The capture may omit RFCOMM setup, use BLE/GATT, or carry control data on another transport.", fontSize = 9.sp, color = P.sub)
                        }
                        if (report.attPackets > 0 || report.gattCharacteristics.isNotEmpty()) {
                            Text("BLE / GATT DISCOVERY · ATT ${report.attPackets} · characteristics ${report.gattCharacteristics.size} · events ${report.gattEvents.size}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = P.accent)
                            report.gattCharacteristics.take(24).forEach { c ->
                                Text("handle 0x${c.valueHandle.toString(16).padStart(4,'0')} · ${c.uuid} · properties 0x${c.properties.toString(16)}", fontSize = 9.sp, color = P.text)
                            }
                            report.gattEvents.take(30).forEach { event -> Text(event.line(), fontSize = 9.sp, color = P.sub) }
                            if (report.gattEvents.size > 30) Text("Showing first 30 GATT events; full list included in TXT export.", fontSize = 9.sp, color = P.sub)
                            Text("UUIDs are shown as observed. They are not automatically labelled ANC/EQ/battery until verified against controlled captures.", fontSize = 9.sp, color = P.sub)
                        } else {
                            Text("No BLE ATT/GATT packets detected in this capture.", fontSize = 9.sp, color = P.sub)
                        }
                        Text("HCI command opcodes: " + report.opcodeCounts.entries.sortedByDescending { it.value }.take(8).joinToString { "0x${it.key.toString(16).padStart(4,'0')} ×${it.value}" }, fontSize = 10.sp, color = P.sub)
                        Text("HCI event codes: " + report.eventCodeCounts.entries.sortedByDescending { it.value }.take(6).joinToString { "0x${it.key.toString(16).padStart(2,'0')} ×${it.value}" }, fontSize = 10.sp, color = P.sub)
                        ProtocolLab.hciDiff()?.let { diff ->
                            Text("COMPARE TO BASELINE · records ${if (diff.recordDelta >= 0) "+" else ""}${diff.recordDelta}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("New opcodes: ${diff.addedOpcodes.joinToString { "0x${it.toString(16).padStart(4,'0')}" }.ifBlank { "none" }}", fontSize = 10.sp)
                            Text("Removed opcodes: ${diff.removedOpcodes.joinToString { "0x${it.toString(16).padStart(4,'0')}" }.ifBlank { "none" }}", fontSize = 10.sp)
                            Text("Changed counts: ${diff.changedOpcodes.joinToString { "0x${it.first.toString(16).padStart(4,'0')} ${it.second.first}→${it.second.second}" }.ifBlank { "none" }}", fontSize = 10.sp)
                            val candidates = ProtocolLab.commandCandidates()
                            Text("COMMAND MAPPING CANDIDATES · ${candidates.size}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = P.accent)
                            candidates.take(20).forEach { candidate ->
                                Text(candidate.line(), fontSize = 9.sp, color = P.text)
                            }
                            TextButton(onClick = {
                                candidates.forEach { ProtocolCommandDatabase.addCandidate(it, report.fileName) }
                            }, enabled = candidates.isNotEmpty()) { Text("Import candidates as OBSERVED") }
                            Text("Candidates show differences only. Repeat one controlled action per capture and manually verify the same signal before assigning an ANC/EQ/battery label.", fontSize = 9.sp, color = P.sub)
                        }
                        if (report.warnings.isNotEmpty()) Text("Warnings: ${report.warnings.joinToString("; ")}", color = Color(0xFFFFB45C), fontSize = 9.sp)
                    }
                }
                Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Feature ID mapping · user-verified labels only", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextField(colors = budsyFieldColors(), value = featureIdText, onValueChange = { featureIdText = it.take(2) }, label = { Text("ID hex") }, modifier = Modifier.width(88.dp), singleLine = true)
                        TextField(colors = budsyFieldColors(), value = featureLabelText, onValueChange = { featureLabelText = it.take(80) }, label = { Text("Verified feature name") }, modifier = Modifier.weight(1f), singleLine = true)
                        TextButton(onClick = {
                            val id = featureIdText.toIntOrNull(16)
                            if (id != null) { ProtocolLab.saveFeatureLabel(id, featureLabelText); featureLabelText = "" }
                        }) { Text("Save") }
                    }
                    Text(ProtocolLab.featureMappings().joinToString(" · ") { "0x${it.first.toString(16).padStart(2,'0')} ${it.second}" }.ifBlank { "No manually verified mappings yet." }, fontSize = 9.sp, color = P.sub)
                }
                var dbCommand by remember { mutableStateOf("0106") }
                var dbLabel by remember { mutableStateOf("") }
                var dbEvidence by remember { mutableStateOf("") }
                var dbTransport by remember { mutableStateOf("BLE/GATT") }
                var dbSample by remember { mutableStateOf("") }
                var dbCaptureA by remember { mutableStateOf("") }
                var dbCaptureB by remember { mutableStateOf("") }
                var dbServiceUuid by remember { mutableStateOf("") }
                var dbCharacteristicUuid by remember { mutableStateOf("") }
                var negativeControlPassed by remember { mutableStateOf(false) }
                Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("COMMAND DATABASE · evidence-backed profiles", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = P.accent)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Profile: ${ProtocolCommandDatabase.activeProfile.value}", fontSize = 10.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            val all = ProtocolCommandDatabase.profiles
                            val next = (all.indexOf(ProtocolCommandDatabase.activeProfile.value) + 1) % all.size
                            ProtocolCommandDatabase.selectProfile(all[next])
                        }) { Text("Change") }
                        TextButton(onClick = { clipboard.setText(AnnotatedString(ProtocolCommandDatabase.exportJson())) }) { Text("Export DB") }
                    }
                    val profileSummary = ProtocolCommandDatabase.profileSummary()
                    Text("PROFILE EVIDENCE · ${profileSummary.total} total · ${profileSummary.observed} observed · ${profileSummary.verified} verified", fontSize = 9.sp, color = P.sub)
                    TextField(colors = budsyFieldColors(), value = dbCommand, onValueChange = { dbCommand = it.take(8) }, label = { Text("Command hex (e.g. 0106)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextField(colors = budsyFieldColors(), value = dbLabel, onValueChange = { dbLabel = it.take(100) }, label = { Text("Observed command label") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextField(colors = budsyFieldColors(), value = dbTransport, onValueChange = { dbTransport = it.take(20) }, label = { Text("Transport") }, modifier = Modifier.weight(1f), singleLine = true)
                        TextField(colors = budsyFieldColors(), value = dbSample, onValueChange = { dbSample = it.take(240) }, label = { Text("Sample hex") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    TextField(colors = budsyFieldColors(), value = dbEvidence, onValueChange = { dbEvidence = it.take(500) }, label = { Text("Evidence / fresh verification note (min 12 chars)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    TextField(colors = budsyFieldColors(), value = dbCaptureA, onValueChange = { dbCaptureA = it.take(100) }, label = { Text("Positive capture reference A") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextField(colors = budsyFieldColors(), value = dbCaptureB, onValueChange = { dbCaptureB = it.take(100) }, label = { Text("Distinct positive capture reference B") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextField(colors = budsyFieldColors(), value = dbServiceUuid, onValueChange = { dbServiceUuid = it.take(80) }, label = { Text("Confirmed GATT service UUID (if applicable)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextField(colors = budsyFieldColors(), value = dbCharacteristicUuid, onValueChange = { dbCharacteristicUuid = it.take(80) }, label = { Text("Confirmed GATT write characteristic UUID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextButton(onClick = { negativeControlPassed = !negativeControlPassed }) {
                        Text(if (negativeControlPassed) "✓ Negative control passed" else "Mark negative control passed")
                    }
                    TextButton(onClick = {
                        if (ProtocolCommandDatabase.addObserved(dbTransport, dbCommand, dbLabel, dbEvidence, dbSample)) {
                            dbLabel = ""; dbEvidence = ""; dbSample = ""
                        }
                    }) { Text("Save as OBSERVED") }
                    Text("Only mark VERIFIED after repeated controlled captures and a negative-control test.", fontSize = 9.sp, color = P.sub)
                    ProtocolCommandDatabase.visibleEntries().take(20).forEach { entry ->
                        Column(Modifier.fillMaxWidth().insetPanel(8.dp).padding(7.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(entry.line(), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (entry.status == "VERIFIED") P.green else P.text)
                            Text(entry.evidence, fontSize = 9.sp, color = P.sub)
                            if (entry.sample.isNotBlank()) Text("Sample: ${entry.sample}", fontSize = 8.sp, color = P.sub)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (entry.status != "VERIFIED") TextButton(onClick = {
                                    ProtocolCommandDatabase.verifyWithCaptureEvidence(entry.id, dbEvidence,
                                        dbCaptureA, dbCaptureB, negativeControlPassed)
                                }, enabled = dbEvidence.trim().length >= 12 && dbCaptureA.isNotBlank() && dbCaptureB.isNotBlank() &&
                                    !dbCaptureA.equals(dbCaptureB, true) && negativeControlPassed &&
                                    ProtocolCommandDatabase.activeProfile.value != "Unassigned") { Text("Verify with capture evidence") }
                                TextButton(onClick = { ProtocolCommandDatabase.delete(entry.id) }) { Text("Delete") }
                            }
                        }
                    }
                    val readiness = ProtocolReleaseReadiness.buildReport(
                        ProtocolCommandDatabase.activeProfile.value, profileSummary,
                        ProtocolLab.importedHci != null, ProtocolLab.baselineHci != null
                    )
                    Text(readiness.releaseStatus, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB45C))
                    val gateEntry = ProtocolCommandDatabase.visibleEntries().firstOrNull()
                    val manualGate = ProtocolReleaseReadiness.assessTransmission(
                        ProtocolCommandDatabase.activeProfile.value, gateEntry?.command.orEmpty(),
                        gateEntry?.transport.orEmpty(), gateEntry?.status == "VERIFIED",
                        listOf(dbCaptureA, dbCaptureB).filter { it.isNotBlank() }.distinct().size,
                        negativeControlPassed, dbServiceUuid, dbCharacteristicUuid
                    )
                    Text("COMMAND SAFETY GATE · ${manualGate.decision}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = P.sub)
                    manualGate.reasons.forEach { Text("• $it", fontSize = 9.sp, color = P.sub) }
                    TextButton(onClick = { clipboard.setText(AnnotatedString(readiness.asText())) }) { Text("Copy final readiness report") }
                    Text("Verification requires a device-specific profile, two distinct positive captures, a passed negative control and a fresh note. This is still not a hardware certification.", fontSize = 9.sp, color = P.sub)
                }
                Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val liveSummary = ProtocolLiveMonitor.summarize(events)
                    Text("LIVE MONITOR · BUDSY CONNECTION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = P.accent)
                    Text("${liveSummary.visible} retained · TX ${liveSummary.tx} · RX ${liveSummary.rx} · matched ${liveSummary.matched} · unknown ${liveSummary.unknown}", fontSize = 10.sp, color = P.text)
                    if (liveSummary.unknown > 0) Text("Unknown command activity detected. Save a raw sample and compare controlled captures before assigning meaning.", fontSize = 10.sp, color = Color(0xFFFFB45C))
                    TextField(colors = budsyFieldColors(), value = liveSearch, onValueChange = { liveSearch = it.take(48) }, label = { Text("Search command / payload / decoded text") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        ProtocolLiveMonitor.Filter.values().forEach { filter ->
                            TextButton(onClick = { liveFilter = filter }) {
                                Text((if (liveFilter == filter) "• " else "") + filter.name)
                            }
                        }
                    }
                }
                val filteredEvents = ProtocolLiveMonitor.filter(events, liveFilter, liveSearch).takeLast(100).reversed()
                androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (filteredEvents.isEmpty()) {
                        item { Text(if (ProtocolLab.capturing) "Waiting for Budsy control traffic…" else "No matching captured events. Start capture, then use Budsy controls while connected.", fontSize = 11.sp, color = P.sub, modifier = Modifier.padding(10.dp)) }
                    }
                    items(filteredEvents.size) { index ->
                        val event = filteredEvents[index]
                        Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(9.dp)) {
                            Text("${event.direction}  0x${Protocol.hex(event.command ushr 8)}${Protocol.hex(event.command)} · ${event.label}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (event.direction == "TX") P.accent else Color(0xFF35C98A))
                            Text(event.line(), fontSize = 10.sp, color = P.text)
                            if (event.confidence.isNotBlank()) Text(event.confidence, fontSize = 9.sp, color = P.sub)
                        }
                    }
                }
                Text("Decoder: ${ProtocolLab.catalogSummary().size} command IDs · ${ProtocolLab.unknownCommands} lifetime unknown frames. History is saved locally on this phone.", fontSize = 10.sp, color = P.sub)
                Text("Scope: LIVE means Budsy's own control connection only. It does not sniff HeyMelody or other apps. Imported HCI/GATT reports are offline snapshots, not live interception.", fontSize = 10.sp, color = P.sub)
                Text("HCI import: enable Bluetooth HCI snoop in Android Developer options, reproduce the action in HeyMelody, create a bug report, extract the btsnoop log, then import it here. Budsy cannot directly read Android's protected Bluetooth log folder.", fontSize = 10.sp, color = P.sub)
                Text("Safety: imported HCI packets are analyzed only. Arbitrary packet replay is intentionally disabled; unknown feature labels must be verified manually.", fontSize = 10.sp, color = P.sub)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun ProtocolAutoTesterDialog(onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<ProtocolAutoTester.Result>>(emptyList()) }
    var runAt by remember { mutableLongStateOf(0L) }
    var startedCaptureHere by remember { mutableStateOf(false) }
    // Resolve the CompositionLocal palette while inside the composable scope.
    // The statusColor callback itself is an ordinary Kotlin lambda, so it must
    // not access the @Composable P getter.
    val palette = P
    val statusColor: (ProtocolAutoTester.Status) -> Color = { status ->
        when (status) {
            ProtocolAutoTester.Status.PASS -> palette.green
            ProtocolAutoTester.Status.PARTIAL -> palette.accent
            ProtocolAutoTester.Status.FAIL -> Color(0xFFFF666F)
            ProtocolAutoTester.Status.UNVERIFIED -> palette.sub
        }
    }
    fun runChecks() {
        if (!Buds.connected) {
            results = listOf(ProtocolAutoTester.Result("Earbud control connection", ProtocolAutoTester.Status.FAIL,
                "Connect earbuds before running protocol checks", "Connect the device and run this test again"))
            return
        }
        running = true
        runAt = System.currentTimeMillis()
        startedCaptureHere = !ProtocolLab.capturing
        if (startedCaptureHere) ProtocolLab.start()
        Buds.refreshAll() // Read-only query set already used by the app; no feature-setting commands are sent.
        scope.launch {
            kotlinx.coroutines.delay(7000)
            results = ProtocolAutoTester.evaluate(
                events = ProtocolLab.events.toList(), since = runAt,
                connected = Buds.connected, deviceName = Buds.deviceName, deviceAddress = Buds.deviceAddr,
                ancMode = Buds.ancMode, eqPreset = Buds.eqPreset,
                gameMode = Buds.gameMode, bassLevel = Buds.bassLevel, firmware = Buds.firmware,
                peerCount = Buds.multiDevicePeers.size, gattState = Buds.gattProbeState
            )
            if (startedCaptureHere) ProtocolLab.stop()
            running = false
        }
    }
    AlertDialog(
        shape = RoundedCornerShape(28.dp), containerColor = P.sheet,
        onDismissRequest = { if (!running) onDismiss() },
        title = { Text("Automatic Protocol Tester") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Runs only read-only queries already used by Budsy. It does not toggle ANC, EQ, Game Mode, Find My Buds, firmware, or unknown commands.", fontSize = 11.sp, color = P.sub)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (Buds.connected) "CONNECTED · ${Buds.deviceName}" else "NOT CONNECTED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (Buds.connected) P.green else Color(0xFFFF666F))
                        Text("${ProtocolLab.events.size} saved frames · ${ProtocolLab.matchedReplies} matched replies", fontSize = 9.sp, color = P.sub)
                    }
                    TextButton(enabled = !running, onClick = { runChecks() }) { Text(if (running) "Testing…" else "Run safe checks") }
                }
                if (running) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = P.accent)
                        Text("Querying battery, ANC, EQ, flags, gestures, BassWave, firmware and peer status…", fontSize = 10.sp, color = P.sub)
                    }
                }
                if (results.isNotEmpty()) {
                    val counts = results.groupingBy { it.status }.eachCount()
                    Text("RESULT · PASS ${counts[ProtocolAutoTester.Status.PASS] ?: 0}   PARTIAL ${counts[ProtocolAutoTester.Status.PARTIAL] ?: 0}   FAIL ${counts[ProtocolAutoTester.Status.FAIL] ?: 0}   UNVERIFIED ${counts[ProtocolAutoTester.Status.UNVERIFIED] ?: 0}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = P.text)
                    androidx.compose.foundation.lazy.LazyColumn(
                        Modifier.fillMaxWidth().weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(results.size) { index ->
                            val item = results[index]
                            Column(Modifier.fillMaxWidth().insetPanel(10.dp).padding(9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.feature, modifier = Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = P.text)
                                    Text(item.status.name, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = statusColor(item.status))
                                }
                                Text(item.evidence, fontSize = 10.sp, color = P.sub)
                                if (item.nextStep.isNotBlank()) Text("Next: ${item.nextStep}", fontSize = 9.sp, color = P.text)
                            }
                        }
                    }
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(ProtocolAutoTester.report(Buds.deviceName, Buds.deviceAddr, results)))
                    }) { Text("Copy test report") }
                } else if (!running) {
                    Text("No test run yet. Connect the earbuds, then run the safe checks. For stronger evidence, start Protocol capture before changing one feature at a time.", fontSize = 10.sp, color = P.sub)
                }
                Text("Meaning: PASS = matched protocol response/read-back; PARTIAL = protocol data exists but physical behavior is not proven; FAIL = query failed or returned an error; UNVERIFIED = no adequate evidence. A PASS does not prove sound quality, ANC effectiveness, or compatibility with every model.", fontSize = 9.sp, color = P.sub)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss, enabled = !running) { Text("Close") } }
    )
}

private data class ThemeChoiceItem(
    val mode: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector
)

@Composable
private fun ThemeChoiceCard(
    selected: Boolean, title: String, subtitle: String,
    icon: ImageVector, mode: Int, onClick: () -> Unit
) {
    val accent = when (mode) {
        ThemeMode.STOCK -> Color(0xFF3478F6)
        ThemeMode.AURORA -> Color(0xFF20BFFF)
        ThemeMode.CRYSTAL -> Color(0xFF1688EF)
        ThemeMode.NOTHING -> Color(0xFFFF5148)
        else -> Color(0xFFE8C58A)
    }
    // Only the selected card animates; the other four used to run two infinite animations each,
    // which is what made the Settings page (and the Nothing / Aurora cards) stutter.
    val pulse: State<Float>; val drift: State<Float>
    if (selected) {
        val transition = rememberInfiniteTransition(label = "themeIconMotion$mode")
        pulse = transition.animateFloat(
            initialValue = 0.96f, targetValue = 1.06f,
            animationSpec = infiniteRepeatable(tween(if (mode == ThemeMode.NOTHING) 900 else if (mode == ThemeMode.CRYSTAL) 1500 else 1250, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "themeIconPulse$mode"
        )
        drift = transition.animateFloat(
            initialValue = -2.5f, targetValue = 2.5f,
            animationSpec = infiniteRepeatable(tween(if (mode == ThemeMode.TITANIUM) 1900 else 1350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "themeIconDrift$mode"
        )
    } else { pulse = remember { mutableStateOf(1f) }; drift = remember { mutableStateOf(0f) } }
    val shape = RoundedCornerShape(20.dp)
    val liquid = isLiquid()
    val ocean = isOcean()
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    Row(
        (if (ocean) Modifier.fillMaxWidth()
            .oceanGlass(20.dp, selected, 5.dp, pressed)
            .pressClickable(src) { fb(title.hashCode()); onClick() }
        else if (liquid) Modifier.fillMaxWidth()
            .glassTile3D(20.dp, selected, 6.dp, pressed)
            .pressClickable(src) { fb(title.hashCode()); onClick() }
        else Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) accent.copy(alpha = 0.09f) else P.sheet.copy(alpha = 0.72f))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) accent.copy(alpha = 0.8f) else P.line, shape)
            .tapFade { onClick() })
            .heightIn(min = 72.dp).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            (if (ocean) Modifier.size(48.dp).oceanBubble(selected)
            else if (liquid) Modifier.size(48.dp).glassChip(48.dp, selected)
            else Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha = 0.22f), P.tile)))),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = title, tint = if (ocean) (if (selected) Color.White else P.accent) else if (liquid) (if (selected) Color.White else glassTokens().chipInk) else accent,
                modifier = Modifier.size(24.dp).graphicsLayer {
                    scaleX = if (selected) pulse.value else 1f
                    scaleY = if (selected) pulse.value else 1f
                    translationY = if (selected && (mode == ThemeMode.CRYSTAL || mode == ThemeMode.CRYSTAL)) drift.value else 0f
                    rotationZ = when {
                        !selected -> 0f
                        mode == ThemeMode.TITANIUM -> drift.value * 2.8f
                        mode == ThemeMode.NOTHING -> 0f
                        mode == ThemeMode.AURORA -> drift.value * 0.35f
                        else -> 0f
                    }
                })
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Txt(title, 15, FontWeight.SemiBold, P.text, maxLines = 1)
            Txt(subtitle, 12, color = P.sub, lineHeight = 16, maxLines = 2)
        }
        Spacer(Modifier.width(8.dp))
        if (liquid || ocean) GlassCheck(selected, size = 24.dp, preview = pressed && !selected)
        else if (selected) Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = accent, modifier = Modifier.size(22.dp))
        else Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = P.sub, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun Diagnostics(x: Ctx) {
    val b = x.b
    val logCopiedText = stringResource(R.string.log_copied)
    val clip = LocalClipboardManager.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ValueRow(stringResource(R.string.name_2), if (b.connected) b.deviceName else "\u2014", chevron = false, icon = Icons.Rounded.Badge)
        ValueRow(stringResource(R.string.bluetooth_address_2), if (b.connected) b.deviceAddr else "\u2014", chevron = false, icon = Icons.Rounded.Bluetooth)
        ValueRow(stringResource(R.string.status_2), if (b.connected) stringResource(R.string.connected) else b.status, chevron = false, icon = Icons.Rounded.Info)
        ValueRow(stringResource(R.string.firmware_2), if (b.connected) (com.nordbuds.studio.protocol.Protocol.formatFirmware(b.firmware) ?: "\u2014") else "\u2014", chevron = false, icon = Icons.Rounded.SystemUpdate)
        ValueRow(stringResource(R.string.connected_to_buds_2), if (b.connected && b.peers.isNotEmpty()) b.peers.joinToString(", ") else "\u2014", chevron = false, icon = Icons.Rounded.Devices)

        if (b.connected) WideButton(stringResource(R.string.disconnect_2), false, icon = Icons.Rounded.LinkOff) { b.disconnect() } else GlassPanel { ConnectBlock(x) }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Equalizer, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.custom_eq_saved_on_the_buds_read_only), 15, FontWeight.Medium, P.text)
            }
            Spacer(Modifier.height(6.dp))
            Txt(b.customEq ?: stringResource(R.string.nothing_read_yet), 13, FontWeight.Normal, P.sub, lineHeight = 18)
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Flag, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.feature_flags), 15, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.scan_2), false, icon = Icons.Rounded.Search) { b.scanFlags() }
            }
            Spacer(Modifier.height(6.dp))
            Txt(stringResource(R.string.to_find_a_switch_such_as_ear_detection_or_dual_c), 12, lineHeight = 17)
            Spacer(Modifier.height(6.dp))
            if (b.flags.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 13)
        }
        b.flags.toSortedMap().forEach { (id, v) ->
            ValueRow(
                stringResource(R.string.flag_name_unknown, Protocol.hex(id).uppercase()),
                "ID 0x${Protocol.hex(id).uppercase()} · ${if (v == 1) "On" else "Off"} · read-only until mapped",
                chevron = false, icon = Icons.Rounded.Flag
            )
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.TouchApp, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.gesture_table_reported_by_the_buds), 15, FontWeight.Medium, P.text)
            }
            Spacer(Modifier.height(6.dp))
            val keys = b.gest.keys.sorted()
            if (keys.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 14)
            keys.forEach { k ->
                Txt(stringResource(R.string.gesture_table_entry, if (k / 16 == 1) stringResource(R.string.left) else if (k / 16 == 2) stringResource(R.string.right) else stringResource(R.string.gesture_side, k / 16), k % 16, Protocol.hex(b.gest[k] ?: 0).uppercase()), 13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp))
            }
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.BugReport, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                Txt(stringResource(R.string.protocol_log), 15, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.copy), false, icon = Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(b.logText())); x.toast(logCopiedText) }
                Spacer(Modifier.width(6.dp))
                val shareCtx = LocalContext.current
                SmallButton(stringResource(R.string.share), false, icon = Icons.Rounded.Share) {
                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, b.logText()) }
                    try { shareCtx.startActivity(Intent.createChooser(send, null)) } catch (_: Exception) {}
                }
            }
            Spacer(Modifier.height(6.dp))
            val ver = b.logVersion
            val lines = remember(ver) { b.logText().lines().takeLast(14) }
            Txt(if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) stringResource(R.string.empty) else lines.joinToString("\n"), 11, FontWeight.Normal, P.sub, lineHeight = 15)
        }
        Txt(stringResource(R.string.unofficial_disclaimer), 12, lineHeight = 18, modifier = Modifier.padding(horizontal = 6.dp))
    }
}


/** Bluetooth button: same glass squircle chip as every other icon in the app (blue when connected). */
@Composable
private fun BluetoothOrb(on: Boolean, pressed: Boolean = false) {
    val sc by androidx.compose.animation.core.animateFloatAsState(if (pressed) 0.9f else 1f, androidx.compose.animation.core.spring(0.5f, 700f), label = "orbPress")
    Box(
        Modifier.size(44.dp).graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (pressed) 0.85f else 1f }.glassChip(44.dp, on || pressed),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Bluetooth, null, tint = if (on || pressed) Color.White else glassTokens().chipInk, modifier = Modifier.size(25.dp)) }
}
