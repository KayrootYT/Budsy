package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/** One permanent Stock Budsy identity; appearance switches Light, Dark and AMOLED. */
object ThemeMode {
    /** The only built-in theme. Imported themes will be managed separately. */
    const val AURORA = 0 // legacy IDs retained only for source compatibility
    const val CRYSTAL = 1
    const val NOTHING = 2
    const val TITANIUM = 3
    const val STOCK = 4
    const val ONEPLUS = 5
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

private fun stockPal(appearance: Int): Pal = when (appearance) {
    AppearanceMode.LIGHT, AppearanceMode.SYSTEM -> Pal(false, false,
        Color(0xFFF5F5F7), Color.White, Color(0xFFE9E9ED), Color(0xFF17171A),
        Color(0xFF77777D), Color(0xFFE5E5E9), Color(0xFFD6D6DC), Color(0xFF3478F6),
        Color(0xFF28A66A), Color(0xFFE0A12D), Color(0xFFE05252), Color(0xF9FFFFFF), Color(0xFF79A9FF))
    AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF101012), Color(0xFF1B1B1F),
        Color(0xFFF5F5F7), Color(0xFF9A9AA2), Color(0xFF29292E), Color(0xFF393940), Color(0xFF6C9FFF),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xFF09090B), Color(0xFF91B5FF))
    else -> Pal(true, false, Color(0xFF17181B), Color(0xFF222328), Color(0xFF2C2D33),
        Color(0xFFF5F5F7), Color(0xFF9A9AA2), Color(0xFF34353B), Color(0xFF414249), Color(0xFF6C9FFF),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xF9222328), Color(0xFF91B5FF))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null): Pal {
    val stock = stockPal(appearance)
    val dark = appearance != AppearanceMode.LIGHT && appearance != AppearanceMode.SYSTEM
    val base = if (style == ThemeMode.STOCK) stock else when (style) {
        ThemeMode.AURORA -> if (dark) Pal(true, appearance == AppearanceMode.AMOLED, if (appearance == AppearanceMode.AMOLED) Color.Black else Color(0xFF071522), Color(0xFF10283A), Color(0xFF1B3C50), Color(0xFFEAF8FF), Color(0xFF9CB8C9), Color(0xFF244457), Color(0xFF31566A), Color(0xFF36C8FF), Color(0xFF35D39A), Color(0xFFFFC45C), Color(0xFFFF6B72), Color(0xF9102230), Color(0xFF8B8CFF)) else Pal(false, false, Color(0xFFF0F9FF), Color.White, Color(0xFFE0F2FA), Color(0xFF102638), Color(0xFF607D8B), Color(0xFFD4E7F0), Color(0xFFB8D7E5), Color(0xFF078FCB), Color(0xFF159B6B), Color(0xFFD99119), Color(0xFFD94D57), Color(0xF9FFFFFF), Color(0xFF7868D8))
        ThemeMode.CRYSTAL -> if (dark) Pal(true, appearance == AppearanceMode.AMOLED, if (appearance == AppearanceMode.AMOLED) Color.Black else Color(0xFF111B2B), Color(0xFF1C2B40), Color(0xFF293B52), Color(0xFFF3F8FF), Color(0xFFA8B9CE), Color(0xFF344963), Color(0xFF405B78), Color(0xFF8FCBFF), Color(0xFF52D6A4), Color(0xFFFFC86B), Color(0xFFFF7777), Color(0xF91A2A40), Color(0xFFC4B7FF)) else Pal(false, false, Color(0xFFF3F7FD), Color.White, Color(0xFFE4EDF8), Color(0xFF17263B), Color(0xFF73849A), Color(0xFFDCE6F2), Color(0xFFC8D7E8), Color(0xFF3988D8), Color(0xFF28A879), Color(0xFFD99A32), Color(0xFFD95762), Color(0xF9FFFFFF), Color(0xFF8A7BE0))
        ThemeMode.NOTHING -> if (dark) Pal(true, appearance == AppearanceMode.AMOLED, Color(0xFF080808), Color(0xFF171717), Color(0xFF242424), Color(0xFFF5F5F5), Color(0xFFAAAAAA), Color(0xFF333333), Color(0xFF494949), Color(0xFFFF5148), Color(0xFF70D69A), Color(0xFFFFC15A), Color(0xFFFF5148), Color(0xFF101010), Color(0xFFFF8B82)) else Pal(false, false, Color(0xFFF4F4F4), Color.White, Color(0xFFE8E8E8), Color(0xFF171717), Color(0xFF777777), Color(0xFFE0E0E0), Color(0xFFCCCCCC), Color(0xFFE54840), Color(0xFF24985F), Color(0xFFD28D25), Color(0xFFD83D38), Color(0xF9FFFFFF), Color(0xFFFF8178))
        ThemeMode.TITANIUM -> if (dark) Pal(true, appearance == AppearanceMode.AMOLED, if (appearance == AppearanceMode.AMOLED) Color.Black else Color(0xFF171717), Color(0xFF292929), Color(0xFF383838), Color(0xFFF4F0E8), Color(0xFFB7AEA0), Color(0xFF48433B), Color(0xFF5C554A), Color(0xFFD6B77A), Color(0xFF75C99C), Color(0xFFE2B65E), Color(0xFFE4776E), Color(0xF9272727), Color(0xFFB8C3D1)) else Pal(false, false, Color(0xFFF5F2EC), Color.White, Color(0xFFE9E3D8), Color(0xFF292720), Color(0xFF81796B), Color(0xFFE5DED2), Color(0xFFD5CBBB), Color(0xFF9A7742), Color(0xFF328B65), Color(0xFFC18A32), Color(0xFFC6534D), Color(0xF9FFFFFF), Color(0xFF6C8194))
        else -> if (dark) Pal(true, appearance == AppearanceMode.AMOLED, if (appearance == AppearanceMode.AMOLED) Color.Black else Color(0xFF101114), Color(0xFF1D2025), Color(0xFF292D33), Color(0xFFF4F6F8), Color(0xFFA2AAB4), Color(0xFF303740), Color(0xFF414B56), Color(0xFF16A5E8), Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xF91B1F24), Color(0xFF8CB9D8)) else Pal(false, false, Color(0xFFF3F6F8), Color.White, Color(0xFFE4EAEE), Color(0xFF17212A), Color(0xFF71808B), Color(0xFFDCE3E8), Color(0xFFC9D4DC), Color(0xFF087FB8), Color(0xFF269A69), Color(0xFFD99C35), Color(0xFFD95762), Color(0xF9FFFFFF), Color(0xFF6CA7CC))
    }
    if (imported == null) return base
    val c = imported.colorsFor(appearance)
    fun col(v: Long?, d: Color) = v?.let(::Color) ?: d
    val card = col(c.card, base.tile)
    val accent = col(c.accent, base.accent)
    return Pal(base.dark, base.amoled, col(c.bg, base.bg), card, col(c.thumb, base.thumb),
        col(c.text, base.text), col(c.sub, base.sub), col(c.line, base.line), col(c.track, base.track), accent,
        col(c.green, base.green), col(c.amber, base.amber), col(c.red, base.red),
        col(c.sheet, if (c.card != null) card else base.sheet), col(c.accent2, if (c.accent != null) accent else base.accent2))
}

@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) = if (mode == ThemeMode.NOTHING)
    TypeSpec(FontFamily.Monospace, 0.86f, -0.15f) else TypeSpec(FontFamily.SansSerif, 1f, 0f)

/** Theme-owned presentation tokens for the five built-in identities. */
private fun builtInThemeSpec(mode: Int): ThemeSpec = when (mode) {
    ThemeMode.AURORA -> ThemeSpec(name = "Aurora Glass", source = "builtin-aurora",
        shapes = ShapeSpec(panel = 28f, card = 24f, tile = 22f, button = 18f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1.1f, borderAlpha = 0.72f, fillAlpha = 0.92f, glow = true),
        motion = MotionSpec(speed = 1.08f, enter = true, bounce = true, glowPulse = true, tabTransition = "slide"),
        background = BackgroundSpec(blobs = true, imageAlpha = 0.88f))
    ThemeMode.CRYSTAL -> ThemeSpec(name = "Crystal Light", source = "builtin-crystal",
        shapes = ShapeSpec(panel = 30f, card = 26f, tile = 24f, button = 20f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1.2f, borderAlpha = 0.86f, fillAlpha = 0.96f, glow = false),
        motion = MotionSpec(speed = 0.92f, enter = true, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, imageAlpha = 0.94f))
    ThemeMode.NOTHING -> ThemeSpec(name = "Nothing Matrix", source = "builtin-nothing",
        shapes = ShapeSpec(panel = 14f, card = 12f, tile = 10f, button = 10f, pill = 8f),
        card = CardSpec(style = CardStyle.OUTLINE, borderWidth = 1f, borderAlpha = 0.62f, fillAlpha = 1f, glow = false),
        font = FontSpec(family = "mono", scale = 0.90f, tracking = -0.12f),
        motion = MotionSpec(speed = 0.82f, enter = false, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, dotMatrix = true, imageAlpha = 0.9f))
    ThemeMode.TITANIUM -> ThemeSpec(name = "Titanium Luxury", source = "builtin-titanium",
        shapes = ShapeSpec(panel = 24f, card = 20f, tile = 18f, button = 15f, pill = 50f),
        card = CardSpec(style = CardStyle.GRADIENT, borderWidth = 1f, borderAlpha = 0.68f, fillAlpha = 0.96f, glow = false,
            gradientFrom = 0xFF3A3B3F, gradientTo = 0xFF202226),
        motion = MotionSpec(speed = 0.88f, enter = true, bounce = false, glowPulse = false, tabTransition = "fade"),
        background = BackgroundSpec(blobs = false, imageAlpha = 0.9f))
    ThemeMode.ONEPLUS -> ThemeSpec(name = "OnePlus Aurora", source = "builtin-oneplus",
        shapes = ShapeSpec(panel = 22f, card = 18f, tile = 18f, button = 14f, pill = 50f),
        card = CardSpec(style = CardStyle.GRADIENT, borderWidth = 0.8f, borderAlpha = 0.48f, fillAlpha = 0.98f, glow = true,
            gradientFrom = 0xFF14283D, gradientTo = 0xFF0D1724),
        motion = MotionSpec(speed = 1.16f, enter = true, bounce = true, glowPulse = true, tabTransition = "slide"),
        background = BackgroundSpec(blobs = true, imageAlpha = 0.9f))
    else -> ThemeSpec.STOCK.copy(name = "Stock Budsy", source = "builtin-stock",
        shapes = ShapeSpec(panel = 22f, card = 18f, tile = 18f, button = 16f, pill = 50f),
        card = CardSpec(style = CardStyle.SOLID, borderWidth = 0.8f, borderAlpha = 0.5f, fillAlpha = 1f, glow = false),
        motion = MotionSpec(speed = 1f, enter = true, bounce = true, glowPulse = false, tabTransition = "fade"))
}

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.AURORA) }
val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.AURORA, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

/** The active theme spec (Stock when nothing imported is applied) and the id/folder it was loaded from. */
val LocalThemeSpec = staticCompositionLocalOf { ThemeSpec.STOCK }
val LocalThemeId = staticCompositionLocalOf<String?> { null }
/** True when an imported theme is applied (lets Components pick themed or stock chrome). */
val LocalThemed = staticCompositionLocalOf { false }

/** Loads the theme font, falling back to the generic family if the file is missing or not a valid font. */
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun loadFamily(ctx: android.content.Context, themeId: String?, spec: ThemeSpec?): FontFamily {
    val generic = when (spec?.font?.family) { "serif" -> FontFamily.Serif; "mono" -> FontFamily.Monospace; "cursive" -> FontFamily.Cursive; else -> FontFamily.SansSerif }
    if (spec == null || themeId == null) return generic
    val dir = ThemeStore.themeDir(ctx, themeId) ?: return generic
    val regular = spec.font.file?.let { ThemeStore.resolve(dir, it) } ?: return generic
    return try {
        android.graphics.Typeface.createFromFile(regular)        // throws on corrupt font files
        val bold = spec.font.boldFile?.let { ThemeStore.resolve(dir, it) }?.takeIf { f -> runCatching { android.graphics.Typeface.createFromFile(f) }.isSuccess }
        FontFamily(
            androidx.compose.ui.text.font.Font(regular, FontWeight.Normal),
            androidx.compose.ui.text.font.Font(regular, FontWeight.Medium),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.SemiBold),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.Bold)
        )
    } catch (_: Throwable) { generic }
}

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null, themeId: String? = null, content: @Composable () -> Unit) {
    // Keep the selected built-in identity flowing through composition; imported packages
    // still supply their own ThemeSpec and override the built-in palette where defined.
    val safeMode = mode.coerceIn(ThemeMode.AURORA, ThemeMode.ONEPLUS)
    val spec = imported ?: builtInThemeSpec(safeMode)
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = remember(safeMode, appearance, imported) { makePal(safeMode, appearance, imported) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val family = remember(themeId, imported) { loadFamily(ctx, themeId, imported) }
    val themedTypography = remember(family) {
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = family), displayMedium = t.displayMedium.copy(fontFamily = family),
            displaySmall = t.displaySmall.copy(fontFamily = family), headlineLarge = t.headlineLarge.copy(fontFamily = family),
            headlineMedium = t.headlineMedium.copy(fontFamily = family), headlineSmall = t.headlineSmall.copy(fontFamily = family),
            titleLarge = t.titleLarge.copy(fontFamily = family), titleMedium = t.titleMedium.copy(fontFamily = family),
            titleSmall = t.titleSmall.copy(fontFamily = family), bodyLarge = t.bodyLarge.copy(fontFamily = family),
            bodyMedium = t.bodyMedium.copy(fontFamily = family), bodySmall = t.bodySmall.copy(fontFamily = family),
            labelLarge = t.labelLarge.copy(fontFamily = family), labelMedium = t.labelMedium.copy(fontFamily = family),
            labelSmall = t.labelSmall.copy(fontFamily = family)
        )
    }
    val typeSpec = remember(family, imported, safeMode) {
        val base = typeSpecFor(safeMode)
        if (imported != null) TypeSpec(family, spec.font.scale, spec.font.tracking) else base
    }
    val systemReduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(
        LocalPal provides p,
        LocalTypeSpec provides typeSpec,
        LocalReduceMotion provides (systemReduce || !spec.motion.enabled),
        LocalThemeMode provides safeMode,
        LocalThemeSpec provides spec,
        LocalThemeId provides themeId,
        LocalThemed provides (imported != null || safeMode != ThemeMode.STOCK)
    ) {
        MaterialTheme(colorScheme = cs, typography = themedTypography, content = content)
    }
}
