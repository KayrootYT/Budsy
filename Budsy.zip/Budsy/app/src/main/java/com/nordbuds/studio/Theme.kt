package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/** One permanent Stock Budsy identity; appearance switches Light, Dark and AMOLED. */
object ThemeMode {
    /** The only built-in theme. Imported themes will be managed separately. */
    const val AURORA = 0 // legacy IDs retained only for source compatibility
    const val CRYSTAL = 1
    const val NOTHING = 2
    const val TITANIUM = 3
    const val STOCK = 4
}

object AppearanceMode {
    const val SYSTEM = -1
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

@Immutable
class Pal(
    val dark: Boolean, val amoled: Boolean, val bg: Color, val tile: Color, val thumb: Color,
    val text: Color, val sub: Color, val line: Color, val track: Color, val accent: Color,
    val green: Color, val amber: Color, val red: Color, val sheet: Color, val accent2: Color
) {
    val onAccent: Color get() = if (accent.luminance() > 0.40f) Color(0xFF101010) else Color.White
}

private fun stockPal(appearance: Int): Pal = when (appearance) {
    AppearanceMode.LIGHT, AppearanceMode.SYSTEM -> Pal(false, false,
        Color(0xFFF5F5F7), Color.White, Color(0xFFE9E9ED), Color(0xFF17171A),
        Color(0xFF5B6B86), Color(0x331B3A7A), Color(0x33557099), Color(0xFF2F7BFF),
        Color(0xFF28A66A), Color(0xFFE0A12D), Color(0xFFE05252), Color(0xF2F4F8FF), Color(0xFF63A8FF))
    AppearanceMode.AMOLED -> Pal(true, true, Color.Black, Color(0xFF101012), Color(0xFF1B1B1F),
        Color(0xFFF5F5F7), Color(0xFFB4B0C8), Color(0x38FFFFFF), Color(0x33FFFFFF), Color(0xFF8B5CF6),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xF2100820), Color(0xFFB794FF))
    else -> Pal(true, false, Color(0xFF17181B), Color(0xFF222328), Color(0xFF2C2D33),
        Color(0xFFF5F5F7), Color(0xFFA9BAD6), Color(0x38FFFFFF), Color(0x33FFFFFF), Color(0xFF1EA7FF),
        Color(0xFF35C987), Color(0xFFE7B34F), Color(0xFFFF6B6B), Color(0xF2081A38), Color(0xFF5DC8FF))
}

fun makePal(style: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null): Pal {
    val base = stockPal(appearance)
    if (imported == null) return base
    val c = imported.colorsFor(appearance)
    fun col(v: Long?, d: Color) = v?.let(::Color) ?: d
    val card = col(c.card, base.tile)
    val accent = col(c.accent, base.accent)
    return Pal(base.dark, base.amoled, col(c.bg, base.bg), card, col(c.thumb, base.thumb),
        col(c.text, base.text), col(c.sub, base.sub), col(c.line, base.line), col(c.track, base.track), accent,
        col(c.green, base.green), col(c.amber, base.amber), col(c.red, base.red),
        col(c.sheet, if (c.card != null) card else base.sheet), col(c.accent2, if (c.accent != null) accent else base.accent2))
}

@Immutable
class TypeSpec(val family: FontFamily, val scale: Float, val tracking: Float) {
    fun size(sp: Float): Float = if (scale == 1f) sp else maxOf(sp * scale, minOf(sp, 10f))
}

fun typeSpecFor(mode: Int) = if (mode == ThemeMode.NOTHING)
    TypeSpec(FontFamily.Monospace, 0.86f, -0.15f) else TypeSpec(FontFamily.SansSerif, 1f, 0f)

val LocalTypeSpec = staticCompositionLocalOf { typeSpecFor(ThemeMode.AURORA) }
val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.AURORA, AppearanceMode.DARK) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

/** The active theme spec (Stock when nothing imported is applied) and the id/folder it was loaded from. */
val LocalThemeSpec = staticCompositionLocalOf { ThemeSpec.STOCK }
val LocalThemeId = staticCompositionLocalOf<String?> { null }
/** True when an imported theme is applied (lets Components pick themed or stock chrome). */
val LocalThemed = staticCompositionLocalOf { false }

/** Loads the theme font, falling back to the generic family if the file is missing or not a valid font. */
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun loadFamily(ctx: android.content.Context, themeId: String?, spec: ThemeSpec?): FontFamily {
    val generic = when (spec?.font?.family) { "serif" -> FontFamily.Serif; "mono" -> FontFamily.Monospace; "cursive" -> FontFamily.Cursive; else -> InterFont.get(ctx) ?: FontFamily.SansSerif }
    if (spec == null || themeId == null) return generic
    val dir = ThemeStore.themeDir(ctx, themeId) ?: return generic
    val regular = spec.font.file?.let { ThemeStore.resolve(dir, it) } ?: return generic
    return try {
        android.graphics.Typeface.createFromFile(regular)        // throws on corrupt font files
        val bold = spec.font.boldFile?.let { ThemeStore.resolve(dir, it) }?.takeIf { f -> runCatching { android.graphics.Typeface.createFromFile(f) }.isSuccess }
        FontFamily(
            androidx.compose.ui.text.font.Font(regular, FontWeight.Normal),
            androidx.compose.ui.text.font.Font(regular, FontWeight.Medium),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.SemiBold),
            androidx.compose.ui.text.font.Font(bold ?: regular, FontWeight.Bold)
        )
    } catch (_: Throwable) { generic }
}

@Composable
fun BudsyTheme(mode: Int, appearance: Int = AppearanceMode.DARK, imported: ThemeSpec? = null, themeId: String? = null, content: @Composable () -> Unit) {
    val safeMode = ThemeMode.STOCK
    val spec = imported ?: ThemeSpec.STOCK
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = remember(safeMode, appearance, imported) { makePal(safeMode, appearance, imported) }
    val cs = remember(p) {
        if (p.dark) darkColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
        else lightColorScheme(primary = p.accent, onPrimary = p.onAccent, background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
            onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet, inverseSurface = p.text, inverseOnSurface = p.bg, outline = p.line)
    }
    val family = remember(themeId, imported) { loadFamily(ctx, themeId, imported) }
    val themedTypography = remember(family) {
        val t = Typography()
        Typography(
            displayLarge = t.displayLarge.copy(fontFamily = family), displayMedium = t.displayMedium.copy(fontFamily = family),
            displaySmall = t.displaySmall.copy(fontFamily = family), headlineLarge = t.headlineLarge.copy(fontFamily = family),
            headlineMedium = t.headlineMedium.copy(fontFamily = family), headlineSmall = t.headlineSmall.copy(fontFamily = family),
            titleLarge = t.titleLarge.copy(fontFamily = family), titleMedium = t.titleMedium.copy(fontFamily = family),
            titleSmall = t.titleSmall.copy(fontFamily = family), bodyLarge = t.bodyLarge.copy(fontFamily = family),
            bodyMedium = t.bodyMedium.copy(fontFamily = family), bodySmall = t.bodySmall.copy(fontFamily = family),
            labelLarge = t.labelLarge.copy(fontFamily = family), labelMedium = t.labelMedium.copy(fontFamily = family),
            labelSmall = t.labelSmall.copy(fontFamily = family)
        )
    }
    val typeSpec = remember(family, imported) { TypeSpec(family, spec.font.scale, spec.font.tracking) }
    val systemReduce = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
    CompositionLocalProvider(
        LocalPal provides p,
        LocalTypeSpec provides typeSpec,
        LocalReduceMotion provides (systemReduce || !spec.motion.enabled),
        LocalThemeMode provides safeMode,
        LocalThemeSpec provides spec,
        LocalThemeId provides themeId,
        LocalThemed provides (imported != null)
    ) {
        MaterialTheme(colorScheme = cs, typography = themedTypography, content = content)
    }
}
