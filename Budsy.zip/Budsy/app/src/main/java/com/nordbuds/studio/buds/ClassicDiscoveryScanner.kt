package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/** Classic BR/EDR inquiry scanner, kept separate from BLE advertisements. */
@SuppressLint("MissingPermission")
class ClassicDiscoveryScanner(
    context: Context,
    private val onDevice: (BluetoothDevice) -> Unit,
    private val onState: (Boolean, String?) -> Unit
) {
    private val app = context.applicationContext
    private val adapter: BluetoothAdapter? = app.getSystemService(BluetoothManager::class.java)?.adapter
    private val main = Handler(Looper.getMainLooper())
    private var registered = false
    private var running = false

    private val finishTask = Runnable { stopScan() }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= 33)
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    if (device != null) onDevice(device)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    running = false
                    main.removeCallbacks(finishTask)
                    onState(false, null)
                }
            }
        }
    }

    fun startScan(durationMs: Long = 12_000L): Boolean {
        stopScan()
        val a = adapter
        if (a == null || !a.isEnabled) {
            onState(false, "Bluetooth is unavailable or disabled")
            return false
        }
        return try {
            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }
            ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
            registered = true
            if (!a.startDiscovery()) {
                unregister()
                onState(false, "Classic Bluetooth discovery could not start")
                false
            } else {
                running = true
                onState(true, null)
                main.postDelayed(finishTask, durationMs.coerceIn(3_000L, 20_000L))
                true
            }
        } catch (e: SecurityException) {
            unregister()
            onState(false, "Bluetooth scan permission denied")
            false
        } catch (e: Exception) {
            unregister()
            onState(false, e.message ?: "Unable to start Bluetooth discovery")
            false
        }
    }

    fun stopScan() {
        main.removeCallbacks(finishTask)
        if (running) try { adapter?.cancelDiscovery() } catch (_: Exception) { }
        running = false
        unregister()
        onState(false, null)
    }

    private fun unregister() {
        if (registered) {
            try { app.unregisterReceiver(receiver) } catch (_: Exception) { }
            registered = false
        }
    }
}
