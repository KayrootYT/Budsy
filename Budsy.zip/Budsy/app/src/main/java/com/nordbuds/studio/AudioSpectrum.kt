package com.nordbuds.studio

import android.media.audiofx.Visualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.hypot
import kotlin.math.pow

/**
 * Live spectrum of whatever the phone is playing (music, video, calls on the output mix), reduced to six bands that
 * line up with the EQ sliders (62 Hz, 250 Hz, 1 kHz, 4 kHz, 8 kHz, 16 kHz). Uses android.media.audiofx.Visualizer, which
 * only sees the FFT of the *output* (not the microphone), but Android still asks for the RECORD_AUDIO permission.
 */
object AudioSpectrum {
    const val BANDS = 6
    private val EDGES = floatArrayOf(40f, 120f, 500f, 2000f, 6000f, 11000f, 20000f)
    private val WEIGHT = floatArrayOf(0.9f, 1.0f, 1.2f, 1.7f, 2.4f, 3.2f)

    var levels by mutableStateOf(FloatArray(BANDS)); private set
    var running by mutableStateOf(false); private set
    var failed by mutableStateOf(false); private set

    private var viz: Visualizer? = null
    private var agc = 24f
    private val smooth = FloatArray(BANDS)

    private val listener = object : Visualizer.OnDataCaptureListener {
        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
            if (fft == null || fft.size < 8) return
            val bins = fft.size / 2
            val hzPerBin = (samplingRate / 1000f) / fft.size
            if (hzPerBin <= 0f) return
            val mags = FloatArray(BANDS)
            for (b in 0 until BANDS) {
                val lo = (EDGES[b] / hzPerBin).toInt().coerceAtLeast(1)
                val hi = (EDGES[b + 1] / hzPerBin).toInt().coerceAtMost(bins - 1)
                var m = 0f
                var k = lo
                while (k <= hi) {
                    val mm = hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat())
                    if (mm > m) m = mm
                    k++
                }
                mags[b] = m * WEIGHT[b]
            }
            val peak = mags.maxOrNull() ?: 0f
            agc = maxOf(agc * 0.992f, peak, 1f)
            val out = FloatArray(BANDS)
            for (b in 0 until BANDS) {
                val x = if (peak < 6f) 0f else (mags[b] / maxOf(agc, 24f)).coerceIn(0f, 1f).pow(0.75f)
                smooth[b] = if (x > smooth[b]) x * 0.7f + smooth[b] * 0.3f else smooth[b] * 0.8f + x * 0.2f
                out[b] = smooth[b]
            }
            levels = out
        }
    }

    @Synchronized
    fun start(): Boolean {
        if (viz != null) return true
        failed = false
        return try {
            val v = Visualizer(0)
            v.setEnabled(false)
            val range = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(1024.coerceIn(range[0], range[1]))
            v.setDataCaptureListener(listener, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            viz = v; running = true
            true
        } catch (_: Throwable) { stop(); failed = true; false }
    }

    @Synchronized
    fun stop() {
        try { viz?.setEnabled(false); viz?.release() } catch (_: Throwable) { }
        viz = null; running = false
        smooth.fill(0f); levels = FloatArray(BANDS)
    }
}
