package com.nordbuds.studio

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * "Ocean Reef" — a built-in Budsy theme (Stock Budsy is untouched).
 *
 *  - Real animated water: a rippling surface line, drifting swell bands and swaying light rays.
 *  - Fish of many colours, jellyfish, a turtle, seahorses and coral on the sea floor.
 *  - Cards / tiles are 3D realistic glass (thickness edge, specular rim, gloss) over the water.
 *  - Touching a card sends expanding water ripples from the finger.
 *
 * Everything is drawn with vector paths (no image assets) and honours the system "reduce motion" setting.
 */
object OceanTheme {
    const val ID = "theme_budsy_ocean"

    val SPEC = ThemeSpec(
        name = "Ocean Reef", author = "Budsy", version = "1.0", source = "builtin",
        description = "Living ocean: waves, fish, jellyfish, turtle, seahorses, coral, 3D glass cards and touch ripples.",
        light = ColorSet(
            bg = 0xFF8FE6F2, card = 0xFFFFFFFF, thumb = 0xFFD7F3FA, text = 0xFF05304D, sub = 0xFF1E6A8A,
            line = 0xFF7CC8E0, track = 0xFFB5E6F2, accent = 0xFF0091C8, accent2 = 0xFF00C2B8,
            green = 0xFF1FB36B, amber = 0xFFE69A00, red = 0xFFE5484D, sheet = 0xFFDDF5FB
        ),
        dark = ColorSet(
            bg = 0xFF04223F, card = 0xFF0E4A73, thumb = 0xFF1B6C96, text = 0xFFEAF9FF, sub = 0xFF9CC9E0,
            line = 0xFF5FB8D9, track = 0xFF1A4E73, accent = 0xFF2EE6D6, accent2 = 0xFF3AA0FF,
            green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF0A3558
        ),
        amoled = ColorSet(
            bg = 0xFF000000, card = 0xFF062B45, thumb = 0xFF0B4468, text = 0xFFEAF9FF, sub = 0xFF8FBFD8,
            line = 0xFF3F9CC0, track = 0xFF0F3A57, accent = 0xFF18E0D0, accent2 = 0xFF2E8FFF,
            green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF03121F
        ),
        shapes = ShapeSpec(panel = 28f, card = 22f, tile = 24f, button = 18f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1f, borderAlpha = 0.55f, fillAlpha = 1f, glow = true),
        ocean = true,
        features = setOf("colors", "shapes", "cards", "animation", "background")
    )
}

@Composable
fun isOcean(): Boolean = LocalThemeSpec.current.ocean

// ====================================================================================== background

/** Full-screen living ocean. A single frame clock drives every creature; static when "reduce motion" is on. */
@Composable
fun OceanBackground(modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val mode = if (P.amoled) 2 else if (P.dark) 1 else 0
    var t by remember { mutableFloatStateOf(if (reduce) 9f else 0f) }
    if (!reduce) LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) t = (t + (n - last) / 1_000_000_000f) % 7200f
                last = n
            }
        }
    }
    Canvas(modifier.fillMaxSize()) { drawOcean(t, mode) }
}

private class FishSpec(
    val y: Float, val len: Float, val spd: Float, val off: Float, val dir: Int,
    val c1: Color, val c2: Color, val stripe: Boolean, val alpha: Float
)

private val FISH: List<FishSpec> = listOf(
    FishSpec(0.22f, 46f, 0.030f, 0.10f, 1, Color(0xFFFF8A2B), Color(0xFFFF5A1F), true, 1f),
    FishSpec(0.34f, 38f, 0.042f, 0.55f, -1, Color(0xFF2D7BFF), Color(0xFF1CD0FF), false, 1f),
    FishSpec(0.46f, 52f, 0.024f, 0.80f, 1, Color(0xFFFFE14D), Color(0xFFFFA800), true, 1f),
    FishSpec(0.58f, 34f, 0.050f, 0.30f, -1, Color(0xFFFF7EB6), Color(0xFFFF4F9A), false, 1f),
    FishSpec(0.68f, 44f, 0.034f, 0.65f, 1, Color(0xFF4DF0A0), Color(0xFF1FBF7A), false, 1f),
    FishSpec(0.28f, 26f, 0.060f, 0.90f, -1, Color(0xFFB388FF), Color(0xFF7C4DFF), true, 0.85f),
    FishSpec(0.76f, 30f, 0.045f, 0.45f, 1, Color(0xFFFF5252), Color(0xFFD32F2F), false, 0.9f),
    FishSpec(0.52f, 22f, 0.070f, 0.15f, -1, Color(0xFF7DF9FF), Color(0xFF18C8E0), false, 0.75f)
) + List(6) { k ->   // a tight school of small silver-blue fish
    FishSpec(0.40f + (k % 3) * 0.022f, 15f, 0.038f, 0.50f - k * 0.016f, 1, Color(0xFFD6F4FF), Color(0xFF6CC3F0), false, 0.9f)
}

private class JellySpec(val x: Float, val y: Float, val r: Float, val color: Color, val ph: Float)

private val JELLIES = listOf(
    JellySpec(0.18f, 0.30f, 30f, Color(0xFFFF8FD6), 0.0f),
    JellySpec(0.80f, 0.42f, 24f, Color(0xFF7DF9FF), 2.1f),
    JellySpec(0.55f, 0.64f, 34f, Color(0xFFB08CFF), 4.2f)
)

private class SeahorseSpec(val x: Float, val y: Float, val size: Float, val color: Color, val ph: Float)

private val SEAHORSES = listOf(
    SeahorseSpec(0.10f, 0.74f, 70f, Color(0xFFFFB347), 0.5f),
    SeahorseSpec(0.88f, 0.70f, 58f, Color(0xFFFF7EB6), 2.5f)
)

private class CoralSpec(val x: Float, val kind: Int, val size: Float, val color: Color, val ph: Float)

private val CORALS = listOf(
    CoralSpec(0.05f, 0, 64f, Color(0xFFFF6F91), 0.2f),
    CoralSpec(0.19f, 2, 40f, Color(0xFFFFB84D), 1.0f),
    CoralSpec(0.30f, 3, 74f, Color(0xFF2BD48A), 2.0f),
    CoralSpec(0.43f, 1, 60f, Color(0xFFB07CFF), 3.0f),
    CoralSpec(0.57f, 0, 82f, Color(0xFFFF9A3C), 4.0f),
    CoralSpec(0.69f, 3, 58f, Color(0xFF39E6C2), 5.0f),
    CoralSpec(0.79f, 2, 48f, Color(0xFFFF7EB6), 6.0f),
    CoralSpec(0.90f, 1, 68f, Color(0xFFFF6F91), 7.0f),
    CoralSpec(0.97f, 0, 56f, Color(0xFFFFD166), 8.0f)
)

private fun surfaceWave(x: Float, w: Float, base: Float, t: Float, u: Float): Float =
    base + sin(x / w * 12.566f + t * 1.1f) * 5f * u + sin(x / w * 31.4f - t * 1.7f) * 2.2f * u

private fun DrawScope.drawOcean(t: Float, mode: Int) {
    val w = size.width; val h = size.height
    if (w <= 0f || h <= 0f) return
    val u = w / 400f
    val sY = h * 0.085f          // water surface
    val floorY = h * 0.905f      // sea floor
    val light = mode == 0

    val top = when (mode) { 0 -> Color(0xFF8FE6F2); 1 -> Color(0xFF1C86B0); else -> Color(0xFF0B4F73) }
    val mid = when (mode) { 0 -> Color(0xFF3DB8DA); 1 -> Color(0xFF0A4B7A); else -> Color(0xFF041F37) }
    val deep = when (mode) { 0 -> Color(0xFF137BAE); 1 -> Color(0xFF031D36); else -> Color(0xFF00060C) }

    // 1. water body
    drawRect(Brush.verticalGradient(listOf(top, mid, deep), startY = sY, endY = h))

    // 2. swaying god-rays from the surface
    val rayBottom = h * 0.80f
    for (i in 0..4) {
        val x0 = w * (0.08f + 0.21f * i) + sin(t * 0.25f + i * 1.7f) * 22f * u
        val a = (if (light) 0.16f else 0.12f) + 0.05f * sin(t * 0.8f + i)
        val xb = x0 - 110f * u + sin(t * 0.3f + i) * 14f * u
        val ray = Path().apply {
            moveTo(x0, sY); lineTo(x0 + 22f * u, sY); lineTo(xb + 84f * u, rayBottom); lineTo(xb, rayBottom); close()
        }
        drawPath(ray, Brush.verticalGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), startY = sY, endY = rayBottom))
    }

    // 3. slow swell bands rolling through the water
    for (k in 0..3) {
        val yb = sY + (h - sY) * (0.18f + 0.20f * k)
        val p = Path()
        var x = -10f
        p.moveTo(x, yb)
        while (x <= w + 10f) {
            p.lineTo(x, yb + sin(x / w * 8.2f + t * (0.5f + 0.12f * k) + k * 2f) * 11f * u)
            x += w / 24f
        }
        drawPath(p, Color.White.copy(alpha = if (light) 0.07f else 0.04f), style = Stroke(26f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }

    // 4. creatures, far to near
    for (j in JELLIES) {
        val cx = j.x * w + sin(t * 0.35f + j.ph) * 28f * u
        val cy = j.y * h + sin(t * 0.55f + j.ph * 1.3f) * 30f * u
        drawJelly(cx, cy, j.r * u, j.color, t, j.ph, u)
    }

    // turtle: slow glide across, gentle bob
    run {
        val L = 96f * u
        val cyc = (t * 0.011f + 0.25f) % 1f
        val tx = -L + cyc * (w + 2f * L)
        val ty = h * 0.50f + sin(t * 0.6f) * 14f * u
        drawTurtle(tx, ty, L, t, u)
    }

    for (f in FISH) {
        val L = f.len * u
        val cyc = (t * f.spd + f.off) % 1f
        val xr = -L + cyc * (w + 2f * L)
        val fx = if (f.dir > 0) xr else w - xr
        val fy = f.y * h + sin(t * 1.4f + f.off * 20f) * 7f * u
        drawFish(fx, fy, L, f.dir, f.c1, f.c2, f.stripe, sin(t * 7f + f.off * 10f) * 0.18f * L * 0.5f, f.alpha)
    }

    for (s in SEAHORSES) {
        drawSeahorse(s.x * w + sin(t * 0.5f + s.ph) * 8f * u, s.y * h + sin(t * 0.8f + s.ph) * 10f * u, s.size * u, s.color, t, s.ph)
    }

    // 5. sea floor + coral + weed
    val sand = Path().apply {
        moveTo(0f, h); lineTo(0f, floorY)
        var x = 0f
        while (x <= w + 8f) { lineTo(x, floorY + sin(x / w * 9f) * 5f * u + 4f * u); x += w / 30f }
        lineTo(w, h); close()
    }
    val sandA = when (mode) { 0 -> Color(0xFFF1DBA6); 1 -> Color(0xFF3F6075); else -> Color(0xFF14303F) }
    val sandB = when (mode) { 0 -> Color(0xFFD2B075); 1 -> Color(0xFF1B3346); else -> Color(0xFF050E15) }
    drawPath(sand, Brush.verticalGradient(listOf(sandA, sandB), startY = floorY, endY = h))
    for (c in CORALS) drawCoral(c, w * c.x, floorY + 5f * u, t, u)

    // 6. bubbles
    for (i in 0 until 18) {
        val prog = (t * (0.03f + 0.012f * (i % 4)) + i * 0.173f) % 1f
        val bx = w * ((i * 0.618034f) % 1f) + sin(t * 0.8f + i) * 6f * u
        val by = floorY - prog * (floorY - sY)
        val r = (2f + (i % 4) * 1.6f) * u
        val al = (1f - prog).coerceIn(0f, 1f) * 0.9f + 0.1f
        drawCircle(Color.White.copy(alpha = 0.10f * al), r, Offset(bx, by))
        drawCircle(Color.White.copy(alpha = 0.55f * al), r, Offset(bx, by), style = Stroke(1f * u))
        drawCircle(Color.White.copy(alpha = 0.85f * al), r * 0.25f, Offset(bx - r * 0.35f, by - r * 0.35f))
    }

    // 7. surface: sky above, bright foam line, ripples on top
    val skyTop = when (mode) { 0 -> Color(0xFFBFEFFF); 1 -> Color(0xFF071B33); else -> Color(0xFF000000) }
    val skyBottom = when (mode) { 0 -> Color(0xFFF2FDFF); 1 -> Color(0xFF164C73); else -> Color(0xFF06263D) }
    val step = w / 40f
    val sky = Path().apply {
        moveTo(0f, 0f); lineTo(w, 0f)
        var x = w
        while (x >= 0f) { lineTo(x, surfaceWave(x, w, sY, t, u)); x -= step }
        close()
    }
    drawPath(sky, Brush.verticalGradient(listOf(skyTop, skyBottom), startY = 0f, endY = sY + 8f * u))
    val foam = Path().apply {
        var x = 0f
        moveTo(0f, surfaceWave(0f, w, sY, t, u))
        while (x <= w) { x += step; lineTo(x, surfaceWave(x, w, sY, t, u)) }
        x = w
        while (x >= 0f) { lineTo(x, surfaceWave(x, w, sY, t + 1.5f, u) + 20f * u); x -= step }
        close()
    }
    drawPath(foam, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.38f), Color.Transparent), startY = sY - 6f * u, endY = sY + 30f * u))
    val line = Path().apply {
        moveTo(0f, surfaceWave(0f, w, sY, t, u))
        var x = 0f
        while (x <= w) { x += step; lineTo(x, surfaceWave(x, w, sY, t, u)) }
    }
    drawPath(line, Color.White.copy(alpha = 0.80f), style = Stroke(2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

// ------------------------------------------------------------------------------------------ fish

private fun DrawScope.drawFish(x: Float, y: Float, L: Float, dir: Int, c1: Color, c2: Color, stripe: Boolean, wig: Float, a: Float) {
    val H = L * 0.5f
    withTransform({ translate(x, y); scale(dir.toFloat(), 1f, Offset.Zero) }) {
        val tail = Path().apply {
            moveTo(-L * 0.30f, 0f); lineTo(-L * 0.64f, -H * 0.52f + wig)
            quadTo(-L * 0.52f, wig * 0.5f, -L * 0.64f, H * 0.52f + wig); close()
        }
        drawPath(tail, c2.copy(alpha = a * 0.95f))
        val dorsal = Path().apply { moveTo(L * 0.14f, -H * 0.46f); lineTo(-L * 0.06f, -H * 0.88f); lineTo(-L * 0.26f, -H * 0.40f); close() }
        drawPath(dorsal, c2.copy(alpha = a * 0.9f))
        val body = Path().apply {
            moveTo(L * 0.5f, 0f)
            cubicTo(L * 0.25f, -H * 0.62f, -L * 0.2f, -H * 0.55f, -L * 0.38f, -H * 0.08f)
            lineTo(-L * 0.38f, H * 0.08f)
            cubicTo(-L * 0.2f, H * 0.55f, L * 0.25f, H * 0.62f, L * 0.5f, 0f); close()
        }
        drawPath(body, Brush.verticalGradient(listOf(c1.copy(alpha = a), c2.copy(alpha = a)), startY = -H * 0.6f, endY = H * 0.6f))
        if (stripe) {
            val band = Path().apply {
                moveTo(L * 0.14f, -H * 0.48f); quadTo(L * 0.20f, 0f, L * 0.14f, H * 0.48f)
                lineTo(L * 0.04f, H * 0.50f); quadTo(L * 0.10f, 0f, L * 0.04f, -H * 0.50f); close()
            }
            drawPath(band, Color.White.copy(alpha = a * 0.78f))
        }
        drawOval(Color.White.copy(alpha = a * 0.22f), Offset(-L * 0.20f, -H * 0.42f), Size(L * 0.55f, H * 0.26f))
        drawCircle(Color.White.copy(alpha = a), L * 0.055f, Offset(L * 0.30f, -H * 0.10f))
        drawCircle(Color.Black.copy(alpha = a), L * 0.028f, Offset(L * 0.315f, -H * 0.10f))
    }
}

// ------------------------------------------------------------------------------------------ jellyfish

private fun DrawScope.drawJelly(cx: Float, cy: Float, r: Float, c: Color, t: Float, ph: Float, u: Float) {
    val pulse = sin(t * 2.2f + ph)
    val rw = r * (1f + 0.07f * pulse)
    val rh = r * (0.95f - 0.10f * pulse)
    val cyy = cy - pulse * r * 0.10f
    // soft halo
    drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.30f), Color.Transparent), center = Offset(cx, cyy - rh * 0.3f), radius = rw * 2.1f),
        rw * 2.1f, Offset(cx, cyy - rh * 0.3f))
    // trailing tentacles
    for (i in 0 until 7) {
        val ox = (i - 3) * rw * 0.28f
        val p = Path().apply {
            moveTo(cx + ox, cyy)
            for (j in 1..8) lineTo(cx + ox + sin(t * 2f + ph + i + j * 0.7f) * rw * 0.12f * j / 4f, cyy + j * rh * 0.55f)
        }
        drawPath(p, c.copy(alpha = 0.42f), style = Stroke(1.6f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    // thicker oral arms
    for (i in 0 until 3) {
        val ox = (i - 1) * rw * 0.30f
        val p = Path().apply {
            moveTo(cx + ox, cyy)
            for (j in 1..5) lineTo(cx + ox + sin(t * 1.6f + ph + i * 2f + j * 0.9f) * rw * 0.10f, cyy + j * rh * 0.42f)
        }
        drawPath(p, c.copy(alpha = 0.32f), style = Stroke(3.4f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    // bell
    val bell = Path().apply {
        moveTo(cx - rw, cyy)
        cubicTo(cx - rw, cyy - rh * 1.45f, cx + rw, cyy - rh * 1.45f, cx + rw, cyy)
        quadTo(cx + rw * 0.66f, cyy + rh * 0.20f, cx + rw * 0.33f, cyy)
        quadTo(cx, cyy + rh * 0.20f, cx - rw * 0.33f, cyy)
        quadTo(cx - rw * 0.66f, cyy + rh * 0.20f, cx - rw, cyy)
        close()
    }
    drawPath(bell, Brush.verticalGradient(listOf(c.copy(alpha = 0.78f), c.copy(alpha = 0.22f)), startY = cyy - rh * 1.1f, endY = cyy + rh * 0.2f))
    drawPath(bell, c.copy(alpha = 0.90f), style = Stroke(1.4f * u))
    drawOval(Color.White.copy(alpha = 0.28f), Offset(cx - rw * 0.46f, cyy - rh * 0.98f), Size(rw * 0.9f, rh * 0.46f))
    drawCircle(Color.White.copy(alpha = 0.18f), rw * 0.20f, Offset(cx, cyy - rh * 0.45f))
}

// ------------------------------------------------------------------------------------------ turtle

private fun DrawScope.drawTurtle(x: Float, y: Float, L: Float, t: Float, u: Float) {
    val rx = L * 0.34f; val ry = L * 0.24f
    val skin = Color(0xFF9BD77A); val skinDark = Color(0xFF6DB05A)
    val flip = 22f + 30f * sin(t * 1.8f)
    withTransform({ translate(x, y); rotate(sin(t * 0.6f) * 3f, Offset.Zero) }) {
        // far flipper (dimmer), then rear flipper + tail
        withTransform({ rotate(-flip * 0.8f, Offset(rx * 0.35f, ry * 0.4f)) }) {
            drawOval(skinDark, Offset(rx * 0.35f, ry * 0.4f - L * 0.04f), Size(L * 0.30f, L * 0.085f))
        }
        drawPath(Path().apply { moveTo(-rx, ry * 0.1f); lineTo(-rx - L * 0.12f, ry * 0.25f); lineTo(-rx + L * 0.02f, ry * 0.3f); close() }, skinDark)
        withTransform({ rotate(18f - flip * 0.4f, Offset(-rx * 0.7f, ry * 0.5f)) }) {
            drawOval(skin, Offset(-rx * 0.7f - L * 0.14f, ry * 0.5f - L * 0.03f), Size(L * 0.20f, L * 0.07f))
        }
        // head + neck
        drawOval(skin, Offset(rx * 0.72f, -ry * 0.55f), Size(L * 0.26f, L * 0.16f))
        drawCircle(Color.White, L * 0.020f, Offset(rx + L * 0.16f, -ry * 0.28f))
        drawCircle(Color.Black, L * 0.011f, Offset(rx + L * 0.168f, -ry * 0.28f))
        // plastron (belly) and shell dome
        drawOval(Color(0xFFE6D8A0), Offset(-rx * 0.95f, -ry * 0.12f), Size(rx * 1.9f, ry * 0.34f))
        val shell = Path().apply {
            moveTo(-rx, 0.05f * ry); cubicTo(-rx, -ry * 1.55f, rx, -ry * 1.55f, rx, 0.05f * ry); close()
        }
        drawPath(shell, Brush.verticalGradient(listOf(Color(0xFF52D17C), Color(0xFF1F7F4A)), startY = -ry * 1.1f, endY = 0f))
        val scute = Color(0xFF0E4A2A).copy(alpha = 0.38f)
        drawOval(scute, Offset(-rx * 0.62f, -ry * 0.95f), Size(rx * 0.50f, ry * 0.72f))
        drawOval(scute, Offset(-rx * 0.15f, -ry * 1.10f), Size(rx * 0.50f, ry * 0.80f))
        drawOval(scute, Offset(rx * 0.30f, -ry * 0.90f), Size(rx * 0.46f, ry * 0.66f))
        drawPath(shell, Color(0xFFB8F0C8).copy(alpha = 0.55f), style = Stroke(1.6f * u))
        // near front flipper paddles over the shell
        withTransform({ rotate(flip, Offset(rx * 0.45f, ry * 0.45f)) }) {
            drawOval(skin, Offset(rx * 0.45f, ry * 0.45f - L * 0.05f), Size(L * 0.34f, L * 0.10f))
        }
    }
}

// ------------------------------------------------------------------------------------------ seahorse

private fun DrawScope.drawSeahorse(x: Float, y: Float, S: Float, c: Color, t: Float, ph: Float) {
    val n = 34
    val xs = FloatArray(n + 1); val ys = FloatArray(n + 1); val rs = FloatArray(n + 1)
    var px = 0f; var py = 0f
    var a = (PI / 2.0).toFloat() + 0.25f + sin(t * 1.2f + ph) * 0.05f
    for (i in 0..n) {
        val s = i / n.toFloat()
        xs[i] = px; ys[i] = py
        val bulge = exp(-((s - 0.30f) / 0.13f).pow(2))
        rs[i] = S * (0.030f + 0.075f * (1f - s).pow(1.3f) + 0.040f * bulge)
        val k = when { s < 0.12f -> -0.8f; s < 0.55f -> 1.1f; else -> -4.0f - 7f * (s - 0.55f) }
        a += k / n
        px += cos(a) * S / n; py += sin(a) * S / n
    }
    val light = lerp(c, Color.White, 0.45f)
    val dark = lerp(c, Color.Black, 0.35f)
    val wig = sin(t * 9f + ph) * 0.03f
    withTransform({ translate(x, y); rotate(sin(t * 0.7f + ph) * 4f, Offset.Zero) }) {
        // dorsal fin, behind the body
        val i1 = 9; val i2 = 16
        val fin = Path().apply {
            moveTo(xs[i1] - rs[i1], ys[i1])
            quadTo(xs[i1] - S * (0.20f + wig * 3f), (ys[i1] + ys[i2]) / 2f, xs[i2] - rs[i2], ys[i2]); close()
        }
        drawPath(fin, light.copy(alpha = 0.55f))
        // body: tapering chain of discs, tail first so the head overlaps
        for (i in n downTo 0) drawCircle(c, rs[i], Offset(xs[i], ys[i]))
        for (i in 2..14) drawCircle(light.copy(alpha = 0.30f), rs[i] * 0.45f, Offset(xs[i] + rs[i] * 0.35f, ys[i]))
        for (i in 3..n step 3) drawCircle(dark.copy(alpha = 0.28f), rs[i] * 0.72f, Offset(xs[i] - rs[i] * 0.25f, ys[i]))
        // head: snout, crown, eye
        drawLine(c, Offset(xs[0], ys[0]), Offset(S * 0.17f, S * 0.045f), S * 0.045f, StrokeCap.Round)
        for (q in 0..2) drawLine(light, Offset(-S * 0.02f + q * S * 0.025f, -S * 0.07f), Offset(-S * 0.06f + q * S * 0.03f, -S * 0.13f), S * 0.014f, StrokeCap.Round)
        drawCircle(Color.White, S * 0.022f, Offset(S * 0.035f, -S * 0.025f))
        drawCircle(Color.Black, S * 0.011f, Offset(S * 0.042f, -S * 0.025f))
    }
}

// ------------------------------------------------------------------------------------------ coral

private fun DrawScope.drawBranch(x: Float, y: Float, len: Float, ang: Float, depth: Int, color: Color, sw: Float, t: Float, ph: Float) {
    val a = ang + sin(t * 0.9f + ph + depth) * 0.07f
    val x2 = x + cos(a) * len; val y2 = y + sin(a) * len
    drawLine(color, Offset(x, y), Offset(x2, y2), sw, StrokeCap.Round)
    if (depth > 0) {
        drawBranch(x2, y2, len * 0.72f, a - 0.5f, depth - 1, color, sw * 0.78f, t, ph)
        drawBranch(x2, y2, len * 0.72f, a + 0.5f, depth - 1, color, sw * 0.78f, t, ph)
    } else drawCircle(lerp(color, Color.White, 0.45f), sw * 0.85f, Offset(x2, y2))
}

private fun DrawScope.drawCoral(c: CoralSpec, x: Float, y: Float, t: Float, u: Float) {
    val s = c.size * u
    when (c.kind) {
        0 -> {   // branching coral
            val up = (-PI / 2.0).toFloat()
            drawBranch(x, y, s * 0.34f, up, 3, c.color, 5.5f * u, t, c.ph)
            drawBranch(x + 9f * u, y, s * 0.24f, up + 0.35f, 2, c.color.copy(alpha = 0.9f), 4f * u, t, c.ph + 1f)
        }
        1 -> {   // sea fan
            for (i in 0..8) {
                val ang = -PI.toFloat() * (0.12f + 0.76f * i / 8f) + sin(t * 0.8f + c.ph) * 0.04f
                drawLine(c.color.copy(alpha = 0.92f), Offset(x, y), Offset(x + cos(ang) * s, y + sin(ang) * s), 2.2f * u, StrokeCap.Round)
            }
            for (r in listOf(0.55f, 0.85f)) {
                drawArc(c.color.copy(alpha = 0.7f), -158f, 136f, false, Offset(x - s * r, y - s * r), Size(2f * s * r, 2f * s * r), style = Stroke(1.4f * u))
            }
        }
        2 -> {   // dome / brain coral
            val r = s * 0.5f
            drawArc(c.color, 180f, 180f, true, Offset(x - r, y - r), Size(2f * r, 2f * r))
            drawArc(Color.Black.copy(alpha = 0.18f), 200f, 120f, false, Offset(x - r * 0.7f, y - r * 0.7f), Size(r * 1.4f, r * 1.4f), style = Stroke(1.5f * u))
            drawArc(Color.Black.copy(alpha = 0.14f), 215f, 90f, false, Offset(x - r * 0.4f, y - r * 0.4f), Size(r * 0.8f, r * 0.8f), style = Stroke(1.5f * u))
            drawCircle(Color.White.copy(alpha = 0.35f), r * 0.12f, Offset(x - r * 0.35f, y - r * 0.55f))
        }
        else -> {   // swaying seaweed
            for (q in -1..1) {
                val p = Path().apply {
                    moveTo(x + q * 7f * u, y)
                    for (j in 1..10) {
                        val f = j / 10f
                        lineTo(x + q * 7f * u + sin(t * 1.1f + c.ph + q + f * 3f) * f * 10f * u, y - f * s * (1f - 0.12f * (q * q)))
                    }
                }
                drawPath(p, c.color.copy(alpha = 0.92f), style = Stroke(5f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

// ====================================================================================== glass cards + ripple

private const val RIPPLE_NS = 1_400_000_000L

private class Ripple(val c: Offset, val t0: Long)

/**
 * Realistic 3D glass for cards / tiles / panels: solid thickness edge + soft contact shadow, translucent aqua face
 * (the ocean shows through), top gloss, diagonal window streak, bottom caustic glow and a specular rim.
 * Touching it sends expanding water ripples from the finger. [pressed] sinks the face onto its edge.
 * Reserves [depth] of layout space below the card.
 */
@Composable
fun Modifier.oceanGlass(radius: Dp, active: Boolean = false, depth: Dp = 5.dp, pressed: Boolean = false): Modifier {
    val shape = RoundedCornerShape(radius)
    val mode = if (P.amoled) 2 else if (P.dark) 1 else 0
    val accent = P.accent; val accent2 = P.accent2
    val reduce = LocalReduceMotion.current
    val press by animateFloatAsState(if (pressed) 1f else 0f, spring(0.5f, 520f), label = "oceanPress")
    val on by animateFloatAsState(if (active) 1f else 0f, tween(280), label = "oceanOn")
    val ripples = remember { mutableStateListOf<Ripple>() }
    var now by remember { mutableLongStateOf(0L) }
    LaunchedEffect(ripples.size) {
        while (ripples.isNotEmpty()) {
            withFrameNanos { }
            val n = System.nanoTime()
            now = n
            ripples.removeAll { n - it.t0 > RIPPLE_NS }
        }
    }

    val faceA = when (mode) { 0 -> Color.White.copy(alpha = 0.60f); 1 -> Color(0xFF9BE7FF).copy(alpha = 0.20f); else -> Color(0xFF6FD3FF).copy(alpha = 0.15f) }
    val faceB = when (mode) { 0 -> Color(0xFFB4ECF8).copy(alpha = 0.34f); 1 -> Color(0xFF1D78AA).copy(alpha = 0.34f); else -> Color(0xFF0B4468).copy(alpha = 0.40f) }
    val face = Brush.linearGradient(listOf(lerp(faceA, accent.copy(alpha = 0.46f), on), lerp(faceB, accent2.copy(alpha = 0.30f), on)))
    val edgeBase = when (mode) { 0 -> Color(0xFF3A9DBF); 1 -> Color(0xFF05395C); else -> Color(0xFF062B45) }
    val edge = lerp(edgeBase, accent2.copy(alpha = 0.85f), on * 0.7f)
    val shadowTint = if (mode == 0) Color(0xFF0B5E80) else Color(0xFF000F1E)
    val rim = Brush.linearGradient(listOf(
        lerp(Color.White.copy(alpha = 0.78f), accent, on), Color.White.copy(alpha = 0.14f),
        lerp(Color(0xFF7FE8FF).copy(alpha = 0.30f), accent2, on), Color.White.copy(alpha = 0.42f)
    ))
    val gl = if (mode == 0) 1.2f else 1f

    return this
        .padding(bottom = depth)
        .graphicsLayer { translationY = press * depth.toPx() * 0.62f }
        .drawWithCache {
            val r = radius.toPx(); val d = depth.toPx()
            val faceRect = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
            onDrawBehind {
                val moved = d * 0.62f * press
                clipPath(faceRect, ClipOp.Difference) {
                    val topY = d - moved
                    for (i in 5 downTo 1) {
                        val g = d * 1.8f * i / 5f
                        drawRoundRect(
                            shadowTint.copy(alpha = 0.035f * (1f - press * 0.4f)),
                            Offset(-g * 0.6f, topY + 3.dp.toPx() - g * 0.5f), Size(size.width + 1.2f * g, size.height + 1.2f * g), CornerRadius(r + g * 0.6f)
                        )
                    }
                    drawRoundRect(shadowTint.copy(alpha = 0.22f), Offset(-1f, topY + 1.5.dp.toPx()), Size(size.width + 2f, size.height + 1f), CornerRadius(r + 1f))
                    drawRoundRect(edge, Offset(0f, topY), size, CornerRadius(r))
                }
            }
        }
        .clip(shape)
        .background(face)
        .pointerInput(reduce) {
            if (reduce) return@pointerInput
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)   // observe only; never consumes the touch
                    if (e.type == PointerEventType.Press) {
                        val p = e.changes.firstOrNull()?.position
                        if (p != null) {
                            if (ripples.size >= 4) ripples.removeAt(0)
                            ripples.add(Ripple(p, System.nanoTime()))
                        }
                    }
                }
            }
        }
        .drawBehind {
            val w = size.width; val h = size.height
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f * gl), Color.Transparent), startY = 0f, endY = h * 0.55f))
            drawRect(Brush.linearGradient(
                0f to Color.Transparent, 0.30f to Color.Transparent, 0.44f to Color.White.copy(alpha = 0.13f * gl),
                0.54f to Color.Transparent, 1f to Color.Transparent, start = Offset(0f, 0f), end = Offset(w, h * 0.9f)
            ))
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF7FF3FF).copy(alpha = 0.16f)), startY = h * 0.6f, endY = h))
            // water ripples from the touch point
            val nn = now
            for (rp in ripples) {
                if (nn - rp.t0 < 0L) continue
                val p = ((nn - rp.t0).toFloat() / RIPPLE_NS).coerceIn(0f, 1f)
                val maxR = hypot(w, h) * 0.85f
                for (k in 0..2) {
                    val pk = p - k * 0.13f
                    if (pk <= 0f) continue
                    val rad = maxR * (1f - (1f - pk) * (1f - pk))
                    val al = (1f - pk).pow(1.5f) * (0.55f - k * 0.14f)
                    drawCircle(Color.White.copy(alpha = al), rad, rp.c, style = Stroke((2.6f - k * 0.6f) * density))
                    drawCircle(accent2.copy(alpha = al * 0.6f), (rad - 3f * density).coerceAtLeast(0f), rp.c, style = Stroke(1.4f * density))
                }
                val lens = maxR * p + 1f
                drawCircle(Brush.radialGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.10f * (1f - p)), Color.Transparent), center = rp.c, radius = lens), lens, rp.c)
            }
        }
        .border(1.dp, rim, shape)
}

/** Glass bubble used behind tile icons. */
@Composable
fun Modifier.oceanBubble(active: Boolean): Modifier {
    val accent = P.accent; val accent2 = P.accent2
    return this
        .clip(CircleShape)
        .background(if (active) Brush.linearGradient(listOf(accent, accent2)) else Brush.radialGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.10f))))
        .drawBehind { drawCircle(Color.White.copy(alpha = 0.65f), size.minDimension * 0.09f, Offset(size.width * 0.32f, size.height * 0.28f)) }
        .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape)
}
