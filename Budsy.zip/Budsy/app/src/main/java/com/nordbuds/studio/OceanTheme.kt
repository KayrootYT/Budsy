package com.nordbuds.studio

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * "Ganga Himalaya" (built-in id kept as the old Ocean id) — a built-in Budsy theme (Stock Budsy is untouched).
 *
 *  - Real animated water: a rippling surface line, drifting swell bands and swaying light rays.
 *  - Fish of many colours, jellyfish, a turtle, seahorses and coral on the sea floor.
 *  - Cards / tiles are 3D realistic glass (thickness edge, specular rim, gloss) over the water.
 *  - Touching a card sends small water ripples from the finger.
 *
 * Everything is drawn with vector paths (no image assets) and honours the system "reduce motion" setting.
 */
object OceanTheme {
    const val ID = "theme_budsy_ocean"

    val SPEC = ThemeSpec(
        name = "Ganga Himalaya", author = "Budsy", version = "1.0", source = "builtin",
        description = "The Ganga flowing out of the snow-capped Himalaya: winding river, glass box, glass cards, touch ripples.",
        light = ColorSet(
            bg = 0xFF8FE6F2, card = 0xFFFFFFFF, thumb = 0xFFD7F3FA, text = 0xFF05304D, sub = 0xFF1E6A8A,
            line = 0xFF7CC8E0, track = 0xFFB5E6F2, accent = 0xFF0091C8, accent2 = 0xFF00C2B8,
            green = 0xFF1FB36B, amber = 0xFFE69A00, red = 0xFFE5484D, sheet = 0xFFDDF5FB
        ),
        dark = ColorSet(
            bg = 0xFF04223F, card = 0xFF0E4A73, thumb = 0xFF1B6C96, text = 0xFFEAF9FF, sub = 0xFF9CC9E0,
            line = 0xFF5FB8D9, track = 0xFF1A4E73, accent = 0xFF2EE6D6, accent2 = 0xFF3AA0FF,
            green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF0A3558
        ),
        amoled = ColorSet(
            bg = 0xFF000000, card = 0xFF062B45, thumb = 0xFF0B4468, text = 0xFFEAF9FF, sub = 0xFF8FBFD8,
            line = 0xFF3F9CC0, track = 0xFF0F3A57, accent = 0xFF18E0D0, accent2 = 0xFF2E8FFF,
            green = 0xFF5DF0A8, amber = 0xFFFFC857, red = 0xFFFF6B6B, sheet = 0xFF03121F
        ),
        shapes = ShapeSpec(panel = 28f, card = 22f, tile = 24f, button = 18f, pill = 50f),
        card = CardSpec(style = CardStyle.GLASS, borderWidth = 1f, borderAlpha = 0.55f, fillAlpha = 1f, glow = true),
        ocean = true,
        features = setOf("colors", "shapes", "cards", "animation", "background")
    )
}

@Composable
fun isOcean(): Boolean = LocalThemeSpec.current.ocean

// ====================================================================================== glass cards + ripple

private const val RIPPLE_NS = 900_000_000L

private class Ripple(val c: Offset, val t0: Long)

/**
 * Realistic 3D glass for cards / tiles / panels: solid thickness edge + soft contact shadow, translucent aqua face
 * (the ocean shows through), top gloss, diagonal window streak, bottom caustic glow and a specular rim.
 * Touching it sends small water ripples from the finger. [pressed] sinks the face onto its edge.
 * Reserves [depth] of layout space below the card.
 */
@Composable
fun Modifier.oceanGlass(radius: Dp, active: Boolean = false, depth: Dp = 5.dp, pressed: Boolean = false, frost: Float = 0f): Modifier {
    val shape = RoundedCornerShape(radius)
    val mode = if (P.amoled) 2 else if (P.dark) 1 else 0
    val accent = P.accent; val accent2 = P.accent2
    val reduce = LocalReduceMotion.current
    val press by animateFloatAsState(if (pressed) 1f else 0f, spring(0.5f, 520f), label = "oceanPress")
    val on by animateFloatAsState(if (active) 1f else 0f, tween(280), label = "oceanOn")
    val ripples = remember { mutableStateListOf<Ripple>() }
    var now by remember { mutableLongStateOf(0L) }
    LaunchedEffect(ripples.size) {
        while (ripples.isNotEmpty()) {
            withFrameNanos { }
            val n = System.nanoTime()
            now = n
            ripples.removeAll { n - it.t0 > RIPPLE_NS }
        }
    }

    val faceA = when (mode) { 0 -> Color.White.copy(alpha = 0.60f); 1 -> Color(0xFF9BE7FF).copy(alpha = 0.20f); else -> Color(0xFF6FD3FF).copy(alpha = 0.15f) }
    val faceB = when (mode) { 0 -> Color(0xFFB4ECF8).copy(alpha = 0.34f); 1 -> Color(0xFF1D78AA).copy(alpha = 0.34f); else -> Color(0xFF0B4468).copy(alpha = 0.40f) }
    val face = Brush.linearGradient(listOf(lerp(faceA, accent.copy(alpha = 0.46f), on), lerp(faceB, accent2.copy(alpha = 0.30f), on)))
    val edgeBase = when (mode) { 0 -> Color(0xFF3A9DBF); 1 -> Color(0xFF05395C); else -> Color(0xFF062B45) }
    val edge = lerp(edgeBase, accent2.copy(alpha = 0.85f), on * 0.7f)
    val shadowTint = if (mode == 0) Color(0xFF0B5E80) else Color(0xFF000F1E)
    val rim = Brush.linearGradient(listOf(
        lerp(Color.White.copy(alpha = 0.78f), accent, on), Color.White.copy(alpha = 0.14f),
        lerp(Color(0xFF7FE8FF).copy(alpha = 0.30f), accent2, on), Color.White.copy(alpha = 0.42f)
    ))
    val gl = if (mode == 0) 1.2f else 1f
    val frostColor = when (mode) { 0 -> Color(0xFFD8F3FA); 1 -> Color(0xFF0A3558); else -> Color(0xFF03121F) }.copy(alpha = frost)

    return this
        .padding(bottom = depth)
        .graphicsLayer { translationY = press * depth.toPx() * 0.62f }
        .drawWithCache {
            val r = radius.toPx(); val d = depth.toPx()
            val faceRect = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
            onDrawBehind {
                val moved = d * 0.62f * press
                clipPath(faceRect, ClipOp.Difference) {
                    val topY = d - moved
                    for (i in 5 downTo 1) {
                        val g = d * 1.8f * i / 5f
                        drawRoundRect(
                            shadowTint.copy(alpha = 0.035f * (1f - press * 0.4f)),
                            Offset(-g * 0.6f, topY + 3.dp.toPx() - g * 0.5f), Size(size.width + 1.2f * g, size.height + 1.2f * g), CornerRadius(r + g * 0.6f)
                        )
                    }
                    drawRoundRect(shadowTint.copy(alpha = 0.22f), Offset(-1f, topY + 1.5.dp.toPx()), Size(size.width + 2f, size.height + 1f), CornerRadius(r + 1f))
                    drawRoundRect(edge, Offset(0f, topY), size, CornerRadius(r))
                }
            }
        }
        .clip(shape)
        .then(if (frost > 0f) Modifier.background(frostColor) else Modifier)
        .background(face)
        .pointerInput(reduce) {
            if (reduce) return@pointerInput
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)   // observe only; never consumes the touch
                    if (e.type == PointerEventType.Press) {
                        val p = e.changes.firstOrNull()?.position
                        if (p != null) {
                            if (ripples.size >= 4) ripples.removeAt(0)
                            ripples.add(Ripple(p, System.nanoTime()))
                        }
                    }
                }
            }
        }
        .drawBehind {
            val w = size.width; val h = size.height
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f * gl), Color.Transparent), startY = 0f, endY = h * 0.55f))
            drawRect(Brush.linearGradient(
                0f to Color.Transparent, 0.30f to Color.Transparent, 0.44f to Color.White.copy(alpha = 0.13f * gl),
                0.54f to Color.Transparent, 1f to Color.Transparent, start = Offset(0f, 0f), end = Offset(w, h * 0.9f)
            ))
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF7FF3FF).copy(alpha = 0.16f)), startY = h * 0.6f, endY = h))
            // water ripples from the touch point: small, tight rings (about a fingertip wide), not a card-wide wave
            val nn = now
            for (rp in ripples) {
                if (nn - rp.t0 < 0L) continue
                val p = ((nn - rp.t0).toFloat() / RIPPLE_NS).coerceIn(0f, 1f)
                val maxR = minOf(hypot(w, h) * 0.5f, 40f * density)
                for (k in 0..1) {
                    val pk = p - k * 0.18f
                    if (pk <= 0f) continue
                    val rad = maxR * (1f - (1f - pk) * (1f - pk))
                    val al = (1f - pk).pow(1.6f) * (0.50f - k * 0.18f)
                    drawCircle(Color.White.copy(alpha = al), rad, rp.c, style = Stroke((1.7f - k * 0.5f) * density))
                    drawCircle(accent2.copy(alpha = al * 0.5f), (rad - 2f * density).coerceAtLeast(0f), rp.c, style = Stroke(1f * density))
                }
            }
        }
        .border(1.dp, rim, shape)
}

/** Glass bubble used behind tile icons. */
@Composable
fun Modifier.oceanBubble(active: Boolean): Modifier {
    val accent = P.accent; val accent2 = P.accent2
    return this
        .clip(CircleShape)
        .background(if (active) Brush.linearGradient(listOf(accent, accent2)) else Brush.radialGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.10f))))
        .drawBehind { drawCircle(Color.White.copy(alpha = 0.65f), size.minDimension * 0.09f, Offset(size.width * 0.32f, size.height * 0.28f)) }
        .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape)
}


/**
 * Header / navigation bar glass: lightly see-through (the water world shows behind it) but clearly more solid than the
 * tile cards, so bars, panels and tiles read as three different layers.
 */
@Composable
fun Modifier.oceanHeaderGlass(): Modifier {
    val base = P.sheet
    val a0 = if (P.dark) 0.66f else 0.74f
    return this
        .background(Brush.verticalGradient(listOf(base.copy(alpha = a0), base.copy(alpha = a0 - 0.16f))))
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent), endY = size.height * 0.55f))
            drawLine(Color.White.copy(alpha = 0.38f), Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 1.5f)
        }
}

@Composable
fun Modifier.oceanNavGlass(radius: Dp): Modifier {
    val shape = RoundedCornerShape(radius)
    val base = P.sheet
    val a0 = 0.50f                        // 50% see-through: the water world stays clearly visible behind the bar
    val rim = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.14f), P.accent2.copy(alpha = 0.40f), Color.White.copy(alpha = 0.34f)))
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(base.copy(alpha = a0), base.copy(alpha = a0 - 0.12f))))
        .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent), endY = size.height * 0.5f)) }
        .border(1.dp, rim, shape)
}


/**
 * A pane of curved glass laid over the whole water world: the screen reads as one glass box with rounded corners.
 * Everything is painted once into a cached layer (zero per-frame cost) and never takes touches.
 *  - a thick frosted frame between the screen edge and a rounded inner window (the glass wall thickness)
 *  - bright inner rim + soft outer shade, curved refraction strips down the left / right walls
 *  - a diagonal sheen across the pane and small corner glints
 */
@Composable
fun OceanGlassFrame(modifier: Modifier = Modifier) {
    val dark = P.dark; val amoled = P.amoled
    val accent2 = P.accent2
    Spacer(
        modifier.fillMaxSize().graphicsLayer { alpha = 0.40f }   // glass layer at 40% strength, every appearance
        .drawWithCache {
            val w = size.width; val h = size.height
            val d = density
            val inset = 7f * d                        // wall thickness
            val rad = 40f * d                         // curved corners of the inner window
            val tint = when { amoled -> Color(0xFF010A12); dark -> Color(0xFF031B33); else -> Color(0xFFBFEFFA) }
            val wallA = if (amoled) 0.92f else if (dark) 0.80f else 0.66f

            val window = Path().apply {
                addRoundRect(RoundRect(inset, inset, w - inset, h - inset, CornerRadius(rad)))
            }
            val wall = Path().apply {
                fillType = PathFillType.EvenOdd
                addRect(androidx.compose.ui.geometry.Rect(0f, 0f, w, h))
                addRoundRect(RoundRect(inset, inset, w - inset, h - inset, CornerRadius(rad)))
            }
            val wallBrush = Brush.verticalGradient(listOf(tint.copy(alpha = wallA), tint.copy(alpha = wallA * 0.85f), tint.copy(alpha = wallA)))
            val rimBrush = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.85f), Color.White.copy(alpha = 0.10f), accent2.copy(alpha = 0.45f), Color.White.copy(alpha = 0.55f)),
                start = Offset(0f, 0f), end = Offset(w, h)
            )
            val sideL = Brush.horizontalGradient(listOf(Color.White.copy(alpha = if (dark) 0.20f else 0.34f), Color.Transparent), startX = inset, endX = inset + 22f * d)
            val sideR = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (dark) 0.16f else 0.28f)), startX = w - inset - 22f * d, endX = w - inset)
            val sheen = Brush.linearGradient(
                0f to Color.Transparent, 0.18f to Color.White.copy(alpha = if (dark) 0.06f else 0.12f), 0.30f to Color.Transparent,
                0.62f to Color.Transparent, 0.70f to Color.White.copy(alpha = if (dark) 0.04f else 0.08f), 0.80f to Color.Transparent,
                start = Offset(0f, 0f), end = Offset(w, h)
            )
            val topGloss = Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.10f else 0.18f), Color.Transparent), endY = h * 0.14f)
            val botGloss = Brush.verticalGradient(listOf(Color.Transparent, accent2.copy(alpha = 0.16f)), startY = h * 0.90f, endY = h)

            onDrawBehind {
                // inner window: soft glass sheen, curved refraction strips, top / bottom gloss (clipped to the rounded window)
                clipPath(window) {
                    drawRect(sheen)
                    drawRect(topGloss, size = Size(w, h * 0.14f))
                    drawRect(botGloss, topLeft = Offset(0f, h * 0.90f), size = Size(w, h * 0.10f))
                    drawRect(sideL, topLeft = Offset(inset, 0f), size = Size(22f * d, h))
                    drawRect(sideR, topLeft = Offset(w - inset - 22f * d, 0f), size = Size(22f * d, h))
                    // inner shade just inside the rim gives the wall real thickness
                    drawRoundRect(Color.Black.copy(alpha = if (dark) 0.34f else 0.16f), Offset(inset, inset), Size(w - 2 * inset, h - 2 * inset), CornerRadius(rad),
                        style = Stroke(10f * d))
                }
                // frosted glass wall + bright rim
                drawPath(wall, wallBrush)
                drawRoundRect(rimBrush, Offset(inset, inset), Size(w - 2 * inset, h - 2 * inset), CornerRadius(rad), style = Stroke(1.6f * d))
                drawRoundRect(Color.White.copy(alpha = 0.22f), Offset(inset + 2.2f * d, inset + 2.2f * d), Size(w - 2 * inset - 4.4f * d, h - 2 * inset - 4.4f * d),
                    CornerRadius(rad - 2.2f * d), style = Stroke(0.8f * d))
                // outer edge of the glass box
                drawRect(Color.White.copy(alpha = 0.30f), Offset(0.5f * d, 0.5f * d), Size(w - d, h - d), style = Stroke(1f * d))
                // corner glints
                val g = Color.White.copy(alpha = if (dark) 0.55f else 0.80f)
                drawArc(g, 192f, 62f, false, Offset(inset + 3f * d, inset + 3f * d), Size(2 * rad - 6f * d, 2 * rad - 6f * d), style = Stroke(2.2f * d, cap = StrokeCap.Round))
                drawArc(g.copy(alpha = g.alpha * 0.6f), 286f, 52f, false, Offset(w - inset - 2 * rad + 3f * d, inset + 3f * d), Size(2 * rad - 6f * d, 2 * rad - 6f * d), style = Stroke(1.8f * d, cap = StrokeCap.Round))
                drawArc(g.copy(alpha = g.alpha * 0.5f), 82f, 40f, false, Offset(inset + 3f * d, h - inset - 2 * rad + 3f * d), Size(2 * rad - 6f * d, 2 * rad - 6f * d), style = Stroke(1.6f * d, cap = StrokeCap.Round))
                drawArc(g.copy(alpha = g.alpha * 0.5f), 58f, 40f, false, Offset(w - inset - 2 * rad + 3f * d, h - inset - 2 * rad + 3f * d), Size(2 * rad - 6f * d, 2 * rad - 6f * d), style = Stroke(1.6f * d, cap = StrokeCap.Round))
            }
        }
    )
}
