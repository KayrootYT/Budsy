package com.nordbuds.studio

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nordbuds.studio.protocol.Protocol
import com.nordbuds.studio.protocol.ProtocolDecoder
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Opt-in local protocol history for frames exchanged by Budsy's own control connection. */
object ProtocolLab {
    private const val PREFS = "budsy_protocol_lab"
    private const val KEY_EVENTS = "events_v2"
    private const val KEY_FEATURE_MAP = "feature_map_v1"
    private const val KEY_HCI_REPORT = "hci_report_v1"
    private const val KEY_HCI_BASELINE = "hci_baseline_v1"
    private const val MAX_MEMORY = 3000
    private const val MAX_DISK = 1200
    private var prefs: SharedPreferences? = null
    private val pending = LinkedHashMap<Int, Event>()
    private val catalog = LinkedHashMap<Int, Int>()
    var importedHci by mutableStateOf<HciSnoopImporter.Report?>(null)
        private set
    var baselineHci by mutableStateOf<HciSnoopImporter.Report?>(null)
        private set
    var importError by mutableStateOf<String?>(null)
        private set
    private val featureLabels = linkedMapOf<Int, String>()

    data class Event(
        val time: Long,
        val direction: String,
        val command: Int,
        val group: Int,
        val payload: List<Int>,
        val sequence: Int? = null,
        val decodedTitle: String = "",
        val decodedDetail: String = "",
        val confidence: String = "",
        val latencyMs: Long? = null,
        val matched: Boolean = false
    ) {
        private val stamp: String get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(time))
        val label: String get() = Protocol.commandName(command)
        fun line(): String = buildString {
            append(stamp).append("  ").append(direction).append("  ")
            append("0x").append(Protocol.hex(command ushr 8)).append(Protocol.hex(command))
            append("  [").append(label).append("]")
            if (sequence != null) append("  seq=").append(Protocol.hex(sequence))
            append("  group=").append(Protocol.hex(group))
            if (latencyMs != null) append("  RTT=").append(latencyMs).append("ms")
            append("  payload=").append(payload.joinToString(" ") { Protocol.hex(it) })
            if (decodedDetail.isNotBlank()) append("\n  ").append(decodedTitle).append(": ").append(decodedDetail)
        }
    }

    var capturing by mutableStateOf(false)
        private set
    var totalCaptured by mutableStateOf(0)
        private set
    var matchedReplies by mutableStateOf(0)
        private set
    var unknownCommands by mutableStateOf(0)
        private set
    val events = mutableStateListOf<Event>()

    fun attach(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        restore()
        restoreHci()
        restoreFeatureMap()
        ProtocolCommandDatabase.attach(context)
    }

    fun start() { capturing = true }
    fun stop() { capturing = false; persist() }
    fun clear() {
        events.clear(); pending.clear(); catalog.clear()
        totalCaptured = 0; matchedReplies = 0; unknownCommands = 0
        prefs?.edit()?.remove(KEY_EVENTS)?.apply()
    }

    @Synchronized
    fun record(direction: String, lo: Int, hi: Int, payload: IntArray, sequence: Int? = null) {
        if (!capturing) return
        val command = ((hi and 0x7f) shl 8) or (lo and 0xff)
        val now = System.currentTimeMillis()
        val decoded = ProtocolDecoder.decode(command, hi, payload)
        var latency: Long? = null
        var matched = false
        if (direction == "TX" && sequence != null && (hi and 0x80) == 0) {
            pending[sequence] = Event(now, direction, command, hi, payload.toList(), sequence)
            while (pending.size > 128) pending.remove(pending.keys.first())
        } else if (direction == "RX" && (hi and 0x80) != 0 && sequence != null) {
            val request = pending.remove(sequence)
            if (request != null && request.command == command) {
                latency = (now - request.time).coerceAtLeast(0)
                matched = true
                matchedReplies++
            }
        }
        val event = Event(now, direction, command, hi, payload.toList(), sequence,
            decoded.title, decoded.detail, decoded.confidence, latency, matched)
        events.add(event)
        if (events.size > MAX_MEMORY) events.removeAt(0)
        totalCaptured++
        if (decoded.title.startsWith("Unknown")) unknownCommands++
        catalog[command] = (catalog[command] ?: 0) + 1
        if (totalCaptured % 100 == 0) persist()
    }

    fun catalogSummary(): List<Pair<Int, Int>> = catalog.entries.sortedByDescending { it.value }.map { it.key to it.value }

    fun importHci(fileName: String, bytes: ByteArray) {
        try {
            importedHci = HciSnoopImporter.parse(fileName, bytes)
            importError = null
            persistHci()
        } catch (e: Exception) {
            importError = e.message ?: "Could not read this capture"
        }
    }

    fun useImportedAsBaseline() {
        baselineHci = importedHci
        persistHci()
    }

    fun hciDiff(): HciSnoopImporter.Diff? {
        val a = baselineHci ?: return null
        val b = importedHci ?: return null
        return HciSnoopImporter.diff(a, b)
    }

    fun commandCandidates(): List<CommandMappingEngine.Candidate> {
        val a = baselineHci ?: return emptyList()
        val b = importedHci ?: return emptyList()
        return CommandMappingEngine.compare(a, b)
    }

    fun featureLabel(id: Int): String = featureLabels[id] ?: "Unmapped"
    fun saveFeatureLabel(id: Int, label: String) {
        if (id !in 1..0x20) return
        val clean = label.trim().take(80)
        if (clean.isEmpty()) featureLabels.remove(id) else featureLabels[id] = clean
        prefs?.edit()?.putString(KEY_FEATURE_MAP, JSONObject().apply {
            featureLabels.forEach { (k,v) -> put(k.toString(),v) }
        }.toString())?.apply()
    }
    fun featureMappings(): List<Pair<Int,String>> = featureLabels.entries.sortedBy { it.key }.map { it.key to it.value }

    private fun persistHci() {
        val p = prefs ?: return
        fun encode(r: HciSnoopImporter.Report?): String? = r?.let {
            JSONObject().apply {
                put("file",it.fileName); put("version",it.version); put("link",it.dataLinkType)
                put("records",it.totalRecords); put("sent",it.sentRecords); put("received",it.receivedRecords)
                put("drops",it.droppedRecords); put("commands",it.commandPackets); put("events",it.eventPackets)
                put("acl",it.aclPackets); put("other",it.otherPackets)
                put("opcodes",JSONObject().apply { it.opcodeCounts.forEach { (k,v) -> put(k.toString(),v) } })
                put("eventCodes",JSONObject().apply { it.eventCodeCounts.forEach { (k,v) -> put(k.toString(),v) } })
                put("warnings",JSONArray(it.warnings))
                put("l2capPackets",it.l2capPackets); put("rfcommFrames",it.rfcommFrames)
                put("vendorFrames",JSONArray().apply {
                    it.vendorFrames.takeLast(1000).forEach { frame ->
                        put(JSONObject().apply {
                            put("direction",frame.direction); put("command",frame.command)
                            put("group",frame.group); put("sequence",frame.sequence)
                            put("payload",JSONArray(frame.payload))
                        })
                    }
                })
                put("attPackets",it.attPackets)
                put("gattCharacteristics",JSONArray().apply {
                    it.gattCharacteristics.take(500).forEach { c ->
                        put(JSONObject().apply { put("handle",c.valueHandle); put("uuid",c.uuid); put("properties",c.properties) })
                    }
                })
                put("gattEvents",JSONArray().apply {
                    it.gattEvents.takeLast(1000).forEach { e ->
                        put(JSONObject().apply {
                            put("direction",e.direction); put("opcode",e.opcode); put("name",e.opcodeName)
                            put("handle",e.handle ?: JSONObject.NULL); put("uuid",e.uuid ?: JSONObject.NULL)
                            put("value",JSONArray(e.value))
                        })
                    }
                })
            }.toString()
        }
        p.edit().putString(KEY_HCI_REPORT,encode(importedHci)).putString(KEY_HCI_BASELINE,encode(baselineHci)).apply()
    }

    private fun restoreHci() {
        fun decode(raw: String?): HciSnoopImporter.Report? = try {
            if (raw == null) null else JSONObject(raw).let { o ->
                fun counts(key: String): Map<Int,Int> {
                    val j=o.optJSONObject(key) ?: JSONObject(); val out=linkedMapOf<Int,Int>()
                    j.keys().forEach { k -> k.toIntOrNull()?.let { out[it]=j.optInt(k) } }
                    return out
                }
                val w=o.optJSONArray("warnings") ?: JSONArray()
                HciSnoopImporter.Report(o.optString("file"),o.optLong("version"),o.optLong("link"),
                    o.optInt("records"),o.optInt("sent"),o.optInt("received"),o.optLong("drops"),
                    o.optInt("commands"),o.optInt("events"),o.optInt("acl"),o.optInt("other"),
                    counts("opcodes"),counts("eventCodes"),(0 until w.length()).map { w.getString(it) },
                    (o.optJSONArray("vendorFrames") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { n ->
                            val v=a.getJSONObject(n); val p=v.optJSONArray("payload") ?: JSONArray()
                            HciSnoopImporter.VendorFrame(v.optString("direction"),v.optInt("command"),
                                v.optInt("group"),v.optInt("sequence"),(0 until p.length()).map { p.getInt(it) })
                        }
                    },o.optInt("l2capPackets"),o.optInt("rfcommFrames"),
                    (o.optJSONArray("gattEvents") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { n ->
                            val v=a.getJSONObject(n); val va=v.optJSONArray("value") ?: JSONArray()
                            HciSnoopImporter.GattEvent(v.optString("direction"),v.optInt("opcode"),v.optString("name"),
                                if (v.isNull("handle")) null else v.optInt("handle"),
                                if (v.isNull("uuid")) null else v.optString("uuid"),
                                (0 until va.length()).map { va.getInt(it) })
                        }
                    },
                    (o.optJSONArray("gattCharacteristics") ?: JSONArray()).let { a ->
                        (0 until a.length()).map { n ->
                            val v=a.getJSONObject(n)
                            HciSnoopImporter.GattCharacteristic(v.optInt("handle"),v.optString("uuid"),v.optInt("properties"))
                        }
                    },o.optInt("attPackets"))
            }
        } catch (_: Exception) { null }
        importedHci=decode(prefs?.getString(KEY_HCI_REPORT,null))
        baselineHci=decode(prefs?.getString(KEY_HCI_BASELINE,null))
    }

    private fun restoreFeatureMap() {
        try {
            val o=JSONObject(prefs?.getString(KEY_FEATURE_MAP,"{}") ?: "{}")
            o.keys().forEach { k -> k.toIntOrNull()?.let { id -> featureLabels[id]=o.optString(k) } }
        } catch (_: Exception) { }
    }

    fun exportText(): String = buildString {
        appendLine("Budsy Protocol Laboratory export v2")
        appendLine("Captured frames: $totalCaptured")
        appendLine("Matched replies: $matchedReplies")
        appendLine("Unknown command frames: $unknownCommands")
        appendLine("Scope: Budsy's own RFCOMM control frames only.")
        events.forEach { appendLine(it.line()) }
        importedHci?.let { report ->
            appendLine("\nImported HCI vendor frames:")
            report.vendorFrames.forEach { appendLine(it.line()) }
            appendLine("\nImported BLE / GATT ATT events:")
            report.gattCharacteristics.forEach { appendLine("CHAR handle=0x${it.valueHandle.toString(16).padStart(4,'0')} uuid=${it.uuid} properties=0x${it.properties.toString(16)}") }
            report.gattEvents.forEach { appendLine(it.line()) }
            appendLine("\nDifferential command candidates (unverified):")
            commandCandidates().forEach { appendLine(it.line()) }
        }
        appendLine("\nCommand database profile: ${ProtocolCommandDatabase.activeProfile.value}")
        ProtocolCommandDatabase.visibleEntries().forEach { appendLine(it.line() + " · evidence=" + it.evidence) }
        val readiness = ProtocolReleaseReadiness.buildReport(ProtocolCommandDatabase.activeProfile.value,
            ProtocolCommandDatabase.profileSummary(), importedHci != null, baselineHci != null)
        appendLine("\n" + readiness.asText())
    }

    fun exportJson(): String {
        val arr = JSONArray()
        events.forEach { e ->
            arr.put(JSONObject().apply {
                put("timestamp", e.time); put("direction", e.direction); put("command", e.command)
                put("commandHex", "0x${Protocol.hex(e.command ushr 8)}${Protocol.hex(e.command)}")
                put("group", e.group); put("sequence", e.sequence ?: JSONObject.NULL)
                put("payload", JSONArray(e.payload)); put("decodedTitle", e.decodedTitle)
                put("decodedDetail", e.decodedDetail); put("confidence", e.confidence)
                put("latencyMs", e.latencyMs ?: JSONObject.NULL); put("matched", e.matched)
            })
        }
        val root = JSONObject().put("format", "budsy-protocol-lab-v3")
            .put("capturedFrames", totalCaptured).put("events", arr)
        importedHci?.let { report ->
            root.put("hciImport", JSONObject().apply {
                put("file", report.fileName); put("records", report.totalRecords)
                put("attPackets", report.attPackets); put("rfcommFrames", report.rfcommFrames)
                put("vendorFrames", JSONArray().apply {
                    report.vendorFrames.forEach { f ->
                        put(JSONObject().apply {
                            put("direction",f.direction); put("command",f.command); put("group",f.group)
                            put("sequence",f.sequence); put("payload",JSONArray(f.payload))
                        })
                    }
                })
                put("gattCharacteristics",JSONArray().apply {
                    report.gattCharacteristics.forEach { c ->
                        put(JSONObject().apply { put("valueHandle",c.valueHandle); put("uuid",c.uuid); put("properties",c.properties) })
                    }
                })
                put("gattEvents",JSONArray().apply {
                    report.gattEvents.forEach { e ->
                        put(JSONObject().apply {
                            put("direction",e.direction); put("opcode",e.opcode); put("name",e.opcodeName)
                            put("handle",e.handle ?: JSONObject.NULL); put("uuid",e.uuid ?: JSONObject.NULL)
                            put("value",JSONArray(e.value))
                        })
                    }
                })
                put("mappingCandidates",JSONArray().apply {
                    commandCandidates().forEach { c ->
                        put(JSONObject().apply {
                            put("transport",c.transport); put("signature",c.signature)
                            put("baselineCount",c.baselineCount); put("currentCount",c.currentCount)
                            put("delta",c.delta); put("samples",JSONArray(c.samples))
                            put("verified",false)
                        })
                    }
                })
            })
        }
        root.put("commandDatabase", JSONObject(ProtocolCommandDatabase.exportJson()))
        val readiness = ProtocolReleaseReadiness.buildReport(ProtocolCommandDatabase.activeProfile.value,
            ProtocolCommandDatabase.profileSummary(), importedHci != null, baselineHci != null)
        root.put("releaseReadiness", JSONObject().put("profile", readiness.profile)
            .put("total", readiness.total).put("observed", readiness.observed)
            .put("verified", readiness.verified).put("status", readiness.releaseStatus)
            .put("blockers", JSONArray(readiness.blockers)))
        return root.toString(2)
    }

    @Synchronized
    private fun persist() {
        val p = prefs ?: return
        val arr = JSONArray()
        events.takeLast(MAX_DISK).forEach { e ->
            arr.put(JSONObject().apply {
                put("t", e.time); put("d", e.direction); put("c", e.command); put("g", e.group)
                put("p", JSONArray(e.payload)); put("s", e.sequence ?: JSONObject.NULL)
                put("dt", e.decodedTitle); put("dd", e.decodedDetail); put("cf", e.confidence)
                put("lm", e.latencyMs ?: JSONObject.NULL); put("m", e.matched)
            })
        }
        p.edit().putString(KEY_EVENTS, arr.toString()).apply()
    }

    @Synchronized
    private fun restore() {
        val raw = prefs?.getString(KEY_EVENTS, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val payloadJson = o.optJSONArray("p") ?: JSONArray()
                val payload = (0 until payloadJson.length()).map { payloadJson.getInt(it) }
                val seq = if (o.isNull("s")) null else o.optInt("s")
                val latency = if (o.isNull("lm")) null else o.optLong("lm")
                val e = Event(o.optLong("t"), o.optString("d"), o.optInt("c"), o.optInt("g"),
                    payload, seq, o.optString("dt"), o.optString("dd"), o.optString("cf"),
                    latency, o.optBoolean("m"))
                events.add(e); catalog[e.command] = (catalog[e.command] ?: 0) + 1
                if (e.matched) matchedReplies++
                if (e.decodedTitle.startsWith("Unknown")) unknownCommands++
            }
            totalCaptured = events.size
        } catch (_: Exception) { events.clear() }
    }
}
