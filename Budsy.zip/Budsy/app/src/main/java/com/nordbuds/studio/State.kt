package com.nordbuds.studio

import com.nordbuds.studio.buds.Prefs

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val prefs: Prefs, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit,
    val theme: Int, val setTheme: (Int) -> Unit,
    val appearance: Int, val setAppearance: (Int) -> Unit,
    val activeImportedTheme: String?, val setActiveImportedTheme: (String?) -> Unit,
    val openThemeManager: () -> Unit = {}, val themeChanged: () -> Unit = {},
    val audio: Set<String>, val audioKnown: Boolean,
    val askNotifPerm: () -> Unit = {}, val notifGranted: Boolean = true,
    val askScanPerm: () -> Unit = {}, val scanPerm: Boolean = false
)

/** Tiny cross-screen signals (e.g. the top-bar Bluetooth switch asking the Overview screen to open the device chooser). */
object UiBus {
    val openChooser = androidx.compose.runtime.mutableStateOf(false)
}
