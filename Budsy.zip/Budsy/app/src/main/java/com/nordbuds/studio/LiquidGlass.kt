package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material.icons.rounded.Check
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.remember
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sign

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/**
 * Apple-style continuous-corner "squircle" (superellipse, n = 5) used for every app icon / icon chip.
 * A plain rounded rectangle has a visible seam where the straight edge meets the arc; this curve eases in like iOS icons do.
 */
object IosSquircle : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val a = size.width / 2f; val b = size.height / 2f
        val e = 2.0 / 5.0
        val steps = 160
        val path = Path()
        for (i in 0..steps) {
            val t = 2.0 * PI * i / steps
            val c = cos(t); val sn = sin(t)
            val x = a + a * (sign(c) * abs(c).pow(e)).toFloat()
            val y = b + b * (sign(sn) * abs(sn).pow(e)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Colour tokens of the 3D liquid-glass look for the active appearance (values taken from the Budsy 3D Liquid Glass reference). */
@Immutable
class GlassTokens(
    val bg: List<Color>, val panel: List<Color>, val panelRim: Color,
    val tile: List<Color>, val tileRim: Color, val edge: Color,
    val activeTile: List<Color>, val activeEdge: Color, val activeRim: Color,
    val chip: List<Color>, val chipRim: Color, val chipInk: Color,
    val shine: Float, val shadow: Color, val sheet: Color
)

private val LightGlass = GlassTokens(
    bg = listOf(Color(0xFFEAF3FF), Color(0xFFBDCDE1), Color(0xFF8299B2)),
    panel = listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.09f)), panelRim = Color.White.copy(alpha = 0.63f),
    tile = listOf(Color.White.copy(alpha = 0.85f), Color(0xFFDCE9F8).copy(alpha = 0.66f)), tileRim = Color.White.copy(alpha = 0.93f), edge = Color(0xFFB9C7DA),
    activeTile = listOf(Color.White.copy(alpha = 0.93f), Color(0xFFD7EAFF)), activeEdge = Color(0xFF8FB8E6), activeRim = Color.White,
    chip = listOf(Color.White, Color(0xFFE0EAFA)), chipRim = Color.White, chipInk = Color(0xFF263C54),
    shine = 0.45f, shadow = Color(0xFF30445E), sheet = Color(0xFFEAF2FB)
)
private val DarkGlass = GlassTokens(
    // Neutral charcoal surfaces: the active tile stays grey; only its 3D edge and icon glow blue.
    bg = listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E), Color(0xFF0E0E10)),
    panel = listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.06f)),
    panelRim = Color.White.copy(alpha = 0.12f),
    tile = listOf(Color(0xFF3A3A3C), Color(0xFF2C2C2E)),
    tileRim = Color.White.copy(alpha = 0.15f),
    edge = Color(0xFF0D0D0F),
    activeTile = listOf(Color(0xFF48484A), Color(0xFF3A3A3C)),
    activeEdge = Color(0xFF1B3F6B),
    activeRim = Color(0xFFA5D4FF),
    chip = listOf(Color(0xFF48484A), Color(0xFF2C2C2E)),
    chipRim = Color.White.copy(alpha = 0.21f),
    chipInk = Color(0xFFF2F2F7),
    shine = 0.15f,
    shadow = Color.Black,
    sheet = Color(0xFF2C2C2E)
)
private val AmoledGlass = GlassTokens(
    bg = listOf(Color.Black, Color.Black, Color.Black),
    panel = listOf(Color(0xFF08080A), Color(0xFF08080A)),
    panelRim = Color(0xFF1C1C22),
    tile = listOf(Color(0xFF141418), Color(0xFF0A0A0D)),
    tileRim = Color(0xFF24242A),
    edge = Color.Black,
    activeTile = listOf(Color(0xFF1A1A20), Color(0xFF0F0F14)),
    activeEdge = Color(0xFF0A3A68),
    activeRim = Color(0xFF2E6FA8),
    chip = listOf(Color(0xFF1E1E24), Color(0xFF0E0E12)),
    chipRim = Color.White.copy(alpha = 0.10f),
    chipInk = Color(0xFFB8D4F0),
    shine = 0.08f,
    shadow = Color.Black,
    sheet = Color(0xFF08080A)
)

@Composable
fun glassTokens(): GlassTokens = if (P.amoled) AmoledGlass else if (P.dark) DarkGlass else LightGlass

@Composable
fun glassFill(strong: Boolean = false): Brush = Brush.linearGradient(glassTokens().panel)

@Composable
fun glassRim(): Brush = SolidColor(glassTokens().panelRim)

/** Soft drop shadow drawn only outside the shape (works identically in every appearance; no platform shadow layer). */
fun Modifier.softShadow(radius: Dp, blur: Dp, dy: Dp, color: Color): Modifier = drawBehind {
    val r = minOf(radius.toPx(), size.minDimension / 2f); val b = blur.toPx(); val n = 8
    val face = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
    clipPath(face, ClipOp.Difference) {
        for (i in n downTo 1) {
            val g = b * i / n
            drawRoundRect(color.copy(alpha = color.alpha * 0.12f), Offset(-g, dy.toPx() - g), Size(size.width + 2f * g, size.height + 2f * g), CornerRadius(r + g))
        }
    }
}

/** Frosted glass panel (the "shell"): translucent gradient, bright rim, soft shadow. [active] switches the rim to the accent.
 *  Compose has no backdrop blur; the look comes from translucency over [LiquidBackground]. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val t = glassTokens()
    val amoled = P.amoled
    return this
        .then(if (shadow && !amoled) Modifier.softShadow(radius, 12.dp, 4.dp, t.shadow.copy(alpha = 0.10f)) else Modifier)
        .clip(shape)
        .background(Brush.linearGradient(t.panel))
        .border(1.dp, if (active) SolidColor(P.accent) else Brush.linearGradient(listOf(t.panelRim, t.panelRim.copy(alpha = t.panelRim.alpha * 0.45f), t.panelRim.copy(alpha = t.panelRim.alpha * 0.85f))), shape)
}

/**
 * Raised 3D glass tile (iOS-26 style): solid "thickness" edge under the face, frosted gradient face, glossy top sheen and a
 * specular rim. When [active] the face follows the appearance-specific active surface, the edge becomes a blue 3D layer and a soft blue halo
 * spreads under the tile; when off it is just the neutral silver/graphite edge. [pressed] sinks the face onto its edge.
 * [bold] = always-blue face (filled buttons). Reserves [depth] of layout space below the tile.
 */
@Composable
fun Modifier.glassTile3D(radius: Dp, active: Boolean = false, depth: Dp = 8.dp, pressed: Boolean = false, bold: Boolean = false): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(radius)
    // Push motion (matches the reference recording): a quick, stiff press-in; a soft spring with overshoot on release,
    // so the tile pops slightly above its rest height before settling.
    val press by animateFloatAsState(
        if (pressed) 1f else 0f,
        if (pressed) spring<Float>(1f, 1100f) else spring<Float>(0.42f, 360f),
        label = "glassPress"
    )
    // While pressed, an OFF tile previews the ON look at ~45%.
    val on by animateFloatAsState(if (active || bold) 1f else if (pressed) 0.45f else 0f, tween(260), label = "glassOn")
    val accent = P.accent
    val onFace = if (bold) listOf(Color(0xFF4DA3FF), Color(0xFF1C74E0)) else t.activeTile
    val face = Brush.linearGradient(listOf(lerp(t.tile[0], onFace[0], on), lerp(t.tile[1], onFace[1], on)))
    val edge = lerp(t.edge, if (bold) Color(0xFF1558A8) else t.activeEdge, on)
    val rim = lerp(t.tileRim, t.activeRim, on)
    val specular = Brush.linearGradient(listOf(rim, rim.copy(alpha = rim.alpha * 0.40f), rim.copy(alpha = rim.alpha * 0.85f)))
    val shine = t.shine
    val shadowTint = t.shadow
    val amoled = P.amoled
    return this
        .padding(bottom = depth)
        .offset { IntOffset(0, (press * depth.toPx() * 0.62f).roundToInt()) }
        .drawBehind {
            // Everything below is drawn only OUTSIDE the face (like a CSS box-shadow), so translucent Light/Dark faces never
            // show the edge or glow through them. No platform shadow layers: every appearance uses this one path.
            val r = radius.toPx(); val d = depth.toPx()
            val p = press.coerceIn(0f, 1f)
            val moved = d * 0.62f * press               // how far the face has sunk; the edge stays put, so its visible band shrinks
            val faceRect = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
            clipPath(faceRect, ClipOp.Difference) {
                val top = d - moved
                if (!amoled) {
                    // soft drop shadow that tightens while the tile is pressed in
                    val reach = d * 1.2f
                    for (i in 8 downTo 1) {
                        val g = reach * i / 8f
                        drawRoundRect(
                            shadowTint.copy(alpha = 0.014f * (1f - p * 0.5f)),
                            Offset(-g * 0.6f, top + 3.dp.toPx() - g * 0.5f), Size(size.width + 1.2f * g, size.height + 1.2f * g), CornerRadius(r + g * 0.6f)
                        )
                    }
                }
                // the solid thickness edge
                drawRoundRect(edge, Offset(0f, top), size, CornerRadius(r))
            }
        }
        .clip(shape)
        .background(face)
        .drawBehind {
            // glossy sheen over the top ~43% (drawn behind the content so text stays crisp)
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = shine * 0.8f), Color.Transparent), 0f, size.height * 0.55f))
        }
        .border(1.dp, specular, shape)
        .graphicsLayer { alpha = 1f - 0.3f * press.coerceIn(0f, 1f) }   // content (icon + text) dims while pressed
}

/**
 * Flat inset glass tile for nested content (debug lists, log rows, sub-panels): same face / rim as a tile but no 3D edge.
 * Falls back to the legacy flat fill when an imported theme is active.
 */
@Composable
fun Modifier.insetPanel(radius: Dp = 12.dp, active: Boolean = false): Modifier {
    val shape = RoundedCornerShape(radius)
    if (!isLiquid()) return this.background(P.sheet, shape)
    val t = glassTokens()
    val face = if (active) t.activeTile else t.tile
    return this
        .clip(shape)
        .background(Brush.linearGradient(face))
        .border(1.dp, SolidColor(if (active) t.activeRim else t.tileRim), shape)
}

/** Soft top sheen for opaque glass surfaces (sheets, dialogs, snackbar). Apply right after `.background(...)`. No-op outside the stock look. */
@Composable
fun Modifier.glassSheen(): Modifier {
    if (!isLiquid()) return this
    val shine = glassTokens().shine
    return this.drawBehind {
        // full-width fade clipped by the sheet's own shape: no inner rounded rectangle that reads as an overlapping card
        drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = shine * 0.6f), Color.Transparent), 0f, minOf(size.height * 0.30f, 110.dp.toPx())))
    }
}

/** Pill-shaped glass chip (status pill, value pill). Active = luminous blue face, otherwise neutral glass. */
@Composable
fun Modifier.glassPill(active: Boolean): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(50)
    val dark = P.dark
    val amoled = P.amoled
    val accent = P.accent
    val on by animateFloatAsState(if (active) 1f else 0f, tween(260), label = "pillOn")
    val activeFace = when {
        amoled -> listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63))
        dark -> listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0))
        else -> listOf(Color(0xFF80C8FF), Color(0xFF2585E9))
    }
    val activeRim = when { amoled -> Color(0xFF4A8FD0); dark -> Color(0xFFCFE6FF); else -> Color(0xFFD8EDFF) }
    val face = Brush.linearGradient(listOf(lerp(t.chip[0], activeFace[0], on), lerp(t.chip[1], activeFace[1], on)))
    val rim = lerp(t.chipRim, activeRim, on)
    val gloss = (if (dark) 0.18f else 0.55f) * (1f - on) + 0.34f * on
    val tint = lerp(t.shadow, accent, on)
    return this
        .then(if (amoled) Modifier else Modifier.softShadow(100.dp, 8.dp, 2.dp, t.shadow.copy(alpha = 0.10f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = gloss * 0.7f), Color.Transparent), 0f, size.height * 0.6f))
        }
        .border(1.dp, rim, shape)
}

/**
 * End-of-row state badge shared by every toggle/option row: a blue glass circle with a white tick that pops in when [on].
 * Off shows nothing (reference look) unless [showOff], which draws an empty ring (used by stand-alone toggles).
 */
@Composable
fun GlassCheck(on: Boolean, modifier: Modifier = Modifier, size: Dp = 26.dp, showOff: Boolean = false, preview: Boolean = false) {
    val s by animateFloatAsState(if (on) 1f else if (preview) 0.8f else 0.6f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "glassCheck")
    val ink = glassTokens().chipInk
    val accent = P.accent
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        if (!on && showOff) Box(Modifier.fillMaxSize().border(1.8.dp, ink.copy(alpha = 0.35f), CircleShape))
        if (!on && preview) Box(   // press preview (reference video): neutral ring that fills in on release
            Modifier.fillMaxSize().graphicsLayer { scaleX = 0.9f; scaleY = 0.9f }
                .background(ink.copy(alpha = 0.10f), CircleShape).border(1.4.dp, ink.copy(alpha = 0.35f), CircleShape)
        )
        if (on || (s > 0.62f && !preview)) Box(
            Modifier.fillMaxSize()
                .graphicsLayer { scaleX = s; scaleY = s; alpha = ((s - 0.6f) / 0.4f).coerceIn(0f, 1f) * (if (on) 1f else 0.9f) }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF5BB5FF), Color(0xFF2589ED))))
                .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(size * 0.6f)) }
    }
}

/** Glass icon chip (squircle) with a gradient face, rim and top gloss. Active = luminous blue; cross-fades between the two. */
@Composable
fun Modifier.glassChip(box: Dp, active: Boolean): Modifier {
    val t = glassTokens()
    val shape = IosSquircle
    val dark = P.dark
    val amoled = P.amoled
    val accent = P.accent
    val on by animateFloatAsState(if (active) 1f else 0f, tween(260), label = "chipOn")
    val activeChip = when {
        amoled -> listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63))
        dark -> listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0))
        else -> listOf(Color(0xFF80C8FF), Color(0xFF2585E9))
    }
    val activeRim = when {
        amoled -> Color(0xFF4A8FD0)
        dark -> Color(0xFFCFE6FF)
        else -> Color(0xFFD8EDFF)
    }
    val face = Brush.linearGradient(listOf(lerp(t.chip[0], activeChip[0], on), lerp(t.chip[1], activeChip[1], on)))
    val rim = lerp(t.chipRim, activeRim, on)
    val glossA = (if (dark) 0.18f else 0.55f) * (1f - on) + 0.34f * on
    val tint = lerp(t.shadow, accent, on)
    return this
        .then(if (amoled) Modifier else Modifier.softShadow(box * 0.26f, 8.dp, 2.dp, t.shadow.copy(alpha = 0.10f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = glossA * 0.75f), Color.Transparent), 0f, size.height * 0.62f))
        }
        .border(1.dp, rim, shape)
}

/** Panel / row title with a glass icon chip. */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Numbered ring used by slot tiles (Sound Lab presets). */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Glass icon chip: gradient squircle with rim and gloss; [color] tints it (blue accent = luminous active chip). */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val active = color == P.accent
    Box(modifier.size(box).glassChip(box, active), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else glassTokens().chipInk, modifier = Modifier.size(box * 0.56f))
    }
}

private fun Color.compositeOverWhite(): Color = this.compositeOver(Color.White)

/**
 * Header app mark. If the app ships its own logo file (res/drawable-nodpi/oneplus_logo.png / .webp, supplied by the
 * owner of that brand) it is shown as-is; otherwise a neutral iOS-style Budsy icon is drawn.
 */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = IosSquircle
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/**
 * iOS stock wallpaper. Dark = the default iOS dark wallpaper look: deep midnight blue falling to black with one large,
 * soft blue light from the top and a faint indigo glow low on the screen (no pink / multi-colour blobs).
 * AMOLED keeps a true-black base with only a barely-there blue bloom. Light = the airy iOS sky-blue default.
 */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val amoled = P.amoled
    val dark = P.dark
    Box(
        modifier.fillMaxSize().drawBehind {
            val w = size.width; val h = size.height
            fun glow(c: Color, a: Float, cx: Float, cy: Float, r: Float) =
                drawCircle(Brush.radialGradient(listOf(c.copy(alpha = a), c.copy(alpha = a * 0.35f), Color.Transparent), Offset(cx * w, cy * h), r * w), r * w, Offset(cx * w, cy * h))
            when {
                amoled -> {
                    drawRect(Color.Black)
                    glow(Color(0xFF0A5CFF), 0.16f, 0.50f, -0.04f, 1.00f)
                }
                dark -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1B3F), Color(0xFF060E24), Color(0xFF02040C))))
                    glow(Color(0xFF1F6BFF), 0.42f, 0.78f, 0.02f, 1.05f)
                    glow(Color(0xFF0A84FF), 0.20f, 0.05f, 0.42f, 0.90f)
                    glow(Color(0xFF4B3FE0), 0.20f, 0.85f, 0.96f, 0.85f)
                }
                else -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFFDCEBFF), Color(0xFFEAF2FD), Color(0xFFF6F9FE))))
                    glow(Color(0xFF7DB8FF), 0.50f, 0.15f, 0.02f, 0.95f)
                    glow(Color(0xFFB9A8FF), 0.30f, 0.98f, 0.30f, 0.80f)
                    glow(Color(0xFF9ADBFF), 0.30f, 0.20f, 0.85f, 0.90f)
                }
            }
        }
    )
}
