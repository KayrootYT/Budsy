package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material.icons.rounded.Check
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.remember
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Colour tokens of the 3D liquid-glass look for the active appearance (values taken from the Budsy 3D Liquid Glass reference). */
@Immutable
class GlassTokens(
    val bg: List<Color>, val panel: List<Color>, val panelRim: Color,
    val tile: List<Color>, val tileRim: Color, val edge: Color,
    val activeTile: List<Color>, val activeEdge: Color, val activeRim: Color,
    val chip: List<Color>, val chipRim: Color, val chipInk: Color,
    val shine: Float, val shadow: Color, val sheet: Color
)

private val LightGlass = GlassTokens(
    bg = listOf(Color(0xFFEAF3FF), Color(0xFFBDCDE1), Color(0xFF8299B2)),
    panel = listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.09f)), panelRim = Color.White.copy(alpha = 0.63f),
    tile = listOf(Color.White.copy(alpha = 0.85f), Color(0xFFDCE9F8).copy(alpha = 0.66f)), tileRim = Color.White.copy(alpha = 0.93f), edge = Color(0xFF829AB5),
    activeTile = listOf(Color.White.copy(alpha = 0.93f), Color(0xFFD7EAFF)), activeEdge = Color(0xFF2878B6), activeRim = Color.White,
    chip = listOf(Color.White, Color(0xFFE0EAFA)), chipRim = Color.White, chipInk = Color(0xFF263C54),
    shine = 0.72f, shadow = Color(0xFF263D58), sheet = Color(0xFFEAF2FB)
)
private val DarkGlass = GlassTokens(
    // Neutral charcoal surfaces: the active tile stays grey; only its 3D edge and icon glow blue.
    bg = listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E), Color(0xFF0E0E10)),
    panel = listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.06f)),
    panelRim = Color.White.copy(alpha = 0.12f),
    tile = listOf(Color(0xFF3A3A3C), Color(0xFF2C2C2E)),
    tileRim = Color.White.copy(alpha = 0.15f),
    edge = Color(0xFF0D0D0F),
    activeTile = listOf(Color(0xFF48484A), Color(0xFF3A3A3C)),
    activeEdge = Color(0xFF0E4F96),
    activeRim = Color(0xFFA5D4FF),
    chip = listOf(Color(0xFF48484A), Color(0xFF2C2C2E)),
    chipRim = Color.White.copy(alpha = 0.21f),
    chipInk = Color(0xFFF2F2F7),
    shine = 0.15f,
    shadow = Color.Black,
    sheet = Color(0xFF2C2C2E)
)
private val AmoledGlass = GlassTokens(
    bg = listOf(Color.Black, Color.Black, Color.Black),
    panel = listOf(Color(0xFF08080A), Color(0xFF08080A)),
    panelRim = Color(0xFF1C1C22),
    tile = listOf(Color(0xFF141418), Color(0xFF0A0A0D)),
    tileRim = Color(0xFF24242A),
    edge = Color.Black,
    activeTile = listOf(Color(0xFF1A1A20), Color(0xFF0F0F14)),
    activeEdge = Color(0xFF0A3A68),
    activeRim = Color(0xFF2E6FA8),
    chip = listOf(Color(0xFF1E1E24), Color(0xFF0E0E12)),
    chipRim = Color.White.copy(alpha = 0.10f),
    chipInk = Color(0xFFB8D4F0),
    shine = 0.08f,
    shadow = Color.Black,
    sheet = Color(0xFF08080A)
)

@Composable
fun glassTokens(): GlassTokens = if (P.amoled) AmoledGlass else if (P.dark) DarkGlass else LightGlass

@Composable
fun glassFill(strong: Boolean = false): Brush = Brush.linearGradient(glassTokens().panel)

@Composable
fun glassRim(): Brush = SolidColor(glassTokens().panelRim)

/** Frosted glass panel (the "shell"): translucent gradient, bright rim, soft shadow. [active] switches the rim to the accent.
 *  Compose has no backdrop blur; the look comes from translucency over [LiquidBackground]. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val t = glassTokens()
    val amoled = P.amoled
    return this
        .then(if (shadow && !amoled) Modifier.shadow(14.dp, shape, clip = false, ambientColor = t.shadow.copy(alpha = 0.22f), spotColor = t.shadow.copy(alpha = 0.26f)) else Modifier)
        .clip(shape)
        .background(Brush.linearGradient(t.panel))
        .border(1.dp, if (active) SolidColor(P.accent) else Brush.linearGradient(listOf(t.panelRim, t.panelRim.copy(alpha = t.panelRim.alpha * 0.45f), t.panelRim.copy(alpha = t.panelRim.alpha * 0.85f))), shape)
}

/**
 * Raised 3D glass tile (iOS-26 style): solid "thickness" edge under the face, frosted gradient face, glossy top sheen and a
 * specular rim. When [active] the face follows the appearance-specific active surface, the edge becomes a blue 3D layer and a soft blue halo
 * spreads under the tile; when off it is just the neutral silver/graphite edge. [pressed] sinks the face onto its edge.
 * [bold] = always-blue face (filled buttons). Reserves [depth] of layout space below the tile.
 */
@Composable
fun Modifier.glassTile3D(radius: Dp, active: Boolean = false, depth: Dp = 8.dp, pressed: Boolean = false, bold: Boolean = false): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(radius)
    // Push motion (matches the reference recording): a quick, stiff press-in; a soft spring with overshoot on release,
    // so the tile pops slightly above its rest height before settling.
    val press by animateFloatAsState(
        if (pressed) 1f else 0f,
        if (pressed) spring<Float>(1f, 1100f) else spring<Float>(0.42f, 360f),
        label = "glassPress"
    )
    // While pressed, an OFF tile previews the ON look at ~45%.
    val on by animateFloatAsState(if (active || bold) 1f else if (pressed) 0.45f else 0f, tween(260), label = "glassOn")
    val accent = P.accent
    val onFace = if (bold) listOf(Color(0xFF4DA3FF), Color(0xFF1C74E0)) else t.activeTile
    val face = Brush.linearGradient(listOf(lerp(t.tile[0], onFace[0], on), lerp(t.tile[1], onFace[1], on)))
    val edge = lerp(t.edge, if (bold) Color(0xFF1558A8) else t.activeEdge, on)
    val rim = lerp(t.tileRim, t.activeRim, on)
    val specular = Brush.linearGradient(listOf(rim, rim.copy(alpha = rim.alpha * 0.40f), rim.copy(alpha = rim.alpha * 0.85f)))
    val shine = t.shine
    val shadowTint = lerp(t.shadow, accent, on)
    val amoled = P.amoled
    return this
        .padding(bottom = depth)
        .then(if (amoled) Modifier else Modifier.graphicsLayer {
            // soft drop shadow that tightens while the tile is pressed in
            shadowElevation = depth.toPx() * (1f - press.coerceIn(0f, 1f) * 0.65f)
            this.shape = shape
            clip = false
            ambientShadowColor = shadowTint.copy(alpha = 0.22f)
            spotShadowColor = shadowTint.copy(alpha = 0.32f)
        })
        .drawBehind {
            val r = radius.toPx(); val d = depth.toPx()
            val p = press.coerceIn(0f, 1f)
            if (on > 0.01f) {
                // blue glow of the lit 3D layer: stacked translucent rounded rects fading outwards
                val reach = 14.dp.toPx()
                for (i in 6 downTo 1) {
                    val g = reach * i / 6f
                    drawRoundRect(
                        accent.copy(alpha = 0.05f * on * (1f - p * 0.5f)),
                        Offset(-g, d - g + 5.dp.toPx()), Size(size.width + 2f * g, size.height + 2f * g), CornerRadius(r + g)
                    )
                }
            }
            // the solid thickness edge goes faint while the face is pushed onto it
            drawRoundRect(edge.copy(alpha = edge.alpha * (1f - 0.7f * p)), Offset(0f, d), size, CornerRadius(r))
        }
        .offset { IntOffset(0, (press * depth.toPx() * 0.62f).roundToInt()) }
        .clip(shape)
        .background(face)
        .drawBehind {
            // glossy sheen over the top ~43% (drawn behind the content so text stays crisp)
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = shine), Color.Transparent)),
                Offset(size.width * 0.035f, 2.dp.toPx()), Size(size.width * 0.93f, size.height * 0.43f),
                CornerRadius(40.dp.toPx())
            )
        }
        .border(1.dp, specular, shape)
        .graphicsLayer { alpha = 1f - 0.3f * press.coerceIn(0f, 1f) }   // content (icon + text) dims while pressed
}

/**
 * End-of-row state badge shared by every toggle/option row: a blue glass circle with a white tick that pops in when [on].
 * Off shows nothing (reference look) unless [showOff], which draws an empty ring (used by stand-alone toggles).
 */
@Composable
fun GlassCheck(on: Boolean, modifier: Modifier = Modifier, size: Dp = 26.dp, showOff: Boolean = false, preview: Boolean = false) {
    val s by animateFloatAsState(if (on) 1f else if (preview) 0.8f else 0.6f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "glassCheck")
    val ink = glassTokens().chipInk
    val accent = P.accent
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        if (!on && showOff) Box(Modifier.fillMaxSize().border(1.8.dp, ink.copy(alpha = 0.35f), CircleShape))
        if (on || s > 0.62f) Box(
            Modifier.fillMaxSize()
                .graphicsLayer { scaleX = s; scaleY = s; alpha = ((s - 0.6f) / 0.4f).coerceIn(0f, 1f) * (if (on) 1f else 0.9f) }
                .shadow(4.dp, CircleShape, clip = false, ambientColor = accent.copy(alpha = 0.4f), spotColor = accent.copy(alpha = 0.5f))
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF5BB5FF), Color(0xFF2589ED))))
                .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(size * 0.6f)) }
    }
}

/** Glass icon chip (squircle) with a gradient face, rim and top gloss. Active = luminous blue; cross-fades between the two. */
@Composable
fun Modifier.glassChip(box: Dp, active: Boolean): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(box * 0.38f)
    val dark = P.dark
    val amoled = P.amoled
    val accent = P.accent
    val on by animateFloatAsState(if (active) 1f else 0f, tween(260), label = "chipOn")
    val activeChip = when {
        amoled -> listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63))
        dark -> listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0))
        else -> listOf(Color(0xFF80C8FF), Color(0xFF2585E9))
    }
    val activeRim = when {
        amoled -> Color(0xFF4A8FD0)
        dark -> Color(0xFFCFE6FF)
        else -> Color(0xFFD8EDFF)
    }
    val face = Brush.linearGradient(listOf(lerp(t.chip[0], activeChip[0], on), lerp(t.chip[1], activeChip[1], on)))
    val rim = lerp(t.chipRim, activeRim, on)
    val glossA = (if (dark) 0.18f else 0.55f) * (1f - on) + 0.34f * on
    val tint = lerp(t.shadow, accent, on)
    return this
        .then(if (amoled) Modifier else Modifier.shadow(4.dp, shape, clip = false,
            ambientColor = tint.copy(alpha = 0.25f), spotColor = tint.copy(alpha = 0.30f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = glossA), Color.Transparent)),
                Offset(size.width * 0.08f, size.height * 0.04f), Size(size.width * 0.84f, size.height * 0.46f),
                CornerRadius(box.toPx() * 0.3f)
            )
        }
        .border(1.dp, rim, shape)
}

/** Panel / row title with a glass icon chip. */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Numbered ring used by slot tiles (Sound Lab presets). */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Glass icon chip: gradient squircle with rim and gloss; [color] tints it (blue accent = luminous active chip). */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val active = color == P.accent
    Box(modifier.size(box).glassChip(box, active), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else glassTokens().chipInk, modifier = Modifier.size(box * 0.56f))
    }
}

private fun Color.compositeOverWhite(): Color = this.compositeOver(Color.White)

/**
 * Header app mark. If the app ships its own logo file (res/drawable-nodpi/oneplus_logo.png / .webp, supplied by the
 * owner of that brand) it is shown as-is; otherwise a neutral iOS-style Budsy icon is drawn.
 */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = RoundedCornerShape(9.dp)
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/** 3D liquid-glass backdrop: soft radial gradient per appearance (icy blue / graphite / pure black) with a faint diagonal sheen. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val t = glassTokens()
    val amoled = P.amoled
    Box(
        modifier.fillMaxSize()
            .background(if (amoled) SolidColor(Color.Black) else Brush.verticalGradient(t.bg))
            .then(if (amoled) Modifier else Modifier.background(Brush.linearGradient(
                listOf(Color.White.copy(alpha = if (P.dark) 0.04f else 0.08f), Color.Transparent, Color.White.copy(alpha = if (P.dark) 0.02f else 0.06f))
            )))
    )
}
