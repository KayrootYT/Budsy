package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.remember
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Colour tokens of the 3D liquid-glass look for the active appearance (values taken from the Budsy 3D Liquid Glass reference). */
@Immutable
class GlassTokens(
    val bg: List<Color>, val panel: List<Color>, val panelRim: Color,
    val tile: List<Color>, val tileRim: Color, val edge: Color,
    val activeTile: List<Color>, val activeEdge: Color, val activeRim: Color,
    val chip: List<Color>, val chipRim: Color, val chipInk: Color,
    val shine: Float, val shadow: Color, val sheet: Color
)

private val LightGlass = GlassTokens(
    bg = listOf(Color(0xFFEAF3FF), Color(0xFFBDCDE1), Color(0xFF8299B2)),
    panel = listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.09f)), panelRim = Color.White.copy(alpha = 0.63f),
    tile = listOf(Color.White.copy(alpha = 0.85f), Color(0xFFDCE9F8).copy(alpha = 0.66f)), tileRim = Color.White.copy(alpha = 0.93f), edge = Color(0xFF829AB5),
    activeTile = listOf(Color.White.copy(alpha = 0.93f), Color(0xFFD7EAFF)), activeEdge = Color(0xFF2878B6), activeRim = Color.White,
    chip = listOf(Color.White, Color(0xFFE0EAFA)), chipRim = Color.White, chipInk = Color(0xFF263C54),
    shine = 0.72f, shadow = Color(0xFF263D58), sheet = Color(0xFFEAF2FB)
)
private val DarkGlass = GlassTokens(
    bg = listOf(Color(0xFF414B5A), Color(0xFF252B36), Color(0xFF171B23)),
    panel = listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.024f)), panelRim = Color.White.copy(alpha = 0.145f),
    tile = listOf(Color(0xFF495565), Color(0xFF303946)), tileRim = Color.White.copy(alpha = 0.21f), edge = Color(0xFF161D27),
    activeTile = listOf(Color(0xFF2E8DE5), Color(0xFF155AAB)), activeEdge = Color(0xFF103B69), activeRim = Color.White.copy(alpha = 0.5f),
    chip = listOf(Color(0xFF58677B), Color(0xFF303E50)), chipRim = Color.White.copy(alpha = 0.3f), chipInk = Color(0xFFE8F3FF),
    shine = 0.26f, shadow = Color.Black, sheet = Color(0xFF2A313D)
)
private val AmoledGlass = GlassTokens(
    bg = listOf(Color.Black, Color.Black, Color.Black),
    panel = listOf(Color(0xFF080A0E), Color(0xFF080A0E)), panelRim = Color(0xFF333B49),
    tile = listOf(Color(0xFF191E27), Color(0xFF090C11)), tileRim = Color(0xFF455064), edge = Color(0xFF030407),
    activeTile = listOf(Color(0xFF102C49), Color(0xFF09182B)), activeEdge = Color(0xFF03101E), activeRim = Color(0xFF54B2FF).copy(alpha = 0.5f),
    chip = listOf(Color(0xFF252F3D), Color(0xFF10151D)), chipRim = Color.White.copy(alpha = 0.2f), chipInk = Color(0xFFD5EAFF),
    shine = 0.14f, shadow = Color.Black, sheet = Color(0xFF0B0E13)
)

@Composable
fun glassTokens(): GlassTokens = if (P.amoled) AmoledGlass else if (P.dark) DarkGlass else LightGlass

@Composable
fun glassFill(strong: Boolean = false): Brush = Brush.linearGradient(glassTokens().panel)

@Composable
fun glassRim(): Brush = SolidColor(glassTokens().panelRim)

/** Frosted glass panel (the "shell"): translucent gradient, bright rim, soft shadow. [active] switches the rim to the accent.
 *  Compose has no backdrop blur; the look comes from translucency over [LiquidBackground]. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val t = glassTokens()
    val amoled = P.amoled
    return this
        .then(if (shadow && !amoled) Modifier.shadow(14.dp, shape, clip = false, ambientColor = t.shadow.copy(alpha = 0.22f), spotColor = t.shadow.copy(alpha = 0.26f)) else Modifier)
        .clip(shape)
        .background(Brush.linearGradient(t.panel))
        .border(1.dp, if (active) SolidColor(P.accent) else SolidColor(t.panelRim), shape)
}

/**
 * Raised 3D glass tile: a solid "thickness" edge under the face, frosted gradient face, glossy top sheen and a bright rim.
 * Reserves [depth] of layout space below the tile. [press] (0..1) sinks the face onto its edge.
 */
@Composable
fun Modifier.glassTile3D(radius: Dp, active: Boolean = false, depth: Dp = 6.dp, pressed: Boolean = false): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(radius)
    val press by animateFloatAsState(if (pressed) 1f else 0f, tween(110), label = "glassPress")
    val face = Brush.linearGradient(if (active) t.activeTile else t.tile)
    val edge = if (active) t.activeEdge else t.edge
    val rim = if (active) t.activeRim else t.tileRim
    val shine = if (active) t.shine * 0.5f else t.shine
    val glow = if (active) P.accent else Color.Transparent
    return this
        .padding(bottom = depth)
        .then(if (P.amoled) Modifier else Modifier.shadow(depth, shape, clip = false,
            ambientColor = (if (active) glow else t.shadow).copy(alpha = 0.22f), spotColor = (if (active) glow else t.shadow).copy(alpha = 0.30f)))
        .drawBehind {
            drawRoundRect(edge, Offset(0f, depth.toPx()), size, CornerRadius(radius.toPx()))
        }
        .offset { IntOffset(0, (press * (depth.toPx() * 0.6f)).roundToInt()) }
        .clip(shape)
        .background(face)
        .drawBehind {
            // glossy sheen over the top ~43% (drawn behind the content so text stays crisp)
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = shine), Color.Transparent)),
                Offset(size.width * 0.035f, 2.dp.toPx()), Size(size.width * 0.93f, size.height * 0.43f),
                CornerRadius(40.dp.toPx())
            )
        }
        .border(1.dp, rim, shape)
}

/** Glass icon chip (squircle) with a gradient face, rim and top gloss. Active = luminous blue. */
@Composable
fun Modifier.glassChip(box: Dp, active: Boolean): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(box * 0.38f)
    val dark = P.dark
    val face = if (active) Brush.linearGradient(listOf(Color(0xFF80C8FF), Color(0xFF2585E9))) else Brush.linearGradient(t.chip)
    return this
        .then(if (P.amoled) Modifier else Modifier.shadow(4.dp, shape, clip = false,
            ambientColor = (if (active) P.accent else t.shadow).copy(alpha = 0.25f), spotColor = (if (active) P.accent else t.shadow).copy(alpha = 0.30f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = if (active) 0.34f else if (dark) 0.18f else 0.55f), Color.Transparent)),
                Offset(size.width * 0.08f, size.height * 0.04f), Size(size.width * 0.84f, size.height * 0.46f),
                CornerRadius(box.toPx() * 0.3f)
            )
        }
        .border(1.dp, if (active) Color(0xFFD8EDFF) else t.chipRim, shape)
}

/** Panel / row title with a glowing accent icon and an optional trailing control (switch, button…). */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Circled number used as the icon of the Custom EQ slot tiles. */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Glass icon chip: gradient squircle with rim and gloss; [color] tints it (blue accent = luminous active chip). */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val active = color == P.accent
    Box(modifier.size(box).glassChip(box, active), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else glassTokens().chipInk, modifier = Modifier.size(box * 0.56f))
    }
}

private fun Color.compositeOverWhite(): Color = this.compositeOver(Color.White)

/**
 * Header app mark. If the app ships its own logo file (res/drawable-nodpi/oneplus_logo.png / .webp, supplied by the
 * owner of that brand) it is shown as-is; otherwise a neutral iOS-style Budsy icon is drawn.
 */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = RoundedCornerShape(9.dp)
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/** 3D liquid-glass backdrop: soft radial gradient per appearance (icy blue / graphite / pure black) with a faint diagonal sheen. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val t = glassTokens()
    val amoled = P.amoled
    Box(
        modifier.fillMaxSize()
            .background(if (amoled) SolidColor(Color.Black) else Brush.verticalGradient(t.bg))
            .then(if (amoled) Modifier else Modifier.background(Brush.linearGradient(
                listOf(Color.White.copy(alpha = if (P.dark) 0.04f else 0.08f), Color.Transparent, Color.White.copy(alpha = if (P.dark) 0.02f else 0.06f))
            )))
    )
}
