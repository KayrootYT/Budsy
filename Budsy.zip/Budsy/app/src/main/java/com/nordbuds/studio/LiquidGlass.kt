package com.nordbuds.studio

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.roundToInt

// Budsy glass design language. Implements the "Control Center / 3D Glass" demo exactly:
// flat gradient tiles with a 1dp border, a rounded icon badge, a scale-in check circle, a translucent shell panel
// and a radial stage background, for Light, Dark and AMOLED. No 3D edge, drop shadows or gloss.
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Colour tokens of the demo's StagePalette for the active appearance. */
@Immutable
class GlassTokens(
    val bg: List<Color>,                                   // stageBg (radial)
    val panel: List<Color>, val panelRim: Color,           // shell panel + panelBorder
    val tile: List<Color>, val tileRim: Color,             // tile + tileBorder
    val activeTile: List<Color>, val activeRim: Color,     // activeTile + activeBorder
    val chip: List<Color>, val chipInk: Color,             // iconBg + iconInk
    val activeChip: List<Color>,                           // activeIconBg
    val checkBg: Color, val sheet: Color
)

private val LightGlass = GlassTokens(
    bg = listOf(Color(0xFFEAF3FF), Color(0xFFBDCDE1), Color(0xFF8299B2)),
    panel = listOf(Color(0x42FFFFFF), Color(0x18FFFFFF)), panelRim = Color(0xA0FFFFFF),
    tile = listOf(Color(0xD9FFFFFF), Color(0xA8DCE9F8)), tileRim = Color(0xECFFFFFF),
    activeTile = listOf(Color(0xEDFFFFFF), Color(0xFFD7EAFF)), activeRim = Color.White,
    chip = listOf(Color.White, Color(0xFFE0EAFA)), chipInk = Color(0xFF263C54),
    activeChip = listOf(Color(0xFF80C8FF), Color(0xFF2585E9)),
    checkBg = Color(0xFF2589ED), sheet = Color(0xFFEAF2FB)
)
private val DarkGlass = GlassTokens(
    bg = listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E), Color(0xFF0E0E10)),
    panel = listOf(Color(0x14FFFFFF), Color(0x06FFFFFF)), panelRim = Color(0x1FFFFFFF),
    tile = listOf(Color(0xFF3A3A3C), Color(0xFF2C2C2E)), tileRim = Color(0x26FFFFFF),
    activeTile = listOf(Color(0xFF48484A), Color(0xFF3A3A3C)), activeRim = Color(0xFFA5D4FF),
    chip = listOf(Color(0xFF48484A), Color(0xFF2C2C2E)), chipInk = Color(0xFFF2F2F7),
    activeChip = listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0)),
    checkBg = Color(0xFF3A9AF0), sheet = Color(0xFF2C2C2E)
)
private val AmoledGlass = GlassTokens(
    bg = listOf(Color.Black, Color.Black),
    panel = listOf(Color(0xFF08080A), Color(0xFF08080A)), panelRim = Color(0xFF1C1C22),
    tile = listOf(Color(0xFF141418), Color(0xFF0A0A0D)), tileRim = Color(0xFF24242A),
    activeTile = listOf(Color(0xFF1A1A20), Color(0xFF0F0F14)), activeRim = Color(0xFF2E6FA8),
    chip = listOf(Color(0xFF1E1E24), Color(0xFF0E0E12)), chipInk = Color(0xFFB8D4F0),
    activeChip = listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63)),
    checkBg = Color(0xFF1E88FF), sheet = Color(0xFF08080A)
)

/** Filled-button / selected-pill gradient from the demo's mode picker. */
private val ButtonBlue = listOf(Color(0xFF399FFF), Color(0xFF0874DF))

@Composable
fun glassTokens(): GlassTokens = if (P.amoled) AmoledGlass else if (P.dark) DarkGlass else LightGlass

@Composable
fun glassFill(strong: Boolean = false): Brush = Brush.linearGradient(glassTokens().panel)

@Composable
fun glassRim(): Brush = SolidColor(glassTokens().panelRim)

/** Shell panel: translucent gradient + 1dp border (demo "Shell panel"). [active] switches the border to the accent. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val t = glassTokens()
    return this
        .clip(shape)
        .background(Brush.linearGradient(t.panel))
        .border(1.dp, if (active) SolidColor(P.accent) else SolidColor(t.panelRim), shape)
}

/**
 * Demo GlassTile surface: gradient face (tile / activeTile), 1dp border (tileBorder / activeBorder).
 * Pressed = scale 0.985 and 4dp down over 180ms. [bold] = filled button (blue gradient).
 */
@Composable
fun Modifier.glassTile(radius: Dp, active: Boolean = false, pressed: Boolean = false, bold: Boolean = false): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(radius)
    val scale by animateFloatAsState(if (pressed) 0.985f else 1f, tween(180), label = "tileScale")
    val face = Brush.linearGradient(if (bold) ButtonBlue else if (active) t.activeTile else t.tile)
    val rim = if (bold) Color(0x33FFFFFF) else if (active) t.activeRim else t.tileRim
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale; translationY = if (pressed) 4.dp.toPx() else 0f }
        .clip(shape)
        .background(face)
        .border(1.dp, rim, shape)
}

/** Flat inset tile for nested content (debug lists, log rows). Falls back to the legacy fill under an imported theme. */
@Composable
fun Modifier.insetPanel(radius: Dp = 12.dp, active: Boolean = false): Modifier {
    val shape = RoundedCornerShape(radius)
    if (!isLiquid()) return this.background(P.sheet, shape)
    val t = glassTokens()
    return this.clip(shape)
        .background(Brush.linearGradient(if (active) t.activeTile else t.tile))
        .border(1.dp, if (active) t.activeRim else t.tileRim, shape)
}

/** Demo icon badge: rounded square, iconBg gradient, activeIconBg when active. */
@Composable
fun Modifier.glassChip(box: Dp, active: Boolean): Modifier {
    val t = glassTokens()
    return this
        .clip(RoundedCornerShape(box * 0.38f))
        .background(Brush.linearGradient(if (active) t.activeChip else t.chip))
}

/** Pill with the same face as the icon badge (status pill, value pill). */
@Composable
fun Modifier.glassPill(active: Boolean): Modifier {
    val t = glassTokens()
    return this.clip(RoundedCornerShape(50)).background(Brush.linearGradient(if (active) t.activeChip else t.chip))
}

/**
 * Demo checkmark: solid checkBg circle that scales 0.4 -> 1 (280ms) and fades in (220ms) when [on].
 * [showOff] draws an empty ring when off (used by stand-alone toggles so they stay visible). [preview] is kept for source compatibility.
 */
@Composable
fun GlassCheck(on: Boolean, modifier: Modifier = Modifier, size: Dp = 21.dp, showOff: Boolean = false, preview: Boolean = false) {
    val scale by animateFloatAsState(if (on) 1f else 0.4f, tween(280), label = "checkScale")
    val alpha by animateFloatAsState(if (on) 1f else 0f, tween(220), label = "checkAlpha")
    val t = glassTokens()
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        if (!on && showOff) Box(Modifier.fillMaxSize().border(1.8.dp, t.chipInk.copy(alpha = 0.35f), CircleShape))
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha }
                .background(t.checkBg, CircleShape),
            contentAlignment = Alignment.Center
        ) { Txt("✓", (size.value * 0.52f).roundToInt().coerceAtLeast(8), FontWeight.Normal, Color.White, maxLines = 1) }
    }
}

/** Panel / row title with a glass icon badge. */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Numbered ring used by slot tiles (Sound Lab presets). */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Glass icon badge; [color] == accent means active (blue badge, white icon). */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val active = color == P.accent
    Box(modifier.size(box).glassChip(box, active), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else glassTokens().chipInk, modifier = Modifier.size(box * 0.56f))
    }
}

/** Header app mark. Uses res/drawable-nodpi/oneplus_logo if supplied by the owner, else a neutral Budsy badge. */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = RoundedCornerShape(9.dp)
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/** Demo stage background: radial gradient (Light icy blue / Dark graphite), pure black for AMOLED. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val t = glassTokens()
    val amoled = P.amoled
    Box(
        modifier.fillMaxSize().drawWithCache {
            val brush = Brush.radialGradient(
                t.bg, center = Offset(size.width / 2f, size.height / 2f),
                radius = (hypot(size.width, size.height) / 2f).coerceAtLeast(1f)
            )
            onDrawBehind { if (amoled) drawRect(Color.Black) else drawRect(brush) }
        }
    )
}
