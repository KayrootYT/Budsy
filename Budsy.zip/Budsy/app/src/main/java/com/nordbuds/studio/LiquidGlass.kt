package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.material.icons.rounded.Check
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.remember
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import androidx.lifecycle.repeatOnLifecycle
import kotlin.math.sign

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/**
 * Apple-style continuous-corner "squircle" (superellipse, n = 5) used for every app icon / icon chip.
 * A plain rounded rectangle has a visible seam where the straight edge meets the arc; this curve eases in like iOS icons do.
 */
object IosSquircle : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val a = size.width / 2f; val b = size.height / 2f
        val e = 2.0 / 5.0
        val steps = 160
        val path = Path()
        for (i in 0..steps) {
            val t = 2.0 * PI * i / steps
            val c = cos(t); val sn = sin(t)
            val x = a + a * (sign(c) * abs(c).pow(e)).toFloat()
            val y = b + b * (sign(sn) * abs(sn).pow(e)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Colour tokens of the 3D liquid-glass look for the active appearance (values taken from the Budsy 3D Liquid Glass reference). */
@Immutable
class GlassTokens(
    val bg: List<Color>, val panel: List<Color>, val panelRim: Color,
    val tile: List<Color>, val tileRim: Color, val edge: Color,
    val activeTile: List<Color>, val activeEdge: Color, val activeRim: Color,
    val chip: List<Color>, val chipRim: Color, val chipInk: Color,
    val shine: Float, val shadow: Color, val sheet: Color
)

private val LightGlass = GlassTokens(
    bg = listOf(Color(0xFFEAF3FF), Color(0xFFBDCDE1), Color(0xFF8299B2)),
    panel = listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.09f)), panelRim = Color.White.copy(alpha = 0.63f),
    tile = listOf(Color.White.copy(alpha = 0.85f), Color(0xFFDCE9F8).copy(alpha = 0.66f)), tileRim = Color.White.copy(alpha = 0.93f), edge = Color(0xFFB9C7DA),
    activeTile = listOf(Color.White.copy(alpha = 0.93f), Color(0xFFD7EAFF)), activeEdge = Color(0xFF8FB8E6), activeRim = Color.White,
    chip = listOf(Color.White, Color(0xFFE0EAFA)), chipRim = Color.White, chipInk = Color(0xFF263C54),
    shine = 0.45f, shadow = Color(0xFF30445E), sheet = Color(0xFFEAF2FB)
)
private val DarkGlass = GlassTokens(
    // Neutral charcoal surfaces: the active tile stays grey; only its 3D edge and icon glow blue.
    bg = listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E), Color(0xFF0E0E10)),
    panel = listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.06f)),
    panelRim = Color.White.copy(alpha = 0.12f),
    tile = listOf(Color(0xFF3A3A3C), Color(0xFF2C2C2E)),
    tileRim = Color.White.copy(alpha = 0.15f),
    edge = Color(0xFF0D0D0F),
    activeTile = listOf(Color(0xFF48484A), Color(0xFF3A3A3C)),
    activeEdge = Color(0xFF1B3F6B),
    activeRim = Color(0xFFA5D4FF),
    chip = listOf(Color(0xFF48484A), Color(0xFF2C2C2E)),
    chipRim = Color.White.copy(alpha = 0.21f),
    chipInk = Color(0xFFF2F2F7),
    shine = 0.15f,
    shadow = Color.Black,
    sheet = Color(0xFF2C2C2E)
)
private val AmoledGlass = GlassTokens(
    bg = listOf(Color.Black, Color.Black, Color.Black),
    panel = listOf(Color(0xFF08080A), Color(0xFF08080A)),
    panelRim = Color(0xFF1C1C22),
    tile = listOf(Color(0xFF141418), Color(0xFF0A0A0D)),
    tileRim = Color(0xFF24242A),
    edge = Color.Black,
    activeTile = listOf(Color(0xFF1A1A20), Color(0xFF0F0F14)),
    activeEdge = Color(0xFF0A3A68),
    activeRim = Color(0xFF2E6FA8),
    chip = listOf(Color(0xFF1E1E24), Color(0xFF0E0E12)),
    chipRim = Color.White.copy(alpha = 0.10f),
    chipInk = Color(0xFFB8D4F0),
    shine = 0.08f,
    shadow = Color.Black,
    sheet = Color(0xFF08080A)
)

@Composable
fun glassTokens(): GlassTokens = if (P.amoled) AmoledGlass else if (P.dark) DarkGlass else LightGlass

@Composable
fun glassFill(strong: Boolean = false): Brush = Brush.linearGradient(glassTokens().panel)

@Composable
fun glassRim(): Brush = SolidColor(glassTokens().panelRim)

/** Soft drop shadow drawn only outside the shape (works identically in every appearance; no platform shadow layer). */
fun Modifier.softShadow(radius: Dp, blur: Dp, dy: Dp, color: Color): Modifier = drawWithCache {
    // path + sizes are built once per size change, not on every frame; 5 layers is visually identical to 8 at these blurs
    val r = minOf(radius.toPx(), size.minDimension / 2f); val bl = blur.toPx(); val off = dy.toPx(); val n = 5
    val face = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
    onDrawBehind {
        clipPath(face, ClipOp.Difference) {
            for (i in n downTo 1) {
                val g = bl * i / n
                drawRoundRect(color.copy(alpha = color.alpha * 0.19f), Offset(-g, off - g), Size(size.width + 2f * g, size.height + 2f * g), CornerRadius(r + g))
            }
        }
    }
}

/** Two-part depth: a wide ambient shadow plus a tight, darker contact shadow right under the edge (how real objects sit on a surface). */
fun Modifier.depthShadow(radius: Dp, color: Color): Modifier =
    this.softShadow(radius, 20.dp, 9.dp, color.copy(alpha = 0.11f))
        .softShadow(radius, 4.dp, 1.5.dp, color.copy(alpha = 0.26f))

/**
 * Multi-layer glass reflection, drawn inside the panel: (1) broad top light, (2) diagonal window-light streak,
 * (3) faint bounce light from the bottom edge, (4) thin inner rim that is bright on top and fades down.
 * All static gradients: drawn once per size, no per-frame work.
 */
fun Modifier.glassReflections(radius: Dp, strength: Float): Modifier = drawWithCache {
    val h = size.height; val w = size.width
    val top = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.13f * strength), Color.Transparent), 0f, minOf(h * 0.38f, 130.dp.toPx()))
    val streak = Brush.linearGradient(
        0f to Color.Transparent, 0.32f to Color.Transparent, 0.46f to Color.White.copy(alpha = 0.085f * strength),
        0.56f to Color.Transparent, 1f to Color.Transparent,
        start = Offset(0f, 0f), end = Offset(w, h * 0.85f)
    )
    val bounce = Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.05f * strength)), h * 0.78f, h)
    val inner = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f * strength), Color.White.copy(alpha = 0.03f * strength), Color.White.copy(alpha = 0.10f * strength)))
    val inset = 1.5.dp.toPx(); val cr = (radius.toPx() - inset).coerceAtLeast(0f)
    onDrawBehind {
        drawRect(top); drawRect(streak); drawRect(bounce)
        drawRoundRect(inner, Offset(inset, inset), Size(w - 2 * inset, h - 2 * inset), CornerRadius(cr), style = Stroke(0.8.dp.toPx()))
    }
}

/** Frosted glass panel (the "shell"): translucent gradient, bright rim, soft shadow. [active] switches the rim to the accent.
 *  Compose has no backdrop blur; the look comes from translucency over [LiquidBackground]. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val t = glassTokens()
    val amoled = P.amoled
    return this
        .then(if (shadow && !amoled) Modifier.depthShadow(radius, t.shadow) else Modifier)
        .clip(shape)
        .frostedBackdrop()
        .background(Brush.linearGradient(t.panel))
        .glassReflections(radius, if (P.dark) 1f else 1.5f)
        .border(1.dp, if (active) SolidColor(P.accent) else Brush.linearGradient(listOf(t.panelRim, t.panelRim.copy(alpha = t.panelRim.alpha * 0.45f), t.panelRim.copy(alpha = t.panelRim.alpha * 0.85f))), shape)
}

/**
 * Raised 3D glass tile (iOS-26 style): solid "thickness" edge under the face, frosted gradient face, glossy top sheen and a
 * specular rim. When [active] the face follows the appearance-specific active surface, the edge becomes a blue 3D layer and a soft blue halo
 * spreads under the tile; when off it is just the neutral silver/graphite edge. [pressed] sinks the face onto its edge.
 * [bold] = always-blue face (filled buttons). Reserves [depth] of layout space below the tile.
 */
@Composable
fun Modifier.glassTile3D(radius: Dp, active: Boolean = false, depth: Dp = 8.dp, pressed: Boolean = false, bold: Boolean = false): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(radius)
    // Push motion (matches the reference recording): a quick, stiff press-in; a soft spring with overshoot on release,
    // so the tile pops slightly above its rest height before settling.
    val press by animateFloatAsState(
        if (pressed) 1f else 0f,
        if (pressed) spring<Float>(1f, 1100f) else spring<Float>(0.42f, 360f),
        label = "glassPress"
    )
    // While pressed, an OFF tile previews the ON look at ~45%.
    val on by animateFloatAsState(if (active || bold) 1f else if (pressed) 0.45f else 0f, tween(260), label = "glassOn")
    val accent = P.accent
    val onFace = if (bold) listOf(Color(0xFF4DA3FF), Color(0xFF1C74E0)) else t.activeTile
    val face = Brush.linearGradient(listOf(lerp(t.tile[0], onFace[0], on), lerp(t.tile[1], onFace[1], on)))
    val edge = lerp(t.edge, if (bold) Color(0xFF1558A8) else t.activeEdge, on)
    val rim = lerp(t.tileRim, t.activeRim, on)
    val specular = Brush.linearGradient(listOf(rim, rim.copy(alpha = rim.alpha * 0.40f), rim.copy(alpha = rim.alpha * 0.85f)))
    val shine = t.shine
    val shadowTint = t.shadow
    val amoled = P.amoled
    return this
        .padding(bottom = depth)
        .graphicsLayer { translationY = press * depth.toPx() * 0.62f }   // draw-phase only: no relayout while pressing
        .drawWithCache {
            // Everything below is drawn only OUTSIDE the face (like a CSS box-shadow), so translucent Light/Dark faces never
            // show the edge or glow through them. The face path is cached per size.
            val r = radius.toPx(); val d = depth.toPx()
            val faceRect = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
            val one = 1.dp.toPx()
            onDrawBehind {
                val p = press.coerceIn(0f, 1f)
                val moved = d * 0.62f * press               // how far the face has sunk; the edge stays put, so its visible band shrinks
                clipPath(faceRect, ClipOp.Difference) {
                    val top = d - moved
                    if (!amoled) {
                        // ambient drop shadow that tightens while pressed
                        val reach = d * 1.3f
                        for (i in 5 downTo 1) {
                            val g = reach * i / 5f
                            drawRoundRect(
                                shadowTint.copy(alpha = 0.022f * (1f - p * 0.5f)),
                                Offset(-g * 0.6f, top + 3.dp.toPx() - g * 0.5f), Size(size.width + 1.2f * g, size.height + 1.2f * g), CornerRadius(r + g * 0.6f)
                            )
                        }
                        // tight contact shadow right under the edge: anchors the tile to the surface
                        drawRoundRect(shadowTint.copy(alpha = 0.20f), Offset(-one, top + 1.5.dp.toPx()), Size(size.width + 2 * one, size.height + one), CornerRadius(r + one))
                    }
                    // the solid thickness edge
                    drawRoundRect(edge, Offset(0f, top), size, CornerRadius(r))
                }
            }
        }
        .clip(shape)
        .background(face)
        .drawBehind {
            // glossy sheen over the top ~43% (drawn behind the content so text stays crisp)
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = shine * 0.8f), Color.Transparent), 0f, size.height * 0.55f))
        }
        .border(1.dp, specular, shape)
        .graphicsLayer { alpha = 1f - 0.3f * press.coerceIn(0f, 1f) }   // content (icon + text) dims while pressed
}

/**
 * Flat inset glass tile for nested content (debug lists, log rows, sub-panels): same face / rim as a tile but no 3D edge.
 * Falls back to the legacy flat fill when an imported theme is active.
 */
@Composable
fun Modifier.insetPanel(radius: Dp = 12.dp, active: Boolean = false): Modifier {
    val shape = RoundedCornerShape(radius)
    if (!isLiquid()) return this.background(P.sheet, shape)
    val t = glassTokens()
    val face = if (active) t.activeTile else t.tile
    return this
        .clip(shape)
        .background(Brush.linearGradient(face))
        .border(1.dp, SolidColor(if (active) t.activeRim else t.tileRim), shape)
}

/** Soft top sheen for opaque glass surfaces (sheets, dialogs, snackbar). Apply right after `.background(...)`. No-op outside the stock look. */
@Composable
fun Modifier.glassSheen(): Modifier {
    if (!isLiquid()) return this
    val shine = glassTokens().shine
    return this.drawBehind {
        // full-width fade clipped by the sheet's own shape: no inner rounded rectangle that reads as an overlapping card
        drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = shine * 0.6f), Color.Transparent), 0f, minOf(size.height * 0.30f, 110.dp.toPx())))
    }
}

/** Pill-shaped glass chip (status pill, value pill). Active = luminous blue face, otherwise neutral glass. */
@Composable
fun Modifier.glassPill(active: Boolean): Modifier {
    val t = glassTokens()
    val shape = RoundedCornerShape(50)
    val dark = P.dark
    val amoled = P.amoled
    val accent = P.accent
    val on by animateFloatAsState(if (active) 1f else 0f, tween(260), label = "pillOn")
    val activeFace = when {
        amoled -> listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63))
        dark -> listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0))
        else -> listOf(Color(0xFF80C8FF), Color(0xFF2585E9))
    }
    val activeRim = when { amoled -> Color(0xFF4A8FD0); dark -> Color(0xFFCFE6FF); else -> Color(0xFFD8EDFF) }
    val face = Brush.linearGradient(listOf(lerp(t.chip[0], activeFace[0], on), lerp(t.chip[1], activeFace[1], on)))
    val rim = lerp(t.chipRim, activeRim, on)
    val gloss = (if (dark) 0.18f else 0.55f) * (1f - on) + 0.34f * on
    val tint = lerp(t.shadow, accent, on)
    return this
        .then(if (amoled) Modifier else Modifier.softShadow(100.dp, 8.dp, 2.dp, t.shadow.copy(alpha = 0.10f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = gloss * 0.7f), Color.Transparent), 0f, size.height * 0.6f))
        }
        .border(1.dp, rim, shape)
}

/**
 * End-of-row state badge shared by every toggle/option row: a blue glass circle with a white tick that pops in when [on].
 * Off shows nothing (reference look) unless [showOff], which draws an empty ring (used by stand-alone toggles).
 */
@Composable
fun GlassCheck(on: Boolean, modifier: Modifier = Modifier, size: Dp = 26.dp, showOff: Boolean = false, preview: Boolean = false) {
    val s by animateFloatAsState(if (on) 1f else if (preview) 0.8f else 0.6f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "glassCheck")
    val ink = glassTokens().chipInk
    val accent = P.accent
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        if (!on && showOff) Box(Modifier.fillMaxSize().border(1.8.dp, ink.copy(alpha = 0.35f), CircleShape))
        if (!on && preview) Box(   // press preview (reference video): neutral ring that fills in on release
            Modifier.fillMaxSize().graphicsLayer { scaleX = 0.9f; scaleY = 0.9f }
                .background(ink.copy(alpha = 0.10f), CircleShape).border(1.4.dp, ink.copy(alpha = 0.35f), CircleShape)
        )
        if (on || (s > 0.62f && !preview)) Box(
            Modifier.fillMaxSize()
                .graphicsLayer { scaleX = s; scaleY = s; alpha = ((s - 0.6f) / 0.4f).coerceIn(0f, 1f) * (if (on) 1f else 0.9f) }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF5BB5FF), Color(0xFF2589ED))))
                .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(size * 0.6f)) }
    }
}

/** Glass icon chip (squircle) with a gradient face, rim and top gloss. Active = luminous blue; cross-fades between the two. */
@Composable
fun Modifier.glassChip(box: Dp, active: Boolean): Modifier {
    val t = glassTokens()
    val shape = IosSquircle
    val dark = P.dark
    val amoled = P.amoled
    val accent = P.accent
    val on by animateFloatAsState(if (active) 1f else 0f, tween(260), label = "chipOn")
    val activeChip = when {
        amoled -> listOf(Color(0xFF4A9EE8), Color(0xFF0D3A63))
        dark -> listOf(Color(0xFF6BBCFF), Color(0xFF1E7FE0))
        else -> listOf(Color(0xFF80C8FF), Color(0xFF2585E9))
    }
    val activeRim = when {
        amoled -> Color(0xFF4A8FD0)
        dark -> Color(0xFFCFE6FF)
        else -> Color(0xFFD8EDFF)
    }
    val face = Brush.linearGradient(listOf(lerp(t.chip[0], activeChip[0], on), lerp(t.chip[1], activeChip[1], on)))
    val rim = lerp(t.chipRim, activeRim, on)
    val glossA = (if (dark) 0.18f else 0.55f) * (1f - on) + 0.34f * on
    val tint = lerp(t.shadow, accent, on)
    return this
        .then(if (amoled) Modifier else Modifier.softShadow(box * 0.26f, 8.dp, 2.dp, t.shadow.copy(alpha = 0.10f)))
        .clip(shape)
        .background(face)
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = glossA * 0.75f), Color.Transparent), 0f, size.height * 0.62f))
        }
        .border(1.dp, rim, shape)
}

/** Panel / row title with a glass icon chip. */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Numbered ring used by slot tiles (Sound Lab presets). */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Glass icon chip: gradient squircle with rim and gloss; [color] tints it (blue accent = luminous active chip). */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val active = color == P.accent
    Box(modifier.size(box).glassChip(box, active), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (active) Color.White else glassTokens().chipInk, modifier = Modifier.size(box * 0.56f))
    }
}

private fun Color.compositeOverWhite(): Color = this.compositeOver(Color.White)

/**
 * Header app mark. If the app ships its own logo file (res/drawable-nodpi/oneplus_logo.png / .webp, supplied by the
 * owner of that brand) it is shown as-is; otherwise a neutral iOS-style Budsy icon is drawn.
 */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = IosSquircle
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/**
 * iOS stock wallpaper. Dark = premium neutral graphite falling to near-black with a faint top light (no colour tint).
 * AMOLED = pure black. Light = the airy iOS sky-blue default.
 */
/** Shared state for the animated wallpaper and the frosted-glass backdrop (one bitmap + one phase for the whole app). */
object LiquidFx {
    var phase by androidx.compose.runtime.mutableFloatStateOf(0f)                         // 0..1 loop, drives the light waves
    var blurred by androidx.compose.runtime.mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null)
    var screen by androidx.compose.runtime.mutableStateOf(androidx.compose.ui.unit.IntSize.Zero)
}

@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val amoled = P.amoled
    val dark = P.dark
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dm = ctx.resources.displayMetrics
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val dir = androidx.compose.ui.platform.LocalLayoutDirection.current

    // Backdrop blur, GPU-cheap: the static wallpaper is rendered ONCE into a tiny bitmap (1/10 size). Upscaling it with
    // bilinear filtering is a smooth, true blur, and every glass panel just draws a slice of it: no RenderEffect passes.
    LaunchedEffect(amoled, dark, dm.widthPixels, dm.heightPixels) {
        LiquidFx.screen = androidx.compose.ui.unit.IntSize(dm.widthPixels, dm.heightPixels)
        if (amoled) { LiquidFx.blurred = null; return@LaunchedEffect }
        val sw = (dm.widthPixels / 10).coerceAtLeast(8); val sh = (dm.heightPixels / 10).coerceAtLeast(8)
        val bmp = androidx.compose.ui.graphics.ImageBitmap(sw, sh)
        androidx.compose.ui.graphics.drawscope.CanvasDrawScope().draw(dens, dir, androidx.compose.ui.graphics.Canvas(bmp), Size(sw.toFloat(), sh.toFloat())) {
            drawWallpaper(false, dark)
        }
        LiquidFx.blurred = bmp
    }

    // Slow light-wave clock: stepped at ~20 fps (the motion is slow, so it looks smooth but costs a third of a 60 fps redraw),
    // runs only while the app is on screen, and stays still if the system animation scale is 0 (battery saver / reduce motion).
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    LaunchedEffect(amoled) {
        val scale = android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        if (amoled || scale == 0f) return@LaunchedEffect
        owner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.RESUMED) {
            var last = 0L
            while (true) {
                androidx.compose.runtime.withFrameNanos { now ->
                    if (now - last >= 50_000_000L) { last = now; LiquidFx.phase = ((now / 1_000_000L) % 28_000L) / 28_000f }
                }
            }
        }
    }

    Box(modifier.fillMaxSize().drawBehind {
        drawWallpaper(amoled, dark)
        drawLiquidWaves(size.width, size.height, amoled, dark, LiquidFx.phase, bands = true)
    })
}

/**
 * Animated liquid light: three big soft lights drifting on slow sine paths, plus two translucent wave bands low on the
 * screen that slide sideways. Dark = faint neutral white (no colour), Light = soft sky blue. Nothing in AMOLED.
 */
fun DrawScope.drawLiquidWaves(w: Float, h: Float, amoled: Boolean, dark: Boolean, ph: Float, bands: Boolean) {
    if (amoled) return
    val a = ph * 2f * PI.toFloat()
    val c1 = if (dark) Color.White else Color(0xFF7DB8FF)
    val c2 = if (dark) Color(0xFFD0D0D8) else Color(0xFFB9A8FF)
    val c3 = if (dark) Color(0xFFFFFFFF) else Color(0xFF9ADBFF)
    val k = if (dark) 0.055f else 0.34f
    fun blob(cx: Float, cy: Float, r: Float, al: Float, c: Color) =
        drawCircle(Brush.radialGradient(listOf(c.copy(alpha = al), Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
    blob(w * (0.25f + 0.22f * sin(a)), h * (0.16f + 0.05f * cos(a)), w * 0.85f, k, c1)
    blob(w * (0.82f + 0.14f * cos(a + 1.3f)), h * (0.52f + 0.07f * sin(a + 2f)), w * 0.70f, k * 0.8f, c2)
    blob(w * (0.40f + 0.25f * sin(a + 4f)), h * (0.93f + 0.03f * cos(a)), w * 0.95f, k * 0.75f, c3)
    if (!bands) return
    fun band(base: Float, amp: Float, freq: Float, shift: Float, al: Float, c: Color) {
        val path = Path()
        val steps = 24
        path.moveTo(0f, h)
        for (i in 0..steps) { val x = w * i / steps; path.lineTo(x, base + amp * sin(x / w * freq * 2f * PI.toFloat() + shift)) }
        path.lineTo(w, h); path.close()
        drawPath(path, Brush.verticalGradient(listOf(c.copy(alpha = al), Color.Transparent), base - amp, base + h * 0.22f))
    }
    band(h * 0.72f, h * 0.030f, 1.4f, a * 1f, k * 0.55f, c1)
    band(h * 0.82f, h * 0.040f, 1.0f, -a * 1.3f + 1f, k * 0.40f, c3)
}

/**
 * Frosted glass: draws the matching slice of the pre-blurred wallpaper (plus the live light blobs) behind the panel.
 * Apply after `.clip(shape)`. Nothing is blurred per frame, so it stays cheap even with many panels.
 */
@Composable
fun Modifier.frostedBackdrop(): Modifier {
    val amoled = P.amoled; val dark = P.dark
    if (amoled) return this
    var origin by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { origin = it.positionInWindow() }
        .drawBehind {
            val bmp = LiquidFx.blurred ?: return@drawBehind
            val sc = LiquidFx.screen
            if (sc.width == 0) return@drawBehind
            translate(-origin.x, -origin.y) {
                drawImage(bmp, dstSize = sc, filterQuality = androidx.compose.ui.graphics.FilterQuality.Low)
                drawLiquidWaves(sc.width.toFloat(), sc.height.toFloat(), false, dark, LiquidFx.phase, bands = false)
            }
        }
}

/** Paints the stock wallpaper; shared by the screen background and the frosted-glass backdrop. */
fun DrawScope.drawWallpaper(amoled: Boolean, dark: Boolean) {
    val w = size.width; val h = size.height
    fun glow(c: Color, a: Float, cx: Float, cy: Float, r: Float) =
        drawCircle(Brush.radialGradient(listOf(c.copy(alpha = a), c.copy(alpha = a * 0.35f), Color.Transparent), Offset(cx * w, cy * h), r * w), r * w, Offset(cx * w, cy * h))
    when {
        amoled -> {
            drawRect(Color.Black)
        }
        dark -> {
            // neutral graphite, matches the charcoal cards/tiles: no blue tint, just a soft top light for depth
            drawRect(Brush.verticalGradient(listOf(Color(0xFF1C1C1F), Color(0xFF111113), Color(0xFF09090B))))
            glow(Color(0xFFFFFFFF), 0.07f, 0.50f, -0.05f, 1.10f)
            glow(Color(0xFFB8B8C0), 0.03f, 0.90f, 0.95f, 0.80f)
        }
        else -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFDCEBFF), Color(0xFFEAF2FD), Color(0xFFF6F9FE))))
            glow(Color(0xFF7DB8FF), 0.50f, 0.15f, 0.02f, 0.95f)
            glow(Color(0xFFB9A8FF), 0.30f, 0.98f, 0.30f, 0.80f)
            glow(Color(0xFF9ADBFF), 0.30f, 0.85f, 0.85f, 0.90f)
        }
    }
}
