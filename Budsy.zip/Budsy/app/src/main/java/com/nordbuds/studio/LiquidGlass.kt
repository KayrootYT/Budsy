package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** Translucent glass body: bright at the top, fading toward the bottom. */
@Composable
fun glassFill(strong: Boolean = false): Brush {
    val dark = P.dark
    val amoled = P.amoled
    return when {
        !dark -> Brush.verticalGradient(listOf(Color.White.copy(alpha = if (strong) 0.84f else 0.66f), Color.White.copy(alpha = if (strong) 0.60f else 0.38f)))
        amoled -> Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.11f), Color.White.copy(alpha = 0.04f)))
        else -> Brush.verticalGradient(listOf(Color(0xFFA9C8FF).copy(alpha = 0.17f), Color(0xFF6FA0FF).copy(alpha = 0.06f)))
    }
}

/** Bright glass edge: a white rim that catches light on the corners. */
@Composable
fun glassRim(): Brush =
    if (!P.dark) Brush.linearGradient(listOf(Color.White.copy(alpha = 0.98f), Color(0xFFC9DCFA).copy(alpha = 0.60f), Color.White.copy(alpha = 0.90f)))
    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.36f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.20f)))

/** Frosted glass surface: soft drop shadow, translucent body, top sheen and a bright rim. [active] switches the rim to the accent. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val dark = P.dark
    val accent = P.accent
    val accent2 = P.accent2
    val fill = glassFill(strong)
    val rim: Brush = if (active) Brush.linearGradient(listOf(accent2, accent)) else glassRim()
    val sheen = Brush.verticalGradient(0f to Color.White.copy(alpha = if (dark) 0.10f else 0.55f), 0.38f to Color.Transparent)
    val tint = if (active) Brush.linearGradient(listOf(accent.copy(alpha = 0.16f), accent2.copy(alpha = 0.08f))) else null
    val shadowColor = if (dark) Color.Black else Color(0xFF2A5BB5)
    return this
        .then(
            if (shadow) Modifier.drawBehind {
                val r = radius.toPx()
                for (i in 1..5) {
                    val g = i * 2.2.dp.toPx()
                    drawRoundRect(
                        color = shadowColor.copy(alpha = (if (dark) 0.10f else 0.050f) * (6 - i) / 5f),
                        topLeft = Offset(-g, -g + 7.dp.toPx()),
                        size = Size(size.width + g * 2f, size.height + g * 2f),
                        cornerRadius = CornerRadius(r + g, r + g),
                        style = Stroke(2.4.dp.toPx())
                    )
                }
            } else Modifier
        )
        .clip(shape)
        .background(fill)
        .then(if (tint != null) Modifier.background(tint) else Modifier)
        .background(sheen)
        .border(if (active) 1.5.dp else 1.dp, rim, shape)
}

/** Panel / row title with a glowing accent icon and an optional trailing control (switch, button…). */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = P.accent, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Txt(title, 18, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Circled number used as the icon of the Custom EQ slot tiles. */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** Header mark: rounded square with a "1" and a small plus, as in the Budsy app icon. */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val tint = P.text
    Box(
        modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(glassFill(true)).border(1.dp, glassRim(), RoundedCornerShape(13.dp)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(22.dp).drawBehind {
                val sw = 2.dp.toPx()
                drawRoundRect(tint, topLeft = Offset(sw / 2f, sw * 1.6f), size = Size(size.width - sw * 1.6f, size.height - sw * 2.1f), cornerRadius = CornerRadius(4.dp.toPx()), style = Stroke(sw))
                val cx = size.width - 1.5.dp.toPx(); val cy = 2.dp.toPx(); val a = 3.5.dp.toPx()
                drawLine(tint, Offset(cx - a, cy), Offset(cx + a, cy), sw, StrokeCap.Round)
                drawLine(tint, Offset(cx, cy - a), Offset(cx, cy + a), sw, StrokeCap.Round)
            },
            contentAlignment = Alignment.Center
        ) { Txt("1", 12, FontWeight.Bold, tint, Modifier.padding(top = 2.dp), maxLines = 1) }
    }
}

/**
 * Full-screen liquid backdrop. Everything is drawn from cubic-bezier paths (the same shapes an SVG would hold),
 * so it stays crisp on every screen size. Light = icy white silk, Dark = deep navy with blue ribbons,
 * AMOLED = pure black with violet ribbons. Cached per size and palette; nothing is redrawn per frame.
 */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    val dark = P.dark
    val amoled = P.amoled
    val a1 = P.accent
    val a2 = P.accent2
    Box(modifier.fillMaxSize().drawWithCache {
        val w = size.width
        val h = size.height
        val base = Brush.verticalGradient(
            when {
                amoled -> listOf(Color(0xFF000000), Color(0xFF080317), Color(0xFF000000))
                dark -> listOf(Color(0xFF030A1C), Color(0xFF071F4E), Color(0xFF040D26))
                else -> listOf(Color(0xFFF8FBFF), Color(0xFFDCEAFF), Color(0xFFBBD6FF))
            }
        )
        val glowTop = Brush.radialGradient(
            listOf(if (dark) a1.copy(alpha = 0.50f) else Color.White.copy(alpha = 0.95f), Color.Transparent),
            center = Offset(w * 0.12f, h * 0.04f), radius = w * 1.05f
        )
        val glowMid = Brush.radialGradient(
            listOf(a2.copy(alpha = if (dark) 0.38f else 0.40f), Color.Transparent),
            center = Offset(w * 0.98f, h * 0.52f), radius = w * 0.95f
        )
        val glowLow = Brush.radialGradient(
            listOf(a1.copy(alpha = if (dark) 0.34f else 0.30f), Color.Transparent),
            center = Offset(w * 0.06f, h * 0.99f), radius = w * 0.95f
        )

        // Three silk ribbons: top sweep, centre crossing and bottom swell.
        val ribbonTop = Path().apply {
            moveTo(w * 0.30f, -h * 0.02f)
            cubicTo(w * 0.52f, h * 0.12f, w * 0.78f, h * 0.02f, w * 1.10f, h * 0.20f)
            lineTo(w * 1.10f, h * 0.34f)
            cubicTo(w * 0.80f, h * 0.18f, w * 0.50f, h * 0.30f, w * 0.12f, h * 0.06f)
            close()
        }
        val ribbonMid = Path().apply {
            moveTo(w * 1.10f, h * 0.40f)
            cubicTo(w * 0.78f, h * 0.36f, w * 0.52f, h * 0.52f, -w * 0.10f, h * 0.46f)
            lineTo(-w * 0.10f, h * 0.60f)
            cubicTo(w * 0.40f, h * 0.68f, w * 0.80f, h * 0.50f, w * 1.10f, h * 0.58f)
            close()
        }
        val ribbonLow = Path().apply {
            moveTo(-w * 0.10f, h * 0.80f)
            cubicTo(w * 0.25f, h * 0.70f, w * 0.60f, h * 0.96f, w * 1.10f, h * 0.84f)
            lineTo(w * 1.10f, h * 1.05f)
            lineTo(-w * 0.10f, h * 1.05f)
            close()
        }
        // Thin highlight curves that follow the ribbon edges.
        val edgeTop = Path().apply {
            moveTo(w * 0.12f, h * 0.06f)
            cubicTo(w * 0.50f, h * 0.30f, w * 0.80f, h * 0.18f, w * 1.10f, h * 0.34f)
        }
        val edgeMid = Path().apply {
            moveTo(-w * 0.10f, h * 0.60f)
            cubicTo(w * 0.40f, h * 0.68f, w * 0.80f, h * 0.50f, w * 1.10f, h * 0.58f)
        }
        val edgeLow = Path().apply {
            moveTo(-w * 0.10f, h * 0.80f)
            cubicTo(w * 0.25f, h * 0.70f, w * 0.60f, h * 0.96f, w * 1.10f, h * 0.84f)
        }

        val ribbonBrush = if (dark)
            Brush.linearGradient(listOf(a2.copy(alpha = 0.46f), a1.copy(alpha = 0.10f), Color.Transparent), start = Offset(w, 0f), end = Offset(0f, h * 0.6f))
        else
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.85f), Color(0xFF8DB8FF).copy(alpha = 0.30f)), start = Offset(0f, 0f), end = Offset(w, h * 0.5f))
        val ribbonBrush2 = if (dark)
            Brush.linearGradient(listOf(a1.copy(alpha = 0.40f), a2.copy(alpha = 0.06f)), start = Offset(0f, h * 0.5f), end = Offset(w, h * 0.5f))
        else
            Brush.linearGradient(listOf(Color(0xFF9CC4FF).copy(alpha = 0.40f), Color.White.copy(alpha = 0.78f)), start = Offset(0f, h * 0.5f), end = Offset(w, h * 0.6f))
        val ribbonBrush3 = if (dark)
            Brush.verticalGradient(listOf(a1.copy(alpha = 0.00f), a1.copy(alpha = 0.36f)), startY = h * 0.72f, endY = h)
        else
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.0f), Color(0xFF8DB8FF).copy(alpha = 0.45f)), startY = h * 0.72f, endY = h)

        val edgeColor = if (dark) a2 else Color.White
        val glowStroke = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
        val lineStroke = Stroke(width = 1.3.dp.toPx(), cap = StrokeCap.Round)

        onDrawBehind {
            drawRect(base)
            drawRect(glowTop)
            drawRect(glowMid)
            drawRect(glowLow)
            drawPath(ribbonTop, ribbonBrush)
            drawPath(ribbonMid, ribbonBrush2)
            drawPath(ribbonLow, ribbonBrush3)
            for (p in listOf(edgeTop, edgeMid, edgeLow)) {
                drawPath(p, edgeColor.copy(alpha = if (dark) 0.12f else 0.35f), style = glowStroke)
                drawPath(p, edgeColor.copy(alpha = if (dark) 0.62f else 0.95f), style = lineStroke)
            }
        }
    })
}
