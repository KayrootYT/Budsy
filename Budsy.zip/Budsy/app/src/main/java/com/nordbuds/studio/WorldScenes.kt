package com.nordbuds.studio

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/*
 * Painted, vector-only world scenes. Nothing is loaded from disk and no image assets are used.
 *
 * Every moving thing is a function of one clock `t` in 0..120 seconds. All periods used (4, 5, 6, 8, 10, 12, 15, 20, 24, 30, 40, 60 s)
 * divide 120, so the loop restarts without a visible jump. With "reduce motion" the clock is frozen on a pleasant frame.
 */

private const val TAU = 6.2831853f
private const val LOOP_S = 120f

private fun hash(n: Int): Float { val x = sin(n * 127.1f + 311.7f) * 43758.547f; return x - floor(x) }
private fun fr(x: Float): Float = x - floor(x)
private fun pick(mode: Int, day: Long, night: Long, amoled: Long): Color = Color(when (mode) { SceneMode.DAY -> day; SceneMode.NIGHT -> night; else -> amoled })

/** Animated scene for [world] in [mode] (SceneMode.DAY / NIGHT / AMOLED). Used by the app background and the picker previews. */
@Composable
fun WorldScene(world: Int, mode: Int, modifier: Modifier = Modifier, animate: Boolean = true) {
    val live = animate && !LocalReduceMotion.current
    val clock = rememberInfiniteTransition(label = "worldClock").animateFloat(
        initialValue = 0f, targetValue = LOOP_S,
        animationSpec = infiniteRepeatable(tween((LOOP_S * 1000).toInt(), easing = LinearEasing), RepeatMode.Restart),
        label = "worldT"
    )
    Canvas(modifier) {
        val t = if (live) clock.value else 14f
        when (world) {
            World.FOREST -> forestScene(mode, t)
            World.SNOW -> snowScene(mode, t)
            World.DESERT -> desertScene(mode, t)
            World.OCEAN -> oceanScene(mode, t)
        }
    }
}

/** Full-screen background for the applied world (nothing for Stock Budsy). */
@Composable
fun WorldBackground(modifier: Modifier = Modifier) {
    val world = LocalThemeSpec.current.world
    if (world == World.NONE) return
    val mode = if (P.amoled) SceneMode.AMOLED else if (P.dark) SceneMode.NIGHT else SceneMode.DAY
    WorldScene(world, mode, modifier.fillMaxSize(), animate = true)
}

// ====================================================================================== shared pieces

private fun DrawScope.sky(top: Color, bottom: Color) = drawRect(Brush.verticalGradient(listOf(top, bottom)))

private fun DrawScope.glow(c: Offset, r: Float, color: Color) =
    drawCircle(Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r), radius = r, center = c)

private fun DrawScope.stars(t: Float, count: Int, maxY: Float, tint: Color) {
    val d = density
    for (i in 0 until count) {
        val x = hash(i * 3) * size.width
        val y = hash(i * 3 + 1) * maxY
        val r = (0.6f + hash(i * 3 + 2) * 1.1f) * d
        val tw = 0.5f + 0.5f * sin(TAU * (t / 6f + hash(i + 77)))
        drawCircle(tint.copy(alpha = 0.30f + 0.70f * tw), r, Offset(x, y))
    }
}

private fun DrawScope.moon(c: Offset, r: Float, amoled: Boolean) {
    glow(c, r * 3.4f, Color(0xFFFFF4D6).copy(alpha = if (amoled) 0.10f else 0.20f))
    drawCircle(Color(0xFFFFF1CF), r, c)
    val crater = Color(0xFFE2CE9F).copy(alpha = 0.55f)
    drawCircle(crater, r * 0.22f, Offset(c.x - r * 0.30f, c.y - r * 0.20f))
    drawCircle(crater, r * 0.15f, Offset(c.x + r * 0.28f, c.y + r * 0.18f))
    drawCircle(crater, r * 0.10f, Offset(c.x + r * 0.05f, c.y - r * 0.45f))
}

private fun DrawScope.sun(c: Offset, r: Float, core: Color, halo: Color, t: Float) {
    val pulse = 1f + 0.04f * sin(TAU * t / 8f)
    glow(c, r * 4.4f * pulse, halo.copy(alpha = 0.38f))
    glow(c, r * 2.2f, halo.copy(alpha = 0.55f))
    drawCircle(core, r, c)
}

private fun ridgeY(x: Float, w: Float, baseY: Float, amp: Float, freq: Float, phase: Float, seed: Float): Float {
    val u = x / w * TAU * freq
    return baseY + amp * (0.6f * sin(u + phase) + 0.3f * sin(u * 2.3f + phase * 1.7f + seed) + 0.1f * sin(u * 5.1f + seed * 3f))
}

private fun DrawScope.ridge(baseY: Float, amp: Float, freq: Float, phase: Float, seed: Float, color: Color, rim: Color? = null, rimW: Float = 0f) {
    val w = size.width; val h = size.height
    val steps = 32
    val fill = Path(); fill.moveTo(0f, h)
    val top = Path()
    for (i in 0..steps) {
        val x = w * i / steps
        val y = ridgeY(x, w, baseY, amp, freq, phase, seed)
        fill.lineTo(x, y)
        if (i == 0) top.moveTo(x, y) else top.lineTo(x, y)
    }
    fill.lineTo(w, h); fill.close()
    drawPath(fill, color)
    if (rim != null) drawPath(top, rim, style = Stroke(rimW, cap = StrokeCap.Round))
}

private fun DrawScope.pine(x: Float, baseY: Float, s: Float, leaf: Color, trunk: Color, snow: Color?, sway: Float) {
    drawRect(trunk, Offset(x - s * 0.05f, baseY - s * 0.18f), Size(s * 0.10f, s * 0.18f))
    for (k in 0..2) {
        val yb = baseY - s * 0.14f - s * 0.24f * k
        val hh = s * 0.42f - s * 0.06f * k
        val hw = s * 0.27f - s * 0.06f * k
        val off = sway * (k + 1) / 3f
        val p = Path()
        p.moveTo(x - hw, yb); p.lineTo(x + off, yb - hh); p.lineTo(x + hw, yb); p.close()
        drawPath(p, leaf)
        if (snow != null) {
            val c = Path()
            val yc = yb - hh * 0.50f
            c.moveTo(x + off * 0.5f - hw * 0.50f, yc); c.lineTo(x + off, yb - hh); c.lineTo(x + off * 0.5f + hw * 0.50f, yc)
            c.lineTo(x + off * 0.5f, yc + hh * 0.10f); c.close()
            drawPath(c, snow)
        }
    }
}

private fun DrawScope.roundTree(x: Float, baseY: Float, s: Float, leaf: Color, trunk: Color, sway: Float) {
    drawRect(trunk, Offset(x - s * 0.04f, baseY - s * 0.30f), Size(s * 0.08f, s * 0.30f))
    drawCircle(leaf, s * 0.24f, Offset(x + sway * 0.4f, baseY - s * 0.46f))
    drawCircle(leaf, s * 0.19f, Offset(x - s * 0.17f + sway * 0.3f, baseY - s * 0.36f))
    drawCircle(leaf, s * 0.19f, Offset(x + s * 0.17f + sway * 0.3f, baseY - s * 0.36f))
}

private fun DrawScope.mountains(baseY: Float, peakH: Float, count: Int, seed: Int, body: Color, cap: Color?) {
    val w = size.width; val h = size.height
    val step = w / count
    val body0 = Path(); body0.moveTo(0f, h); body0.lineTo(0f, baseY)
    val caps = ArrayList<Path>()
    for (i in 0 until count) {
        val vl = baseY - peakH * 0.10f * hash(seed + i)
        val vr = baseY - peakH * 0.10f * hash(seed + i + 1)
        val px = i * step + step * (0.28f + 0.44f * hash(seed + i + 20))
        val py = baseY - peakH * (0.55f + 0.45f * hash(seed + i + 50))
        body0.lineTo(i * step, vl); body0.lineTo(px, py)
        if (cap != null) {
            val lx = px + (i * step - px) * 0.36f; val ly = py + (vl - py) * 0.36f
            val rx = px + ((i + 1) * step - px) * 0.36f; val ry = py + (vr - py) * 0.36f
            val c = Path()
            c.moveTo(px, py); c.lineTo(lx, ly); c.lineTo(px - (px - lx) * 0.25f, ly + (py - ly) * -0.35f)
            c.lineTo(px + (rx - px) * 0.30f, ry + (ry - py) * 0.30f); c.lineTo(rx, ry); c.close()
            caps.add(c)
        }
    }
    body0.lineTo(w, baseY); body0.lineTo(w, h); body0.close()
    drawPath(body0, body)
    if (cap != null) caps.forEach { drawPath(it, cap) }
}

/** Particles that fall from the top to the bottom and wrap around (snow, leaves). */
private fun DrawScope.fall(t: Float, count: Int, seed: Int, cycleS: Float, radiusPx: Float, color: Color, sidePx: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until count) {
        val ph = fr(t / cycleS + hash(i + seed))
        val x = fr(hash(i * 2 + seed + 1) + sin(TAU * (ph * 2f + hash(i + seed + 9))) * (sidePx / w)) * w
        val y = ph * (h + 20f) - 10f
        drawCircle(color, radiusPx * (0.7f + 0.6f * hash(i + seed + 31)), Offset(x, y))
    }
}

// ====================================================================================== FOREST

private fun DrawScope.forestScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    sky(pick(mode, 0xFFC9E8D6, 0xFF06140E, 0xFF000000), pick(mode, 0xFFEAF5DC, 0xFF123524, 0xFF030A06))
    if (!night) {
        sun(Offset(w * 0.80f, h * 0.13f), w * 0.07f, Color(0xFFFFF6C8), Color(0xFFFFE9A0), t)
        // light shafts through the canopy
        for (i in 0..2) {
            val x0 = w * (0.45f + 0.16f * i) + sin(TAU * (t / 12f + i * 0.3f)) * 12f * d
            val a = 0.10f + 0.06f * sin(TAU * (t / 10f + i * 0.25f))
            val p = Path(); p.moveTo(x0, 0f); p.lineTo(x0 + 46f * d, 0f); p.lineTo(x0 - w * 0.22f + 90f * d, h * 0.7f); p.lineTo(x0 - w * 0.22f, h * 0.7f); p.close()
            drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFF3B8).copy(alpha = a), Color.Transparent), startY = 0f, endY = h * 0.7f))
        }
    } else {
        stars(t, 55, h * 0.4f, Color(0xFFEFFFF2))
        moon(Offset(w * 0.22f, h * 0.12f), w * 0.055f, mode == SceneMode.AMOLED)
    }
    val far = pick(mode, 0xFF9CCB9A, 0xFF123A28, 0xFF0A1F14)
    val mid = pick(mode, 0xFF5FA66A, 0xFF0C2A1C, 0xFF06140C)
    val near = pick(mode, 0xFF2F7A3E, 0xFF07180F, 0xFF030A06)
    val trunk = pick(mode, 0xFF5B4326, 0xFF0A120C, 0xFF040806)
    ridge(h * 0.58f, h * 0.05f, 1.2f, 0.4f, 1f, far)
    for (i in 0 until 9) {
        val x = w * (i + 0.5f) / 9f + (hash(i + 5) - 0.5f) * w * 0.05f
        val y = ridgeY(x, w, h * 0.58f, h * 0.05f, 1.2f, 0.4f, 1f) + 6f * d
        val sw = sin(TAU * (t / 8f + hash(i))) * 2f * d
        if (hash(i + 40) > 0.4f) pine(x, y, h * 0.12f, far, trunk, null, sw) else roundTree(x, y, h * 0.12f, far, trunk, sw)
    }
    ridge(h * 0.70f, h * 0.045f, 1.6f, 1.7f, 2f, mid)
    for (i in 0 until 8) {
        val x = w * (i + 0.3f) / 8f + (hash(i + 15) - 0.5f) * w * 0.05f
        val y = ridgeY(x, w, h * 0.70f, h * 0.045f, 1.6f, 1.7f, 2f) + 8f * d
        val sw = sin(TAU * (t / 6f + hash(i + 3))) * 3f * d
        if (hash(i + 60) > 0.35f) pine(x, y, h * 0.19f, mid, trunk, null, sw) else roundTree(x, y, h * 0.19f, mid, trunk, sw)
    }
    // drifting mist
    for (i in 0..2) {
        val my = h * (0.52f + 0.13f * i)
        val dx = sin(TAU * (t / (20f + 10f * (i % 2)) + i * 0.3f)) * w * 0.08f
        val mc = if (night) Color(0xFF9FE3B8).copy(alpha = 0.05f) else Color.White.copy(alpha = 0.22f)
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, mc, Color.Transparent), startY = my - h * 0.05f, endY = my + h * 0.05f),
            Offset(dx - w * 0.1f, my - h * 0.05f), Size(w * 1.2f, h * 0.10f))
    }
    ridge(h * 0.86f, h * 0.035f, 1.1f, 3.1f, 4f, near)
    // big trees framing both edges
    for (i in 0 until 4) {
        val x = if (i < 2) w * (0.03f + 0.10f * i) else w * (0.80f + 0.10f * (i - 2))
        val sw = sin(TAU * (t / 5f + hash(i + 90))) * 5f * d
        pine(x, h * 0.99f, h * (0.34f + 0.06f * hash(i + 70)), near, trunk, null, sw)
    }
    if (!night) {
        fall(t, 12, 200, 24f, 2.6f * d, Color(0xFFE2B84A).copy(alpha = 0.85f), 40f * d)
        fall(t, 8, 260, 30f, 2.2f * d, Color(0xFF7BC25A).copy(alpha = 0.85f), 50f * d)
    } else {
        val ff = Color(0xFFC6F04D)
        for (i in 0 until 24) {
            val x = hash(i * 5 + 300) * w + sin(TAU * (t / 15f + hash(i * 5 + 302))) * 26f * d
            val y = h * (0.35f + 0.55f * hash(i * 5 + 301)) + sin(TAU * (t / 10f + hash(i * 5 + 303))) * 18f * d
            val b = max(0f, sin(TAU * (t / 6f + hash(i * 5 + 304))))
            val a = b * b
            glow(Offset(x, y), 10f * d, ff.copy(alpha = 0.50f * a))
            drawCircle(ff.copy(alpha = 0.95f * a), 1.7f * d, Offset(x, y))
        }
    }
}

// ====================================================================================== SNOW

private fun DrawScope.snowScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    sky(pick(mode, 0xFFCFE6F7, 0xFF050F22, 0xFF000000), pick(mode, 0xFFF4FAFF, 0xFF18365E, 0xFF040A14))
    if (!night) {
        sun(Offset(w * 0.20f, h * 0.12f), w * 0.05f, Color(0xFFFFFFFF), Color(0xFFFFF3D0), t)
    } else {
        stars(t, 70, h * 0.45f, Color(0xFFEAF4FF))
        // aurora ribbons
        val cols = listOf(Color(0xFF5DF0A8), Color(0xFFA78BFA), Color(0xFF4AD6F5))
        for (k in 0..2) {
            val base = h * (0.16f + 0.07f * k)
            val band = h * 0.16f
            val p = Path()
            val steps = 24
            for (i in 0..steps) {
                val x = w * i / steps
                val y = base + sin(x / w * TAU * (1.3f + 0.4f * k) + TAU * t / (20f + 4f * k) + k) * h * 0.035f
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            for (i in steps downTo 0) {
                val x = w * i / steps
                val y = base + band + sin(x / w * TAU * (1.1f + 0.3f * k) + TAU * t / (24f + 6f * k) + k * 2f) * h * 0.05f
                p.lineTo(x, y)
            }
            p.close()
            val a = (if (mode == SceneMode.AMOLED) 0.24f else 0.32f) * (0.75f + 0.25f * sin(TAU * (t / 10f + k * 0.3f)))
            drawPath(p, Brush.verticalGradient(listOf(Color.Transparent, cols[k].copy(alpha = a), Color.Transparent), startY = base - h * 0.04f, endY = base + band + h * 0.06f))
        }
        moon(Offset(w * 0.82f, h * 0.10f), w * 0.045f, mode == SceneMode.AMOLED)
    }
    val capCol = pick(mode, 0xFFFFFFFF, 0xFFBFD8F5, 0xFF5C7DA8).let { if (mode == SceneMode.AMOLED) it.copy(alpha = 0.7f) else it }
    mountains(h * 0.60f, h * 0.30f, 3, 11, pick(mode, 0xFFB8D0E8, 0xFF1B3556, 0xFF0A1628), capCol)
    mountains(h * 0.68f, h * 0.22f, 4, 31, pick(mode, 0xFF9DBBDB, 0xFF12294A, 0xFF070F1D), capCol)
    val snow = pick(mode, 0xFFF8FCFF, 0xFF2A4C7A, 0xFF0B1A2E)
    val leaf = pick(mode, 0xFF4F7F6A, 0xFF0F2A3A, 0xFF07131C)
    val cap = pick(mode, 0xFFFFFFFF, 0xFF8FB3E0, 0xFF3A5A86)
    val trunk = pick(mode, 0xFF5B4326, 0xFF0A1018, 0xFF04080C)
    ridge(h * 0.78f, h * 0.035f, 1.3f, 0.8f, 3f, snow, rim = Color.White.copy(alpha = if (night) 0.25f else 0.7f), rimW = 1.5f * d)
    for (i in 0 until 9) {
        val x = w * (i + 0.4f) / 9f + (hash(i + 8) - 0.5f) * w * 0.04f
        val y = ridgeY(x, w, h * 0.78f, h * 0.035f, 1.3f, 0.8f, 3f) + 6f * d
        pine(x, y, h * (0.13f + 0.05f * hash(i + 3)), leaf, trunk, cap, sin(TAU * (t / 8f + hash(i))) * 2f * d)
    }
    ridge(h * 0.90f, h * 0.03f, 0.9f, 2.4f, 5f, snow, rim = Color.White.copy(alpha = if (night) 0.30f else 0.85f), rimW = 1.5f * d)
    val flake = if (night) Color.White else Color.White
    val halo = if (night) Color.Transparent else Color(0xFF9FC4E6).copy(alpha = 0.35f)
    // three depth layers of snowfall
    for (layer in 0..2) {
        val count = intArrayOf(26, 18, 12)[layer]
        val cyc = floatArrayOf(24f, 15f, 10f)[layer]
        val r = floatArrayOf(1.3f, 2.0f, 3.3f)[layer] * d
        if (!night) fall(t, count, 500 + layer * 40, cyc, r * 1.7f, halo, 18f * d)
        fall(t, count, 500 + layer * 40, cyc, r, flake.copy(alpha = if (layer == 2) 0.95f else 0.80f), 18f * d)
    }
}

// ====================================================================================== REGISTAAN (desert)

private fun DrawScope.camel(x: Float, y: Float, s: Float, color: Color, step: Float) {
    drawRoundRect(color, Offset(x - s * 0.9f, y - s * 1.1f), Size(s * 1.8f, s * 0.7f), androidx.compose.ui.geometry.CornerRadius(s * 0.3f))
    drawCircle(color, s * 0.32f, Offset(x - s * 0.1f, y - s * 1.25f))
    val neck = Path(); neck.moveTo(x + s * 0.7f, y - s * 1.05f); neck.lineTo(x + s * 1.15f, y - s * 1.75f)
    drawPath(neck, color, style = Stroke(s * 0.26f, cap = StrokeCap.Round))
    drawCircle(color, s * 0.2f, Offset(x + s * 1.3f, y - s * 1.8f))
    for (k in 0..3) {
        val lx = x - s * 0.7f + k * s * 0.47f
        val sw = sin(step + k * 1.6f) * s * 0.18f
        val leg = Path(); leg.moveTo(lx, y - s * 0.45f); leg.lineTo(lx + sw, y)
        drawPath(leg, color, style = Stroke(s * 0.16f, cap = StrokeCap.Round))
    }
}

private fun DrawScope.cactus(x: Float, baseY: Float, s: Float, color: Color) {
    val sw = s * 0.16f
    drawRoundRect(color, Offset(x - sw / 2f, baseY - s), Size(sw, s), androidx.compose.ui.geometry.CornerRadius(sw / 2f))
    val l = Path(); l.moveTo(x, baseY - s * 0.38f); l.lineTo(x - s * 0.28f, baseY - s * 0.38f); l.lineTo(x - s * 0.28f, baseY - s * 0.68f)
    val r = Path(); r.moveTo(x, baseY - s * 0.55f); r.lineTo(x + s * 0.26f, baseY - s * 0.55f); r.lineTo(x + s * 0.26f, baseY - s * 0.82f)
    drawPath(l, color, style = Stroke(sw * 0.9f, cap = StrokeCap.Round))
    drawPath(r, color, style = Stroke(sw * 0.9f, cap = StrokeCap.Round))
}

private fun DrawScope.desertScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    sky(pick(mode, 0xFFFFD79A, 0xFF0D0820, 0xFF000000), pick(mode, 0xFFFFF0CF, 0xFF3B2150, 0xFF0A0510))
    if (!night) {
        sun(Offset(w * 0.5f, h * 0.20f), w * 0.11f, Color(0xFFFFF2C0), Color(0xFFFFB84A), t)
    } else {
        stars(t, 90, h * 0.5f, Color(0xFFFFEFD6))
        moon(Offset(w * 0.72f, h * 0.16f), w * 0.13f, mode == SceneMode.AMOLED)
    }
    val rimCol = pick(mode, 0xFFFFE2A8, 0xFF8A6AB0, 0xFF6B4A8A).copy(alpha = if (mode == SceneMode.AMOLED) 0.35f else 0.55f)
    ridge(h * 0.56f, h * 0.045f, 1.0f, 0.5f, 1f, pick(mode, 0xFFEBC27A, 0xFF3A2A55, 0xFF140C1C), rimCol, 1.4f * d)
    ridge(h * 0.66f, h * 0.05f, 1.3f, 2.2f, 2f, pick(mode, 0xFFDDA85B, 0xFF2D2147, 0xFF0E0814), rimCol, 1.4f * d)
    // camel caravan on the middle dune
    val cam = pick(mode, 0xFF5A3A1E, 0xFF0D0818, 0xFF1A1024)
    for (i in 0..2) {
        val ph = fr(t / 60f + i * 0.07f)
        val x = -w * 0.1f + ph * (w * 1.3f)
        val y = ridgeY(x, w, h * 0.66f, h * 0.05f, 1.3f, 2.2f, 2f) + 3f * d
        camel(x, y, w * 0.016f, cam, TAU * (t / 4f))
    }
    ridge(h * 0.77f, h * 0.045f, 0.9f, 4.0f, 3f, pick(mode, 0xFFC98B43, 0xFF221838, 0xFF080410), rimCol, 1.4f * d)
    cactus(w * 0.14f, ridgeY(w * 0.14f, w, h * 0.77f, h * 0.045f, 0.9f, 4.0f, 3f) + 4f * d, h * 0.07f, pick(mode, 0xFF4F8A3A, 0xFF14241C, 0xFF0A140E))
    ridge(h * 0.89f, h * 0.04f, 1.1f, 5.3f, 4f, pick(mode, 0xFFAE6F31, 0xFF160F28, 0xFF040208), rimCol, 1.4f * d)
    if (!night) {
        // heat shimmer above the far dunes
        for (i in 0..4) {
            val y0 = h * (0.50f + 0.025f * i)
            val p = Path()
            for (k in 0..20) {
                val x = w * k / 20f
                val y = y0 + sin(k * 0.9f + TAU * t / 5f + i) * 2.2f * d
                if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, Color.White.copy(alpha = 0.14f), style = Stroke(1.3f * d))
        }
    }
    // wind-blown sand
    val sand = pick(mode, 0xFFE9C98A, 0xFFB89CD0, 0xFF8E76A8).copy(alpha = if (night) 0.35f else 0.60f)
    for (i in 0 until 34) {
        val ph = fr(t / (10f + 2f * (i % 3)) + hash(i + 400))
        val x = ph * (w + 40f) - 20f
        val y = h * (0.52f + 0.42f * hash(i + 401)) + sin(TAU * (ph * 3f + hash(i))) * 6f * d
        drawCircle(sand, (0.8f + hash(i + 402)) * d, Offset(x, y))
    }
}

// ====================================================================================== SAMUNDAR (ocean)

private fun DrawScope.fish(x: Float, y: Float, s: Float, dir: Float, body: Color, fin: Color, wag: Float) {
    val tx = x - dir * s * 0.9f
    val tail = Path(); tail.moveTo(tx, y); tail.lineTo(tx - dir * s * 0.7f, y - s * 0.45f + wag); tail.lineTo(tx - dir * s * 0.7f, y + s * 0.45f + wag); tail.close()
    drawPath(tail, fin)
    drawOval(body, Offset(x - s, y - s * 0.45f), Size(s * 2f, s * 0.9f))
    drawCircle(Color.White, s * 0.13f, Offset(x + dir * s * 0.55f, y - s * 0.1f))
    drawCircle(Color(0xFF102030), s * 0.06f, Offset(x + dir * s * 0.57f, y - s * 0.1f))
}

private fun DrawScope.jelly(x: Float, y: Float, s: Float, color: Color, t: Float, seed: Float) {
    val pulse = 1f + 0.08f * sin(TAU * (t / 5f + seed))
    glow(Offset(x, y), s * 2.4f, color.copy(alpha = 0.25f))
    drawArc(color.copy(alpha = 0.55f), 180f, 180f, true, Offset(x - s * pulse, y - s * 0.8f * pulse), Size(2f * s * pulse, 1.6f * s * pulse))
    for (k in 0..4) {
        val tx = x - s * 0.7f + k * s * 0.35f
        val p = Path(); p.moveTo(tx, y)
        for (j in 1..4) p.lineTo(tx + sin(TAU * (t / 6f + seed + j * 0.15f + k * 0.1f)) * s * 0.14f, y + j * s * 0.35f)
        drawPath(p, color.copy(alpha = 0.50f), style = Stroke(1.4f * density, cap = StrokeCap.Round))
    }
}

private fun DrawScope.oceanScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    sky(pick(mode, 0xFFA6EEF7, 0xFF0A4A78, 0xFF000000), pick(mode, 0xFF3AA9D6, 0xFF021426, 0xFF010A12))
    // light shafts from the surface
    for (i in 0..4) {
        val x0 = w * (0.02f + 0.22f * i) + sin(TAU * (t / 12f + i * 0.2f)) * 20f * d
        val a = (if (mode == SceneMode.DAY) 0.24f else if (mode == SceneMode.NIGHT) 0.07f else 0.03f) * (0.65f + 0.35f * sin(TAU * (t / 10f + i * 0.17f)))
        val p = Path(); p.moveTo(x0, 0f); p.lineTo(x0 + 46f * d, 0f); p.lineTo(x0 + w * 0.16f + 130f * d, h * 0.8f); p.lineTo(x0 + w * 0.16f, h * 0.8f); p.close()
        drawPath(p, Brush.verticalGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), startY = 0f, endY = h * 0.8f))
    }
    if (night) glow(Offset(w * 0.7f, -h * 0.02f), w * 0.7f, Color(0xFF8FD8FF).copy(alpha = if (mode == SceneMode.AMOLED) 0.08f else 0.18f))
    // surface shimmer
    val surf = Path()
    for (k in 0..24) {
        val x = w * k / 24f
        val y = 9f * d + sin(k * 0.7f + TAU * t / 8f) * 3.5f * d
        if (k == 0) surf.moveTo(x, y) else surf.lineTo(x, y)
    }
    drawPath(surf, Color.White.copy(alpha = if (night) 0.18f else 0.55f), style = Stroke(1.6f * d))

    // sea floor
    ridge(h * 0.92f, h * 0.02f, 1.4f, 0.6f, 2f, pick(mode, 0xFFE8D6A0, 0xFF0B2E4A, 0xFF03111C))
    val weed = pick(mode, 0xFF2FB36B, 0xFF0E8A6A, 0xFF0A5A48)
    for (i in 0 until 8) {
        val bx = w * (0.04f + 0.12f * i) + hash(i + 11) * w * 0.04f
        val hh = h * (0.10f + 0.09f * hash(i + 12))
        val p = Path(); p.moveTo(bx, h)
        for (j in 1..5) p.lineTo(bx + sin(TAU * (t / 8f + hash(i) + j * 0.12f)) * j * 4.5f * d, h - hh * j / 5f)
        drawPath(p, weed, style = Stroke(4.2f * d, cap = StrokeCap.Round))
    }
    val coralA = pick(mode, 0xFFFF7A8A, 0xFFB5465A, 0xFF7A2E3E)
    val coralB = pick(mode, 0xFFFFA84D, 0xFFB5702A, 0xFF7A4A1C)
    for (i in 0 until 4) {
        val cx = w * (0.14f + 0.24f * i)
        val c = if (i % 2 == 0) coralA else coralB
        drawCircle(c, 9f * d, Offset(cx, h * 0.955f)); drawCircle(c, 7f * d, Offset(cx - 11f * d, h * 0.965f)); drawCircle(c, 7f * d, Offset(cx + 11f * d, h * 0.965f))
    }

    // fish
    val bodies = listOf(0xFFFF8A3DL, 0xFFFFD23DL, 0xFF3D8BFFL, 0xFFFF5C8AL, 0xFF3DDDB5L, 0xFFFFA35CL, 0xFF7B8CFFL)
    for (i in 0 until 7) {
        val dir = if (i % 2 == 0) 1f else -1f
        val s = (9f + 6f * hash(i + 600)) * d
        val cyc = floatArrayOf(40f, 60f, 30f, 40f, 60f, 30f, 40f)[i]
        val ph = fr(t / cyc + hash(i + 601))
        val x = if (dir > 0f) -2f * s + ph * (w + 4f * s) else w + 2f * s - ph * (w + 4f * s)
        val y = h * (0.22f + 0.5f * hash(i + 602)) + sin(TAU * (t / 10f + hash(i + 603))) * 8f * d
        var body = Color(bodies[i])
        if (mode == SceneMode.NIGHT) body = lerp(body, Color(0xFF052038), 0.45f)
        if (mode == SceneMode.AMOLED) body = lerp(body, Color.Black, 0.55f)
        fish(x, y, s, dir, body, body.copy(alpha = 0.85f), sin(TAU * (t / 4f) * 2f + i) * s * 0.18f)
    }

    // bubbles
    for (i in 0 until 22) {
        val ph = fr(t / (12f + 4f * (i % 3)) + hash(i + 700))
        val y = h * (1f - ph)
        val x = hash(i + 701) * w + sin(TAU * (ph * 3f + hash(i))) * 10f * d
        val r = (2f + 4f * hash(i + 702)) * d
        drawCircle(Color.White.copy(alpha = if (night) 0.30f else 0.55f), r, Offset(x, y), style = Stroke(1.1f * d))
        drawCircle(Color.White.copy(alpha = if (night) 0.45f else 0.75f), r * 0.22f, Offset(x - r * 0.35f, y - r * 0.35f))
    }

    if (night) {
        val g = if (mode == SceneMode.AMOLED) Color(0xFF18E0D0) else Color(0xFF2EE6D6)
        for (i in 0 until 46) {
            val x = hash(i + 800) * w + sin(TAU * (t / 20f + hash(i + 801))) * 20f * d
            val y = fr(hash(i + 802) - t / 60f) * h
            val a = 0.25f + 0.75f * (0.5f + 0.5f * sin(TAU * (t / 6f + hash(i + 803))))
            glow(Offset(x, y), 7f * d, g.copy(alpha = 0.25f * a))
            drawCircle(g.copy(alpha = 0.85f * a), 1.3f * d, Offset(x, y))
        }
        for (i in 0..2) {
            val x = w * (0.2f + 0.3f * i) + sin(TAU * (t / 20f + i * 0.3f)) * 14f * d
            val y = h * (0.30f + 0.12f * i) + sin(TAU * (t / 12f + i * 0.2f)) * 16f * d
            jelly(x, y, (16f + 6f * i) * d, if (i == 1) Color(0xFFB98CFF) else Color(0xFF3AE6F0), t, i * 0.21f)
        }
    } else {
        jelly(w * 0.78f, h * 0.38f + sin(TAU * t / 12f) * 14f * d, 15f * d, Color(0xFFFFFFFF).copy(alpha = 0.75f), t, 0.1f)
    }
}
