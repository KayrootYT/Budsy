package com.nordbuds.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/*
 * Painted, vector-only world scenes. Nothing is loaded from disk and no image assets are used.
 *
 * Every moving thing is a function of one clock `t` in 0..120 seconds. All periods used (4, 5, 6, 8, 10, 12, 15, 20, 24, 30, 40, 60 s)
 * divide 120, so the loop restarts without a visible jump.
 *
 * The clock is stepped at ~30 fps instead of the display refresh rate, only runs while the app is RESUMED, and freezes
 * on a pleasant frame when the system animation scale is 0, when "Living backgrounds" is off, or for static previews.
 * That keeps four full-screen vector worlds from heating the phone or eating the battery.
 */

private const val TAU = 6.2831853f
private const val LOOP_S = 120f
private const val STATIC_T = 18f

/** App-wide switch for the animated worlds (Settings > Appearance > Living backgrounds). */
object AmbientFx {
    var enabled by mutableStateOf(true)
}

private fun hash(n: Int): Float { val x = sin(n * 127.1f + 311.7f) * 43758.547f; return x - floor(x) }
private fun fr(x: Float): Float = x - floor(x)
private fun pick(mode: Int, day: Long, night: Long, amoled: Long): Color = Color(when (mode) { SceneMode.DAY -> day; SceneMode.NIGHT -> night; else -> amoled })

/**
 * Shared ~30 fps clock. Returns a time in seconds inside the 120 s loop, or [STATIC_T] when the scene must not animate.
 * The frame loop is lifecycle aware: it stops when the app is not in the foreground.
 */
@Composable
private fun rememberWorldTime(animate: Boolean): Float {
    val reduce = LocalReduceMotion.current || !AmbientFx.enabled
    if (!animate || reduce) return STATIC_T
    var t by remember { mutableFloatStateOf(STATIC_T) }
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            var last = 0L
            while (true) {
                withFrameNanos { now ->
                    if (last == 0L) last = now
                    val gap = now - last
                    if (gap >= 33_000_000L) {
                        t = (t + gap / 1_000_000_000f) % LOOP_S
                        last = now
                    }
                }
            }
        }
    }
    return t
}

/** Animated scene for [world] in [mode] (SceneMode.DAY / NIGHT / AMOLED). Used by the app background and the picker previews. */
@Composable
fun WorldScene(world: Int, mode: Int, modifier: Modifier = Modifier, animate: Boolean = true) {
    val t = rememberWorldTime(animate)
    Canvas(modifier) {
        when (world) {
            World.FOREST -> forestScene(mode, t)
            World.SNOW -> snowScene(mode, t)
            World.DESERT -> desertScene(mode, t)
            World.OCEAN -> oceanScene(mode, t)
        }
    }
}

/** Full-screen background for the applied world (nothing for Stock Budsy). */
@Composable
fun WorldBackground(modifier: Modifier = Modifier, animate: Boolean = true) {
    val world = LocalThemeSpec.current.world
    if (world == World.NONE) return
    val mode = if (P.amoled) SceneMode.AMOLED else if (P.dark) SceneMode.NIGHT else SceneMode.DAY
    WorldScene(world, mode, modifier.fillMaxSize(), animate = animate)
}

// ====================================================================================== shared painting helpers

private fun DrawScope.sky3(top: Color, mid: Color, bottom: Color) =
    drawRect(Brush.verticalGradient(0f to top, 0.52f to mid, 1f to bottom))

private fun DrawScope.glow(c: Offset, r: Float, color: Color) =
    drawCircle(Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r), radius = r, center = c)

/** Sun / moon halo built from three soft layers instead of one hard-edged gradient. */
private fun DrawScope.bloom(c: Offset, r: Float, color: Color, alpha: Float) {
    glow(c, r, color.copy(alpha = alpha * 0.55f))
    glow(c, r * 0.62f, color.copy(alpha = alpha * 0.45f))
    glow(c, r * 0.34f, color.copy(alpha = alpha * 0.35f))
}

/** Cinematic edge darkening: keeps the centre of the screen (the cards) readable on every world. */
private fun DrawScope.vignette(strength: Float = 0.22f, tint: Color = Color.Black) {
    drawRect(
        Brush.radialGradient(
            0f to Color.Transparent,
            0.58f to Color.Transparent,
            1f to tint.copy(alpha = strength),
            center = Offset(size.width * 0.5f, size.height * 0.46f),
            radius = max(size.width, size.height) * 0.74f
        )
    )
}

/** Soft horizontal mist / haze band that hides the seam between depth layers. */
private fun DrawScope.hazeBand(y: Float, halfH: Float, color: Color, alpha: Float) {
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, color.copy(alpha = alpha), Color.Transparent), y - halfH, y + halfH)
    )
}

private fun DrawScope.stars(t: Float, count: Int, maxY: Float, tint: Color) {
    val d = density
    for (i in 0 until count) {
        val x = hash(i * 3) * size.width
        val y = hash(i * 3 + 1) * maxY
        val r = (0.6f + hash(i * 3 + 2) * 1.1f) * d
        val tw = 0.5f + 0.5f * sin(TAU * (t / 6f + hash(i + 77)))
        drawCircle(tint.copy(alpha = 0.30f + 0.70f * tw), r, Offset(x, y))
        if (hash(i + 91) > 0.93f) {
            // a few brighter stars get a tiny cross flare
            drawLine(tint.copy(alpha = 0.25f + 0.45f * tw), Offset(x - r * 3f, y), Offset(x + r * 3f, y), 0.7f * d)
            drawLine(tint.copy(alpha = 0.25f + 0.45f * tw), Offset(x, y - r * 3f), Offset(x, y + r * 3f), 0.7f * d)
        }
    }
}

private fun DrawScope.moon(c: Offset, r: Float, amoled: Boolean) {
    bloom(c, r * 4.6f, Color(0xFFFFF4D6), if (amoled) 0.30f else 0.55f)
    drawCircle(Color(0xFFFFF1CF), r, c)
    drawCircle(Color(0xFFFFF9E8).copy(alpha = 0.75f), r * 0.82f, Offset(c.x - r * 0.10f, c.y - r * 0.12f))
    val crater = Color(0xFFE2CE9F).copy(alpha = 0.50f)
    drawCircle(crater, r * 0.22f, Offset(c.x - r * 0.30f, c.y - r * 0.20f))
    drawCircle(crater, r * 0.15f, Offset(c.x + r * 0.28f, c.y + r * 0.18f))
    drawCircle(crater, r * 0.10f, Offset(c.x + r * 0.05f, c.y - r * 0.45f))
}

private fun DrawScope.sun(c: Offset, r: Float, core: Color, halo: Color, t: Float) {
    val pulse = 1f + 0.04f * sin(TAU * t / 8f)
    bloom(c, r * 5.2f * pulse, halo, 0.55f)
    bloom(c, r * 2.4f, halo, 0.45f)
    drawCircle(Brush.radialGradient(listOf(Color.White, core), center = c, radius = r * 1.1f), r, c)
}

/** Slow soft clouds. [y] is a fraction of the screen height. */
private fun DrawScope.cloudBank(t: Float, y: Float, count: Int, color: Color, seed: Int) {
    val w = size.width; val h = size.height
    for (i in 0 until count) {
        val speed = 60f / (0.6f + hash(i + seed + 2))
        val x = fr(hash(i + seed) + t / speed) * (w + w * 0.5f) - w * 0.25f
        val cy = h * y * (0.75f + 0.55f * hash(i + seed + 1))
        val cw = w * (0.24f + 0.20f * hash(i + seed + 3))
        val a = 0.55f + 0.45f * hash(i + seed + 4)
        drawOval(
            Brush.radialGradient(listOf(color.copy(alpha = color.alpha * a), Color.Transparent), Offset(x, cy), cw * 0.62f),
            Offset(x - cw * 0.5f, cy - cw * 0.13f), Size(cw, cw * 0.26f)
        )
        drawOval(
            Brush.radialGradient(listOf(color.copy(alpha = color.alpha * a * 0.75f), Color.Transparent), Offset(x + cw * 0.22f, cy - cw * 0.05f), cw * 0.42f),
            Offset(x - cw * 0.10f, cy - cw * 0.16f), Size(cw * 0.78f, cw * 0.22f)
        )
    }
}

/** Small V-shaped birds drifting across the sky. */
private fun DrawScope.birds(t: Float, y: Float, color: Color, count: Int, seed: Int) {
    val w = size.width; val d = density
    for (i in 0 until count) {
        val speed = 60f / (0.35f + 0.25f * hash(i + seed + 2))
        val x = fr(hash(i + seed) + t / speed) * (w + w * 0.2f) - w * 0.1f
        val yy = y + sin(TAU * (t / 10f + hash(i + seed + 1))) * 12f * d + (i % 3) * 9f * d
        val s = (5f + 2.5f * hash(i + seed + 3)) * d
        val flap = sin(TAU * (t / 4f + hash(i + seed + 4))) * 0.35f
        val p = Path()
        p.moveTo(x - s, yy)
        p.quadraticTo(x - s * 0.42f, yy - s * (0.45f + flap), x, yy + s * 0.10f)
        p.quadraticTo(x + s * 0.42f, yy - s * (0.45f + flap), x + s, yy)
        drawPath(p, color, style = Stroke(1.3f * d, cap = StrokeCap.Round))
    }
}

private fun DrawScope.ridgeY(x: Float, w: Float, baseY: Float, amp: Float, freq: Float, phase: Float, seed: Float): Float {
    val u = x / w * TAU * freq
    return baseY + amp * (0.6f * sin(u + phase) + 0.3f * sin(u * 2.3f + phase * 1.7f + seed) + 0.1f * sin(u * 5.1f + seed * 3f))
}

/**
 * A soft rolling ridge. The fill is a vertical gradient (lit crest -> darker base) instead of a flat colour, and the
 * crest gets a rim light, which is what makes the dunes and hills read as solid 3D forms.
 */
private fun DrawScope.ridge(baseY: Float, amp: Float, freq: Float, phase: Float, seed: Float, color: Color, rim: Color? = null, rimW: Float = 0f) {
    val w = size.width; val h = size.height
    val steps = 40
    val fill = Path(); fill.moveTo(0f, h)
    val top = Path()
    for (i in 0..steps) {
        val x = w * i / steps
        val y = ridgeY(x, w, baseY, amp, freq, phase, seed)
        fill.lineTo(x, y)
        if (i == 0) top.moveTo(x, y) else top.lineTo(x, y)
    }
    fill.lineTo(w, h); fill.close()
    drawPath(
        fill,
        Brush.verticalGradient(
            0f to lerp(color, Color.White, 0.12f),
            0.45f to color,
            1f to lerp(color, Color.Black, 0.32f),
            startY = baseY - amp, endY = h
        )
    )
    if (rim != null) {
        drawPath(top, Color.Black.copy(alpha = 0.10f), style = Stroke(rimW * 3.2f, cap = StrokeCap.Round))
        drawPath(top, rim, style = Stroke(rimW, cap = StrokeCap.Round))
    }
}

/** Conifer with a shaded right face, a lit left face and an optional snow cap — reads as a real tree, not a triangle. */
private fun DrawScope.pine(x: Float, baseY: Float, s: Float, leaf: Color, trunk: Color, snow: Color?, sway: Float) {
    val d = density
    drawRect(
        Brush.horizontalGradient(listOf(lerp(trunk, Color.Black, 0.25f), trunk, lerp(trunk, Color.White, 0.12f))),
        Offset(x - s * 0.05f, baseY - s * 0.20f), Size(s * 0.10f, s * 0.20f)
    )
    for (k in 0..2) {
        val yb = baseY - s * 0.14f - s * 0.24f * k
        val hh = s * 0.44f - s * 0.07f * k
        val hw = s * 0.28f - s * 0.06f * k
        val off = sway * (k + 1) / 3f
        val l = Path(); l.moveTo(x - hw, yb); l.lineTo(x + off, yb - hh); l.lineTo(x + off * 0.5f, yb); l.close()
        drawPath(l, lerp(leaf, Color.White, 0.10f))
        val r = Path(); r.moveTo(x + off, yb - hh); r.lineTo(x + hw, yb); r.lineTo(x + off * 0.5f + hw * 0.08f, yb); r.close()
        drawPath(r, lerp(leaf, Color.Black, 0.24f))
        if (snow != null && k == 2) {
            val yc = yb - hh * 0.55f
            val c = Path()
            c.moveTo(x + off, yb - hh)
            c.lineTo(x + off - hw * 0.44f, yc)
            c.lineTo(x + off - hw * 0.16f, yc + hh * 0.06f)
            c.lineTo(x + off + hw * 0.05f, yc - hh * 0.05f)
            c.lineTo(x + off + hw * 0.44f, yc)
            c.close()
            drawPath(c, snow)
        }
    }
    // faint trunk shadow on the ground
    drawOval(Color.Black.copy(alpha = 0.10f), Offset(x - s * 0.16f, baseY - s * 0.02f), Size(s * 0.32f, s * 0.08f))
}

/** Broadleaf tree: dark base, main canopy, sunlit crown. */
private fun DrawScope.roundTree(x: Float, baseY: Float, s: Float, leaf: Color, trunk: Color, sway: Float) {
    drawRect(
        Brush.horizontalGradient(listOf(lerp(trunk, Color.Black, 0.25f), trunk, lerp(trunk, Color.White, 0.10f))),
        Offset(x - s * 0.04f, baseY - s * 0.32f), Size(s * 0.08f, s * 0.32f)
    )
    val cy = baseY - s * 0.48f
    drawCircle(lerp(leaf, Color.Black, 0.28f), s * 0.25f, Offset(x + sway * 0.4f, cy + s * 0.04f))
    drawCircle(lerp(leaf, Color.Black, 0.12f), s * 0.22f, Offset(x - s * 0.16f + sway * 0.3f, cy + s * 0.10f))
    drawCircle(leaf, s * 0.23f, Offset(x + s * 0.14f + sway * 0.3f, cy + s * 0.02f))
    drawCircle(lerp(leaf, Color.White, 0.18f), s * 0.15f, Offset(x + sway * 0.35f - s * 0.04f, cy - s * 0.07f))
    drawOval(Color.Black.copy(alpha = 0.10f), Offset(x - s * 0.18f, baseY - s * 0.02f), Size(s * 0.36f, s * 0.09f))
}

/** Little clump of grass blades for the foreground. */
private fun DrawScope.grassTuft(x: Float, baseY: Float, hh: Float, color: Color, sway: Float) {
    val d = density
    for (k in 0..2) {
        val p = Path()
        p.moveTo(x + (k - 1) * hh * 0.20f, baseY)
        p.quadraticTo(x + (k - 1) * hh * 0.22f + sway, baseY - hh * 0.60f, x + (k - 1) * hh * 0.38f + sway * 1.4f, baseY - hh)
        drawPath(p, color, style = Stroke(1.5f * d, cap = StrokeCap.Round))
    }
}

/** Falling petals / leaves with rotation. */
private fun DrawScope.leaves(t: Float, count: Int, seed: Int, cycleS: Float, color: Color, wobble: Float) {
    val w = size.width; val h = size.height; val d = density
    for (i in 0 until count) {
        val ph = fr(t / cycleS + hash(i + seed))
        val x = fr(hash(i * 2 + seed + 1) + sin(TAU * (ph * 2f + hash(i + seed + 9))) * (wobble / w)) * w
        val y = ph * (h + 30f) - 15f
        val s = (2.2f + 2.2f * hash(i + seed + 31)) * d
        val spin = 360f * fr(t / cycleS * (0.5f + hash(i + seed + 12)) + hash(i + seed + 13))
        rotate(spin, Offset(x, y)) { drawOval(color, Offset(x - s, y - s * 0.6f), Size(s * 2f, s * 1.2f)) }
    }
}

/** Twinkling sparkle on snow / water. */
private fun DrawScope.sparkles(t: Float, count: Int, yMin: Float, yMax: Float, color: Color, seed: Int) {
    val d = density
    for (i in 0 until count) {
        val x = hash(i * 4 + seed) * size.width
        val y = yMin + hash(i * 4 + seed + 1) * (yMax - yMin)
        val tw = max(0f, sin(TAU * (t / 6f + hash(i + seed + 2))))
        val a = tw * tw * tw
        if (a < 0.05f) continue
        val r = (0.7f + hash(i + seed + 3)) * d
        drawCircle(color.copy(alpha = 0.75f * a), r, Offset(x, y))
        drawLine(color.copy(alpha = 0.35f * a), Offset(x - r * 3.2f, y), Offset(x + r * 3.2f, y), 0.6f * d)
        drawLine(color.copy(alpha = 0.35f * a), Offset(x, y - r * 3.2f), Offset(x, y + r * 3.2f), 0.6f * d)
    }
}

/** A row of peaks, each split into a sunlit left face and a shaded right face, with a notched snow cap. */
private fun DrawScope.mountainRange(baseY: Float, peakH: Float, count: Int, seed: Int, lit: Color, shade: Color, cap: Color?) {
    val w = size.width; val h = size.height; val d = density
    val step = w / count
    for (i in 0 until count) {
        val x0 = i * step - step * 0.15f
        val x1 = (i + 1) * step + step * 0.15f
        val px = x0 + step * (0.32f + 0.36f * hash(seed + i + 20))
        val py = baseY - peakH * (0.55f + 0.45f * hash(seed + i + 50))
        val tri = Path(); tri.moveTo(x0, baseY); tri.lineTo(px, py); tri.lineTo(x1, baseY); tri.close()
        drawPath(tri, Brush.verticalGradient(listOf(lit, lerp(lit, Color.Black, 0.30f)), startY = py, endY = baseY))
        val shadowSide = Path(); shadowSide.moveTo(px, py); shadowSide.lineTo(x1, baseY); shadowSide.lineTo(px, baseY); shadowSide.close()
        drawPath(shadowSide, shade.copy(alpha = 0.55f))
        if (cap != null) {
            val lx = px + (x0 - px) * 0.38f; val ly = py + (baseY - py) * 0.38f
            val rx = px + (x1 - px) * 0.38f; val ry = py + (baseY - py) * 0.38f
            val c = Path()
            c.moveTo(px, py)
            c.lineTo(lx, ly)
            c.lineTo(px + (lx - px) * 0.35f, ly + (py - ly) * 0.12f)
            c.lineTo(px, ly + (py - ly) * 0.28f)
            c.lineTo(px + (rx - px) * 0.40f, ry + (py - ry) * 0.10f)
            c.lineTo(rx, ry)
            c.close()
            drawPath(c, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), cap.copy(alpha = 0.35f)), startY = py, endY = ly + d * 2f))
        }
        // base shadow where the mountain meets the ground
        drawLine(Color.Black.copy(alpha = 0.10f), Offset(x0, baseY), Offset(x1, baseY), 2f * d)
    }
    // soft mist along the whole range
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.05f), Color.Transparent), baseY - peakH * 0.1f, baseY + h * 0.04f))
}

/** Particles that fall from the top to the bottom and wrap around (snow, dust, leaves). */
private fun DrawScope.fall(t: Float, count: Int, seed: Int, cycleS: Float, radiusPx: Float, color: Color, sidePx: Float) {
    if (color.alpha <= 0.01f) return
    val w = size.width; val h = size.height
    for (i in 0 until count) {
        val ph = fr(t / cycleS + hash(i + seed))
        val x = fr(hash(i * 2 + seed + 1) + sin(TAU * (ph * 2f + hash(i + seed + 9))) * (sidePx / w)) * w
        val y = ph * (h + 20f) - 10f
        drawCircle(color, radiusPx * (0.7f + 0.6f * hash(i + seed + 31)), Offset(x, y))
    }
}

// ====================================================================================== FOREST

private fun DrawScope.forestScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    val amoled = mode == SceneMode.AMOLED

    sky3(
        pick(mode, 0xFFBBE6CB, 0xFF04110B, 0xFF000000),
        pick(mode, 0xFFE2F1D3, 0xFF0A2115, 0xFF020A05),
        pick(mode, 0xFFF8EFCB, 0xFF153A24, 0xFF06130C)
    )
    if (!night) {
        sun(Offset(w * 0.80f, h * 0.13f), w * 0.062f, Color(0xFFFFF9DC), Color(0xFFFFE49A), t)
        cloudBank(t, 0.16f, 3, Color.White.copy(alpha = 0.55f), 400)
        birds(t, h * 0.22f, Color(0xFF2C4633).copy(alpha = 0.55f), 4, 900)
        // light shafts through the canopy
        for (i in 0..3) {
            val x0 = w * (0.42f + 0.15f * i) + sin(TAU * (t / 12f + i * 0.3f)) * 12f * d
            val a = 0.09f + 0.05f * sin(TAU * (t / 10f + i * 0.25f))
            val p = Path()
            p.moveTo(x0, 0f); p.lineTo(x0 + 52f * d, 0f)
            p.lineTo(x0 - w * 0.24f + 104f * d, h * 0.74f); p.lineTo(x0 - w * 0.24f, h * 0.74f)
            p.close()
            drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFFF3B8).copy(alpha = a), Color.Transparent), startY = 0f, endY = h * 0.74f))
        }
    } else {
        stars(t, 62, h * 0.42f, Color(0xFFE9FFF2))
        moon(Offset(w * 0.22f, h * 0.12f), w * 0.052f, amoled)
    }

    val far = pick(mode, 0xFF9CCB9A, 0xFF143C2A, 0xFF0A1F14)
    val mid = pick(mode, 0xFF5FA66A, 0xFF0D2C1E, 0xFF06140C)
    val near = pick(mode, 0xFF2F7A3E, 0xFF081B11, 0xFF030A06)
    val trunk = pick(mode, 0xFF5B4326, 0xFF0B140E, 0xFF040806)

    // far valley + its tree line
    ridge(h * 0.57f, h * 0.05f, 1.2f, 0.4f, 1f, far, rim = if (night) null else Color(0xFFB7DDB4).copy(alpha = 0.25f), rimW = 1.2f * d)
    for (i in 0 until 9) {
        val x = w * (i + 0.5f) / 9f + (hash(i + 5) - 0.5f) * w * 0.05f
        val y = ridgeY(x, w, h * 0.57f, h * 0.05f, 1.2f, 0.4f, 1f) + 6f * d
        val sw = sin(TAU * (t / 8f + hash(i))) * 2f * d
        if (hash(i + 40) > 0.4f) pine(x, y, h * 0.13f, far, trunk, null, sw) else roundTree(x, y, h * 0.13f, far, trunk, sw)
    }
    hazeBand(h * 0.62f, h * 0.06f, if (night) Color(0xFF9FE3B8) else Color.White, if (night) 0.05f else 0.28f)

    // mid slope
    ridge(h * 0.71f, h * 0.045f, 1.6f, 1.7f, 2f, mid, rim = if (night) null else Color(0xFF8CCB8E).copy(alpha = 0.22f), rimW = 1.2f * d)
    for (i in 0 until 8) {
        val x = w * (i + 0.3f) / 8f + (hash(i + 15) - 0.5f) * w * 0.05f
        val y = ridgeY(x, w, h * 0.71f, h * 0.045f, 1.6f, 1.7f, 2f) + 8f * d
        val sw = sin(TAU * (t / 6f + hash(i + 3))) * 3f * d
        if (hash(i + 60) > 0.35f) pine(x, y, h * 0.20f, mid, trunk, null, sw) else roundTree(x, y, h * 0.20f, mid, trunk, sw)
    }

    // drifting mist between the layers
    for (i in 0..2) {
        val my = h * (0.55f + 0.12f * i)
        val dx = sin(TAU * (t / (20f + 10f * (i % 2)) + i * 0.3f)) * w * 0.08f
        val mc = if (night) Color(0xFF9FE3B8).copy(alpha = 0.06f) else Color.White.copy(alpha = 0.24f)
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, mc, Color.Transparent), startY = my - h * 0.05f, endY = my + h * 0.05f),
            Offset(dx - w * 0.1f, my - h * 0.05f), Size(w * 1.2f, h * 0.10f)
        )
    }

    // near meadow
    ridge(h * 0.87f, h * 0.035f, 1.1f, 3.1f, 4f, near, rim = if (night) null else Color(0xFF6FB57C).copy(alpha = 0.30f), rimW = 1.4f * d)
    // sun dapples on the grass (day only)
    if (!night) {
        for (i in 0 until 6) {
            val x = hash(i + 320) * w
            val y = h * (0.88f + 0.09f * hash(i + 321))
            drawOval(Color(0xFFFFF2B0).copy(alpha = 0.10f + 0.08f * hash(i + 322)), Offset(x - 26f * d, y - 6f * d), Size(52f * d, 12f * d))
        }
    }
    // big trees framing both edges
    for (i in 0 until 4) {
        val x = if (i < 2) w * (0.02f + 0.11f * i) else w * (0.79f + 0.11f * (i - 2))
        val sw = sin(TAU * (t / 5f + hash(i + 90))) * 5f * d
        pine(x, h * 1.0f, h * (0.36f + 0.07f * hash(i + 70)), near, trunk, null, sw)
    }
    // foreground grass
    for (i in 0 until 16) {
        val x = (i + 0.4f) * w / 16f
        grassTuft(x, h + 4f * d, (10f + 9f * hash(i + 500)) * d, lerp(near, Color.Black, 0.18f), sin(TAU * (t / 6f + hash(i + 501))) * 4f * d)
    }

    if (!night) {
        leaves(t, 14, 200, 24f, Color(0xFFE2B84A).copy(alpha = 0.85f), 42f * d)
        leaves(t, 9, 260, 30f, Color(0xFF7BC25A).copy(alpha = 0.85f), 52f * d)
    } else {
        val ff = Color(0xFFC6F04D)
        for (i in 0 until 30) {
            val x = hash(i * 5 + 300) * w + sin(TAU * (t / 15f + hash(i * 5 + 302))) * 26f * d
            val y = h * (0.34f + 0.56f * hash(i * 5 + 301)) + sin(TAU * (t / 10f + hash(i * 5 + 303))) * 18f * d
            val b = max(0f, sin(TAU * (t / 6f + hash(i * 5 + 304))))
            val a = b * b
            glow(Offset(x, y), 11f * d, ff.copy(alpha = 0.45f * a))
            drawCircle(ff.copy(alpha = 0.95f * a), 1.8f * d, Offset(x, y))
        }
    }
    vignette(if (night) 0.30f else 0.20f)
}

// ====================================================================================== SNOW

private fun DrawScope.snowScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    val amoled = mode == SceneMode.AMOLED

    sky3(
        pick(mode, 0xFFB9D7F2, 0xFF020817, 0xFF000000),
        pick(mode, 0xFFE2EFFB, 0xFF0A1B33, 0xFF02060D),
        pick(mode, 0xFFFCFDFF, 0xFF17365C, 0xFF06101F)
    )
    if (!night) {
        sun(Offset(w * 0.20f, h * 0.13f), w * 0.052f, Color(0xFFFFFFFF), Color(0xFFFFF3D0), t)
        cloudBank(t, 0.20f, 3, Color.White.copy(alpha = 0.65f), 700)
        birds(t, h * 0.30f, Color(0xFF4F6D8C).copy(alpha = 0.35f), 3, 950)
    } else {
        stars(t, 78, h * 0.48f, Color(0xFFEAF4FF))
        // aurora: four overlapping curtains, each with a soft inner glow and a bright crest
        val cols = listOf(Color(0xFF5DF0A8), Color(0xFFA78BFA), Color(0xFF4AD6F5), Color(0xFF7EFFD6))
        for (k in 0..3) {
            val base = h * (0.13f + 0.075f * k)
            val band = h * (0.15f + 0.02f * k)
            val p = Path()
            val steps = 30
            for (i in 0..steps) {
                val x = w * i / steps
                val y = base + sin(x / w * TAU * (1.2f + 0.4f * k) + TAU * t / (20f + 4f * k) + k) * h * 0.035f
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            for (i in steps downTo 0) {
                val x = w * i / steps
                val y = base + band + sin(x / w * TAU * (1.0f + 0.3f * k) + TAU * t / (24f + 6f * k) + k * 2f) * h * 0.05f
                p.lineTo(x, y)
            }
            p.close()
            val a = (if (amoled) 0.26f else 0.34f) * (0.75f + 0.25f * sin(TAU * (t / 10f + k * 0.3f)))
            drawPath(p, Brush.verticalGradient(listOf(Color.Transparent, cols[k].copy(alpha = a), Color.Transparent), startY = base - h * 0.05f, endY = base + band + h * 0.06f))
            // luminous crest line
            val crest = Path()
            for (i in 0..steps) {
                val x = w * i / steps
                val y = base + sin(x / w * TAU * (1.2f + 0.4f * k) + TAU * t / (20f + 4f * k) + k) * h * 0.035f
                if (i == 0) crest.moveTo(x, y) else crest.lineTo(x, y)
            }
            drawPath(crest, cols[k].copy(alpha = 0.45f), style = Stroke(1.2f * d, cap = StrokeCap.Round))
        }
        moon(Offset(w * 0.82f, h * 0.10f), w * 0.044f, amoled)
    }

    val lit = pick(mode, 0xFFC6DAEE, 0xFF24406A, 0xFF0C1A2C)
    val shade = pick(mode, 0xFF8AA8C8, 0xFF112440, 0xFF060E19)
    val capCol = pick(mode, 0xFFFFFFFF, 0xFFC9DEF7, 0xFF6A86AE)
    mountainRange(h * 0.62f, h * 0.34f, 3, 11, lit, shade, capCol)
    mountainRange(h * 0.70f, h * 0.24f, 4, 31, lerp(lit, shade, 0.35f), shade, capCol)

    val snow = pick(mode, 0xFFF8FCFF, 0xFF2C4F7E, 0xFF0C1C30)
    val leaf = pick(mode, 0xFF406B5E, 0xFF0F2A3A, 0xFF07131C)
    val cap = pick(mode, 0xFFFFFFFF, 0xFF8FB3E0, 0xFF3A5A86)
    val trunk = pick(mode, 0xFF5B4326, 0xFF0B1219, 0xFF04080C)

    // snow field with a rim highlight
    ridge(h * 0.80f, h * 0.035f, 1.3f, 0.8f, 3f, snow, rim = Color.White.copy(alpha = if (night) 0.30f else 0.85f), rimW = 1.5f * d)
    for (i in 0 until 10) {
        val x = w * (i + 0.4f) / 10f + (hash(i + 8) - 0.5f) * w * 0.04f
        val y = ridgeY(x, w, h * 0.80f, h * 0.035f, 1.3f, 0.8f, 3f) + 6f * d
        pine(x, y, h * (0.14f + 0.06f * hash(i + 3)), leaf, trunk, cap, sin(TAU * (t / 8f + hash(i))) * 2f * d)
    }
    // frozen lake strip: a cold reflective band under the tree line
    val lakeTop = h * 0.90f
    drawRect(
        brush = Brush.verticalGradient(listOf(lerp(snow, cap, 0.35f), lerp(snow, Color.Black, 0.25f)), lakeTop, h),
        topLeft = Offset(0f, lakeTop),
        size = Size(w, h - lakeTop)
    )
    for (i in 0..6) {
        val y = lakeTop + (h - lakeTop) * (i / 6f)
        drawLine(Color.White.copy(alpha = if (night) 0.08f else 0.28f), Offset(w * (0.05f + hash(i) * 0.12f), y), Offset(w * (0.62f + hash(i + 5) * 0.33f), y), 1.1f * d, cap = StrokeCap.Round)
    }
    // foreground drifts
    ridge(h * 0.955f, h * 0.025f, 0.8f, 2.4f, 6f, lerp(snow, Color.White, 0.18f), rim = Color.White.copy(alpha = 0.55f), rimW = 1.4f * d)
    sparkles(t, 26, h * 0.84f, h * 0.99f, Color.White, 1200)

    // snowfall: three depth layers
    for (layer in 0..2) {
        val count = intArrayOf(30, 20, 13)[layer]
        val cyc = floatArrayOf(24f, 15f, 10f)[layer]
        val r = floatArrayOf(1.3f, 2.0f, 3.2f)[layer] * d
        if (!night) fall(t, count, 500 + layer * 40, cyc, r * 1.7f, Color(0xFF9FC4E6).copy(alpha = 0.32f), 18f * d)
        fall(t, count, 500 + layer * 40, cyc, r, Color.White.copy(alpha = if (layer == 2) 0.95f else 0.80f), 18f * d)
    }
    vignette(if (night) 0.30f else 0.18f, if (night) Color.Black else Color(0xFF26425F))
}

// ====================================================================================== REGISTAAN (desert)

private fun DrawScope.camel(x: Float, y: Float, s: Float, color: Color, step: Float) {
    drawRoundRect(color, Offset(x - s * 0.9f, y - s * 1.1f), Size(s * 1.8f, s * 0.7f), androidx.compose.ui.geometry.CornerRadius(s * 0.3f))
    drawCircle(color, s * 0.32f, Offset(x - s * 0.1f, y - s * 1.25f))
    val neck = Path(); neck.moveTo(x + s * 0.7f, y - s * 1.05f); neck.lineTo(x + s * 1.15f, y - s * 1.75f)
    drawPath(neck, color, style = Stroke(s * 0.26f, cap = StrokeCap.Round))
    drawCircle(color, s * 0.2f, Offset(x + s * 1.3f, y - s * 1.8f))
    for (k in 0..3) {
        val lx = x - s * 0.7f + k * s * 0.47f
        val sw = sin(step + k * 1.6f) * s * 0.18f
        val leg = Path(); leg.moveTo(lx, y - s * 0.45f); leg.lineTo(lx + sw, y)
        drawPath(leg, color, style = Stroke(s * 0.16f, cap = StrokeCap.Round))
    }
}

private fun DrawScope.cactus(x: Float, baseY: Float, s: Float, color: Color) {
    val sw = s * 0.17f
    drawRoundRect(
        Brush.horizontalGradient(listOf(lerp(color, Color.Black, 0.22f), color, lerp(color, Color.White, 0.15f))),
        Offset(x - sw / 2f, baseY - s), Size(sw, s), androidx.compose.ui.geometry.CornerRadius(sw / 2f)
    )
    val l = Path(); l.moveTo(x, baseY - s * 0.38f); l.lineTo(x - s * 0.28f, baseY - s * 0.38f); l.lineTo(x - s * 0.28f, baseY - s * 0.68f)
    val r = Path(); r.moveTo(x, baseY - s * 0.55f); r.lineTo(x + s * 0.26f, baseY - s * 0.55f); r.lineTo(x + s * 0.26f, baseY - s * 0.82f)
    drawPath(l, color, style = Stroke(sw * 0.9f, cap = StrokeCap.Round))
    drawPath(r, color, style = Stroke(sw * 0.9f, cap = StrokeCap.Round))
    drawOval(Color.Black.copy(alpha = 0.16f), Offset(x - s * 0.30f, baseY - s * 0.02f), Size(s * 0.60f, s * 0.10f))
}

private fun DrawScope.desertScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    val amoled = mode == SceneMode.AMOLED

    sky3(
        pick(mode, 0xFFF0AE63, 0xFF07040F, 0xFF000000),
        pick(mode, 0xFFFFD99C, 0xFF1A1030, 0xFF080410),
        pick(mode, 0xFFFFF3DC, 0xFF3E2452, 0xFF120818)
    )
    if (!night) {
        sun(Offset(w * 0.5f, h * 0.19f), w * 0.105f, Color(0xFFFFF6CE), Color(0xFFFFB84A), t)
        cloudBank(t, 0.12f, 2, Color(0xFFFFE7C4).copy(alpha = 0.40f), 1100)
        birds(t, h * 0.26f, Color(0xFF6B4A2C).copy(alpha = 0.45f), 3, 1300)
    } else {
        stars(t, 96, h * 0.52f, Color(0xFFFFEFD6))
        moon(Offset(w * 0.72f, h * 0.16f), w * 0.13f, amoled)
        cloudBank(t, 0.30f, 2, Color(0xFF5A3A78).copy(alpha = 0.22f), 1150)
    }

    val rimCol = pick(mode, 0xFFFFE2A8, 0xFFB79ADC, 0xFF7E58A8).copy(alpha = if (amoled) 0.40f else 0.60f)
    val far = pick(mode, 0xFFE9C084, 0xFF3A2A55, 0xFF140C1C)
    val dune1 = pick(mode, 0xFFDCA85B, 0xFF2D2147, 0xFF0E0814)
    val dune2 = pick(mode, 0xFFC98B43, 0xFF221838, 0xFF080410)
    val dune3 = pick(mode, 0xFFAE6F31, 0xFF160F28, 0xFF040208)

    ridge(h * 0.54f, h * 0.045f, 1.0f, 0.5f, 1f, far, rimCol, 1.4f * d)
    hazeBand(h * 0.58f, h * 0.05f, pick(mode, 0xFFFFEBC8, 0xFF6B4A8A, 0xFF2A1A3A), if (night) 0.10f else 0.28f)
    ridge(h * 0.64f, h * 0.05f, 1.3f, 2.2f, 2f, dune1, rimCol, 1.4f * d)

    // camel caravan on the middle dune, with a soft shadow beneath each animal
    val cam = pick(mode, 0xFF5A3A1E, 0xFF0D0818, 0xFF1A1024)
    for (i in 0..2) {
        val ph = fr(t / 60f + i * 0.07f)
        val x = -w * 0.12f + ph * (w * 1.34f)
        val y = ridgeY(x, w, h * 0.64f, h * 0.05f, 1.3f, 2.2f, 2f) + 3f * d
        drawOval(Color.Black.copy(alpha = 0.14f), Offset(x - w * 0.03f, y - 2f * d), Size(w * 0.06f, 3.2f * d))
        camel(x, y, w * 0.016f, cam, TAU * (t / 4f))
    }

    ridge(h * 0.76f, h * 0.045f, 0.9f, 4.0f, 3f, dune2, rimCol, 1.4f * d)
    cactus(w * 0.13f, ridgeY(w * 0.13f, w, h * 0.76f, h * 0.045f, 0.9f, 4.0f, 3f) + 4f * d, h * 0.075f, pick(mode, 0xFF4F8A3A, 0xFF14241C, 0xFF0A140E))
    // a few wind-carved rocks on the right
    val rock = pick(mode, 0xFFB9803F, 0xFF1D1533, 0xFF0A0610)
    for (i in 0..2) {
        val rx = w * (0.80f + 0.06f * i)
        val ry = ridgeY(rx, w, h * 0.76f, h * 0.045f, 0.9f, 4.0f, 3f) + 2f * d
        drawOval(lerp(rock, Color.White, 0.10f), Offset(rx - 13f * d, ry - 9f * d), Size(26f * d, 14f * d))
        drawOval(lerp(rock, Color.Black, 0.25f), Offset(rx - 9f * d, ry - 3f * d), Size(18f * d, 8f * d))
    }
    ridge(h * 0.88f, h * 0.04f, 1.1f, 5.3f, 4f, dune3, rimCol, 1.4f * d)

    if (!night) {
        // heat shimmer above the far dunes
        for (i in 0..4) {
            val y0 = h * (0.50f + 0.025f * i)
            val p = Path()
            for (k in 0..24) {
                val x = w * k / 24f
                val y = y0 + sin(k * 0.9f + TAU * t / 5f + i) * 2.2f * d
                if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, Color.White.copy(alpha = 0.12f), style = Stroke(1.3f * d))
        }
    }
    // wind-blown sand
    val sand = pick(mode, 0xFFE9C98A, 0xFFB89CD0, 0xFF8E76A8).copy(alpha = if (night) 0.35f else 0.60f)
    for (i in 0 until 38) {
        val ph = fr(t / (10f + 2f * (i % 3)) + hash(i + 400))
        val x = ph * (w + 40f) - 20f
        val y = h * (0.52f + 0.42f * hash(i + 401)) + sin(TAU * (ph * 3f + hash(i))) * 6f * d
        drawCircle(sand, (0.8f + hash(i + 402)) * d, Offset(x, y))
    }
    if (night) {
        // a tiny camp fire and its glow far on the right dune
        val fx = w * 0.86f; val fy = h * 0.885f
        bloom(Offset(fx, fy), 60f * d, Color(0xFFFFB347), 0.35f)
        drawCircle(Color(0xFFFFD27A), 2.6f * d, Offset(fx, fy))
        drawCircle(Color(0xFFFF8A3D).copy(alpha = 0.8f), 1.6f * d, Offset(fx, fy - 2f * d))
    }
    vignette(if (night) 0.34f else 0.20f, if (night) Color.Black else Color(0xFF3A2410))
}

// ====================================================================================== SAMUNDAR (ocean)

private fun DrawScope.fish(x: Float, y: Float, s: Float, dir: Float, body: Color, fin: Color, wag: Float) {
    val tx = x - dir * s * 0.9f
    val tail = Path(); tail.moveTo(tx, y); tail.lineTo(tx - dir * s * 0.7f, y - s * 0.45f + wag); tail.lineTo(tx - dir * s * 0.7f, y + s * 0.45f + wag); tail.close()
    drawPath(tail, fin)
    drawOval(body, Offset(x - s, y - s * 0.45f), Size(s * 2f, s * 0.9f))
    // belly highlight
    drawOval(lerp(body, Color.White, 0.30f).copy(alpha = 0.45f), Offset(x - s * 0.7f, y + s * 0.02f), Size(s * 1.2f, s * 0.34f))
    drawCircle(Color.White, s * 0.13f, Offset(x + dir * s * 0.55f, y - s * 0.1f))
    drawCircle(Color(0xFF102030), s * 0.06f, Offset(x + dir * s * 0.57f, y - s * 0.1f))
}

private fun DrawScope.jelly(x: Float, y: Float, s: Float, color: Color, t: Float, seed: Float) {
    val pulse = 1f + 0.08f * sin(TAU * (t / 5f + seed))
    glow(Offset(x, y), s * 2.6f, color.copy(alpha = 0.22f))
    drawArc(color.copy(alpha = 0.55f), 180f, 180f, true, Offset(x - s * pulse, y - s * 0.8f * pulse), Size(2f * s * pulse, 1.6f * s * pulse))
    drawArc(lerp(color, Color.White, 0.45f).copy(alpha = 0.40f), 200f, 140f, true, Offset(x - s * 0.86f * pulse, y - s * 0.86f * pulse), Size(1.7f * s * pulse, 1.5f * s * pulse))
    for (k in 0..4) {
        val tx = x - s * 0.7f + k * s * 0.35f
        val p = Path(); p.moveTo(tx, y)
        for (j in 1..4) p.lineTo(tx + sin(TAU * (t / 6f + seed + j * 0.15f + k * 0.1f)) * s * 0.14f, y + j * s * 0.35f)
        drawPath(p, color.copy(alpha = 0.50f), style = Stroke(1.4f * density, cap = StrokeCap.Round))
    }
}

/** Branching coral: a trunk plus two side branches, drawn with rounded strokes. */
private fun DrawScope.branchCoral(x: Float, baseY: Float, s: Float, color: Color) {
    val d = density
    drawRoundRect(color, Offset(x - s * 0.07f, baseY - s), Size(s * 0.14f, s), androidx.compose.ui.geometry.CornerRadius(s * 0.07f))
    for (k in 0..1) {
        val dir = if (k == 0) -1f else 1f
        val p = Path()
        p.moveTo(x, baseY - s * 0.35f)
        p.quadraticTo(x + dir * s * 0.30f, baseY - s * 0.55f, x + dir * s * 0.22f, baseY - s * 0.92f)
        drawPath(p, color, style = Stroke(s * 0.11f, cap = StrokeCap.Round))
        drawCircle(lerp(color, Color.White, 0.20f), s * 0.06f, Offset(x + dir * s * 0.22f, baseY - s * 0.92f))
    }
    drawCircle(lerp(color, Color.White, 0.24f), s * 0.08f, Offset(x, baseY - s))
}

private fun DrawScope.oceanScene(mode: Int, t: Float) {
    val w = size.width; val h = size.height; val d = density
    val night = mode != SceneMode.DAY
    val amoled = mode == SceneMode.AMOLED

    sky3(
        pick(mode, 0xFFB6F2FB, 0xFF0A4A78, 0xFF00101A),
        pick(mode, 0xFF57C2E6, 0xFF043055, 0xFF010810),
        pick(mode, 0xFF0E6EA6, 0xFF010E1C, 0xFF000205)
    )
    // light shafts from the surface
    for (i in 0..5) {
        val x0 = w * (0.01f + 0.20f * i) + sin(TAU * (t / 12f + i * 0.2f)) * 20f * d
        val a = (if (mode == SceneMode.DAY) 0.22f else if (mode == SceneMode.NIGHT) 0.07f else 0.03f) * (0.65f + 0.35f * sin(TAU * (t / 10f + i * 0.17f)))
        val p = Path()
        p.moveTo(x0, 0f); p.lineTo(x0 + 50f * d, 0f)
        p.lineTo(x0 + w * 0.18f + 140f * d, h * 0.82f); p.lineTo(x0 + w * 0.18f, h * 0.82f)
        p.close()
        drawPath(p, Brush.verticalGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), startY = 0f, endY = h * 0.82f))
    }
    // caustics near the surface
    for (i in 0..2) {
        val y0 = h * (0.05f + 0.035f * i)
        val p = Path()
        for (k in 0..20) {
            val x = w * k / 20f
            val y = y0 + sin(k * 0.8f + TAU * (t / 8f + i * 0.3f)) * 4f * d
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        drawPath(p, Color.White.copy(alpha = if (night) 0.10f else 0.34f), style = Stroke((1.6f - i * 0.3f) * d))
    }
    if (night) bloom(Offset(w * 0.7f, -h * 0.02f), w * 0.75f, Color(0xFF8FD8FF), if (amoled) 0.10f else 0.22f)
    // surface shimmer line
    val surf = Path()
    for (k in 0..28) {
        val x = w * k / 28f
        val y = 8f * d + sin(k * 0.7f + TAU * t / 8f) * 3.5f * d
        if (k == 0) surf.moveTo(x, y) else surf.lineTo(x, y)
    }
    drawPath(surf, Color.White.copy(alpha = if (night) 0.18f else 0.55f), style = Stroke(1.6f * d))

    // distant school of small fish
    val schoolX = w * 0.22f + sin(TAU * t / 60f) * w * 0.10f
    val schoolY = h * 0.30f + sin(TAU * t / 20f) * 8f * d
    val school = if (night) Color(0xFF9CC9E0).copy(alpha = 0.30f) else Color(0xFF0B4A6E).copy(alpha = 0.30f)
    for (i in 0 until 14) {
        drawOval(school, Offset(schoolX + (i % 7) * 10f * d + (i / 7) * 6f * d, schoolY + (i % 4) * 6f * d), Size(7f * d, 3f * d))
    }

    // sea floor
    ridge(h * 0.93f, h * 0.02f, 1.4f, 0.6f, 2f, pick(mode, 0xFFE8D6A0, 0xFF0B2E4A, 0xFF03111C))
    val weed = pick(mode, 0xFF2FB36B, 0xFF0E8A6A, 0xFF0A5A48)
    for (i in 0 until 9) {
        val bx = w * (0.03f + 0.11f * i) + hash(i + 11) * w * 0.04f
        val hh = h * (0.10f + 0.10f * hash(i + 12))
        val p = Path(); p.moveTo(bx, h)
        for (j in 1..5) p.lineTo(bx + sin(TAU * (t / 8f + hash(i) + j * 0.12f)) * j * 4.5f * d, h - hh * j / 5f)
        drawPath(p, weed, style = Stroke(4.2f * d, cap = StrokeCap.Round))
    }
    val coralA = pick(mode, 0xFFFF7A8A, 0xFFB5465A, 0xFF7A2E3E)
    val coralB = pick(mode, 0xFFFFA84D, 0xFFB5702A, 0xFF7A4A1C)
    for (i in 0 until 4) branchCoral(w * (0.12f + 0.22f * i), h * 0.955f, (16f + 8f * hash(i + 40)) * d, if (i % 2 == 0) coralA else coralB)
    for (i in 0..3) {
        val rx = w * (0.06f + 0.25f * i)
        drawOval(pick(mode, 0xFF8A7A62, 0xFF0A2438, 0xFF041018), Offset(rx, h * 0.945f), Size(34f * d, 13f * d))
    }

    // bigger fish
    val bodies = listOf(0xFFFF8A3DL, 0xFFFFD23DL, 0xFF3D8BFFL, 0xFFFF5C8AL, 0xFF3DDDB5L, 0xFFFFA35CL, 0xFF7B8CFFL)
    for (i in 0 until 7) {
        val dir = if (i % 2 == 0) 1f else -1f
        val s = (9f + 6f * hash(i + 600)) * d
        val cyc = floatArrayOf(40f, 60f, 30f, 40f, 60f, 30f, 40f)[i]
        val ph = fr(t / cyc + hash(i + 601))
        val x = if (dir > 0f) -2f * s + ph * (w + 4f * s) else w + 2f * s - ph * (w + 4f * s)
        val y = h * (0.22f + 0.52f * hash(i + 602)) + sin(TAU * (t / 10f + hash(i + 603))) * 8f * d
        var body = Color(bodies[i])
        if (mode == SceneMode.NIGHT) body = lerp(body, Color(0xFF052038), 0.45f)
        if (amoled) body = lerp(body, Color.Black, 0.55f)
        fish(x, y, s, dir, body, body.copy(alpha = 0.85f), sin(TAU * (t / 4f) * 2f + i) * s * 0.18f)
    }

    // bubbles
    for (i in 0 until 22) {
        val ph = fr(t / (12f + 4f * (i % 3)) + hash(i + 700))
        val y = h * (1f - ph)
        val x = hash(i + 701) * w + sin(TAU * (ph * 3f + hash(i))) * 10f * d
        val r = (2f + 4f * hash(i + 702)) * d
        drawCircle(Color.White.copy(alpha = if (night) 0.30f else 0.55f), r, Offset(x, y), style = Stroke(1.1f * d))
        drawCircle(Color.White.copy(alpha = if (night) 0.45f else 0.75f), r * 0.22f, Offset(x - r * 0.35f, y - r * 0.35f))
    }

    if (night) {
        val g = if (amoled) Color(0xFF18E0D0) else Color(0xFF2EE6D6)
        for (i in 0 until 46) {
            val x = hash(i + 800) * w + sin(TAU * (t / 20f + hash(i + 801))) * 20f * d
            val y = fr(hash(i + 802) - t / 60f) * h
            val a = 0.25f + 0.75f * (0.5f + 0.5f * sin(TAU * (t / 6f + hash(i + 803))))
            glow(Offset(x, y), 7f * d, g.copy(alpha = 0.25f * a))
            drawCircle(g.copy(alpha = 0.85f * a), 1.3f * d, Offset(x, y))
        }
        for (i in 0..2) {
            val x = w * (0.2f + 0.3f * i) + sin(TAU * (t / 20f + i * 0.3f)) * 14f * d
            val y = h * (0.30f + 0.12f * i) + sin(TAU * (t / 12f + i * 0.2f)) * 16f * d
            jelly(x, y, (16f + 6f * i) * d, if (i == 1) Color(0xFFB98CFF) else Color(0xFF3AE6F0), t, i * 0.21f)
        }
    } else {
        jelly(w * 0.78f, h * 0.38f + sin(TAU * t / 12f) * 14f * d, 15f * d, Color.White.copy(alpha = 0.75f), t, 0.1f)
    }
    vignette(if (night) 0.34f else 0.22f, Color(0xFF03202E))
}
