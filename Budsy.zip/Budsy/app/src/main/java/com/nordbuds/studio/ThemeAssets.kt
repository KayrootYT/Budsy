package com.nordbuds.studio

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector

@Composable
fun ImportedThemeImage(
    themeId: String?,
    slot: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alpha: Float = 1f
) {
    val ctx = LocalContext.current
    val bitmap = remember(themeId, slot) {
        try {
            val file = ThemeStore.assetFile(ctx, themeId, slot) ?: return@remember null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth !in 1..4096 || bounds.outHeight !in 1..4096) null
            else {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = maxOf(1, maxOf(bounds.outWidth / 2048, bounds.outHeight / 2048))
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeFile(file.absolutePath, opts)
            }
        } catch (_: Exception) { null }
    }
    if (bitmap != null) Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        modifier = modifier,
        contentScale = contentScale,
        alpha = alpha
    )
}

// ------------------------------------------------------------------ engine helpers used by Components

/** Scales an animation duration by the theme's motion speed (2.0 = twice as fast). */
@Composable
fun ms(base: Int): Int = (base / LocalThemeSpec.current.motion.speed).toInt().coerceAtLeast(1)

/** Card fill for imported themes, following [CardSpec.style]. */
@Composable
fun themedCardBrush(): Brush {
    val c = LocalThemeSpec.current.card
    val a = c.fillAlpha
    return when (c.style) {
        CardStyle.SOLID, CardStyle.FLAT -> SolidColor(P.tile.copy(alpha = a))
        CardStyle.GLASS -> Brush.linearGradient(listOf(P.tile.copy(alpha = 0.62f * a), P.tile.copy(alpha = 0.34f * a)))
        CardStyle.GRADIENT -> Brush.linearGradient(listOf(
            c.gradientFrom?.let(::Color) ?: P.tile,
            c.gradientTo?.let(::Color) ?: P.accent.copy(alpha = 0.18f).compositeOver(P.tile)
        ))
        CardStyle.OUTLINE -> SolidColor(Color.Transparent)
    }
}

private fun decodeIcon(ctx: android.content.Context, id: String?, key: String): ImageBitmap? = try {
    val file = ThemeStore.iconFile(ctx, id, key) ?: return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth !in 1..2048 || bounds.outHeight !in 1..2048) null
    else BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 256) })?.asImageBitmap()
} catch (_: Throwable) { null }

/** Icon that a theme may replace with its own PNG/WebP; otherwise the built-in vector icon is drawn. */
@Composable
fun ThemedIcon(key: String, fallback: ImageVector, tint: Color, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val id = LocalThemeId.current
    val spec = LocalThemeSpec.current
    val bmp = remember(id, key) { decodeIcon(ctx, id, key) }
    if (bmp != null) Image(bmp, null, modifier, colorFilter = if (spec.icons.tintAccent) ColorFilter.tint(tint) else null)
    else Icon(fallback, null, tint = tint, modifier = modifier)
}
