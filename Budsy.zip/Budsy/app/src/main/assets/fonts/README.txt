Inter font (SIL OFL 1.1) goes here.
The Gradle task fetchInterFonts downloads it automatically at build time (needs internet).
Offline? Download https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip and copy these 4 files here,
renamed exactly: Inter-Regular.ttf -> inter_regular.ttf, Inter-Medium.ttf -> inter_medium.ttf,
Inter-SemiBold.ttf -> inter_semibold.ttf, Inter-Bold.ttf -> inter_bold.ttf  (found in the zip under extras/ttf/).
