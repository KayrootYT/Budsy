Phosphor Icons (MIT) 'regular' SVGs go here, e.g. waves.svg, bluetooth.svg.
The Gradle task fetchPhosphorIcons downloads the ones the app uses at build time (needs internet).
Offline? Copy the same-named files from https://github.com/phosphor-icons/core (assets/regular/) into this folder.
Missing files just fall back to the Material icon.
