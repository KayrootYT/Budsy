# Budsy UI controls update

## Included
- Moved the primary connection control into the pinned top header. Tap toggles connect/disconnect; long-press opens a compact menu with connect/disconnect and Android Bluetooth options.
- Removed the large connect/disconnect action from the device hero card so the header is the single primary connection control.
- Added an Android system-output FFT spectrum visualizer to the Sound screen. The user explicitly enables it and grants `RECORD_AUDIO`; the app does not save audio. Device/OEM restrictions may prevent system-output capture, in which case the app reports that the stream is unavailable.
- Added the required Android audio permissions.

## Important limitations
- The visualizer is a live spectrum display; it does not itself apply Dolby processing or dynamically rewrite EQ gains. Existing EQ preset/custom-profile and earbuds protocol write paths are retained.
- Actual Dolby Audio certification/processing cannot be claimed or enabled by a UI switch alone. Spatial/audio processing must be implemented only against verified phone or earbuds capabilities.
- This source update was not Gradle-built in this environment because the archive has no Gradle wrapper and no Gradle executable is installed. Run the repository GitHub Actions build or build with a local Gradle 8.9+ setup before installing.


## Sound Lab cleanup
- Removed the Audio Visualizer section and its animated spectrum preview from the Sound screen at the user's request.
- No microphone permission or audio-capture functionality is added. EQ, BassWave, and existing earbuds control paths remain unchanged.


## Liquid Glass blue redesign
- New `LiquidGlass.kt`: frosted glass surfaces (translucent body, top sheen, bright rim, soft shadow) and `LiquidBackground`, a vector-path (SVG-style bezier ribbons) backdrop. Light = icy white/blue silk, Dark = navy with blue ribbons, AMOLED = black with violet ribbons.
- Stock palette retuned to blue glass (accent blue; AMOLED uses violet like the reference). Imported themes are untouched.
- Glass panels, tiles (active tile = glowing blue gradient + check badge), buttons, glass slider thumb, floating glass bottom nav (active tab fills with blue), new header (app mark, "Budsy", blue Connected chip).
- Sound Lab matches the reference: Presets / BassWave (toggle + "x / y" level) / Custom EQ panels, numbered slot tiles, value bubbles above each band, glowing vertical EQ sliders.
- Removed: all green "Earbuds confirmed / read back …" lines (SaveLine no longer shows SAVED), the "Experimental: custom EQ writes…" note, the green Active/Saved row in Custom EQ.
- Not compiled here (no Android SDK / network). Build with the GitHub Actions workflow or local Gradle.

## iOS look (replaces the glass wallpaper)
- Background wallpaper/ribbons removed: plain iOS grouped background (Light F2F2F7, Dark 1C1C1E, AMOLED black) with opaque grouped cards and system blue accent.
- iOS-style cards, tiles, buttons, thin sliders with white thumbs, Settings-style squircle icon chips, tab bar with hairline.
- BassWave shows -10 … +10 again (no 0–20 mapping).
- Header mark: drop your own official logo as res/drawable-nodpi/oneplus_logo.png (or .webp); it is picked up automatically. Without it a neutral Budsy icon is shown.
