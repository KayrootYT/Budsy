# Budsy UI controls update

## Included
- Moved the primary connection control into the pinned top header. Tap toggles connect/disconnect; long-press opens a compact menu with connect/disconnect and Android Bluetooth options.
- Removed the large connect/disconnect action from the device hero card so the header is the single primary connection control.
- Added an Android system-output FFT spectrum visualizer to the Sound screen. The user explicitly enables it and grants `RECORD_AUDIO`; the app does not save audio. Device/OEM restrictions may prevent system-output capture, in which case the app reports that the stream is unavailable.
- Added the required Android audio permissions.

## Important limitations
- The visualizer is a live spectrum display; it does not itself apply Dolby processing or dynamically rewrite EQ gains. Existing EQ preset/custom-profile and earbuds protocol write paths are retained.
- Actual Dolby Audio certification/processing cannot be claimed or enabled by a UI switch alone. Spatial/audio processing must be implemented only against verified phone or earbuds capabilities.
- This source update was not Gradle-built in this environment because the archive has no Gradle wrapper and no Gradle executable is installed. Run the repository GitHub Actions build or build with a local Gradle 8.9+ setup before installing.


## Sound Lab cleanup
- Removed the Audio Visualizer section and its animated spectrum preview from the Sound screen at the user's request.
- No microphone permission or audio-capture functionality is added. EQ, BassWave, and existing earbuds control paths remain unchanged.

## Sound Lab Liquid Glass refresh
- Reworked the Sound tab backdrop with layered blue glass-wave gradients for Light, Dark, and AMOLED appearances.
- Made stock glass panels translucent with subtle accent-edge highlights.
- Recolored Sound Lab success/read-back states from green to the active blue accent for a consistent visual language.
- Removed the experimental custom-EQ firmware warning from the Sound Lab page; compatibility diagnostics remain separate from the main listening interface.
- Removed the Audio Visualizer previously requested by the user; no visualizer was added back.
