# Budsy UI controls update

## Included
- Moved the primary connection control into the pinned top header. Tap toggles connect/disconnect; long-press opens a compact menu with connect/disconnect and Android Bluetooth options.
- Removed the large connect/disconnect action from the device hero card so the header is the single primary connection control.
- Added an Android system-output FFT spectrum visualizer to the Sound screen. The user explicitly enables it and grants `RECORD_AUDIO`; the app does not save audio. Device/OEM restrictions may prevent system-output capture, in which case the app reports that the stream is unavailable.
- Added the required Android audio permissions.

## Important limitations
- The visualizer is a live spectrum display; it does not itself apply Dolby processing or dynamically rewrite EQ gains. Existing EQ preset/custom-profile and earbuds protocol write paths are retained.
- Actual Dolby Audio certification/processing cannot be claimed or enabled by a UI switch alone. Spatial/audio processing must be implemented only against verified phone or earbuds capabilities.
- This source update was not Gradle-built in this environment because the archive has no Gradle wrapper and no Gradle executable is installed. Run the repository GitHub Actions build or build with a local Gradle 8.9+ setup before installing.


## Sound Lab cleanup
- Removed the Audio Visualizer section and its animated spectrum preview from the Sound screen at the user's request.
- No microphone permission or audio-capture functionality is added. EQ, BassWave, and existing earbuds control paths remain unchanged.


## Liquid Glass blue redesign
- New `LiquidGlass.kt`: frosted glass surfaces (translucent body, top sheen, bright rim, soft shadow) and `LiquidBackground`, a vector-path (SVG-style bezier ribbons) backdrop. Light = icy white/blue silk, Dark = navy with blue ribbons, AMOLED = black with violet ribbons.
- Stock palette retuned to blue glass (accent blue; AMOLED uses violet like the reference). Imported themes are untouched.
- Glass panels, tiles (active tile = glowing blue gradient + check badge), buttons, glass slider thumb, floating glass bottom nav (active tab fills with blue), new header (app mark, "Budsy", blue Connected chip).
- Sound Lab matches the reference: Presets / BassWave (toggle + "x / y" level) / Custom EQ panels, numbered slot tiles, value bubbles above each band, glowing vertical EQ sliders.
- Removed: all green "Earbuds confirmed / read back …" lines (SaveLine no longer shows SAVED), the "Experimental: custom EQ writes…" note, the green Active/Saved row in Custom EQ.
- Not compiled here (no Android SDK / network). Build with the GitHub Actions workflow or local Gradle.

## iOS look (replaces the glass wallpaper)
- Background wallpaper/ribbons removed: plain iOS grouped background (Light F2F2F7, Dark 1C1C1E, AMOLED black) with opaque grouped cards and system blue accent.
- iOS-style cards, tiles, buttons, thin sliders with white thumbs, Settings-style squircle icon chips, tab bar with hairline.
- BassWave shows -10 … +10 again (no 0–20 mapping).
- Header mark: drop your own official logo as res/drawable-nodpi/oneplus_logo.png (or .webp); it is picked up automatically. Without it a neutral Budsy icon is shown.

## 3D Liquid Glass touch-control update (2026-11-06)
- Replaced the horizontal ON/OFF slider switch presentation with a raised 3D glass touch button.
- OFF uses a frosted silver/graphite surface; ON uses the accent-blue glass face with a check indicator.
- Added glossy top reflection, rounded glass rim, depth shadow, press-scale animation, and haptic/tap feedback.
- Reused the existing Boolean callbacks and semantics so feature state and device commands remain on the existing code paths.
- Moved Sound Lab Presets, BassWave, and Custom EQ section headings above their content cards; BassWave's touch control now sits beside its outside heading.

## 3D Liquid Glass look applied app-wide (2026-11-06)
- `LiquidGlass.kt`: new Light / Dark / AMOLED glass tokens from the reference, `glassSurface` (frosted panel), `glassTile3D` (solid edge, glossy face, press-down), `glassChip` (icon chip) and a gradient `LiquidBackground`.
- `Components.kt`: rows/cards, `FeatureTile`, `WideButton`, `SmallButton`, icon chips and the floating bottom nav now use the 3D glass look; panels are frosted shells.
- `Theme.kt`: light-mode ink/secondary colours retuned for the blue glass background.
- Not compiled here (no Android SDK / network). Build with the GitHub Actions workflow or local Gradle.

## Glass tick badge, press sink, blue 3D glow (2026-11-06)
- Removed the second (end) icon button from every toggle row. Rows now end with a blue glass circle + white tick when ON (nothing when OFF); stand-alone toggles show an empty ring when OFF.
- Rows, option cards, tiles and buttons sink onto their 3D edge while pressed, then switch ON on release.
- ON state: the edge under the tile turns blue and a soft blue glow spreads beneath it; OFF keeps the neutral silver/graphite edge.
- iOS-26 style details: specular gradient rim, bigger concentric radii, glass slider thumb with glowing fill, glass sheet/dialog/snackbar surfaces, bold blue filled buttons.
- Not compiled here (no Android SDK / network). Build with the GitHub Actions workflow or local Gradle.

## Push animation matched to the reference recording (2026-11-06)
- Press: face sinks onto its 3D edge, edge goes faint, shadow tightens, icon/text dim slightly, OFF tiles preview the ON look (blue chip + ghost tick).
- Release: spring with overshoot (tile pops a little above rest height), chip and face cross-fade to blue, tick pops in, blue edge + glow fade in. Turning OFF reverses it.
- Same push motion on filled/outlined buttons; icon chip no longer tilts in glass mode.
- Not compiled here (no Android SDK / network).


## 3D glass card styling alignment

- Aligned the built-in Stock card surfaces with the supplied Budsy single-tile reference.
- Dark mode keeps the active tile neutral charcoal; blue is reserved for the raised lower edge, active icon chip, and subtle glow.
- AMOLED uses pitch-black surroundings, near-black tile faces, restrained blue edge glow, and the darker active icon gradient.
- Kept the existing shared GlassPanel / glassTile3D components so the styling is applied consistently across app screens without changing Bluetooth, BLE/GATT/RFCOMM, EQ, ANC, or device logic.

## Ocean Reef theme (new built-in theme, Stock untouched)
- New `OceanTheme.kt`; selectable in Theme Manager as "Ocean Reef" (Light / Dark / AMOLED palettes). Stock Budsy code paths are not modified.
- Living background: rippling water surface with foam, swaying light rays, drifting swells, bubbles, sandy sea floor.
- Creatures: multi-colour fish + a small school, jellyfish (pulsing bell, tentacles), sea turtle (paddling flippers), seahorses, branching / fan / dome coral and seaweed. All vector-drawn, no image assets.
- Cards, panels and feature tiles: 3D realistic glass (thickness edge, contact shadow, aqua translucent face, gloss, window streak, caustic glow, specular rim). Active = accent-tinted glass.
- Touch on any card sends concentric water ripples from the finger (observe-only pointer handler, taps/scrolls unaffected). Disabled when system "reduce motion" is on.
- Not compiled here (no Android SDK). Build with the GitHub Actions workflow or local Gradle.

## Ocean Reef – Living Water World (2026-11-09)
- New `WaterWorld.kt`: screen is split at 50% – water below, pond surface + far bank + sky above.
- Water: calm level (gyro/tilt slosh removed), meniscus on glass walls, sky reflection, caustics, sun/moon glitter, glass edge highlights. Touch ripples are small and local (water + glass cards); only the creature actually under the finger darts away.
- Scenery redo: layered snow-capped mountains with shaded faces and haze, shaded broadleaf/conifer trees, jointed spotted stag, tall lotus plants (long stems with buds, half-open and open blooms, standing leaves, roots visible underwater), reed/cattail clumps and flowering plants.
- Touch: real ripples (flat rings on the surface, round rings underwater) that disturb the surface; fish, jellyfish, turtle, seahorses, butterflies, rabbit and deer flee from a finger and drift back.
- Surface: lotus flowers, lily pads, reeds, small flowering plants, butterflies. Land: meadow, trees, bushes, grass, hopping rabbit, grazing deer.
- Light = day (sun, clouds, birds); Dark = evening (low sun, dusk sky, fireflies); AMOLED = night (moon, stars, shooting star, fireflies).
- Appearance cards (Light / Dark / AMOLED / Follow system) now use the Ocean glass tile style.
- Header and bottom navigation are lightly translucent glass; GlassPanel (e.g. BassWave level card) uses a frosted glass that is more solid than tiles.


## World themes + long-hold volume read-back (2026-11-10)
- Removed the old theme system completely: Theme Manager, `.mtz`/`.budsytheme` import, `ThemeStore`, `ThemeParser`, Ocean Reef / Ganga Himalaya and the WaterWorld scene, icon/hero/background packs. Stock Budsy code paths are unchanged.
- New built-in worlds in `WorldThemes.kt` / `WorldScenes.kt`: **Forest**, **Snow**, **Registaan**, **Samundar**. Each has Day, Night and AMOLED palettes and its own animated vector scene (no image assets). Cards, tiles, header and panels use tinted 3D glass. Settings > World Themes picks one; "Stock Budsy" is the first card.
- Gesture read-back: `Protocol.parseGestureTable` now also reads slots other than button 1 (the same slots `buildGestureWrite` writes), so a Long touch and hold = Volume up/down write is not reported as "Earbud kept its previous gesture". The on-call group (button 6) and disabled (button 0) entries are still ignored.
- Not compiled here (no Android SDK / network). Build with the GitHub Actions workflow or local Gradle.
