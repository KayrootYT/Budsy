# Budsy — World art & comfort update (10 Nov 2026)

Ye **latest version** (Forest / Snow / Registaan / Samundar worlds wali) par kaam kiya gaya hai.

## 1. Chaar worlds — ab poori tarah realistic

Har world Day / Night / AMOLED teeno me hand-painted vector scene hai, ab zyada depth ke saath:

- **Forest** — 3-stop sky, soft clouds aur parinde, pedon se aati light rays, gradient pahadiyan,
  do-tone pines + broadleaf trees (sunlit crown), drifting mist ki 3 layers, ghaas par dhoop ke dhabbe,
  foreground grass, din me girte patte aur raat me jugnu.
- **Snow** — polar sky, din me clouds/birds, raat me 4 aurora curtains (glowing crest), shaded pahad
  notched snow caps ke saath, snow-capped pines, frozen lake strip jisme reflection, snow sparkles,
  3 depth layers me snowfall.
- **Registaan** — warm/cool sky, bloomed sun ya bada moon, rim-lit dunes, warm haze, chalta hua
  camel caravan (shadow ke saath), cactus + rocks, udti ret, heat shimmer, raat me chhota camp fire.
- **Samundar** — depth-graded paani, 6 light shafts, surface caustics, door ki fish school,
  branching coral, rocks, kelp, glossy fish, jellyfish glow, bubbles, raat me plankton.
- Har scene me **cinematic vignette** taaki glass cards padhne me clear rahein.

## 2. Naye controls / missing cheezein

- **Living backgrounds** switch (Settings → Appearance aur World Themes ke andar):
  animation off = ek still frame, battery/heat kam. Choice save hoti hai.
- **World Themes picker**:
  - Sirf selected world animate hota hai (baaki still preview) — smooth aur sasta.
  - Picker khula ho to peeche ka app background pause rehta hai.
  - **APPLIED** badge, Stock Budsy ka asli wallpaper mini-preview (silk gradient + light blobs),
    accessibility (Button / RadioButton + selected state).
- **Header connection menu → World Themes** shortcut; world active hone par header icon palette dikhata hai.
- **Appearance cards** (Light / Dark / AMOLED / Follow system) ab live miniature dikhate hain
  (wallpaper + card + shadow + accent + status dot; System me light/dark split).

## 3. Performance / battery

- Pehle scenes display refresh rate (60–120 fps) par chalte the. Ab ek shared **~30 fps clock**
  (`rememberWorldTime`) hai jo app background me jaate hi ruk jaata hai.
- Reduce motion (system animation scale 0) ya Living backgrounds off → sirf ek still frame.
- Static previews par koi clock nahi chalta.

## 4. Code check + tests

- Is environment me verified:
  - `compileDebugKotlin` — **PASS**
  - `testDebugUnitTest` — **87 tests, 0 failures** (3 naye `WorldThemesTest` bhi)
- Naya test: 4 worlds, unique ids/names/accents, aur Light/Dark/AMOLED palette resolution.
- Baaki project (Bluetooth / protocol / EQ / ANC) code chhua nahi gaya.

## 5. Build note

Is aarch64 proot container me Google ka x86-64-only `aapt2` nahi chalta, isliye local check ke liye
Ubuntu ka ARM64 `aapt2` + API 34 framework jar use hua. **Aapke GitHub Actions (x86-64) par normal
`gradle clean testDebugUnitTest assembleDebug` chalega**, koi override nahi chahiye.

Is delivery me APK nahi banaya (aapke kehne ke mutabik) — sirf project source.

## 6. Abhi device par check karna baaki

- Chaaron worlds ka frame rate / heat / look real phone par.
- Real Nord Buds 3 ke saath ANC/EQ read-back (is update me protocol code touched nahi).
