# Budsy 2.0 — Phase 4

## Implemented
- Persisted selected built-in design identity instead of forcing the app to Stock on every launch.
- Added built-in selection entries for Aurora Glass, Crystal Light, Nothing Matrix, OnePlus Aurora, Titanium Luxury, and Stock Budsy.
- Added distinct light, dark, and AMOLED palette definitions for each built-in identity.
- Kept appearance selection independent from design identity.
- Applying a built-in theme clears the imported-theme override; imported theme management remains available.
- Added OnePlus Aurora hero accent mapping.
- Bluetooth / BLE / GATT / RFCOMM implementation files were not modified in this phase.

## Not yet complete
- The five themes still share the existing screen structure and navigation. They are not yet five entirely bespoke UI implementations.
- Theme Customization Studio with live token editing is not included yet.
- Android Gradle build and physical-earbud validation were not run in this environment.
