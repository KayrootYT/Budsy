# Budsy engineering validation status

Date: 2026-10-24

## Changes in this revision
- Restored active-state liquid-glass glow borders and status pulses.
- Added animated hero rings and a subtle floating/tilting product illustration.
- Reduced feature-tile icon scale and tightened label hierarchy for more consistent tile layouts.
- Removed the automatic ANC-Off write during connection; the app preserves the earbud-reported mode until the user changes it.
- Cross-checked custom-EQ `0x0418` inner payload against supplied HeyMelody APK `HeadsetCoreService.M0` / `EqInfo`; Budsy sends it over its RFCOMM control channel. Target-model support and physical behavior remain unverified.
- Added secure-to-insecure RFCOMM fallback only for standard SPP.
- Corrected UTF-8 decoding for custom EQ profile names and peer names.

## Validation performed
- Kotlin compiler check passed for the platform-independent `Protocol.kt` source.
- Protocol smoke checks passed for frame layout, split-frame parsing, RFCOMM EQ round-trip, UTF-8 profile parsing, GATT EQ field layout/range validation, and ANC mask decoding.
- Archive integrity check passed after packaging.

## Not verified in this environment
- Full Android Gradle build / `testDebugUnitTest` / `assembleDebug`: Gradle and Android SDK are not installed in this execution environment.
- UI rendering on a physical device or emulator.
- Actual Nord Buds 3 / Nord Buds 3 Pro hardware behavior for ANC, Find My Buds, battery/case readings, firmware, or custom EQ.
- Custom EQ `0x0418`: the source-level field layout is confirmed, but Nord Buds 3 / Pro firmware acceptance and physical EQ behavior still require target-device capture and read-back. No BLE/GATT UUID is assumed for this command.


## UI theme revision (2026-10-24)
- Added five selectable appearance presets in Settings: Liquid Titanium, Nothing Dot Matrix, OnePlus Aurora, Sony Studio, and Spatial 3D.
- Each preset has its own palette/accent and theme-specific vector hero treatment, header icon motion, and animated theme selector.
- Compact top bar remains fixed in the Scaffold top-bar slot.
- Replaced the static hero image with a Compose vector-rendered earbud/case illustration. Dragging moves the art in the finger direction and springs back; the product does not rotate.
- Validation limitation: a full Android Gradle build could not be run because Gradle/Android SDK are not installed in this environment. UI and touch behavior still require emulator/physical-device verification.

## UI polish pass (2026-10-24)
- Refined the pinned header with a compact theme-icon tile, subtle theme-specific motion, smaller connection status chip, and a divider for clearer separation from the scrollable page.
- Added theme-specific icon motion styles and touch bounce feedback to the five theme selector cards.
- Kept the device artwork directional-drag interaction (translation only; no product rotation).
- Kept all three battery slots stable; case battery now shows an unavailable placeholder instead of disappearing and shifting the row when the reading is unknown or the device is disconnected.
- Validation: archive structure and source changes reviewed; full Android build remains unverified because this environment has no Gradle executable or Android SDK.


## Protocol Laboratory Phase 5 (2026-10-30)
- Added BLE ATT inspection on HCI ACL/L2CAP fixed CID `0x0004` while retaining Phase 4 RFCOMM stream extraction.
- Parses ATT Find Information responses, Read By Type characteristic declarations, Read/Read Blob request-response pairing, writes, notifications, indications, and error responses.
- Tracks observed attribute handles and characteristic UUID/properties; shows raw values and UUIDs in the import UI.
- GATT characteristic/event data is persisted with bounded history and included in TXT/JSON exports.
- Added synthetic btsnoop regression coverage for a characteristic declaration and notification.
- UUID-to-feature meaning remains unverified: no ANC/EQ/battery labels are inferred from UUIDs alone. Analysis remains read-only; no packet replay or writes are sent.

## Phase 5 validation limitations
- ZIP integrity and source-level consistency checks are performed when packaged.
- Android Gradle compilation and unit tests are **not verified**: this project archive has no Gradle wrapper and the execution environment has neither Gradle nor Kotlin compiler installed.
- Synthetic fixtures are not a real OnePlus Nord Buds 3 / Nord Buds 3 Pro capture. A real HCI snoop file is still required to validate the target device's UUIDs, handle map, ATT traffic, encryption state, and proprietary payload meanings.


## Protocol Laboratory Phase 6 (2026-10-30)
- Added differential command mapping for RFCOMM proprietary frames and BLE ATT events.
- Compares baseline/current signatures by transport, direction, command/group or ATT opcode/handle/UUID; detects count and value changes.
- Added candidate list to HCI comparison UI and TXT/JSON exports.
- Added regression tests for new command detection, GATT value changes with stable packet count, and unchanged-signal suppression.
- Candidates remain explicitly unverified; no automatic ANC/EQ/battery semantic labels are assigned.
- Android Gradle build and JUnit execution remain unverified because Gradle wrapper/Gradle/Kotlin compiler are unavailable in this environment.


## Protocol Laboratory Phase 7 (2026-10-30)
- Added persistent local command database with Unassigned, OnePlus Nord Buds 3, and OnePlus Nord Buds 3 Pro profiles.
- Records include transport, command hex, label, sample, evidence, timestamp, and OBSERVED/VERIFIED state.
- New entries default to OBSERVED; promotion requires a fresh verification note different from the original evidence.
- Added profile selector, save, verify, delete, JSON database copy, and inclusion in Protocol JSON export.
- Seeded Unassigned observations from existing traces/source analysis only: 0x0106, 0x0109, 0x010C, 0x010D, and 0x0418. No seeded entry is VERIFIED or attributed to a specific earbuds model.
- Added command-hex validation unit tests.
- Android Gradle build and JUnit execution remain unverified because this environment has no Gradle wrapper, Gradle executable, or Kotlin compiler.

## Protocol Laboratory Phase 8 (2026-10-30)
- Added an in-app live event monitor over Budsy's existing opt-in own-connection capture stream.
- Added TX/RX/Unknown/All filters, search by command/payload/decoded text, live counters, matched-reply count, unknown-traffic caution, and newest-100 event timeline.
- Explicitly labels the capture boundary: no cross-app HeyMelody interception; imported HCI/GATT files remain offline snapshots.
- Added unit tests for event filtering, searching, and summary counts.
- ZIP/source checks can be performed locally; Android Gradle compilation and JUnit execution remain unverified because this environment has no Gradle wrapper, Gradle executable, or Kotlin compiler.


## Final combined Protocol Laboratory delivery (2026-10-30)
- Consolidated Phases 1–12 in one source archive; see `FINAL_DELIVERY.md` and `PROTOCOL_LAB.md`.
- Includes differential candidate import, separate Nord Buds 3 / Nord Buds 3 Pro evidence profiles, multi-capture verification workflow, manual-review-only safety gate, and release-readiness report.
- No arbitrary packet replay or guessed BLE/GATT write path is enabled.
- Real target-device captures, Android Gradle build/tests, emulator/phone UI, physical earbud behavior and upgrade installation remain unverified.

## APK protocol cross-check continuation (2026-11-01)
- Re-opened the supplied HeyMelody 117.6.6 decompiled source and verified `HeadsetCoreService.M0(String, EqInfo, int)` directly.
- Confirmed command decimal 1048 (`0x0418`) is sent through `mSetCommandManager`; it is not a BLE GATT characteristic write.
- Confirmed `EqInfo.getSetCommandByteLength()` allocates `5 + UTF-8 name bytes + 3 * band count` bytes, plus the leading action byte in `M0`.
- Confirmed the band frequency helper writes the 16-bit frequency little-endian (`b.i(value, offset, 2, byte[])`), followed by one gain byte; APK also rejects missing frequency/gain arrays and unequal lengths.
- Confirmed Budsy's `buildCustomEqSetPayload` field order and byte encoding match this source. The regression fixture checks a negative gain as two's-complement and a 1000 Hz frequency as `E8 03`.
- Validation run in this environment: `kotlinc` compilation of platform-independent `Protocol.kt` passed; `unzip -t Budsy.zip` passed.
- Full Android Gradle build, Android unit-test task, install/upgrade, and physical Nord Buds 3 / Pro acceptance remain unverified because this environment has no Android SDK or Gradle wrapper. No firmware support is inferred from the APK source alone.

## 2026-11-01 advanced handler follow-up
- Added `VendorAdvancedHandlers.kt` with source-grounded voice-assistant, hearing and OTA payload codecs.
- Added `VendorAdvancedHandlersTest.kt` covering byte layouts and little-/big-endian fields.
- Local `kotlinc` compile of the new handler + protocol inventory passed.
- Local executable smoke test passed (`advanced-handler-smoke=PASS`).
- Full Android Gradle/JUnit build not run: no Gradle wrapper or Android SDK/Gradle installation in this container.
- OTA transmit path remains intentionally disabled; no firmware update was sent.

## Bluetooth / pairing / GATT / dual-connection hardening (2026-11-01)
- Added explicit normal Android bonding flow before SDP/RFCOMM for unbonded BLE/classic discovery candidates; pairing cancellation now reports a useful reason.
- Corrected classic discovery receiver export mode for system Bluetooth discovery broadcasts.
- Added an in-app GATT diagnostic probe from BLE scan results. It discovers the 079A service, checks write/notify properties, enables CCCD notifications and records candidate inbound frames in Protocol Lab.
- GATT control writes are intentionally not exposed: target-model ATT framing and fragmentation remain unverified.
- Removed the arbitrary unknown-feature-flag-to-Dual-Connection selection path. `0x0112/0x8112` remains read-only peer-state reporting; enable/disable/switch protocol is not established.
- Pure Kotlin protocol compilation and smoke tests passed. Full Android build remains not run because this environment has no Gradle, wrapper, Android SDK or android.jar. Physical tests on Nord Buds 3 and Nord Buds 3 Pro remain pending.
- See `BLUETOOTH_RELEASE_VALIDATION.md` for the exact device acceptance matrix and remaining gates.

## Sound Lab verification update
- EQ preset writes now require `0x0406` acknowledgement plus matching `0x010F` read-back.
- BassWave toggle requires `0x0403` acknowledgement plus matching `0x010D` read-back.
- BassWave level requires `0x041B` acknowledgement plus matching `0x0124` read-back.
- Custom EQ requires `0x0418` acknowledgement plus matching `0x0122` profile name/frequency/gain read-back.
- UI success messages are gated on read-back; timeouts/refusals show failure.
- Pure protocol Kotlin source compilation passed. Full Android build remains unverified (Android SDK/Gradle unavailable in this environment).

## Optimization + polish pass (2026-11-02)
- Release: R8 minify + resource shrinking, `proguard-rules.pro`, baseline profile (`baseline-prof.txt`) + profileinstaller.
- `notifyChanged()` skips widget/notification updates unless connection, battery or name changed.
- Wear heartbeat polls every 2 s only while the app is in the foreground (every 10 s otherwise).
- Protocol Lab persists every 100 frames instead of 10.
- Hindi strings completed (app name / default device name / AMOLED intentionally untranslated).
- Tablet/landscape: content width capped at 640 dp. Predictive back + per-app language (`locales_config.xml`).
- Accessibility: nav tabs expose Tab role, connect icon has a click label. Diagnostics log can be shared.
- Not compiled or run here: build with GitHub Actions and test `assembleRelease` (R8) on a device.

## UI battery arcs + OnePlus mark + BassWave slider (2026-11-04)
- Added live left/right battery arcs to the Overview hero. Arcs animate to the current percentage and use green/cyan/yellow/orange/red threshold colors; unknown battery values are not shown.
- Added a case battery arc only when the Bluetooth session is connected, case battery telemetry is valid, and the live hero state is not BOTH_OUT. Both-buds-out hides the case arc. Case visibility is inferred from the existing wear-position state and case battery slot; the protocol does not expose a separately verified case-link signal.
- Added a red OnePlus-inspired mark at the top-left of the Overview device header.
- Made BassWave's -10..+10 slider continuous (`steps = 0`) so the thumb tracks smoothly while dragging. The app still rounds to the device's integer level and sends one verified write when the drag ends; existing acknowledgement/read-back verification is unchanged.
- Added unit-test coverage for case battery visibility conditions.
- Validation: source/archive integrity checks performed. Full Android compile, JUnit task, APK signing, Play Protect scan, and physical Nord Buds testing are not available in this environment (no Gradle wrapper, Gradle installation, or Android SDK). Do not treat the project as a verified APK build until GitHub Actions or an Android build environment completes these checks.

## Production APK signing configuration (2026-11-04)
- Added Gradle release signing configuration that reads credentials from GitHub Actions environment variables or an optional git-ignored `app/keystore.properties` for local builds.
- Added a dedicated signed-release GitHub Actions workflow. It requires all four signing secrets, validates the keystore and alias, runs release unit tests, assembles the release APK, and verifies its signature/certificate with `apksigner` before artifact upload.
- Added `docs/ANDROID_RELEASE_SIGNING.md` with keystore creation, Termux/local setup, GitHub secret names, backup guidance, and Play Protect limitations.
- No keystore or passwords are included in the archive. A signed release APK cannot be produced until the owner creates and securely configures the persistent signing key in GitHub Actions Secrets.
- Static archive, secret-exclusion, and workflow YAML checks passed. Android compilation and cryptographic APK verification remain pending because this environment has no Gradle installation or Android SDK and no user-owned signing key.


## Phase 7 transport reliability update

See `PHASE7_NOTES.md`. GATT discovery/write watchdogs, ordered bounded RFCOMM IO writes, and BLE scan-result coalescing were added. Protocol identifiers and payload encoding were intentionally preserved. Android build/device validation remains pending because the archive does not include the Gradle wrapper.
