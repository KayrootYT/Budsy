# Budsy Android release signing

Budsy release APKs must always use the same private upload/release keystore. Never commit the keystore, its passwords, or `app/keystore.properties`.

## 1. Create the keystore once

Use a trusted computer with JDK `keytool`, or Termux with a JDK installed. Generate a long-lived key and keep at least two encrypted backups in separate safe locations:

```bash
keytool -genkeypair -v \
  -keystore budsy-release.jks \
  -alias budsy-release \
  -keyalg RSA -keysize 4096 -validity 10000
```

Choose strong, unique store and key passwords. Do not share them in chat, commit them, or regenerate a different key for routine updates. Losing the key can prevent updates from installing over an existing app.

## 2. Add GitHub Actions secrets

In the Budsy GitHub repository open **Settings → Secrets and variables → Actions → New repository secret**. Add these four secrets:

| Secret | Value |
|---|---|
| `BUDSY_KEYSTORE_BASE64` | Base64-encoded bytes of `budsy-release.jks` (single line) |
| `BUDSY_STORE_PASSWORD` | Keystore password |
| `BUDSY_KEY_ALIAS` | `budsy-release` (or the exact alias chosen above) |
| `BUDSY_KEY_PASSWORD` | Private-key password |

Create the Base64 value locally without uploading the `.jks` file to the repository:

```bash
base64 -w 0 budsy-release.jks
```

On platforms whose `base64` does not support `-w`, use `base64 budsy-release.jks | tr -d '\n'`.

## 3. Build a signed APK

Run **Actions → Signed Budsy Release APK → Run workflow**, or push a version tag such as `v1.0.1`. The workflow validates the keystore and alias, runs release unit tests, builds `assembleRelease`, verifies the APK signature with Android `apksigner`, and uploads `Budsy-release-signed-*.apk` as a workflow artifact.

The workflow intentionally fails if any signing secret is missing. It never silently publishes an unsigned release APK. The existing debug workflow remains separate and is not suitable for distributing updates over a release-signed installation.

## 4. Optional local signing

For a local build, create `app/keystore.properties` (this file is git-ignored):

```properties
storeFile=../budsy-release.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=budsy-release
keyPassword=YOUR_KEY_PASSWORD
```

Place the keystore at the path resolved from `app/` and run `gradle assembleRelease`. Never put real passwords in tracked files or logs.

## Play Protect note

APK signing establishes publisher/update identity and detects tampering; it does not guarantee that Google Play Protect will skip a scan or warning. New or rarely installed apps can still receive a scan recommendation. Do not attempt to suppress or bypass Play Protect. Publish through a trusted distribution channel and provide a consistent signing identity, clear privacy disclosures, and a clean security review.
