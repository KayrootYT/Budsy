# Budsy mobile redesign — Lovable design translation

The Lovable project is a web-only interaction prototype. This Android project remains the source of truth for device connectivity and protocol behavior. The redesign is translated into native Jetpack Compose components; no web runtime or browser screen is embedded.

## Design tokens translated
- Screen gutters: 20dp; content top/bottom breathing room: 8dp / 36dp.
- Section spacing: 14dp; section heading top rhythm: 18dp.
- Surfaces: 24–26dp rounded cards with 20dp internal padding.
- Feature tiles: minimum 112dp height, 38dp icon wells, 13sp title and 11sp supporting label.
- Navigation: floating 68dp capsule, 16dp side inset, rounded active indicator and spring transition.
- Existing theme palette continues to drive Light, Dark and AMOLED appearance.

## Screen mapping
- Overview: native live device hero and status, real connection actions, battery data, ANC controls, Find Buds and device details.
- Sound Studio: existing protocol-backed presets, custom EQ, BassWave and supported enhancements.
- Controls: existing earbud gesture assignments and call / wear controls.
- Settings: existing device, firmware, permissions, appearance, theme manager and diagnostics.

## Invariants
- Bluetooth discovery, GATT, RFCOMM, ANC, EQ, battery, gesture and protocol handlers are not replaced by prototype/demo state.
- Prototype-only sample values and demo controls are not copied into the native app.
- Stock Budsy theme and Light/Dark/AMOLED modes remain available.

## Compact iOS-style pass (2026-11-03)
- Tiles 112dp -> 78dp, rows 64dp -> 56dp, panel padding 20dp -> 14dp, page spacing 14dp -> 10dp.
- Icon chips are iOS squircles (30% corner radius), 28dp in tiles and 32dp in rows.
- Typography: 12/10sp tile labels, tight -0.25sp tracking on 15sp+ text.
- Motion: smoother spring press (0.95-0.975 scale), softer entrance (22dp slide + 0.97 scale, ease-out curve).
- Overview: ANC moved directly under the hero; battery rings 62dp; Game Mode is a switch row; removed Sound/Controls/Settings tiles that duplicated the bottom nav.
- Bottom nav 68dp -> 58dp.

## Open-source font + icons
- Font: Inter 4.1 (SIL OFL) is downloaded by Gradle task `fetchInterFonts` into app/src/main/assets/fonts and loaded by InterFont.kt. Default theme font = Inter; falls back to system sans if missing.
- Icons: Phosphor Icons (MIT) are downloaded by `fetchPhosphorIcons` into app/src/main/assets/icons. IosIcons.kt provides an app-package Icon() that swaps every Material icon (by ImageVector.name) for its Phosphor twin, falling back to the Material icon if the SVG is missing.
- Both tasks need internet at build time (GitHub Actions has it).
