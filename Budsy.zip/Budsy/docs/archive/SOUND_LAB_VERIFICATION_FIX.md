# Sound Lab verification fix

## Changes

- EQ preset selection no longer changes the displayed device state optimistically. The selected preset remains the last device-reported value until a matching `0x010F` query response arrives.
- `0x0406` write acknowledgements trigger a `0x010F` read-back. Refusals and timeouts are shown as failures; the current device state is queried again.
- BassWave switch writes (`0x0403`) no longer mutate the displayed flag optimistically. The app waits for `0x010D` feature-flag read-back and compares the requested state.
- BassWave level writes (`0x041B`) wait for `0x0124` read-back and compare the exact returned level.
- Custom EQ writes (`0x0418`) wait for `0x0122` profile read-back and compare the profile name and every frequency/gain band before showing success.
- Custom EQ's active profile marker is updated only after matching device read-back. Local-only profiles remain local and are not labelled as applied to the earbuds.
- Sound Lab now shows per-feature Saving / Saved / Failed status messages.
- Automatic Protocol Tester no longer treats any non-empty Custom EQ response as PASS. It parses profile records and reports PARTIAL until exact write/read-back equality has been verified.

## Evidence and limitations

- The write/query command IDs and existing payload codecs are retained from the supplied HeyMelody source analysis and Budsy implementation.
- A successful ACK alone is not considered success for EQ/BassWave. A matching state read-back is required.
- Acoustic changes (actual bass/tonal perception) still require a controlled listening test; protocol read-back cannot prove sound quality.
- Full Android Gradle build and on-device tests were not run in this environment because Android SDK/Gradle are unavailable here.
