# Budsy — Automatic Protocol Tester delivery

Added **Settings → Protocol Verification → Automatic Protocol Tester**.

The tester starts capture when needed, runs the app's existing read-only refresh/query set, waits for responses, and classifies individual features as PASS / PARTIAL / FAIL / UNVERIFIED. It can copy a text report. It does not automatically change device settings or send unverified commands.

See `AUTOMATIC_PROTOCOL_TESTER.md` for the checks, safety limits, and validation notes.

## Validation
- Protocol tester logic compiled with Kotlin compiler against minimal stubs for app-level dependencies.
- Smoke harness passed: no captured traffic is not falsely marked as a feature pass; a matched battery read-back is classified PASS.
- JUnit regression tests added under `app/src/test/java/com/nordbuds/studio/ProtocolAutoTesterTest.kt`.
- Screens source passed a Kotlin parser check (no syntax diagnostics).
- Full Android Gradle build / APK installation not run: no Gradle executable, Gradle wrapper, or Android SDK is present in the workspace.
- Hardware behavior remains to be checked on Nord Buds 3 and Nord Buds 3 Pro separately.
