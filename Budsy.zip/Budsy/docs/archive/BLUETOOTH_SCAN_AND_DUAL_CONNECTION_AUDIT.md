# Bluetooth scanning, connection and dual-connection audit

Date: 2026-11-01
Inputs: `apk_work_for_review.zip` decoded source and current `Budsy.zip` project.

## 1. What Budsy did before this change

- The connect screen listed `BluetoothAdapter.bondedDevices`; this was paired-device discovery, not nearby BLE scanning.
- RFCOMM `Link` was the active control transport. Its default UUID was incorrectly set to the 079A GATT service UUID.
- The APK's `BaseBRDevice.smali` proves the BR/RFCOMM default is `00001107-D102-11E1-9B23-00025B00A5A5`; Budsy's RFCOMM default has now been corrected to this UUID. The GATT UUID remains `0000079A-D102-11E1-9B23-00025B00A5A5`.
- `GattLink` already existed with the APK-derived service/write/notify UUID family, CCCD subscription and MTU-bounded writes, but it was not selected by the connection manager.
- The app's `searching` indicator represented its bonded-device auto-connect loop, not an active BLE scan.

## 2. APK scan implementation evidence

`com/heytap/headset/component/scan/ScanViewModel.smali` Kotlin metadata identifies separate BLE and Bluetooth Classic result collections:
- `mBleScanList` and `mBrScanList`
- BLE found/remove LiveData and BR found/remove LiveData
- connected-device list
- merge/deduplication into a single scan result list
- explicit `startScan(context, fromStartPage)` and `stopScan()` operations

This is evidence the stock app combines BLE scan results and classic BR scan results; it does not justify filtering only on the 079A service UUID. Budsy's new scanner therefore uses an unfiltered BLE scan, deduplicates by address, ranks likely earbud names, and shows RSSI. Classic bonded-device selection remains available separately.

## 3. Budsy changes

- Added `buds/BleScanner.kt` with low-latency BLE scan, deduplication, RSSI, 15-second bounded scan window, stop handling and scan-failure reporting.
- Added `buds/ClassicDiscoveryScanner.kt` for Android BR/EDR inquiry (`ACTION_FOUND` / discovery-finished), matching the APK's separate BR scan result path.
- Added Android 12+ `BLUETOOTH_SCAN` runtime permission and Android 6–11 `ACCESS_FINE_LOCATION` scan permission. `BLUETOOTH_CONNECT` remains separate so the older paired-device connection flow is not blocked by a scan-permission denial.
- Added nearby BLE results to the Connect screen. A selected result currently enters the existing RFCOMM connection attempt; the GATT transport is not silently substituted.
- `GattLink` remains a separate, explicit transport candidate. Its OPOv1 framing and actual applicability to Nord Buds 3 / 3 Pro still need captures from those models.

## 4. Dual / multi-device protocol evidence

The APK has a source-backed peer-state response:
- Query: `0x0112` (existing Budsy initial-read query)
- Reply: `0x8112` (same command with response bit in group)
- Status byte at payload[0], peer count at payload[1]
- Each peer record parsed by `protocol/commands/g.smali`:
  - 6-byte Bluetooth address
  - 1-byte tail length
  - 1-byte connection state
  - 1-byte flags
  - 1-byte UTF-8 name length
  - name bytes
  - tail length equals `3 + nameLength`
- Flags: bit 0 current device, bit 1 main audio device, bit 2 audio active, bits 3–5 device type.
- SDK model `MultiConnectInformationElement` confirms the semantic fields: address, device name, connection state, current-device, main-audio-device, audio-active and device type.

Budsy now decodes `0x8112` into detailed peer state and exposes it in Settings. The existing generic `dualFlagId` preference is NOT proof of dual-connection enablement. The APK also has a `MultiDevicesConnectRepository` with cloud/repository methods and whitelist capability gating. No safe, source-confirmed earbud write command to enable/disable dual connection was established in this pass, so Budsy does not invent one.

## 5. Remaining / hardware gates

- GATT transport selection and GATT command framing must be confirmed with Nord Buds 3 and Nord Buds 3 Pro captures.
- BLE advertisements may use rotating/private addresses; address deduplication is scan-session scoped only.
- The selected BLE result may not be bonded. RFCOMM may require Android pairing first; test the pairing prompt and bonding transition on-device.
- Validate whether the devices advertise 079A, whether scan result contains a stable name, and whether the GATT service is exposed before enabling GATT as a primary control transport.
- Validate `0x8112` peer records against a real dual-connected device. Do not treat the generic feature flag UI as dual-connect control.
- Full Android Gradle build and physical device tests were not available in this container.

## 6. Verification performed

- Pure Kotlin `VendorAdvancedHandlers.kt` compilation: PASS.
- Multi-device record parser smoke test (single peer, address, state, flags, device type, name): PASS.
- BLE scanner and Compose integration were source-reviewed but cannot be Android-compiled here because no Android SDK / Gradle wrapper is present.
