# Automatic Protocol Tester

## Added UI
Settings → Protocol Verification → Automatic Protocol Tester.

## What it does
- Starts ProtocolLab capture only if capture was previously stopped.
- Runs Budsy's existing read-only refresh/query set through the currently connected control link.
- Waits for responses and matches them by command + sequence number.
- Reports per-feature PASS, PARTIAL, FAIL, or UNVERIFIED with evidence and a next action.
- Lets the user copy a plain-text report.
- Stops capture after the run only if the tester started it; an existing user capture is left running.

## Checks
- Existing control connection and request/response transport.
- Battery, ANC state, wear state, EQ preset, custom EQ query, feature flags, gesture mapping, BassWave, firmware, multi-device peer-list response.
- GATT probe result, if the user already ran Probe GATT.
- Find My Buds sound, voice assistant behavior, hearing behavior, and Game Mode latency are deliberately marked UNVERIFIED or PARTIAL because these require physical interaction or an acoustic/latency observation.

## Safety
This tester sends only the same read-only query set already used by `Buds.refreshAll()`. It does not toggle ANC/EQ/Game Mode, trigger Find My Buds, write gesture mappings, initiate firmware updates, replay imported HCI packets, or send unknown commands.

## Status meaning
- PASS: a matched response and expected read-back data were captured during this run. This is protocol evidence, not proof of acoustic quality.
- PARTIAL: some protocol response/state exists, but physical behavior or the complete state is not proven.
- FAIL: a query was transmitted but no matched response arrived, or the device returned an error.
- UNVERIFIED: no sufficient evidence was captured.

A PASS on one pair of earbuds does not certify another model or firmware revision. Nord Buds 3 and Nord Buds 3 Pro must be tested separately.

## Validation performed in this workspace
- `ProtocolAutoTester.kt` compiled with Kotlin compiler against minimal API stubs for its external app dependencies.
- A smoke harness confirmed that no traffic remains UNVERIFIED and a matched battery response is classified PASS.
- Added JUnit source tests for no-traffic, matched battery response, and transmitted-query/no-response cases.
- Full Android Gradle build and APK installation were not run: this workspace has no Gradle executable/wrapper and no Android SDK installation.
