# Protocol implementation status — 2026-11-01

## Core protocol

- Existing OPOv1 encoder, stream parser, sequence handling, request/reply correlation, RFCOMM transport, HCI importer and ATT inspection remain in place.
- Added `GattLink.kt` from the exact GATT UUIDs in the supplied HeyMelody APK's `GattDevice.smali`.
- GATT service discovery checks the service, write and notify characteristics and CCCD. Notifications enter the same OPOv1 stream parser.
- GATT writes are bounded by negotiated MTU. No guessed ATT fragmentation is attempted.
- GATT is not yet selected automatically by Budsy's connection manager. RFCOMM remains the current user-facing control transport until target model captures confirm which transport is active and which framing is expected.

## Feature protocol

Already implemented in Budsy's RFCOMM control path: battery, firmware query, touch gesture table/write, ANC/hold query/write, feature flags (including game and wear-detect), EQ preset, custom EQ 0x0418, BassWave, find-earbuds, event subscription and peer-list query. `ProtocolInventory.kt` records the source/evidence boundary. Custom EQ 0x0418 is cross-checked against APK `HeadsetCoreService.M0` and `EqInfo`; this is not a guarantee of hardware acceptance on every model.

Remaining inventory-only items are other hearing-related handlers and APK command IDs whose complete request/response layouts or device capability rules are not established. The GMN voice and hearing-process payloads described below have now been source-decoded and ported as pure codecs.

## Advanced protocol

- Multi-device: peer-list query exists; device switching/state mutation is not enabled without verified request payloads.
- Fast Pair: GATT/account-key related handlers exist in the APK. Account-key provisioning is not ported from UUID discovery alone.
- Firmware OTA: `UpgradeManager` exists in the APK. Budsy does not transmit firmware blocks until file validation, device/model checks, transfer framing, checksums, acknowledgements, retry/resume and rollback behavior are reconstructed and tested.
- Spatial command family 0x0422 is kept separate from custom EQ 0x0418.

## Verification limits

No Android SDK/Gradle executable is available in this working container, so a full Gradle build could not be run here. Unit tests were added for the protocol inventory boundaries; run `./gradlew test` and `./gradlew assembleDebug` in CI. Real Nord Buds 3 / Nord Buds 3 Pro hardware tests remain required before enabling GATT or advanced writes.

## Reverse-engineered handler port — 2026-11-01 follow-up

### Voice assistant (source-confirmed codec port)
- Query: command `0x0135`, empty payload (`HeadsetCoreService.V`).
- Set control type: command `0x0432`, one-byte payload (`HeadsetCoreService.S0`). App values map exactly `0 -> 0x01`, `1 -> 0x02`, `2 -> 0x04`; other values rejected.
- Set response: status byte only; zero is success (`HeadsetCoreService` SetCommandManager response case `0x8432`).
- Query response is command `0x8103`, payload `[status, flags]`. `CommandUtil.j` maps flags `0x04 -> controlType 2`, `0x02 -> 1`, `0x01 -> 0`; bit `0x80` means earphone connected. The source parser checks a zero status before decoding.

### Hearing detection / enhancement (source-confirmed codec port)
- Query: command `0x0116` (decimal 278); payload is `count`, repeated 3-byte `(deviceType, frequencyType, dBValue)` records, then a 4-byte big-endian UID (`HeadsetCoreService.Y`).
- Set/process: command `0x040E` (decimal 1038). For action 1 or 3, payload is `action`, `count`, repeated 3-byte records, 4-byte big-endian UID, then optional name bytes (`HeadsetCoreService.B0`). Other action values use a one-byte action-only payload.
- Detection parameter helper: `[0x03, 0x01, deviceType, frequencyType, dBValue]` (`HeadsetCoreService.v1`).
- The DTO record itself is exactly three bytes (`HearingDetectingInfo.getData`).
- These codecs are implemented in `VendorAdvancedHandlers.Hearing`; device capability and action semantics still require Nord Buds hardware verification.

### Firmware OTA (wire protocol codec port; sending intentionally disabled)
- Commands recovered from `p250r8.d`: `0x0300` sync, `0x0301` start, `0x0302` data, `0x0303` block verify, `0x0304` validation done, `0x0305` transfer-complete indication, `0x0306` commit, `0x0307` abort, `0x0308` error, `0x030A` switch, `0x030B` get-MTU. Confirmations use the corresponding `0x83xx` IDs.
- Sync payload: legacy 5-byte form (last up-to-four package hash bytes + device type), or 6-byte form (four zero bytes + device type + section count).
- Sync confirmation: status, device type, resume point, flags, resume offset LE32, block size LE16; source requires at least 14 bytes.
- Start payload: 6-byte legacy form, or 142-byte extended form containing package/section metadata, 32-byte hashes, version/build/name fields.
- Data payload: absolute file offset LE32 + data bytes. Block verification payload: block offset LE32 + CRC32 LE32.
- Data confirmation is exactly `[status, retryDelayLE16]`; MTU confirmation is `[status, deviceType, mtuLE16]`. Block-verify CFM `0x11` retries the current block and `0x13` carries a retry offset LE32.
- `VendorAdvancedHandlers.FirmwareOta` contains codecs and constants only. Budsy does not send OTA packets, accept arbitrary firmware files, or expose a firmware-write button. The source APK's image parsing, whitelist/model checks, section CRC, resume/retry state machine and commit/switch sequencing are not yet ported as an executable updater. This is deliberate to avoid bricking earbuds.

### Verification
- New pure Kotlin source compiles with local `kotlinc`.
- Added JUnit regression tests for voice mapping, hearing record/payload layouts, OTA sync/start/data/CRC/MTU layouts.
- Full Android Gradle build and JUnit execution remain unverified in this container because this project archive has no Gradle wrapper and no installed Android SDK/Gradle distribution.
- Nord Buds 3 and Nord Buds 3 Pro compatibility remains hardware-unverified.

## Bluetooth scanning and multi-device follow-up — 2026-11-01

- Added explicit BLE scanner `buds/BleScanner.kt` and classic BR/EDR inquiry scanner `buds/ClassicDiscoveryScanner.kt`; the old screen only enumerated bonded devices and was not a real nearby scan.
- Corrected the RFCOMM default UUID from the mistakenly reused GATT 079A UUID to APK-confirmed `00001107-D102-11E1-9B23-00025B00A5A5` (`BaseBRDevice.smali`).
- Added Android runtime scan permissions (BLUETOOTH_SCAN on Android 12+, ACCESS_FINE_LOCATION on Android 6–11), a bounded low-latency scan, address deduplication, RSSI and nearby result rows.
- BLE scan selection still uses the known RFCOMM control attempt. `GattLink` remains separate until actual Nord Buds 3 / 3 Pro captures prove GATT control framing and service availability.
- Reverse-engineered multi-device response `0x8112` (query `0x0112`) and ported the peer record decoder. Detailed peer state is now retained and shown in Settings.
- Dual-connection enable/disable is NOT yet verified. The APK has a repository/whitelist-gated MultiDevicesConnect subsystem; no confirmed direct earbud toggle payload was found. The old generic feature-flag mapping is not treated as proof of dual-connect control.
- Pure Kotlin advanced-handler compilation and multi-peer parser smoke test passed. Android Gradle build and device tests remain pending.
