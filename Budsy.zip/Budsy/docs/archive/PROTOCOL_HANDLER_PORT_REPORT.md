# Handler reverse-engineering and port report

## Scope
Source inspected from `apk_work_for_review.zip`, especially:
- `com/oplus/melody/btsdk/multidevice/HeadsetCoreService.java`
- `com/oplus/melody/btsdk/api/data/HearingDetectingInfo.java`
- `com/oplus/melody/btsdk/api/data/GmnVoiceAssistConfig.java`
- `com/oplus/melody/btsdk/protocol/upgrade/UpgradeManager.java`
- `p250r8/a.java` (headset upgrade processor)
- `p250r8/d.java` (upgrade state machine)
- `p156k8/c.java`, `p156k8/d.java` (firmware section and device OTA capability)
- `com/oplus/melody/btsdk/protocol/commands/l.java` (poll command manager)

## Ported to Budsy
New file: `app/src/main/java/com/nordbuds/studio/protocol/VendorAdvancedHandlers.kt`
Tests: `app/src/test/java/com/nordbuds/studio/VendorAdvancedHandlersTest.kt`

### Voice assistant
| Operation | Command | Payload | Evidence |
|---|---:|---|---|
| Query GMN voice config | `0x0135` | empty | `HeadsetCoreService.V()` |
| Set control type | `0x0432` | one byte: app 0->1, 1->2, 2->4 | `HeadsetCoreService.S0()` |
| Query response | `0x8103` | status + one-byte flags | `PollCommandManager.M()` + `CommandUtil.j()` |
| Set response | `0x8432` | status byte | SetCommandManager response dispatch |

The `0x0135` query response is `0x8103`, parsed by `PollCommandManager.M()` via `CommandUtil.j`. Payload is `[status, flags]`; flags map `0x04 -> controlType 2`, `0x02 -> 1`, `0x01 -> 0`, and bit `0x80` indicates connected. Budsy now implements this parser.

### Hearing
| Operation | Command | Payload | Evidence |
|---|---:|---|---|
| Query process/hearing data | `0x0116` | count + 3-byte records + UID BE32 | `HeadsetCoreService.Y()` |
| Set/process | `0x040E` | action; for actions 1/3: count + records + UID BE32 + name bytes | `HeadsetCoreService.B0()` |
| Detection parameter | `0x040E` | `[3,1,record3]` | `HeadsetCoreService.v1()` |

Record layout: `(deviceType, frequencyType, dBValue)`; each field is one byte. `HearingDetectingInfo.getData()` confirms three-byte order.

### OTA command inventory
| Request | Response / indication | Role |
|---:|---:|---|
| `0x0300` | `0x8300` | Sync |
| `0x0301` | `0x8301` | Start section |
| `0x0302` | `0x8302` | Transfer data |
| `0x0303` | `0x8303` | Block verify |
| `0x0304` | `0x8304` | Validation done |
| `0x0305` | `0x8305` | Transfer complete indication/response |
| `0x0306` | `0x8306` | Commit |
| `0x0307` | `0x8307` | Abort |
| `0x0308` | `0x8308` | Error indication/response |
| `0x030A` | `0x830A` | Switch |
| `0x030B` | `0x830B` | Get MTU |

Payload layouts implemented as pure codecs:
- Sync legacy: 5 bytes; trailing package hash bytes (up to 4), then device type.
- Sync section form: 4 reserved zero bytes, device type, section count.
- Start legacy: device type, upgrade type, compressed size LE32 (6 bytes).
- Start extended: same prefix + package type, raw size LE32, section ID LE32, hash ID LE32, 32-byte section hash, 3-byte software version, 24-byte build time, 32-byte name, 32-byte compressed hash (142 bytes).
- Data: offset LE32 + bytes.
- Block verify: block offset LE32 + CRC32 LE32. CFM status `0x11` retries the current block; `0x13` supplies an explicit retry offset LE32.
- Data CFM: status + retry delay LE16.
- MTU CFM: status + device type + MTU LE16.

## Explicit non-port / safety boundary
The OTA state machine in the APK also validates package sections, product/device type, remote capabilities, battery level, checksums, block retry offsets, resume points, validation and commit/switch completion. The full executable update manager is not enabled in Budsy. The new code does not send OTA packets. A wrong firmware image or incorrect model mapping can permanently disable earbuds; a real updater needs authentic firmware package parsing, signature/hash validation, per-model allowlisting, complete ACK/retry/resume handling and hardware testing before any write path is enabled.

## Current status
- Voice control-type payload: source-confirmed and ported.
- Voice query response parser: source-confirmed and ported (`0x8103`, `[status, flags]`).
- Hearing query/process payloads: source-confirmed and ported.
- OTA wire constants and core payload codecs: source-confirmed and ported as pure functions.
- OTA executable transfer: deliberately disabled.
- Nord Buds 3 / Nord Buds 3 Pro: hardware compatibility not yet proven.
