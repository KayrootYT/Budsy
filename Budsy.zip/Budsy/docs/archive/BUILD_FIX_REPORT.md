# Budsy build failure fix

## Evidence
The uploaded GitHub Actions log failed at:
`app/src/main/java/com/nordbuds/studio/Screens.kt`
with three Kotlin Compose errors at lines 1027, 1028 and 1030:
`@Composable invocations can only happen from the context of a @Composable function`.

## Root cause
`ProtocolAutoTesterDialog` defined an ordinary Kotlin callback (`statusColor`) that accessed `P.green`, `P.accent`, and `P.sub`. `P` is a `@Composable @ReadOnlyComposable` CompositionLocal getter, so it cannot be read from inside a non-composable lambda.

## Fix
Read `P` once in the composable scope (`val palette = P`) and capture the immutable `Pal` instance in the callback. The callback now reads `palette.green`, `palette.accent`, and `palette.sub`.

## Validation
- Confirmed the exact three diagnostics in the supplied workflow logs.
- Confirmed the patch replaces the offending callback.
- ZIP integrity test passed (151 entries).
- Full Android Gradle build was not run in this environment: Gradle wrapper is absent and Android SDK/Gradle are not installed. Re-run GitHub Actions to confirm compiler result.
