# Budsy Protocol Laboratory

The Settings screen now contains an opt-in Protocol Laboratory for recording the framed TX/RX traffic exchanged by **Budsy's own RFCOMM control connection**.

## Capture a feature

1. Open Budsy > Settings > Protocol Laboratory.
2. Tap **Start capture**.
3. Connect the Nord Buds from Budsy (or keep the current connection active).
4. Change exactly one setting in Budsy, such as ANC mode, a gesture, Game Mode, or EQ.
5. Wait a few seconds for the earbud reply / state notification.
6. Reopen Protocol Laboratory and use **Copy export**. Paste the log into a text file and share it for protocol analysis.
7. Tap **Stop** before doing unrelated work. **Clear** removes the in-memory capture.

## What is recorded

- TX and RX direction, timestamp, command ID, group, sequence number, and payload bytes.
- Unknown framed commands are kept; the display labels unrecognized IDs as `Unknown command` rather than guessing their purpose.
- Up to 3,000 most recent events are retained in memory for the current app process. Capture is off by default and the capture is not silently uploaded.

## Important boundaries

- This records frames parsed from Budsy's own RFCOMM control socket. It cannot passively inspect HeyMelody or any other app's private Bluetooth connection. Use Android Bluetooth HCI snoop logging (if enabled on the device) for a separate system-level capture of another app's traffic.
- It records complete protocol payloads after frame parsing, not raw Bluetooth radio packets, ATT/GATT packets, retransmissions, or malformed bytes discarded by the frame parser.
- A successful response is not necessarily proof that a feature physically works. Verify by reading the setting back and observing the device behavior.
- No arbitrary raw-command transmitter is exposed. Unknown commands should be studied from captured traffic first; writing guessed payloads can change settings unexpectedly or destabilize the connection.

## Current known command labels

`0100` handshake; `0105` firmware; `0106` battery; `0108` gestures; `0109` wear; `010C` ANC/hold query; `010D` feature discovery; `010F` EQ preset; `0112` peers; `0122` custom EQ query; `0124` BassWave query; `0200` event list; `0205` subscription; `0400` find earbuds; `0401` gesture write; `0403` feature flag write; `0404` ANC/hold write; `0406` preset write; `0418` custom EQ write; `041B` BassWave write.

These labels describe the current reverse-engineered Budsy implementation and are not a guarantee that every firmware uses identical semantics.


## Phase 2 — decoder, correlation, and local protocol history

- A conservative decoder now annotates known reply payloads for battery (`0106`), wear (`0109`), feature flags (`010D`), gesture table (`0108`), firmware (`0105`), and raw-only mode/EQ/BassWave responses.
- Request/reply correlation matches the same command and sequence number and records the observed round-trip time. Unmatched responses remain in the log; no false match is fabricated.
- Captured history is persisted locally in app-private SharedPreferences (up to 1,200 latest frames) and restored when Budsy restarts. Capture remains opt-in.
- TXT and JSON exports are available from the Protocol Laboratory.
- A small observed-command catalog counts frames by command ID.
- Decoder confidence is explicit: values without verified semantic mapping are labelled raw/unverified rather than guessed.

The decoder does not claim to identify every unknown command automatically. New semantics still require controlled one-setting-at-a-time captures and read-back/behavior verification.

Decoder regression tests cover the captured battery/feature layouts, zero-padding handling, and the rule that unverified ANC mode payloads remain raw.


## Phase 3 — HCI snoop import, capture diff, and verified feature labels

- Added a bounded, read-only btsnoop importer (maximum 20 MiB and 100,000 records). It validates the file header, version, datalink, record lengths, and truncation.
- It summarizes HCI command opcodes, HCI event codes, ACL packet counts, TX/RX direction, and dropped-record metadata. It does not claim ACL payloads are decoded into the proprietary RFCOMM protocol; that requires L2CAP/RFCOMM reassembly and vendor-frame extraction.
- Imported report and a selected baseline are saved locally. The comparison reports added/removed HCI opcodes and changed counts.
- Added manual feature-ID annotations for IDs `01..20`; labels are explicitly user-verified rather than guessed from feature bit values.
- Import is via Android's document picker. To obtain a HeyMelody capture, enable Bluetooth HCI snoop in Developer options, reproduce the interaction, generate a bug report, extract the btsnoop file, and import it. Android does not allow ordinary apps to read the protected Bluetooth log directory directly.
- Arbitrary HCI command replay is intentionally not implemented. Imported packets are analysis-only; sending unknown packets to earbuds could alter settings or disrupt the connection.

Regression tests cover btsnoop header/record parsing, HCI packet type counts, direction, opcode/event extraction, diffs, and invalid-file rejection.


## Phase 4 — HCI ACL / L2CAP / RFCOMM reassembly

- HCI ACL fragments are reassembled per direction and connection handle using packet-boundary flags and the L2CAP length.
- L2CAP signaling connection request/response pairs are tracked for RFCOMM PSM `0x0003`; only successfully negotiated dynamic CIDs are treated as RFCOMM.
- RFCOMM UIH frames are parsed with one- and two-octet length fields. DLCI 0 multiplexer control frames are not mistaken for user data.
- Proprietary Budsy/HeyMelody `0xAA` frames are extracted from RFCOMM user-data payloads using the existing protocol stream parser. Each extracted record retains direction, command, group, sequence, and payload.
- Extracted frames are displayed in the HCI import panel and included in TXT export. HCI report persistence stores the extracted frame list.
- This phase supports classic Bluetooth RFCOMM captures. BLE/GATT ATT traffic still requires a separate ATT/GATT decoder and characteristic-fragment reassembly.
- The importer remains analysis-only. No captured HCI command is replayed.

Regression tests use a synthetic btsnoop capture with RFCOMM PSM negotiation and a proprietary battery frame to test extraction end-to-end.


## Phase 5 — BLE / GATT ATT inspection

The HCI snoop importer now inspects the fixed ATT L2CAP channel (CID `0x0004`) in addition to the Phase 4 Classic RFCOMM path. It records observed ATT operations, attribute handles, raw values, UUIDs learned from Find Information responses, and characteristic value handles/properties learned from Read By Type characteristic declarations. Read requests are paired with their response direction when possible. GATT events and characteristic discoveries are included in the on-device import report and TXT export.

Supported ATT observations include Find Information, Read By Type, Read/Read Blob, Write Request/Command, Notification, Indication, Prepare Write, and Error Response. Unknown ATT opcodes remain visible as raw opcode records. UUIDs are displayed as observed identifiers only; the analyzer does not claim that an unknown UUID means ANC, EQ, battery, or another feature.

Limitations: this remains a read-only analyzer of imported HCI H4 btsnoop files. It does not access Android's protected Bluetooth log directory, start system-wide capture, decrypt encrypted BLE link traffic, or transmit/replay packets. GATT discovery can be incomplete if the capture starts after service discovery, omits pairing/encryption setup, or is truncated. ATT requests and responses may not all be present. RFCOMM and ATT are separate transports and are reported separately. No real Nord Buds capture has been validated in this phase; synthetic unit fixtures validate ATT parsing only.


## Phase 6 — Differential command mapping

The laboratory now compares the selected HCI baseline with the latest imported capture and surfaces candidate signals that are new, removed, have changed counts, or retain the same count but carry different values. It compares RFCOMM proprietary command/group/direction signatures and BLE ATT opcode/handle/UUID/direction signatures. Candidate rows show observed counts and up to three sample values. The report and TXT/JSON exports include these unverified candidates.

Recommended controlled workflow:
1. Capture a short baseline while the earbuds are idle.
2. Import it and tap **Set baseline**.
3. Perform exactly one action (for example, toggle ANC once) while capturing a second HCI snoop file.
4. Import the second file and inspect the candidate rows.
5. Repeat the same action several times, then perform a different action as a negative control.
6. Only after a signal consistently follows one action and not the negative control should the operator manually assign a feature label.

This engine does not automatically declare that a command means ANC, EQ, battery, or any other feature. It is a differential evidence tool, not a semantic decoder. Captures with different connection setup, timing, background traffic, encryption, or packet loss can produce noise. Use same-device, same-firmware, same-state captures and repeat each experiment.


## Phase 7 — Persistent command database and device profiles

Added a local, persistent command catalogue with three explicit profiles: Unassigned, OnePlus Nord Buds 3, and OnePlus Nord Buds 3 Pro. Entries record transport, command ID, operator label, raw sample, evidence note, timestamp, and status. New records start as `OBSERVED`. They can only be promoted to `VERIFIED` with a separate fresh note; the same initial evidence text cannot be reused as the verification note. Entries can be deleted and the database can be copied as JSON. Protocol JSON export also embeds the command database.

The initial Unassigned profile is seeded with only observations already present in the supplied traces and prior source analysis: 0x0106, 0x0109, 0x010C, 0x010D and source-level custom-EQ command candidate 0x0418. Their labels explicitly describe uncertainty. None is pre-marked VERIFIED or assigned to either Nord Buds model. Device-specific profiles start empty until matching captures are added by the operator. This prevents cross-model assumptions.

The database is local to the app's private SharedPreferences. It is not cloud-synced, and the JSON action copies the data for backup/sharing; importing a JSON database is not implemented in this phase.


## Phase 8 — In-app live monitor and event triage

Added a live monitor panel over the events Budsy already captures from its own control connection. It reports retained TX/RX counts, matched replies, unknown-command activity, and the latest command; provides All/TX/RX/Unknown filters plus a text search over command IDs, labels, decoded text, and payload bytes; and shows the newest 100 matching events. Unknown traffic is surfaced as a visible caution so it can be saved and compared rather than guessed.

Important boundary: this is **not** a system-wide Bluetooth sniffer. It observes Budsy's own RFCOMM/control traffic only while capture is enabled. It cannot directly intercept HeyMelody or another app's private Bluetooth connection. Imported HCI/btsnoop and GATT reports remain offline snapshots. Android's protected Bluetooth logging and BLE link encryption restrictions still apply.

Added pure helper tests for direction/unknown filters, text/payload search, and live summary counts. No automatic semantic mapping, packet replay, or arbitrary command transmission was added.


## Phase 9 — Differential BLE/RFCOMM feature candidates

- Baseline/current HCI comparison emits candidate signatures for RFCOMM vendor frames and BLE ATT/GATT operations.
- Candidates can be imported into the currently selected device profile, but are always stored as `OBSERVED`.
- Candidate rows retain capture name, count delta and sample values so an operator can repeat the experiment.
- A candidate signature is not a semantic feature mapping. In particular, an ATT handle or UUID is not automatically called ANC, battery, EQ or Game Mode.

## Phase 10 — Model-specific evidence profiles

- Separate persistent profiles are provided for `OnePlus Nord Buds 3` and `OnePlus Nord Buds 3 Pro`, alongside `Unassigned`.
- Entries remain isolated by profile; imported candidates go only into the active profile.
- Verification requires two distinct positive capture references, a passed negative-control attestation and a fresh verification note.
- These fields are operator-entered evidence references. The app does not independently inspect the original files to prove the experiment was performed; preserve the source captures for engineering review.

## Phase 11 — Command safety and manual-review gate

- The release gate blocks a command when the model profile, command identifier, VERIFIED status, two positive capture references or negative control is missing.
- BLE/GATT candidates additionally require a confirmed service UUID and write-characteristic UUID before they can reach manual review.
- Even when the evidence gate passes, the outcome is `MANUAL_REVIEW_ONLY`. No arbitrary packet replay, guessed write, or automatic GATT command transmission is implemented.
- Custom EQ `0x0418` payload layout is cross-checked against the supplied HeyMelody APK source (`HeadsetCoreService.M0` / `EqInfo`) and is sent through Budsy's RFCOMM command channel. Actual command support, accepted values, read-back and physical EQ behavior still require a capture on each target model/firmware. No BLE/GATT UUID is inferred for this command.

## Phase 12 — Consolidated release readiness

- A per-profile readiness report summarizes OBSERVED/VERIFIED entries, transports, imported capture/baseline presence and remaining blockers.
- The capture checklist covers controlled positive/negative experiments, model/firmware isolation, GATT prerequisites and release validation.
- TXT/JSON exports include protocol observations and the command database; the readiness report can be copied from the app.
- Release status intentionally remains `ENGINEERING PREVIEW · NOT HARDWARE-VERIFIED` until real target-device evidence, Android build/test, installation/upgrade and physical feature tests are completed.


## Supplied APK source audit (2026-11-01)

See [APK_PROTOCOL_AUDIT.md](APK_PROTOCOL_AUDIT.md) for the command-ID inventory extracted from the supplied HeyMelody 117.6.6 decompilation, the confirmed `0x0418` custom-EQ field layout, and the commands deliberately left inventory-only pending payload and target-firmware evidence.
