# HeyMelody APK → Budsy protocol audit

## Input inspected

- Budsy source: `Budsy.zip` (103 archive entries).
- Supplied decoded app: package `com.heytap.headset`, version `117.6.6`, versionCode `117006006`, min SDK 24, target SDK 36.
- Decompiled sources: `jadx_source/sources/`; bytecode: `decoded/smali/`.
- Main source evidence: `com/oplus/melody/btsdk/multidevice/HeadsetCoreService.java`, `com/oplus/melody/btsdk/api/data/EqInfo.java`, and `com/oplus/melody/btsdk/manager/service/BluetoothService.java`.

## Confirmed custom EQ implementation

The APK method `HeadsetCoreService.M0(String, EqInfo, int)` checks support for decimal command 1048, builds the payload, then sends command 1048 through `mSetCommandManager`. Decimal 1048 is `0x0418`. `EqInfo.getSetCommandByteLength()` and `M0` establish this payload:

```text
[action][min][max][eqId][utf8NameLength][utf8Name...][bandCount]
repeat bandCount: [frequency low][frequency high][gain byte]
```

- Frequencies are written as 16-bit little-endian values.
- Gain is cast to one byte (signed dB represented in two’s-complement).
- Name length is UTF-8 byte length, not character count.
- APK rejects absent frequency/db arrays and unequal array lengths.
- `0x0422` is not the custom-EQ command; do not route custom EQ through it.
- This is source-level evidence for the command builder. It does not prove Nord Buds 3 firmware supports the command or that the device accepts a particular profile.

Budsy now uses the same byte layout for RFCOMM `0x0418`, clamps edited gains to the active profile’s advertised min/max, and includes regression tests against the recovered field order.

## APK command IDs discovered in HeadsetCoreService

These IDs are observed at the APK source call sites. Most do not have a proven payload schema or Nord Buds 3 support mapping in the supplied evidence; they are inventory only and are deliberately not exposed as arbitrary write buttons.

| Command | Decimal | APK source method | Budsy status |
|---:|---:|---|---|
| `0x109` | 265 | `P()` | Implemented / known layout |
| `0x112` | 274 | `d0()` | Implemented / known layout |
| `0x116` | 278 | `Y()` | Implemented / known layout |
| `0x117` | 279 | `Q()` | Implemented / known layout |
| `0x119` | 281 | `L()` | Implemented / known layout |
| `0x11a` | 282 | `f0()` | Inventory only; schema/support not ported |
| `0x11f` | 287 | `N()` | Implemented / known layout |
| `0x124` | 292 | `D()` | Implemented / known layout |
| `0x126` | 294 | `h0()` | Inventory only; schema/support not ported |
| `0x127` | 295 | `g0()` | Implemented / known layout |
| `0x130` | 304 | `l0()` | Implemented / known layout |
| `0x131` | 305 | `A()` | Implemented / known layout |
| `0x132` | 306 | `c0()` | Implemented / known layout |
| `0x133` | 307 | `j0()` | Implemented / known layout |
| `0x134` | 308 | `W()` | Implemented / known layout |
| `0x135` | 309 | `V()` | Implemented / known layout |
| `0x400` | 1024 | `O0()` | Partially represented; target firmware needs verification |
| `0x403` | 1027 | `j1()` | Partially represented; target firmware needs verification |
| `0x404` | 1028 | `I0()` | Partially represented; target firmware needs verification |
| `0x404` | 1028 | `i1()` | Partially represented; target firmware needs verification |
| `0x405` | 1029 | `t1()` | Partially represented; target firmware needs verification |
| `0x406` | 1030 | `N0()` | Partially represented; target firmware needs verification |
| `0x408` | 1032 | `c1()` | Implemented / known layout |
| `0x40d` | 1037 | `t0()` | Implemented / known layout |
| `0x40e` | 1038 | `B0()` | Implemented / known layout |
| `0x40e` | 1038 | `v1()` | Implemented / known layout |
| `0x40f` | 1039 | `H0()` | Implemented / known layout |
| `0x410` | 1040 | `o1()` | Implemented / known layout |
| `0x411` | 1041 | `K0()` | Implemented / known layout |
| `0x412` | 1042 | `b1()` | Implemented / known layout |
| `0x413` | 1043 | `W0()` | Implemented / known layout |
| `0x414` | 1044 | `P0()` | Implemented / known layout |
| `0x415` | 1045 | `A0()` | Implemented / known layout |
| `0x417` | 1047 | `l1()` | Implemented / known layout |
| `0x418` | 1048 | `M0()` | Partially represented; target firmware needs verification |
| `0x419` | 1049 | `y0()` | Implemented / known layout |
| `0x41a` | 1050 | `V0()` | Implemented / known layout |
| `0x41b` | 1051 | `F0()` | Implemented / known layout |
| `0x41c` | 1052 | `E0()` | Implemented / known layout |
| `0x41d` | 1053 | `d1()` | Implemented / known layout |
| `0x41e` | 1054 | `e1()` | Implemented / known layout |
| `0x420` | 1056 | `R0()` | Implemented / known layout |
| `0x421` | 1057 | `g1()` | Implemented / known layout |
| `0x422` | 1058 | `U0()` | Partially represented; target firmware needs verification |
| `0x423` | 1059 | `Q0()` | Implemented / known layout |
| `0x424` | 1060 | `Y0()` | Implemented / known layout |
| `0x425` | 1061 | `D0()` | Implemented / known layout |
| `0x426` | 1062 | `x1()` | Implemented / known layout |
| `0x427` | 1063 | `n1()` | Implemented / known layout |
| `0x428` | 1064 | `C0()` | Implemented / known layout |
| `0x429` | 1065 | `s0()` | Implemented / known layout |
| `0x42b` | 1067 | `a1()` | Implemented / known layout |
| `0x42c` | 1068 | `p1()` | Implemented / known layout |
| `0x42d` | 1069 | `k1()` | Implemented / known layout |
| `0x42e` | 1070 | `m1()` | Implemented / known layout |
| `0x430` | 1072 | `f1()` | Implemented / known layout |
| `0x431` | 1073 | `T0()` | Implemented / known layout |
| `0x432` | 1074 | `S0()` | Implemented / known layout |
| `0x433` | 1075 | `Z0()` | Implemented / known layout |
| `0x434` | 1076 | `L0()` | Implemented / known layout |
| `0x435` | 1077 | `h1()` | Implemented / known layout |
| `0xf00` | 3840 | `u1()` | Inventory only; schema/support not ported |
| `0xf03` | 3843 | `x0()` | Inventory only; schema/support not ported |

## Safety and compatibility decisions

- The APK is a complete vendor app decompilation, not a standalone protocol specification. It contains application, account/cloud, firmware, diagnostics, health and platform integration code in addition to earbud control.
- Budsy remains a native independent controller. The vendor APK’s private service graph, cloud endpoints, account logic, proprietary firmware updater and platform integrations are not copied wholesale.
- Only commands with an understood payload and transport are candidates for implementation. Unknown command payloads remain inventory-only; no guessed writes or arbitrary packet replay were added.
- BLE ATT/GATT observations in HCI captures are not enough to assign semantics. A target-device capture must confirm service UUID, characteristic UUID, properties, security/pairing, framing and response semantics before any BLE write path is implemented.
- A command ACK is not proof that the physical feature changed. Read-back and physical behavior are required.

## Remaining hardware validation

1. Connect the exact Nord Buds 3 model and firmware with Budsy; save a short protocol export.
2. Query custom EQ list (`0x0122`), save a test profile with `0x0418`, then query again and confirm profile name, id, selected state and gains.
3. Repeat on Nord Buds 3 Pro separately; do not transfer model-specific mappings.
4. Run the Android unit tests and build the APK in GitHub Actions or an Android SDK environment; this container has Java/Kotlin but no Android SDK/Gradle wrapper.
5. Confirm install/upgrade and audio/control coexistence on the phone.

## Follow-up source cross-check (2026-11-01)

The supplied decompiled source was re-opened for the exact `M0` write path. `com.oplus.accountsdk.open.b.i(int, int, int, byte[])` writes each byte using right-shifts by `8 * index`, confirming little-endian frequency encoding. `HeadsetCoreService.M0` writes the frequency at the current band offset for two bytes, advances three bytes, and writes the corresponding `dbValue` byte. It checks for non-empty frequency and dB arrays and equal array lengths before dispatch. Budsy's 0x0418 payload builder and regression fixture match this layout. This is protocol-source verification only, not proof of target firmware acceptance.
