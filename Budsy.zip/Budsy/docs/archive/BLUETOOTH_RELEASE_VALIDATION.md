# Budsy Bluetooth / GATT / Dual-Connection Validation

Date: 2026-11-01

## Implemented in this revision

### BLE discovery
- Explicit unfiltered BLE scan with a bounded scan window, RSSI, last-seen timestamp and address deduplication.
- Android 12+ `BLUETOOTH_SCAN` runtime permission; Android 6–11 fine-location scan permission.
- BLE advertisements are treated as discovery candidates only. An advertised BLE address is not assumed to be the same identity as the classic BR/EDR address.

### Classic discovery
- BR/EDR inquiry remains separate from BLE scanning.
- Receiver registration uses `RECEIVER_EXPORTED` because Bluetooth discovery broadcasts are emitted by the system Bluetooth process on modern Android. The receiver handles only the two Bluetooth discovery actions.

### Pairing and RFCOMM
- Before RFCOMM/SDP, `Link.connect()` requests the normal Android bond flow for an unbonded device and waits up to 30 seconds for `BOND_BONDED`.
- If pairing is cancelled or does not complete, the UI status explains that the Android pairing prompt must be accepted.
- Vendor RFCOMM UUID remains `00001107-D102-11E1-9B23-00025B00A5A5`; standard SPP is fallback only.
- Secure-to-insecure fallback remains restricted to standard SPP.

### GATT diagnostic probe
- BLE result rows expose `Probe GATT`.
- Probe connects, discovers the source-derived `079A` service, checks write/notify characteristic properties, and subscribes to notifications through CCCD.
- Notifications are parsed as candidate OPOv1 frames and captured as `GATT-RX` in Protocol Lab.
- **No GATT control writes are exposed.** APK UUID presence alone does not prove that Budsy's OPOv1 command framing, command routing or ATT fragmentation is correct for Nord Buds 3/3 Pro.

### Dual connection
- The `0x0112` / `0x8112` peer-state query/decoder remains available for read-only peer status.
- Removed the unsafe UI path that let users choose an arbitrary unknown feature flag as the Dual Connection toggle.
- No enable/disable/switch command is claimed. Stock-app multi-device repository/cloud gating and device whitelist behavior are not equivalent to a proven earbud command.

## Validation performed here
- `Protocol.kt` + `VendorAdvancedHandlers.kt`: Kotlin/JVM compile PASS.
- Protocol frame split/reassembly smoke test: PASS.
- `0x8112` single-peer decode smoke test: PASS.
- Voice assistant response decode smoke test: PASS.
- Hearing payload encode smoke test: PASS.
- ZIP integrity: PASS after packaging.

## Not completed / external gates
- Full Android Gradle build and JUnit: NOT RUN; this environment has no Gradle executable, Gradle wrapper, Android SDK or `android.jar`.
- BLE/GATT physical probe: NOT RUN; no Bluetooth adapter or earbuds are attached to this build environment.
- Pairing and RFCOMM acceptance: NOT RUN on hardware.
- Nord Buds 3 and Nord Buds 3 Pro: no separate device captures supplied; model-specific compatibility is unverified.
- Dual connection: requires two host devices connected simultaneously and source/capture evidence for enabling and switching. Only peer-state decoding is implemented.

## Required device acceptance matrix

Run independently for Nord Buds 3 and Nord Buds 3 Pro:
1. Scan with BLE and note advertised name/address/RSSI.
2. Tap Probe GATT; record whether 079A service, 0100... write and 0200... notify characteristics are present and their properties.
3. Stop probe; tap Connect; accept Android's system pairing prompt if shown.
4. Confirm Android bond state is BONDED and RFCOMM connects using the vendor UUID.
5. Confirm handshake and at least one request/response exchange; save Protocol Lab export.
6. Test ANC/EQ only after the response is observed and verify read-back.
7. To test dual connection, connect two separate phones and export `0x8112` responses before/after switching audio focus. Do not enable unknown feature flags.

A real capture must be attached for each model before enabling GATT control writes or a dual-connection toggle.
