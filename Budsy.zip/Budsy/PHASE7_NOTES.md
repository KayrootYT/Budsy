# Budsy 2.0 — Phase 7: Bluetooth transport reliability

## Implemented

- GATT service discovery is guarded so the MTU callback and the MTU fallback timer cannot start discovery twice.
- GATT writes are bounded to 64 queued frames and each in-flight write has a 5-second callback watchdog. A stalled write clears the pending queue and requests a link reset/fallback rather than allowing commands to accumulate indefinitely.
- Existing GATT UUIDs, command frame encoding, sequence generation, payload bytes, and WRITE_TYPE_NO_RESPONSE behavior are unchanged.
- RFCOMM writes now pass through one bounded, ordered IO worker. This preserves byte order while preventing socket writes/flushes from blocking the caller/UI thread.
- Pending RFCOMM writes carry a connection generation token, so queued data from an old connection is discarded after reconnect/close.
- BLE advertisement bursts are coalesced to at most four UI result publications per second; scan duration and discovery behavior remain unchanged.

## Deliberately unchanged

- Vendor service/characteristic UUIDs and RFCOMM UUID selection.
- Protocol command IDs, groups, payload layouts, checksums/framing, and sequence rules.
- No automatic replay of a command after an uncertain write outcome; replay could duplicate ANC/EQ/control actions.
- Existing GATT-to-RFCOMM fallback policy.

## Verification

- Source-level inspection completed for GattLink, Link, BleScanner, and Buds connection/fallback integration.
- ZIP integrity checked after packaging.
- Android compilation and physical-earbud regression tests are not confirmed: this source archive has no `gradlew` or `gradle/wrapper/gradle-wrapper.jar`.
