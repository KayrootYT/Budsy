# Budsy implementation audit (2026-11-05)

This audit is based on the supplied Budsy source archive. It intentionally separates
implemented source paths from features that still need target-earbud verification.

## Already present in this project
- BLE/GATT and RFCOMM transport abstractions (`buds/GattLink.kt`, `buds/Link.kt`).
- ANC/Transparency control and read-back handling in `Buds.kt`.
- EQ preset query/write and read-back (`0x010F` / `0x0406`).
- Custom EQ profile read/write (`0x0122` / `0x0418`).
- BassWave level query/write and read-back (`0x0124` / `0x041B`).
- Feature flag query (`0x010D`) including BassWave flag `0x1D`.
- Device diagnostics, command mapping and protocol monitor tools.
- Audio profile connection observation in `Audio.kt`.

## Not yet proven / do not expose as working toggles
- Spatial Audio ON/OFF on Nord Buds 3. `0x0422` is mentioned in source comments as a
  Spatial type, but the command payload, response semantics, and target firmware
  compatibility are not implemented/verified here.
- HeyMelody Spatial VM's `H0(address, 27, boolean)` must be traced through its concrete
  transport encoder before mapping it to a Budsy packet. The integer 27 alone is not
  enough to infer a command ID or payload.
- Dolby Atmos processing on the earbuds. A UI toggle cannot add Dolby processing if
  neither the phone audio stack nor earbud DSP/firmware exposes it.
- Global third-party-app audio spectrum capture. Android playback capture is restricted
  by Android version, capture policy, and user consent; it is not the same as reading
  the earbud DSP signal.

## Microphone
The Sound Studio must not request `RECORD_AUDIO` for the planned controls. Audio playback
capture, if later added, must use Android's playback-capture permission flow and respect
source-app capture policies. It must not silently fall back to microphone recording.

## Safe next implementation steps
1. Preserve the existing protocol handlers and transports.
2. Extract the exact HeyMelody `H0` call chain and packet encoder from the supplied APK.
3. Capture a positive Spatial ON transition, a positive OFF transition, and a negative
   no-action control on the target Nord Buds 3.
4. Implement a Spatial switch only after matching the payload and response in two
   independent captures and confirming read-back.
5. Keep unsupported effects disabled with a truthful "Not supported by device" state.

## Build verification
This archive has no Gradle wrapper (`gradlew` / `gradle-wrapper.jar`). A successful APK
build cannot be claimed until a Gradle 8.9+ environment is available and the workflow
completes successfully.
