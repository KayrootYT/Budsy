# Phase 9 – Premium UI polish (2026-11-04)

- Moved the OnePlus 1+ raster mark to the pinned top app header, replacing the lightning/app glyph. Removed the duplicated brand mark from the Overview device card.
- Added a PNG logo asset under `app/src/main/res/drawable-nodpi/oneplus_logo_red.png`.
- Reduced the Controls screen earbud illustration from 124dp to 88dp and tightened its stage/halo to improve proportion.
- Standardized FeatureTile sizing and typography (88dp minimum height, 23dp icon, 11sp title, 9sp subtitle) for a more consistent hierarchy.
- Battery row now always retains the Case tile. When case telemetry is unavailable, stale percentage is hidden and the tile explicitly reads “Case disconnected”.
- Existing five built-in theme palettes include Light, Dark and AMOLED branches in `Theme.kt`; these remain intact.
- No Bluetooth/BLE/GATT/RFCOMM protocol implementation files were changed in this UI polish phase.

## Verification
- ZIP archive integrity checked after packaging.
- Android Gradle compilation and physical-device UI/earbud verification were not run in this environment (Gradle executable and wrapper are unavailable).
- The included PNG is a locally rasterized 1+ glyph recreation; for a pixel-exact official press-pack logo, replace it with the official OnePlus PNG asset supplied by the user or obtained through the official brand resource download.
