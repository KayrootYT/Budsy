# Protocol notes

Frame: `AA | length (LEB128 = 7 + payload) | 00 00 | cmd-lo | cmd-hi | seq | payload-len16 LE | payload`.
Length is one byte below 128 and two bytes above (131 -> `83 01`). Our requests use seq 01..FE; seq FF is a push from the earbuds.
Replies set bit 7 of cmd-hi. Sources for the corrections below: published OPOv1 captures (QuickBuds `docs/PROTOCOL.md`, the "Cracking OPOv1" write-up, OpenBuds issue #13 for Nord Buds 3 Pro). They were captured on other models, so every item is still **unverified on your exact Nord Buds 3 firmware**; use Settings > Diagnostics > Protocol log to confirm.

| Cmd | Meaning |
|---|---|
| 0x0100 / 0x0103 | handshake / product id |
| 0x0200 -> 0x0205 | event list -> subscribe to offered events only (1 battery, 2 wear, 3 ANC, 5 game, 6 peers) |
| 0x0108 / 0x0401 | gesture table / write. Entry = `[side, button, gesture, function]`, button 1 = main pad, **6 = on-call group (ignored for main gestures)** |
| 0x010C / 0x0404 | noise-control mask (`01 01 mask`) and hold cycle (`02 01 mask`) |
| 0x010D / 0x0403 | feature switches: 04 wear detection (auto play/pause), 06 game mode, 1D BassWave. **0B is Golden Sound, not ear detection** |
| 0x0400 | find earbuds: `01` start, `00` stop |
| 0x0122 / 0x0418 | custom EQ list / create (01), save+select (02), delete (03). **0x0422 is the Spatial type, not custom EQ** |
| 0x0500 (from buds) | time request: answer `00 <unix seconds LE32>` with the same seq, or the earbuds stop replying and reset the link after 3-5 s |
| 0x050C / 0x051C / 0x051D | answered `00 01 00` / `00 00 00` / `01` |
| 0x0501 / 0x0502 / 0x0504 / 0x0510 | informational pushes, never answered (0x0504 = EQ changed) |
| push 0x0204 event F2 | acknowledged with `00 F2` |

## Hold and Find-device verification status

- Hold write uses `0x0404` with payload `[2, 1, mask]`; app must query `0x010C` submode `2` and compare the returned mask before showing Saved. This path is implemented with timeout/failure UI, but still requires a real Nord Buds 3 firmware capture to confirm the exact payload.
- Find-device uses `0x0400`: payload `[1]` starts both buds, `[1, side]` is sent for a single side, `[0]` stops. If the earbuds refuse the plain start, the older `[2, 1, 2]` list is tried once. The ack (`0x8400`) is now shown to the user instead of "not confirmed".
- The app's classic RFCOMM control connection and Android A2DP/HFP audio route are independent. A connected control channel does not prove media audio is routed to the earbuds; the Overview warning reflects that distinction.


## Custom EQ

- The custom EQ list is read with `0x0122`: `[status, count, (selected, min, max, id, nameLen, name, bandCount, (freqLE16, gain)...)...]`.
- It is written with `0x0418` (decimal 1048), matching the supplied HeyMelody APK's `HeadsetCoreService.M0` / `EqInfo`: `[action, min, max, id, nameLen, name, bandCount, (freqLE16, gain-byte)...]` over the RFCOMM SetCommandManager channel. Action 01 creates (id 00), 02 saves and selects, 03 deletes. Ids are renumbered after create/delete, so the list is re-read after every write.
- `0x0422` is a different command in the APK and is not used for custom EQ. Do not infer a BLE/GATT service UUID from this RFCOMM command implementation.

## Case lid / bud presence

No case-lid command or push has been identified. Wear flags (`0x0109`, push `0x04` sub-type 2) are per-bud only and their
bit meanings are unverified. See DEVICE_HERO_STATES.md. Do not derive lid state from Bluetooth connectivity or wear flags.

## Case lid hint (not used yet)

Captures on other OPOv1 models show bit 2 (0x04) of the wear status as "case lid open" (0 = in case/closed, 1/5 = out of ear, 3/7 = in ear, 4 = in case/open). This app still does not derive the lid from it (see DEVICE_HERO_STATES.md) until it is confirmed on Nord Buds 3.


## In-app capture

See [PROTOCOL_LAB.md](PROTOCOL_LAB.md) for using the opt-in Protocol Laboratory in Settings. It records parsed TX/RX frames on Budsy’s own RFCOMM control connection, including sequence numbers. It cannot passively sniff another app or raw BLE radio traffic.


## Supplied HeyMelody APK cross-check

The `0x0418` inner payload is independently confirmed by the supplied HeyMelody 117.6.6 decompilation: `HeadsetCoreService.M0(String, EqInfo, int)` builds the action/min/max/id/UTF-8-name/band-count/frequency/gain fields and submits decimal command 1048. This confirms the command payload layout, not device support or physical behavior on every Nord Buds firmware. See `APK_PROTOCOL_AUDIT.md` for the broader command inventory and evidence boundaries.

## Protocol implementation phase update (2026-11-01)

- Added a separate `GattLink` transport using the exact service/write/notify UUIDs recovered from the supplied APK's `GattDevice.smali` (`y8.1/i.smali`). It enables CCCD notifications and feeds notification bytes into the existing OPOv1 stream parser.
- GATT is intentionally separate from the existing RFCOMM `Link`; no silent transport fallback is enabled. A frame is written only when it fits the negotiated ATT write limit (`MTU - 3`). ATT-level fragmentation has not been established from the available evidence and is not guessed.
- Added `ProtocolInventory` to separate Core, Feature, and Advanced handlers and record evidence level. Existing feature commands remain routed through the established RFCOMM implementation; the new GATT transport is currently an isolated diagnostic/engineering transport, not the default device control path.
- OTA, Fast Pair account-key provisioning, and some hearing/voice-assistant handlers are catalogued as APK-source discoveries only. They are not exposed as writable operations until their complete packet/state machines and target-device compatibility are verified.

## Additional HeyMelody handlers recovered from review APK

`VendorAdvancedHandlers.kt` contains pure Kotlin payload codecs for:
- GMN voice assistant: query `0x0135`; control-type set `0x0432` with wire values 1/2/4.
- Hearing process: query `0x0116`; set/process `0x040E`; three-byte hearing records and big-endian UID fields.
- Firmware OTA: command IDs `0x0300..0x0308`, `0x030A`, `0x030B` and their `0x83xx` confirmations; sync/start/data/block-verify/validation/commit/abort/switch/MTU payload helpers.

These are codecs only. Voice query response decoding is not guessed because the APK poll-parser method failed JADX decompilation. Firmware OTA sending remains disabled until package verification and per-model hardware testing are complete. See `PROTOCOL_HANDLER_PORT_REPORT.md` for evidence and exact boundaries.
