# Budsy 2.0 — Consolidated Delivery (Phases 1–8)

This archive consolidates the latest cumulative Budsy source revision through Phase 8. It is delivered as `Budsy.zip` as requested.

## Included phase work

- **Phase 1–2 — Overview and battery presentation:** hero battery arcs removed; battery status tiles placed before Noise Control; left/right values are hidden when disconnected; case tile visibility is guarded by available telemetry and hero state; battery progress and threshold colors animate. Existing hero animations are retained.
- **Phase 3 — Sound controls:** BassWave slider is continuous while dragging and sends the device's integer level on drag completion. Sound writes use acknowledgement and read-back verification as documented in the source status notes.
- **Phase 4–6 — Themes and customization groundwork:** built-in theme/mode infrastructure and theme customization work are carried in the cumulative source. See `THEME_IMPLEMENTATION.md`, `THEME_PACKAGE_FORMAT.md`, and `PHASE6_NOTES.md` for the implemented scope and limitations. Do not assume every theme has wholly independent screen layouts unless confirmed in the code.
- **Phase 7 — Transport reliability:** GATT discovery/write watchdogs, ordered bounded RFCOMM writes, and BLE scan-result coalescing. Protocol identifiers and payload encoding were preserved.
- **Phase 8 — Smart reconnect:** duplicate ACL/A2DP connection broadcasts are coalesced; bounded retry schedule (2s, 5s); successful connection stops retries; explicit Disconnect cancels recovery and persists the paused state.

## Compatibility safeguards

Existing UUIDs, command IDs, payload layouts, sequence generation, BLE characteristics, RFCOMM service UUIDs, and protocol parsing were not intentionally changed by the Phase 7–8 transport work. Firmware update transmit remains disabled where protocol behavior is unverified. No arbitrary packet replay or guessed BLE write path is enabled.

## Verification status

- ZIP archive integrity must be checked after packaging (see delivery report).
- Source-level inspections and platform-independent protocol checks are recorded in `BUILD_STATUS.md`.
- **Not verified:** full Android Gradle build, Android unit-test task, signed APK assembly, emulator/phone UI, and physical OnePlus Nord Buds 3 / Nord Buds 3 Pro acceptance. The archive has no Gradle wrapper and this execution environment has no confirmed Android SDK/Gradle build environment.
- Do not treat this source ZIP as a tested or installable APK. Run the repository's GitHub Actions release workflow with the owner's configured signing secrets to validate release assembly and signing.
