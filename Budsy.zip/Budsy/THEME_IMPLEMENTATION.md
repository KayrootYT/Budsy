# Budsy Theme Engine

Files: `ThemeEngine.kt` (spec, parser), `ThemeStore.kt` (import/export/library, safe extraction), `Theme.kt` (palette, font loading, CompositionLocals),
`ThemeAssets.kt` (images, themed icons, card brush, motion speed), `ThemeManagerScreen.kt` (page), hooks in `Components.kt` and `MainActivity.kt`.

Flow: package -> ThemeStore.importPackage -> normalised `theme.properties` in `files/budsy_themes/<id>/` -> ThemeSpec -> BudsyTheme provides
LocalPal, LocalTypeSpec, LocalThemeSpec, LocalThemed, LocalReduceMotion -> every component reads them.
Stock Budsy = ThemeSpec.STOCK with `LocalThemed = false`, so stock rendering is unchanged.

Not yet verified: the Gradle build and the unit tests were not run in the environment that produced this change (no Android toolchain). Run a CI build before release.

## Phase 4 update — built-in identity selection

The built-in identity selector now exposes Aurora Glass, Crystal Light, Nothing Matrix, OnePlus Aurora, Titanium Luxury, and the permanent Stock Budsy option. The selected identity is persisted in `design_theme`; Light, Dark, AMOLED, and System appearance remain a separate preference. Imported `.mtz` / `.budsytheme` packages continue to override the built-in palette and remain independently managed. The five identities have distinct palette tokens and continue to flow through the existing theme-aware component and hero rendering paths. This is the built-in theme foundation; a fully per-theme bespoke screen/navigation architecture and a visual token editor are still future work.
