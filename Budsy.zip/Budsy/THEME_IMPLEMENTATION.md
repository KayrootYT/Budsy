# Budsy Theme Engine

Files: `ThemeEngine.kt` (spec, parser), `ThemeStore.kt` (import/export/library, safe extraction), `Theme.kt` (palette, font loading, CompositionLocals),
`ThemeAssets.kt` (images, themed icons, card brush, motion speed), `ThemeManagerScreen.kt` (page), hooks in `Components.kt` and `MainActivity.kt`.

Flow: package -> ThemeStore.importPackage -> normalised `theme.properties` in `files/budsy_themes/<id>/` -> ThemeSpec -> BudsyTheme provides
LocalPal, LocalTypeSpec, LocalThemeSpec, LocalThemed, LocalReduceMotion -> every component reads them.
Stock Budsy = ThemeSpec.STOCK with `LocalThemed = false`, so stock rendering is unchanged.

Not yet verified: the Gradle build and the unit tests were not run in the environment that produced this change (no Android toolchain). Run a CI build before release.
