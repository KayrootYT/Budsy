# Build log fixes

The supplied GitHub Actions log failed during `:app:compileDebugKotlin`, not during Android SDK setup.

Fixes applied:
- Added the missing `kotlinx.coroutines.launch` import used by the directional drag-return animation.
- Added missing Compose animation-core imports used by the animated pinned header.
- Replaced invalid four-argument `Triple(...)` theme entries with a typed `ThemeChoiceItem` model.
- Added missing Compose `background` and `RoundedCornerShape` imports in the theme settings UI.
- Marked the diagnostics UI function `@Composable`.

Validation:
- ZIP structure/integrity checked after packaging.
- This container does not have Gradle or an Android SDK configured, so a new Android build has not been run here. Run the GitHub Actions build to confirm there are no further compiler errors.

## Hero + connection update
- Hero: case is larger (330dp stage). Case is layered (closed / empty open / per-cradle bud sprites). A bud taken out lifts out of its cradle and floats above the case; the other bud stays in the case. Both out: case fades away, both buds settle in the centre. Putting a bud back reverses the animation.
- Connection: the app is only "Connected" after the earbuds answer a protocol frame (no more fake connections). Battery is re-polled until all slots are filled, wear state is polled every 2s, a 30s watchdog drops dead links so auto-connect can retry.
- Auto-connect: new `BtConnectReceiver` connects as soon as the earbuds connect to the phone, even if the app is closed. The in-app retry loop is faster while the earbuds are connected as audio.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build to confirm.
