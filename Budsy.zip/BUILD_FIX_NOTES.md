# Build log fixes

The supplied GitHub Actions log failed during `:app:compileDebugKotlin`, not during Android SDK setup.

Fixes applied:
- Added the missing `kotlinx.coroutines.launch` import used by the directional drag-return animation.
- Added missing Compose animation-core imports used by the animated pinned header.
- Replaced invalid four-argument `Triple(...)` theme entries with a typed `ThemeChoiceItem` model.
- Added missing Compose `background` and `RoundedCornerShape` imports in the theme settings UI.
- Marked the diagnostics UI function `@Composable`.

Validation:
- ZIP structure/integrity checked after packaging.
- This container does not have Gradle or an Android SDK configured, so a new Android build has not been run here. Run the GitHub Actions build to confirm there are no further compiler errors.

## Hero + connection update
- Hero: case is larger (330dp stage). Open state uses the original open-case art (both buds inside); when a bud is removed it switches to empty case + per-cradle bud sprites and the bud lifts out and floats above the case, the other stays. Both out: case fades away, buds settle in the centre. Reverse when put back.
- Connection: the app is only "Connected" after the earbuds answer a protocol frame (no more fake connections). Battery is re-polled until all slots are filled, wear state is polled every 2s, a 30s watchdog drops dead links so auto-connect can retry.
- Auto-connect: new `BtConnectReceiver` connects as soon as the earbuds connect to the phone, even if the app is closed. The in-app retry loop is faster while the earbuds are connected as audio.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build to confirm.

## Hero: cradle blur fix + realistic bud animation
- `hero_case_empty_{black,white}.png`: smudged (blurred) area where the buds used to sit was repainted with clean, crisp cradle wells.
- `HeroArt.kt`: spring-based lift (soft settle), bud rises straight up then drifts in an arc, cradle sprite and real bud swap at the same instant (no ghosting), soft contact shadow under the lifted bud.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build to confirm.
- hero_case_empty_*: replaced with real empty-case photos (no painted/fake cradles). Closed/open-with-buds/sprites still belong to the old case model.

## Hero / UI overhaul
- Case: new real empty-case photos (white 58422 / black 58421); buds: new real bud photos (4). Hero now draws the buds standing in the cradles, clipped at the case lip; no sprite crops from the old case. Old open-case/sprite/pair PNGs removed. Closed-case PNGs are still the old model (need a closed photo of the new case).
- Lag: palette/typography/colour scheme cached (they were rebuilt on every recomposition, invalidating the whole UI); glow border caches its brush; only the selected theme card animates.
- Tiles/rows: one size system (TILE_H=96dp, ROW_H=64dp).
- Light/Dark: onAccent (dark text on the lime accent), deeper accents in Light, Material onPrimary/inverseSurface set.
- Launcher icon: new Nord-Buds style adaptive icon (+ monochrome for themed icons).
- Earbud controls: real bud photo (white on dark, black on light) with a pulsing touch-pad marker.
- Not compiled here (no Gradle/SDK): run the GitHub Actions build.
