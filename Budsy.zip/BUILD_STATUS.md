# Budsy engineering validation status

Date: 2026-10-24

## Changes in this revision
- Restored active-state liquid-glass glow borders and status pulses.
- Added animated hero rings and a subtle floating/tilting product illustration.
- Reduced feature-tile icon scale and tightened label hierarchy for more consistent tile layouts.
- Removed the automatic ANC-Off write during connection; the app preserves the earbud-reported mode until the user changes it.
- Added a separate, guarded encoder and unit tests for the observed GATT custom-EQ `0x0418` field layout. It is not connected to a live GATT writer because service/characteristic IDs and framing/checksum remain unverified.
- Added secure-to-insecure RFCOMM fallback only for standard SPP.
- Corrected UTF-8 decoding for custom EQ profile names and peer names.

## Validation performed
- Kotlin compiler check passed for the platform-independent `Protocol.kt` source.
- Protocol smoke checks passed for frame layout, split-frame parsing, RFCOMM EQ round-trip, UTF-8 profile parsing, GATT EQ field layout/range validation, and ANC mask decoding.
- Archive integrity check passed after packaging.

## Not verified in this environment
- Full Android Gradle build / `testDebugUnitTest` / `assembleDebug`: Gradle and Android SDK are not installed in this execution environment.
- UI rendering on a physical device or emulator.
- Actual Nord Buds 3 / Nord Buds 3 Pro hardware behavior for ANC, Find My Buds, battery/case readings, firmware, or custom EQ.
- GATT `0x0418` hardware writes: do not enable until the proprietary service UUID, write characteristic UUID, transport framing, and response semantics are confirmed from a target-device capture.


## UI theme revision (2026-10-24)
- Added five selectable appearance presets in Settings: Liquid Titanium, Nothing Dot Matrix, OnePlus Aurora, Sony Studio, and Spatial 3D.
- Each preset has its own palette/accent and theme-specific vector hero treatment, header icon motion, and animated theme selector.
- Compact top bar remains fixed in the Scaffold top-bar slot.
- Replaced the static hero image with a Compose vector-rendered earbud/case illustration. Dragging moves the art in the finger direction and springs back; the product does not rotate.
- Validation limitation: a full Android Gradle build could not be run because Gradle/Android SDK are not installed in this environment. UI and touch behavior still require emulator/physical-device verification.

## UI polish pass (2026-10-24)
- Refined the pinned header with a compact theme-icon tile, subtle theme-specific motion, smaller connection status chip, and a divider for clearer separation from the scrollable page.
- Added theme-specific icon motion styles and touch bounce feedback to the five theme selector cards.
- Kept the device artwork directional-drag interaction (translation only; no product rotation).
- Kept all three battery slots stable; case battery now shows an unavailable placeholder instead of disappearing and shifting the row when the reading is unknown or the device is disconnected.
- Validation: archive structure and source changes reviewed; full Android build remains unverified because this environment has no Gradle executable or Android SDK.


## Protocol Laboratory Phase 5 (2026-10-30)
- Added BLE ATT inspection on HCI ACL/L2CAP fixed CID `0x0004` while retaining Phase 4 RFCOMM stream extraction.
- Parses ATT Find Information responses, Read By Type characteristic declarations, Read/Read Blob request-response pairing, writes, notifications, indications, and error responses.
- Tracks observed attribute handles and characteristic UUID/properties; shows raw values and UUIDs in the import UI.
- GATT characteristic/event data is persisted with bounded history and included in TXT/JSON exports.
- Added synthetic btsnoop regression coverage for a characteristic declaration and notification.
- UUID-to-feature meaning remains unverified: no ANC/EQ/battery labels are inferred from UUIDs alone. Analysis remains read-only; no packet replay or writes are sent.

## Phase 5 validation limitations
- ZIP integrity and source-level consistency checks are performed when packaged.
- Android Gradle compilation and unit tests are **not verified**: this project archive has no Gradle wrapper and the execution environment has neither Gradle nor Kotlin compiler installed.
- Synthetic fixtures are not a real OnePlus Nord Buds 3 / Nord Buds 3 Pro capture. A real HCI snoop file is still required to validate the target device's UUIDs, handle map, ATT traffic, encryption state, and proprietary payload meanings.


## Protocol Laboratory Phase 6 (2026-10-30)
- Added differential command mapping for RFCOMM proprietary frames and BLE ATT events.
- Compares baseline/current signatures by transport, direction, command/group or ATT opcode/handle/UUID; detects count and value changes.
- Added candidate list to HCI comparison UI and TXT/JSON exports.
- Added regression tests for new command detection, GATT value changes with stable packet count, and unchanged-signal suppression.
- Candidates remain explicitly unverified; no automatic ANC/EQ/battery semantic labels are assigned.
- Android Gradle build and JUnit execution remain unverified because Gradle wrapper/Gradle/Kotlin compiler are unavailable in this environment.


## Protocol Laboratory Phase 7 (2026-10-30)
- Added persistent local command database with Unassigned, OnePlus Nord Buds 3, and OnePlus Nord Buds 3 Pro profiles.
- Records include transport, command hex, label, sample, evidence, timestamp, and OBSERVED/VERIFIED state.
- New entries default to OBSERVED; promotion requires a fresh verification note different from the original evidence.
- Added profile selector, save, verify, delete, JSON database copy, and inclusion in Protocol JSON export.
- Seeded Unassigned observations from existing traces/source analysis only: 0x0106, 0x0109, 0x010C, 0x010D, and 0x0418. No seeded entry is VERIFIED or attributed to a specific earbuds model.
- Added command-hex validation unit tests.
- Android Gradle build and JUnit execution remain unverified because this environment has no Gradle wrapper, Gradle executable, or Kotlin compiler.

## Protocol Laboratory Phase 8 (2026-10-30)
- Added an in-app live event monitor over Budsy's existing opt-in own-connection capture stream.
- Added TX/RX/Unknown/All filters, search by command/payload/decoded text, live counters, matched-reply count, unknown-traffic caution, and newest-100 event timeline.
- Explicitly labels the capture boundary: no cross-app HeyMelody interception; imported HCI/GATT files remain offline snapshots.
- Added unit tests for event filtering, searching, and summary counts.
- ZIP/source checks can be performed locally; Android Gradle compilation and JUnit execution remain unverified because this environment has no Gradle wrapper, Gradle executable, or Kotlin compiler.


## Final combined Protocol Laboratory delivery (2026-10-30)
- Consolidated Phases 1–12 in one source archive; see `FINAL_DELIVERY.md` and `PROTOCOL_LAB.md`.
- Includes differential candidate import, separate Nord Buds 3 / Nord Buds 3 Pro evidence profiles, multi-capture verification workflow, manual-review-only safety gate, and release-readiness report.
- No arbitrary packet replay or guessed BLE/GATT write path is enabled.
- Real target-device captures, Android Gradle build/tests, emulator/phone UI, physical earbud behavior and upgrade installation remain unverified.
