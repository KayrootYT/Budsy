# Protocol notes

```kotlin
/**
 * Reverse-engineered OPPO/OnePlus earbud control protocol.
 *
 * Frame: AA | length16 LE (= 7 + payload length) | reserved | command-low |
 * command-group | sequence | payload-length16 LE | payload bytes.
 * Group 0x01 is query, 0x02 is unsolicited push, and 0x04 is set. Replies
 * set bit 7 of the group byte (for example 0x0106 -> group 0x81).
 *
 * Commands observed in this implementation: 0x0105 firmware, 0x0106 battery,
 * 0x0108 gesture table, 0x0109 wear state, 0x010C noise/hold modes,
 * 0x010D feature flags, 0x010F EQ preset, 0x0112 peers, 0x0122 custom EQ,
 * 0x0124 BassWave; writes 0x0401 gesture, 0x0403 flag, 0x0404 ANC/hold,
 * 0x0406 preset, 0x041B BassWave, 0x0422 custom EQ.
 *
 * Gesture entry: [side, 0x01, gestureId, functionId], side 1=left, 2=right.
 * This protocol is reverse engineered and has not been verified on every firmware.
 */
```

## Hold and Find-device verification status

- Hold write uses `0x0404` with payload `[2, 1, mask]`; app must query `0x010C` submode `2` and compare the returned mask before showing Saved. This path is implemented with timeout/failure UI, but still requires a real Nord Buds 3 firmware capture to confirm the exact payload.
- Find-device start uses command id `0x0000`, SET group, and payload `[count, side IDs...]` as in the existing app. Stop currently sends a zero target count (`[0]`), which is a cautious candidate inferred from the list encoding and is explicitly unverified on Nord Buds 3 firmware `110.110.100`.
- The app's classic RFCOMM control connection and Android A2DP/HFP audio route are independent. A connected control channel does not prove media audio is routed to the earbuds; the Overview warning reflects that distinction.


## Custom EQ transport separation

- RFCOMM command `0x0422` continues to use `buildCustomEqPayload()` and its existing profile-response round-trip test.
- GATT command `0x0418` has a separate `buildGattCustomEqPayload()` encoder for the observed field order: `p3, min, max, eqId, UTF-8 name length, name, band count, band records`.
- The GATT encoder is unit-tested but is **not sent to the earbuds yet**. The target service UUID, writable characteristic UUID, write mode, and packet wrapper/checksum must be verified from a real Nord Buds 3 / Nord Buds 3 Pro capture before enabling hardware writes. A payload unit test alone does not establish device compatibility.
- On connect, Budsy now reads the reported Noise Control state without automatically forcing ANC Off. This avoids silently overriding the user's existing listening preference.
