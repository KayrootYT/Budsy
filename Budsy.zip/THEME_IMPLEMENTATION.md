# Budsy — Four Theme UI Implementation

## Theme identities
- Aurora Glass: deep navy, electric blue accents, luminous glass panels.
- Crystal Light: pearl white, frosted panels, sky-blue accents.
- Nothing Matrix: AMOLED black, dot-matrix texture, signal-red accents and monospace typography.
- Titanium Luxury: graphite metallic panels, champagne-gold accents.

## App-wide integration
The theme mode is provided through a Compose CompositionLocal and is consumed by the shared background, grouped panels, feature tiles, reusable cards, and bottom navigation. This applies across Overview, Sound, Controls, Settings, and shared dialogs/components that use the design system. Selecting a theme also selects its reference appearance (Crystal=Light, Nothing=AMOLED, Aurora/Titanium=Dark). The appearance selector remains available as an override.

## Preserved implementation
Bluetooth connection and protocol implementation files were not edited for this UI pass. In particular, the BLE GATT and classic/RFCOMM transport source files remain in the project.

## Verification status
- ZIP integrity: verified after packaging.
- Source sanity checks: verified for the four theme IDs, Settings entries, global theme provider, and absence of retired theme constants.
- Android Gradle build / unit tests: NOT RUN in this environment. The project does not include `gradlew` / `gradle-wrapper.jar`, and a Gradle installation / Android SDK is not available here. Run the included GitHub Actions workflow to compile and test on an Android build runner.
