# Budsy Theme Engine

Files: `ThemeEngine.kt` (spec, parser), `ThemeStore.kt` (import/export/library, safe extraction), `Theme.kt` (palette, font loading, CompositionLocals),
`ThemeAssets.kt` (images, themed icons, card brush, motion speed), `ThemeManagerScreen.kt` (page), hooks in `Components.kt` and `MainActivity.kt`.

Flow: package -> ThemeStore.importPackage -> normalised `theme.properties` in `files/budsy_themes/<id>/` -> ThemeSpec -> BudsyTheme provides
LocalPal, LocalTypeSpec, LocalThemeSpec, LocalThemed, LocalReduceMotion -> every component reads them.
Stock Budsy = ThemeSpec.STOCK with `LocalThemed = false`, so stock rendering is unchanged.

Not yet verified: the Gradle build and the unit tests were not run in the environment that produced this change (no Android toolchain). Run a CI build before release.


## Theme Engine V2 implementation

`ThemeEngine.kt` now parses a safe `UiSpec` block for full-app layout tokens and per-screen renderer profiles. `Theme.kt` exposes the active UI spec through `LocalUiSpec`; `MainActivity.kt` exposes the active screen key. `Components.kt`, `ThemeAssets.kt`, and `Screens.kt` consume the theme for page rhythm, panel/tile styles, row sizing, header/navigation variants, dialog geometry, screen-specific overview/sound/control/settings variants, custom icon tinting, and background effects.

Schema 2 packages must declare `ui.complete=true`, complete palettes/layout selections, and all six app icon assets. Legacy schema 1 themes remain importable for compatibility. Packages remain data-only and cannot execute code. Bluetooth, BLE/GATT, RFCOMM, ANC, EQ and device protocol code are not modified by the theme engine.

Build verification is still required in Android Gradle CI. This source archive does not include a Gradle wrapper or Android SDK, so local APK compilation was not available during this edit.


## V3 renderer work (2026-11-03)

- Replaced icon chips with profile-specific animated icon containers (pixel/outlined/soft geometry, press squash, active pop, optional spatial idle motion).
- Rebuilt feature tiles as distinct horizontal console rows for Nothing/Sony/Titanium and editorial/glass poster tiles for Aurora/Crystal/Spatial, with animated active borders and touch feedback.
- Reworked cards, row surfaces, switches, button shapes, battery visuals, and settings rows by theme profile.
- Added theme-owned screen identity panels for Sound, Controls, and Settings; Sony/Spatial receive a moving spectrum visual.
- Controls actions now switch between full-width list/console layouts and grid layouts based on the theme's controlsLayout.
- Schema-2 imports retain the schema marker and reject incomplete packages, missing wallpaper/font, missing system icons, or missing five-state hero artwork.
- Existing Bluetooth/BLE/GATT/RFCOMM, ANC, EQ, and protocol source files were not edited.

Build status: source and package archives are ZIP-validated and Kotlin syntax diagnostics show no parser errors. A full Android Gradle build was not run because this environment has no Android SDK/Gradle installation; the repository workflow is configured to run `testDebugUnitTest assembleDebug` on GitHub Actions.
