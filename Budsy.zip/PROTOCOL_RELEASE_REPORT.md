# Budsy Protocol Laboratory — consolidated Phase 9–12 delivery

## Delivered in this archive
- Differential candidate import into the active model profile, preserving source capture and samples.
- Separate Nord Buds 3 / Nord Buds 3 Pro evidence profiles with OBSERVED/VERIFIED counts.
- Stronger verification workflow requiring two distinct positive capture references, negative-control attestation and a fresh note.
- Transmission safety gate that blocks missing evidence and missing BLE/GATT UUIDs.
- Manual-review-only outcome; no arbitrary packet replay or unverified GATT writes.
- Copyable per-profile release-readiness report.
- Capture checklist and regression tests for the new evidence and safety gates.

## Current evidence status
The seeded observations (0x0106, 0x0109, 0x010C, 0x010D and source-level 0x0418) remain in the Unassigned profile and remain OBSERVED. No device-specific hardware semantics are asserted by the archive. The custom EQ 0x0418 field layout is source-level reverse engineering only; target service/write characteristic UUID, wrapper/checksum and response behavior still need real captures.

## Validation boundary
- ZIP integrity: verified after packaging.
- Source consistency: reviewed with targeted checks.
- Android Gradle build and JUnit execution: not verified; this environment has no Gradle wrapper/executable, Android SDK or Kotlin compiler.
- Emulator/physical phone UI: not verified.
- Nord Buds 3 / Nord Buds 3 Pro hardware: not tested in this environment.

## Release status
**Engineering preview — not hardware-certified and not a verified APK release.** Use `DEVICE_CAPTURE_CHECKLIST.md` to gather the remaining model-specific evidence, then run the Android build/test/install-upgrade matrix in a configured Android environment.


## Final combined package note

Phases 9–12 are consolidated in `FINAL_DELIVERY.md` and `PROTOCOL_LAB.md`. This source package is an engineering preview. It does not claim hardware certification or a verified APK build. See `DEVICE_CAPTURE_CHECKLIST.md` for the remaining real-device evidence and release checks.
