# OnePlus Nord Buds 3 / Nord Buds 3 Pro — evidence capture checklist

Use one model profile at a time. Do not combine captures from different models or firmware versions.

## Capture setup
- [ ] Record exact retail model and firmware version shown by the companion app.
- [ ] Record Android phone model, Android version, Budsy build/version and companion-app version.
- [ ] Enable Android Developer options → Bluetooth HCI snoop log.
- [ ] Start from a known baseline: earbuds charged, case state noted, both buds seated/removed state recorded.
- [ ] Create a bug report after each controlled experiment and extract the btsnoop log.
- [ ] Import each capture separately; preserve original files with date/time and action names.

## Controlled experiments (one variable at a time)
- [ ] Idle baseline: no control changes for 30–60 seconds.
- [ ] Battery: open case / close case / remove left / reseat left / remove right / reseat right.
- [ ] Noise control: Off → ANC → Transparency → Off, waiting for each state to settle.
- [ ] Game/low-latency mode: Off → On → Off.
- [ ] Touch controls: perform one known gesture on one side only.
- [ ] EQ: select one preset, then change one manual band only if the official app exposes it.
- [ ] Find earbuds: trigger once, note audible/visual response and stop it.
- [ ] Negative control: repeat the same capture window without changing the target setting.

## Evidence quality
- [ ] Two distinct positive captures show the same candidate signal for the same action.
- [ ] Negative-control capture does not show the same state transition.
- [ ] Compare direction, command/ATT opcode, handle, UUID, payload, timing and repeatability.
- [ ] Keep ATT handles and UUIDs tied to the same connection/session; handles can change after reconnect or firmware changes.
- [ ] Mark semantics VERIFIED only after reviewing original raw captures and documenting the test.
- [ ] Never infer a 0% case battery from an unknown/zero placeholder without a verified status field.

## GATT write prerequisites
- [ ] Confirm service UUID from target-device discovery.
- [ ] Confirm characteristic UUID and write/write-without-response properties.
- [ ] Confirm security/encryption requirements and MTU/fragmentation behavior.
- [ ] Confirm vendor frame wrapper, length, checksum and sequence rules.
- [ ] Confirm response/ACK and error semantics with a safe, reversible operation.
- [ ] Keep firmware update and irreversible operations out of exploratory replay.

## Release checklist
- [ ] Build `assembleDebug` and `testDebugUnitTest` in a configured Android environment.
- [ ] Install cleanly on a test phone.
- [ ] Upgrade over the previous Budsy build without uninstalling; confirm application ID/signing continuity.
- [ ] Test each feature on real Nord Buds 3 hardware.
- [ ] Repeat separately on real Nord Buds 3 Pro hardware.
- [ ] Export command database and final readiness report; attach capture references.
