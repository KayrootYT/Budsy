# Device hero animation state behavior

- When Buds reports disconnected, the hero art shows the charging case only.
- When connected, it shows left and right earbuds with soft cyan rim glow and a brighter case indicator.
- The current Buds state model does not expose a verified charging-case lid/open state or per-earbud-in-case presence signal. The UI intentionally does not pretend to know those positions. Once the protocol returns a reliable lid/presence state, extend `DeviceHeroArt` with an explicit state enum for `CASE_CLOSED`, `CASE_OPEN_WITH_BUDS`, `BUDS_OUT`, and `UNKNOWN`.
- The artwork is drawn with Compose Canvas and a small number of gradients/shapes to avoid a heavy real-time 3D rendering loop.
