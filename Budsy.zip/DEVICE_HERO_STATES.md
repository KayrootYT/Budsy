# Device hero states

The home-screen hero shows one of five states (plus Unknown/Unverified). Bluetooth connection, case-lid
state and per-bud position are **separate inputs** (`HeroInput`) resolved by `HeroResolver` (HeroState.kt).

| # | State | Required (all confirmed) |
|---|-------|--------------------------|
| 1 | Case closed | lid = CLOSED, **or** Bluetooth disconnected (presentation only) |
| 2 | Open, both inside | lid OPEN, left INSIDE, right INSIDE |
| 3 | Left bud outside | lid OPEN, left OUTSIDE, right INSIDE |
| 4 | Right bud outside | lid OPEN, left INSIDE, right OUTSIDE |
| 5 | Both outside | lid OPEN, left OUTSIDE, right OUTSIDE |

Rules: positions are never inferred from Bluetooth; the lid is never inferred from disconnection; any unknown
required value gives **Unverified**; lid CLOSED with a bud OUTSIDE is flagged as conflicting data; events are
debounced (a new state must stay stable 450 ms; A→B→A does not flicker); transitions animate lid and each bud
independently; no battery values or events are invented. Every hero shows a provenance caption
(VERIFIED / PRESENTATION / PREVIEW / UNVERIFIED).

## Protocol limitation (important)

The reverse-engineered protocol (see PROTOCOL.md) has **no case-lid message**. Command `0x0109` / push `0x04,2`
returns per-bud wear flags only. Consequently:

- `Buds.lidState` is always `UNKNOWN`, so **states 2–5 can never be reported as verified hardware states** today.
- While connected with bud positions reported, the hero shows the matching bud arrangement as **ESTIMATED** (dashed outline + caption: lid not reported). It is never labelled verified.
- While connected with no bud data yet, the hero shows **Unverified**.
- While disconnected the closed case is shown as a **presentation**, not a lid claim.
- The wear-flag bit mapping (bit0 = out of case, bit1 = in ear) is itself unverified on real firmware.
- The previous behaviour (treating "not worn" flags as "in case" and rendering an open case) was removed because
  it asserted a lid state the device never reported.
- If a firmware capture reveals a lid signal, set `Buds.lidState` from it; the resolver, art and tests already handle OPEN/CLOSED.

## Debug preview

Settings → enable Diagnostics → **Hero preview (debug)**. Pick any of the five states or Unknown; choose "Live"
to return to device data. Preview is labelled PREVIEW and is never presented as detected.
