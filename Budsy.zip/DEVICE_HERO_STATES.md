# Device hero state behavior

- Disconnected: renders only the closed charging case.
- Connected and both earbud wear flags report in-case: renders the open case with both smaller buds nested inside, with lid and case lighting animation.
- Connected and buds are reported outside: renders only left and right earbuds; the charging case is hidden.
- If wear flags are unknown, defaults to connected buds-out view rather than inventing in-case status.
- Artwork uses lightweight Compose Canvas gradients/shapes and existing low-cost pulse animation; no continuous heavy 3D renderer.
