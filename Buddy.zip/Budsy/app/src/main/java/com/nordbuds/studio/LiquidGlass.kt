package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.remember
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Liquid Glass design language for the built-in Stock theme: frosted translucent surfaces with a bright rim,
// a soft top sheen and a drifting blue "silk" background drawn from vector paths (SVG-style, resolution independent).
// Imported themes keep using their own card styles; everything here is only used for the stock look.

/** True when the built-in (non-imported) look is active. */
@Composable
fun isLiquid(): Boolean = !LocalThemed.current && LocalThemeMode.current == ThemeMode.STOCK

/** iOS grouped-card fill (opaque, no gradient). */
@Composable
fun glassFill(strong: Boolean = false): Brush = SolidColor(P.tile)

/** iOS hairline edge. */
@Composable
fun glassRim(): Brush = SolidColor(if (P.dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.06f))

/** iOS grouped card: opaque fill, hairline edge, very light shadow in light mode only. [active] switches the edge to the accent. */
@Composable
fun Modifier.glassSurface(radius: Dp, active: Boolean = false, strong: Boolean = false, shadow: Boolean = true): Modifier {
    val shape = RoundedCornerShape(radius)
    val dark = P.dark
    val accent = P.accent
    val fill = glassFill(strong)
    val rim: Brush = if (active) SolidColor(accent) else glassRim()
    return this
        .then(
            if (shadow && !dark) Modifier.drawBehind {
                val r = radius.toPx()
                for (i in 1..3) {
                    val g = i * 2.dp.toPx()
                    drawRoundRect(
                        color = Color(0xFF1B2A4A).copy(alpha = 0.035f * (4 - i) / 3f),
                        topLeft = Offset(-g, -g + 3.dp.toPx()),
                        size = Size(size.width + g * 2f, size.height + g * 2f),
                        cornerRadius = CornerRadius(r + g, r + g),
                        style = Stroke(2.dp.toPx())
                    )
                }
            } else Modifier
        )
        .clip(shape)
        .background(fill)
        .border(if (active) 1.5.dp else 0.5.dp, rim, shape)
}

/** Panel / row title with a glowing accent icon and an optional trailing control (switch, button…). */
@Composable
fun PanelHeader(title: String, icon: ImageVector, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IosChip(icon, P.accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Txt(title, 17, FontWeight.SemiBold, P.text, Modifier.weight(1f), maxLines = 1)
        if (trailing != null) trailing()
    }
}

/** Circled number used as the icon of the Custom EQ slot tiles. */
@Composable
fun NumberRing(n: Int, tint: Color, size: Dp = 26.dp) {
    Box(Modifier.size(size).border(1.8.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
        Txt(n.toString(), 14, FontWeight.SemiBold, tint, maxLines = 1)
    }
}

/** iOS Settings-style icon chip: continuous-corner squircle, vertical colour gradient, white glyph. */
@Composable
fun IosChip(icon: ImageVector, color: Color, box: Dp = 30.dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(box * 0.225f)
    Box(
        modifier.size(box).clip(shape).background(Brush.verticalGradient(listOf(color.copy(alpha = 0.82f).compositeOverWhite(), color))),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(box * 0.62f)) }
}

private fun Color.compositeOverWhite(): Color = this.compositeOver(Color.White)

/**
 * Header app mark. If the app ships its own logo file (res/drawable-nodpi/oneplus_logo.png / .webp, supplied by the
 * owner of that brand) it is shown as-is; otherwise a neutral iOS-style Budsy icon is drawn.
 */
@Composable
fun BudsyMark(modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(ctx) { ctx.resources.getIdentifier("oneplus_logo", "drawable", ctx.packageName) }
    val shape = RoundedCornerShape(9.dp)
    if (res != 0) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), null,
            modifier.size(40.dp).clip(shape), contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else IosChip(Icons.Rounded.Headphones, P.accent, 40.dp, modifier)
}

/** Plain iOS grouped background: no wallpaper, no gradients. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(P.bg))
}
